/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 3651
(module, __unused_webpack_exports, __webpack_require__) {


if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
    throw new Error("This script should only be loaded in a browser extension.");
}
if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
    const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
    const ERROR_TO_IGNORE = `A listener indicated an asynchronous response by returning true, but the message channel closed before a response was received`;
    const wrapAPIs = extensionAPIs => {
        const apiMetadata = __webpack_require__(2058);
        if (Object.keys(apiMetadata).length === 0) {
            throw new Error("api-metadata.json has not been included in browser-polyfill");
        }
        class DefaultWeakMap extends WeakMap {
            constructor(createItem, items = undefined) {
                super(items);
                this.createItem = createItem;
            }
            get(key) {
                if (!this.has(key)) {
                    this.set(key, this.createItem(key));
                }
                return super.get(key);
            }
        }
        const isThenable = value => {
            return value && typeof value === "object" && typeof value.then === "function";
        };
        const makeCallback = (promise, metadata) => {
            let error = new Error();
            return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                    error.message = extensionAPIs.runtime.lastError.message;
                    promise.reject(error);
                }
                else if (metadata.singleCallbackArg ||
                    (callbackArgs.length <= 1 && metadata.singleCallbackArg !== false)) {
                    promise.resolve(callbackArgs[0]);
                }
                else {
                    promise.resolve(callbackArgs);
                }
            };
        };
        const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
        const wrapAsyncFunction = (name, metadata) => {
            return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                    throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                    throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                    if (metadata.fallbackToNoCallback) {
                        try {
                            target[name](...args, makeCallback({ resolve, reject }, metadata));
                        }
                        catch (cbError) {
                            console.warn(`${name} API method doesn't seem to support the callback parameter, ` +
                                "falling back to call it without a callback: ", cbError);
                            target[name](...args);
                            metadata.fallbackToNoCallback = false;
                            metadata.noCallback = true;
                            resolve();
                        }
                    }
                    else if (metadata.noCallback) {
                        target[name](...args);
                        resolve();
                    }
                    else {
                        target[name](...args, makeCallback({ resolve, reject }, metadata));
                    }
                });
            };
        };
        const wrapMethod = (target, method, wrapper) => {
            return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                    return wrapper.call(thisObj, target, ...args);
                },
            });
        };
        let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
        const wrapObject = (target, wrappers = {}, metadata = {}) => {
            let cache = Object.create(null);
            let handlers = {
                has(proxyTarget, prop) {
                    return prop in target || prop in cache;
                },
                get(proxyTarget, prop, receiver) {
                    if (prop in cache) {
                        return cache[prop];
                    }
                    if (!(prop in target)) {
                        return undefined;
                    }
                    let value = target[prop];
                    if (typeof value === "function") {
                        if (typeof wrappers[prop] === "function") {
                            value = wrapMethod(target, target[prop], wrappers[prop]);
                        }
                        else if (hasOwnProperty(metadata, prop)) {
                            let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                            value = wrapMethod(target, target[prop], wrapper);
                        }
                        else {
                            value = value.bind(target);
                        }
                    }
                    else if (typeof value === "object" && value !== null &&
                        (hasOwnProperty(wrappers, prop) ||
                            hasOwnProperty(metadata, prop))) {
                        value = wrapObject(value, wrappers[prop], metadata[prop]);
                    }
                    else if (hasOwnProperty(metadata, "*")) {
                        value = wrapObject(value, wrappers[prop], metadata["*"]);
                    }
                    else {
                        Object.defineProperty(cache, prop, {
                            configurable: true,
                            enumerable: true,
                            get() {
                                return target[prop];
                            },
                            set(value) {
                                target[prop] = value;
                            },
                        });
                        return value;
                    }
                    cache[prop] = value;
                    return value;
                },
                set(proxyTarget, prop, value, receiver) {
                    if (prop in cache) {
                        cache[prop] = value;
                    }
                    else {
                        target[prop] = value;
                    }
                    return true;
                },
                defineProperty(proxyTarget, prop, desc) {
                    return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget, prop) {
                    return Reflect.deleteProperty(cache, prop);
                },
            };
            let proxyTarget = Object.create(target);
            return new Proxy(proxyTarget, handlers);
        };
        const wrapEvent = wrapperMap => ({
            addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
            },
            hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
            },
            removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
            },
        });
        const onRequestFinishedWrappers = new DefaultWeakMap(listener => {
            if (typeof listener !== "function") {
                return listener;
            }
            return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                    getContent: {
                        minArgs: 0,
                        maxArgs: 0,
                    },
                });
                listener(wrappedReq);
            };
        });
        const onMessageWrappers = new DefaultWeakMap(listener => {
            if (typeof listener !== "function") {
                return listener;
            }
            return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise(resolve => {
                    wrappedSendResponse = function (response) {
                        didCallSendResponse = true;
                        resolve(response);
                    };
                });
                let result;
                try {
                    result = listener(message, sender, wrappedSendResponse);
                }
                catch (err) {
                    result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                    return false;
                }
                const sendPromisedResult = (promise) => {
                    promise.then(msg => {
                        sendResponse(msg);
                    }, error => {
                        let message;
                        if (error && (error instanceof Error ||
                            typeof error.message === "string")) {
                            message = error.message;
                        }
                        else {
                            message = "An unexpected error occurred";
                        }
                        sendResponse({
                            __mozWebExtensionPolyfillReject__: true,
                            message,
                        });
                    }).catch(err => {
                        console.error("Failed to send onMessage rejected reply", err);
                    });
                };
                if (isResultThenable) {
                    sendPromisedResult(result);
                }
                else {
                    sendPromisedResult(sendResponsePromise);
                }
                return true;
            };
        });
        const wrappedSendMessageCallback = ({ reject, resolve }, reply) => {
            if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE || extensionAPIs.runtime.lastError.message.includes(ERROR_TO_IGNORE)) {
                    resolve();
                }
                else {
                    reject(new Error(extensionAPIs.runtime.lastError.message));
                }
            }
            else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
            }
            else {
                resolve(reply);
            }
        };
        const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
            if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
            }
            if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
            }
            return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, { resolve, reject });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
            });
        };
        const staticWrappers = {
            devtools: {
                network: {
                    onRequestFinished: wrapEvent(onRequestFinishedWrappers),
                },
            },
            runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", { minArgs: 1, maxArgs: 3 }),
            },
            tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", { minArgs: 2, maxArgs: 3 }),
            },
        };
        const settingMetadata = {
            clear: { minArgs: 1, maxArgs: 1 },
            get: { minArgs: 1, maxArgs: 1 },
            set: { minArgs: 1, maxArgs: 1 },
        };
        apiMetadata.privacy = {
            network: { "*": settingMetadata },
            services: { "*": settingMetadata },
            websites: { "*": settingMetadata },
        };
        return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
    };
    module.exports = wrapAPIs(chrome);
}
else {
    module.exports = globalThis.browser;
}


/***/ },

/***/ 1287
(module) {


module.exports = function (cssWithMappingToString) {
    var list = [];
    list.toString = function toString() {
        return this.map(function (item) {
            var content = "";
            var needLayer = typeof item[5] !== "undefined";
            if (item[4]) {
                content += "@supports (".concat(item[4], ") {");
            }
            if (item[2]) {
                content += "@media ".concat(item[2], " {");
            }
            if (needLayer) {
                content += "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {");
            }
            content += cssWithMappingToString(item);
            if (needLayer) {
                content += "}";
            }
            if (item[2]) {
                content += "}";
            }
            if (item[4]) {
                content += "}";
            }
            return content;
        }).join("");
    };
    list.i = function i(modules, media, dedupe, supports, layer) {
        if (typeof modules === "string") {
            modules = [[null, modules, undefined]];
        }
        var alreadyImportedModules = {};
        if (dedupe) {
            for (var k = 0; k < this.length; k++) {
                var id = this[k][0];
                if (id != null) {
                    alreadyImportedModules[id] = true;
                }
            }
        }
        for (var _k = 0; _k < modules.length; _k++) {
            var item = [].concat(modules[_k]);
            if (dedupe && alreadyImportedModules[item[0]]) {
                continue;
            }
            if (typeof layer !== "undefined") {
                if (typeof item[5] === "undefined") {
                    item[5] = layer;
                }
                else {
                    item[1] = "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {").concat(item[1], "}");
                    item[5] = layer;
                }
            }
            if (media) {
                if (!item[2]) {
                    item[2] = media;
                }
                else {
                    item[1] = "@media ".concat(item[2], " {").concat(item[1], "}");
                    item[2] = media;
                }
            }
            if (supports) {
                if (!item[4]) {
                    item[4] = "".concat(supports);
                }
                else {
                    item[1] = "@supports (".concat(item[4], ") {").concat(item[1], "}");
                    item[4] = supports;
                }
            }
            list.push(item);
        }
    };
    return list;
};


/***/ },

/***/ 2929
(module) {


module.exports = function (item) {
    var content = item[1];
    var cssMapping = item[3];
    if (!cssMapping) {
        return content;
    }
    if (typeof btoa === "function") {
        var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(cssMapping))));
        var data = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(base64);
        var sourceMapping = "/*# ".concat(data, " */");
        return [content].concat([sourceMapping]).join("\n");
    }
    return [content].join("\n");
};


/***/ },

/***/ 9033
(module, __unused_webpack___webpack_exports__, __webpack_require__) {


;// ../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js
var injectStylesIntoStyleTag_namespaceObject = /*#__PURE__*/__webpack_require__.cjs(function(module, exports) {


var stylesInDOM = [];
function getIndexByIdentifier(identifier) {
  var result = -1;
  for (var i = 0; i < stylesInDOM.length; i++) {
    if (stylesInDOM[i].identifier === identifier) {
      result = i;
      break;
    }
  }
  return result;
}
function modulesToDom(list, options) {
  var idCountMap = {};
  var identifiers = [];
  for (var i = 0; i < list.length; i++) {
    var item = list[i];
    var id = options.base ? item[0] + options.base : item[0];
    var count = idCountMap[id] || 0;
    var identifier = "".concat(id, " ").concat(count);
    idCountMap[id] = count + 1;
    var indexByIdentifier = getIndexByIdentifier(identifier);
    var obj = {
      css: item[1],
      media: item[2],
      sourceMap: item[3],
      supports: item[4],
      layer: item[5]
    };
    if (indexByIdentifier !== -1) {
      stylesInDOM[indexByIdentifier].references++;
      stylesInDOM[indexByIdentifier].updater(obj);
    } else {
      var updater = addElementStyle(obj, options);
      options.byIndex = i;
      stylesInDOM.splice(i, 0, {
        identifier: identifier,
        updater: updater,
        references: 1
      });
    }
    identifiers.push(identifier);
  }
  return identifiers;
}
function addElementStyle(obj, options) {
  var api = options.domAPI(options);
  api.update(obj);
  var updater = function updater(newObj) {
    if (newObj) {
      if (newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap && newObj.supports === obj.supports && newObj.layer === obj.layer) {
        return;
      }
      api.update(obj = newObj);
    } else {
      api.remove();
    }
  };
  return updater;
}
module.exports = function (list, options) {
  options = options || {};
  list = list || [];
  var lastIdentifiers = modulesToDom(list, options);
  return function update(newList) {
    newList = newList || [];
    for (var i = 0; i < lastIdentifiers.length; i++) {
      var identifier = lastIdentifiers[i];
      var index = getIndexByIdentifier(identifier);
      stylesInDOM[index].references--;
    }
    var newLastIdentifiers = modulesToDom(newList, options);
    for (var _i = 0; _i < lastIdentifiers.length; _i++) {
      var _identifier = lastIdentifiers[_i];
      var _index = getIndexByIdentifier(_identifier);
      if (stylesInDOM[_index].references === 0) {
        stylesInDOM[_index].updater();
        stylesInDOM.splice(_index, 1);
      }
    }
    lastIdentifiers = newLastIdentifiers;
  };
};
});

var injectStylesIntoStyleTag_default = /*#__PURE__*/__webpack_require__.n(injectStylesIntoStyleTag_namespaceObject);
;// ../../node_modules/style-loader/dist/runtime/styleDomAPI.js
var styleDomAPI_namespaceObject = /*#__PURE__*/__webpack_require__.cjs(function(module, exports) {


/* istanbul ignore next  */
function apply(styleElement, options, obj) {
  var css = "";
  if (obj.supports) {
    css += "@supports (".concat(obj.supports, ") {");
  }
  if (obj.media) {
    css += "@media ".concat(obj.media, " {");
  }
  var needLayer = typeof obj.layer !== "undefined";
  if (needLayer) {
    css += "@layer".concat(obj.layer.length > 0 ? " ".concat(obj.layer) : "", " {");
  }
  css += obj.css;
  if (needLayer) {
    css += "}";
  }
  if (obj.media) {
    css += "}";
  }
  if (obj.supports) {
    css += "}";
  }
  var sourceMap = obj.sourceMap;
  if (sourceMap && typeof btoa !== "undefined") {
    css += "\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))), " */");
  }

  // For old IE
  /* istanbul ignore if  */
  options.styleTagTransform(css, styleElement, options.options);
}
function removeStyleElement(styleElement) {
  // istanbul ignore if
  if (styleElement.parentNode === null) {
    return false;
  }
  styleElement.parentNode.removeChild(styleElement);
}

/* istanbul ignore next  */
function domAPI(options) {
  if (typeof document === "undefined") {
    return {
      update: function update() {},
      remove: function remove() {}
    };
  }
  var styleElement = options.insertStyleElement(options);
  return {
    update: function update(obj) {
      apply(styleElement, options, obj);
    },
    remove: function remove() {
      removeStyleElement(styleElement);
    }
  };
}
module.exports = domAPI;
});

var styleDomAPI_default = /*#__PURE__*/__webpack_require__.n(styleDomAPI_namespaceObject);
;// ../../node_modules/style-loader/dist/runtime/insertBySelector.js
var insertBySelector_namespaceObject = /*#__PURE__*/__webpack_require__.cjs(function(module, exports) {


var memo = {};

/* istanbul ignore next  */
function getTarget(target) {
  if (typeof memo[target] === "undefined") {
    var styleTarget = document.querySelector(target);

    // Special case to return head of iframe instead of iframe itself
    if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
      try {
        // This will throw an exception if access to iframe is blocked
        // due to cross-origin restrictions
        styleTarget = styleTarget.contentDocument.head;
      } catch (e) {
        // istanbul ignore next
        styleTarget = null;
      }
    }
    memo[target] = styleTarget;
  }
  return memo[target];
}

/* istanbul ignore next  */
function insertBySelector(insert, style) {
  var target = getTarget(insert);
  if (!target) {
    throw new Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");
  }
  target.appendChild(style);
}
module.exports = insertBySelector;
});

var insertBySelector_default = /*#__PURE__*/__webpack_require__.n(insertBySelector_namespaceObject);
;// ../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js
var setAttributesWithoutAttributes_namespaceObject = /*#__PURE__*/__webpack_require__.cjs(function(module, exports) {


/* istanbul ignore next  */
function setAttributesWithoutAttributes(styleElement) {
  var nonce =  true ? __webpack_require__.nc : 0;
  if (nonce) {
    styleElement.setAttribute("nonce", nonce);
  }
}
module.exports = setAttributesWithoutAttributes;
});

var setAttributesWithoutAttributes_default = /*#__PURE__*/__webpack_require__.n(setAttributesWithoutAttributes_namespaceObject);
;// ../../node_modules/style-loader/dist/runtime/insertStyleElement.js
var insertStyleElement_namespaceObject = /*#__PURE__*/__webpack_require__.cjs(function(module, exports) {


/* istanbul ignore next  */
function insertStyleElement(options) {
  var element = document.createElement("style");
  options.setAttributes(element, options.attributes);
  options.insert(element, options.options);
  return element;
}
module.exports = insertStyleElement;
});

var insertStyleElement_default = /*#__PURE__*/__webpack_require__.n(insertStyleElement_namespaceObject);
;// ../../node_modules/style-loader/dist/runtime/styleTagTransform.js
var styleTagTransform_namespaceObject = /*#__PURE__*/__webpack_require__.cjs(function(module, exports) {


/* istanbul ignore next  */
function styleTagTransform(css, styleElement) {
  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = css;
  } else {
    while (styleElement.firstChild) {
      styleElement.removeChild(styleElement.firstChild);
    }
    styleElement.appendChild(document.createTextNode(css));
  }
}
module.exports = styleTagTransform;
});

var styleTagTransform_default = /*#__PURE__*/__webpack_require__.n(styleTagTransform_namespaceObject);
// EXTERNAL MODULE: ./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].use[1]!../../node_modules/postcss-loader/dist/cjs.js!./assets/styles/globals.css
var globals = __webpack_require__(1046);
;// ./assets/styles/globals.css

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (styleTagTransform_default());
options.setAttributes = (setAttributesWithoutAttributes_default());

      options.insert = insertBySelector_default().bind(null, "head");
    
options.domAPI = (styleDomAPI_default());
options.insertStyleElement = (insertStyleElement_default());

var update = injectStylesIntoStyleTag_default()(globals/* default */.A, options);




       /* harmony default export */ const styles_globals = (globals/* default */.A && globals/* default */.A.locals ? globals/* default */.A.locals : undefined);

// EXTERNAL MODULE: ./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].use[1]!../../node_modules/postcss-loader/dist/cjs.js!./src/desktop-options/ui/unsupported-browser-banner.css
var unsupported_browser_banner = __webpack_require__(1276);
;// ./src/desktop-options/ui/unsupported-browser-banner.css

      
      
      
      
      
      
      
      
      

var unsupported_browser_banner_options = {};

unsupported_browser_banner_options.styleTagTransform = (styleTagTransform_default());
unsupported_browser_banner_options.setAttributes = (setAttributesWithoutAttributes_default());

      unsupported_browser_banner_options.insert = insertBySelector_default().bind(null, "head");
    
unsupported_browser_banner_options.domAPI = (styleDomAPI_default());
unsupported_browser_banner_options.insertStyleElement = (insertStyleElement_default());

var unsupported_browser_banner_update = injectStylesIntoStyleTag_default()(unsupported_browser_banner/* default */.A, unsupported_browser_banner_options);




       /* harmony default export */ const ui_unsupported_browser_banner = (unsupported_browser_banner/* default */.A && unsupported_browser_banner/* default */.A.locals ? unsupported_browser_banner/* default */.A.locals : undefined);

;// ../../node_modules/@eyeo/webext-ad-filtering-solution/dist/ewe-ui.js
var ewe_ui_namespaceObject = /*#__PURE__*/__webpack_require__.cjs(function(module, exports) {

(function webpackUniversalModuleDefinition(root, factory) {
    if (true)
        module.exports = factory();
    else // removed by dead control flow
{}
})(self, () => {
    return (() => {
        "use strict";
        var __webpack_modules__ = ({
            7795(module, __unused_webpack_exports, __nested_webpack_require_530__) {
                if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
                    throw new Error("This script should only be loaded in a browser extension.");
                }
                if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
                    const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
                    const ERROR_TO_IGNORE = `A listener indicated an asynchronous response by returning true, but the message channel closed before a response was received`;
                    const wrapAPIs = extensionAPIs => {
                        const apiMetadata = __nested_webpack_require_530__(9438);
                        if (Object.keys(apiMetadata).length === 0) {
                            throw new Error("api-metadata.json has not been included in browser-polyfill");
                        }
                        class DefaultWeakMap extends WeakMap {
                            constructor(createItem, items = undefined) {
                                super(items);
                                this.createItem = createItem;
                            }
                            get(key) {
                                if (!this.has(key)) {
                                    this.set(key, this.createItem(key));
                                }
                                return super.get(key);
                            }
                        }
                        const isThenable = value => {
                            return value && typeof value === "object" && typeof value.then === "function";
                        };
                        const makeCallback = (promise, metadata) => {
                            let error = new Error();
                            return (...callbackArgs) => {
                                if (extensionAPIs.runtime.lastError) {
                                    error.message = extensionAPIs.runtime.lastError.message;
                                    promise.reject(error);
                                }
                                else if (metadata.singleCallbackArg ||
                                    (callbackArgs.length <= 1 && metadata.singleCallbackArg !== false)) {
                                    promise.resolve(callbackArgs[0]);
                                }
                                else {
                                    promise.resolve(callbackArgs);
                                }
                            };
                        };
                        const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
                        const wrapAsyncFunction = (name, metadata) => {
                            return function asyncFunctionWrapper(target, ...args) {
                                if (args.length < metadata.minArgs) {
                                    throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                                }
                                if (args.length > metadata.maxArgs) {
                                    throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                                }
                                return new Promise((resolve, reject) => {
                                    if (metadata.fallbackToNoCallback) {
                                        try {
                                            target[name](...args, makeCallback({ resolve, reject }, metadata));
                                        }
                                        catch (cbError) {
                                            console.warn(`${name} API method doesn't seem to support the callback parameter, ` +
                                                "falling back to call it without a callback: ", cbError);
                                            target[name](...args);
                                            metadata.fallbackToNoCallback = false;
                                            metadata.noCallback = true;
                                            resolve();
                                        }
                                    }
                                    else if (metadata.noCallback) {
                                        target[name](...args);
                                        resolve();
                                    }
                                    else {
                                        target[name](...args, makeCallback({ resolve, reject }, metadata));
                                    }
                                });
                            };
                        };
                        const wrapMethod = (target, method, wrapper) => {
                            return new Proxy(method, {
                                apply(targetMethod, thisObj, args) {
                                    return wrapper.call(thisObj, target, ...args);
                                },
                            });
                        };
                        let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
                        const wrapObject = (target, wrappers = {}, metadata = {}) => {
                            let cache = Object.create(null);
                            let handlers = {
                                has(proxyTarget, prop) {
                                    return prop in target || prop in cache;
                                },
                                get(proxyTarget, prop, receiver) {
                                    if (prop in cache) {
                                        return cache[prop];
                                    }
                                    if (!(prop in target)) {
                                        return undefined;
                                    }
                                    let value = target[prop];
                                    if (typeof value === "function") {
                                        if (typeof wrappers[prop] === "function") {
                                            value = wrapMethod(target, target[prop], wrappers[prop]);
                                        }
                                        else if (hasOwnProperty(metadata, prop)) {
                                            let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                                            value = wrapMethod(target, target[prop], wrapper);
                                        }
                                        else {
                                            value = value.bind(target);
                                        }
                                    }
                                    else if (typeof value === "object" && value !== null &&
                                        (hasOwnProperty(wrappers, prop) ||
                                            hasOwnProperty(metadata, prop))) {
                                        value = wrapObject(value, wrappers[prop], metadata[prop]);
                                    }
                                    else if (hasOwnProperty(metadata, "*")) {
                                        value = wrapObject(value, wrappers[prop], metadata["*"]);
                                    }
                                    else {
                                        Object.defineProperty(cache, prop, {
                                            configurable: true,
                                            enumerable: true,
                                            get() {
                                                return target[prop];
                                            },
                                            set(value) {
                                                target[prop] = value;
                                            },
                                        });
                                        return value;
                                    }
                                    cache[prop] = value;
                                    return value;
                                },
                                set(proxyTarget, prop, value, receiver) {
                                    if (prop in cache) {
                                        cache[prop] = value;
                                    }
                                    else {
                                        target[prop] = value;
                                    }
                                    return true;
                                },
                                defineProperty(proxyTarget, prop, desc) {
                                    return Reflect.defineProperty(cache, prop, desc);
                                },
                                deleteProperty(proxyTarget, prop) {
                                    return Reflect.deleteProperty(cache, prop);
                                },
                            };
                            let proxyTarget = Object.create(target);
                            return new Proxy(proxyTarget, handlers);
                        };
                        const wrapEvent = wrapperMap => ({
                            addListener(target, listener, ...args) {
                                target.addListener(wrapperMap.get(listener), ...args);
                            },
                            hasListener(target, listener) {
                                return target.hasListener(wrapperMap.get(listener));
                            },
                            removeListener(target, listener) {
                                target.removeListener(wrapperMap.get(listener));
                            },
                        });
                        const onRequestFinishedWrappers = new DefaultWeakMap(listener => {
                            if (typeof listener !== "function") {
                                return listener;
                            }
                            return function onRequestFinished(req) {
                                const wrappedReq = wrapObject(req, {}, {
                                    getContent: {
                                        minArgs: 0,
                                        maxArgs: 0,
                                    },
                                });
                                listener(wrappedReq);
                            };
                        });
                        const onMessageWrappers = new DefaultWeakMap(listener => {
                            if (typeof listener !== "function") {
                                return listener;
                            }
                            return function onMessage(message, sender, sendResponse) {
                                let didCallSendResponse = false;
                                let wrappedSendResponse;
                                let sendResponsePromise = new Promise(resolve => {
                                    wrappedSendResponse = function (response) {
                                        didCallSendResponse = true;
                                        resolve(response);
                                    };
                                });
                                let result;
                                try {
                                    result = listener(message, sender, wrappedSendResponse);
                                }
                                catch (err) {
                                    result = Promise.reject(err);
                                }
                                const isResultThenable = result !== true && isThenable(result);
                                if (result !== true && !isResultThenable && !didCallSendResponse) {
                                    return false;
                                }
                                const sendPromisedResult = (promise) => {
                                    promise.then(msg => {
                                        sendResponse(msg);
                                    }, error => {
                                        let message;
                                        if (error && (error instanceof Error ||
                                            typeof error.message === "string")) {
                                            message = error.message;
                                        }
                                        else {
                                            message = "An unexpected error occurred";
                                        }
                                        sendResponse({
                                            __mozWebExtensionPolyfillReject__: true,
                                            message,
                                        });
                                    }).catch(err => {
                                        console.error("Failed to send onMessage rejected reply", err);
                                    });
                                };
                                if (isResultThenable) {
                                    sendPromisedResult(result);
                                }
                                else {
                                    sendPromisedResult(sendResponsePromise);
                                }
                                return true;
                            };
                        });
                        const wrappedSendMessageCallback = ({ reject, resolve }, reply) => {
                            if (extensionAPIs.runtime.lastError) {
                                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE || extensionAPIs.runtime.lastError.message.includes(ERROR_TO_IGNORE)) {
                                    resolve();
                                }
                                else {
                                    reject(new Error(extensionAPIs.runtime.lastError.message));
                                }
                            }
                            else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                                reject(new Error(reply.message));
                            }
                            else {
                                resolve(reply);
                            }
                        };
                        const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
                            if (args.length < metadata.minArgs) {
                                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                            }
                            if (args.length > metadata.maxArgs) {
                                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                            }
                            return new Promise((resolve, reject) => {
                                const wrappedCb = wrappedSendMessageCallback.bind(null, { resolve, reject });
                                args.push(wrappedCb);
                                apiNamespaceObj.sendMessage(...args);
                            });
                        };
                        const staticWrappers = {
                            devtools: {
                                network: {
                                    onRequestFinished: wrapEvent(onRequestFinishedWrappers),
                                },
                            },
                            runtime: {
                                onMessage: wrapEvent(onMessageWrappers),
                                onMessageExternal: wrapEvent(onMessageWrappers),
                                sendMessage: wrappedSendMessage.bind(null, "sendMessage", { minArgs: 1, maxArgs: 3 }),
                            },
                            tabs: {
                                sendMessage: wrappedSendMessage.bind(null, "sendMessage", { minArgs: 2, maxArgs: 3 }),
                            },
                        };
                        const settingMetadata = {
                            clear: { minArgs: 1, maxArgs: 1 },
                            get: { minArgs: 1, maxArgs: 1 },
                            set: { minArgs: 1, maxArgs: 1 },
                        };
                        apiMetadata.privacy = {
                            network: { "*": settingMetadata },
                            services: { "*": settingMetadata },
                            websites: { "*": settingMetadata },
                        };
                        return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
                    };
                    module.exports = wrapAPIs(chrome);
                }
                else {
                    module.exports = globalThis.browser;
                }
            },
            9438(module) {
                module.exports = JSON.parse('{"alarms":{"clear":{"minArgs":0,"maxArgs":1},"clearAll":{"minArgs":0,"maxArgs":0},"get":{"minArgs":0,"maxArgs":1},"getAll":{"minArgs":0,"maxArgs":0}},"bookmarks":{"create":{"minArgs":1,"maxArgs":1},"get":{"minArgs":1,"maxArgs":1},"getChildren":{"minArgs":1,"maxArgs":1},"getRecent":{"minArgs":1,"maxArgs":1},"getSubTree":{"minArgs":1,"maxArgs":1},"getTree":{"minArgs":0,"maxArgs":0},"move":{"minArgs":2,"maxArgs":2},"remove":{"minArgs":1,"maxArgs":1},"removeTree":{"minArgs":1,"maxArgs":1},"search":{"minArgs":1,"maxArgs":1},"update":{"minArgs":2,"maxArgs":2}},"browserAction":{"disable":{"minArgs":0,"maxArgs":1,"fallbackToNoCallback":true},"enable":{"minArgs":0,"maxArgs":1,"fallbackToNoCallback":true},"getBadgeBackgroundColor":{"minArgs":1,"maxArgs":1},"getBadgeText":{"minArgs":1,"maxArgs":1},"getPopup":{"minArgs":1,"maxArgs":1},"getTitle":{"minArgs":1,"maxArgs":1},"openPopup":{"minArgs":0,"maxArgs":0},"setBadgeBackgroundColor":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true},"setBadgeText":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true},"setIcon":{"minArgs":1,"maxArgs":1},"setPopup":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true},"setTitle":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true}},"browsingData":{"remove":{"minArgs":2,"maxArgs":2},"removeCache":{"minArgs":1,"maxArgs":1},"removeCookies":{"minArgs":1,"maxArgs":1},"removeDownloads":{"minArgs":1,"maxArgs":1},"removeFormData":{"minArgs":1,"maxArgs":1},"removeHistory":{"minArgs":1,"maxArgs":1},"removeLocalStorage":{"minArgs":1,"maxArgs":1},"removePasswords":{"minArgs":1,"maxArgs":1},"removePluginData":{"minArgs":1,"maxArgs":1},"settings":{"minArgs":0,"maxArgs":0}},"commands":{"getAll":{"minArgs":0,"maxArgs":0}},"contextMenus":{"remove":{"minArgs":1,"maxArgs":1},"removeAll":{"minArgs":0,"maxArgs":0},"update":{"minArgs":2,"maxArgs":2}},"cookies":{"get":{"minArgs":1,"maxArgs":1},"getAll":{"minArgs":1,"maxArgs":1},"getAllCookieStores":{"minArgs":0,"maxArgs":0},"remove":{"minArgs":1,"maxArgs":1},"set":{"minArgs":1,"maxArgs":1}},"devtools":{"inspectedWindow":{"eval":{"minArgs":1,"maxArgs":2,"singleCallbackArg":false}},"panels":{"create":{"minArgs":3,"maxArgs":3,"singleCallbackArg":true},"elements":{"createSidebarPane":{"minArgs":1,"maxArgs":1}}}},"downloads":{"cancel":{"minArgs":1,"maxArgs":1},"download":{"minArgs":1,"maxArgs":1},"erase":{"minArgs":1,"maxArgs":1},"getFileIcon":{"minArgs":1,"maxArgs":2},"open":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true},"pause":{"minArgs":1,"maxArgs":1},"removeFile":{"minArgs":1,"maxArgs":1},"resume":{"minArgs":1,"maxArgs":1},"search":{"minArgs":1,"maxArgs":1},"show":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true}},"extension":{"isAllowedFileSchemeAccess":{"minArgs":0,"maxArgs":0},"isAllowedIncognitoAccess":{"minArgs":0,"maxArgs":0}},"history":{"addUrl":{"minArgs":1,"maxArgs":1},"deleteAll":{"minArgs":0,"maxArgs":0},"deleteRange":{"minArgs":1,"maxArgs":1},"deleteUrl":{"minArgs":1,"maxArgs":1},"getVisits":{"minArgs":1,"maxArgs":1},"search":{"minArgs":1,"maxArgs":1}},"i18n":{"detectLanguage":{"minArgs":1,"maxArgs":1},"getAcceptLanguages":{"minArgs":0,"maxArgs":0}},"identity":{"launchWebAuthFlow":{"minArgs":1,"maxArgs":1}},"idle":{"queryState":{"minArgs":1,"maxArgs":1}},"management":{"get":{"minArgs":1,"maxArgs":1},"getAll":{"minArgs":0,"maxArgs":0},"getSelf":{"minArgs":0,"maxArgs":0},"setEnabled":{"minArgs":2,"maxArgs":2},"uninstallSelf":{"minArgs":0,"maxArgs":1}},"notifications":{"clear":{"minArgs":1,"maxArgs":1},"create":{"minArgs":1,"maxArgs":2},"getAll":{"minArgs":0,"maxArgs":0},"getPermissionLevel":{"minArgs":0,"maxArgs":0},"update":{"minArgs":2,"maxArgs":2}},"pageAction":{"getPopup":{"minArgs":1,"maxArgs":1},"getTitle":{"minArgs":1,"maxArgs":1},"hide":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true},"setIcon":{"minArgs":1,"maxArgs":1},"setPopup":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true},"setTitle":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true},"show":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true}},"permissions":{"contains":{"minArgs":1,"maxArgs":1},"getAll":{"minArgs":0,"maxArgs":0},"remove":{"minArgs":1,"maxArgs":1},"request":{"minArgs":1,"maxArgs":1}},"runtime":{"getBackgroundPage":{"minArgs":0,"maxArgs":0},"getPlatformInfo":{"minArgs":0,"maxArgs":0},"openOptionsPage":{"minArgs":0,"maxArgs":0},"requestUpdateCheck":{"minArgs":0,"maxArgs":0},"sendMessage":{"minArgs":1,"maxArgs":3},"sendNativeMessage":{"minArgs":2,"maxArgs":2},"setUninstallURL":{"minArgs":1,"maxArgs":1}},"sessions":{"getDevices":{"minArgs":0,"maxArgs":1},"getRecentlyClosed":{"minArgs":0,"maxArgs":1},"restore":{"minArgs":0,"maxArgs":1}},"storage":{"local":{"clear":{"minArgs":0,"maxArgs":0},"get":{"minArgs":0,"maxArgs":1},"getBytesInUse":{"minArgs":0,"maxArgs":1},"remove":{"minArgs":1,"maxArgs":1},"set":{"minArgs":1,"maxArgs":1}},"managed":{"get":{"minArgs":0,"maxArgs":1},"getBytesInUse":{"minArgs":0,"maxArgs":1}},"sync":{"clear":{"minArgs":0,"maxArgs":0},"get":{"minArgs":0,"maxArgs":1},"getBytesInUse":{"minArgs":0,"maxArgs":1},"remove":{"minArgs":1,"maxArgs":1},"set":{"minArgs":1,"maxArgs":1}}},"tabs":{"captureVisibleTab":{"minArgs":0,"maxArgs":2},"create":{"minArgs":1,"maxArgs":1},"detectLanguage":{"minArgs":0,"maxArgs":1},"discard":{"minArgs":0,"maxArgs":1},"duplicate":{"minArgs":1,"maxArgs":1},"executeScript":{"minArgs":1,"maxArgs":2},"get":{"minArgs":1,"maxArgs":1},"getCurrent":{"minArgs":0,"maxArgs":0},"getZoom":{"minArgs":0,"maxArgs":1},"getZoomSettings":{"minArgs":0,"maxArgs":1},"goBack":{"minArgs":0,"maxArgs":1},"goForward":{"minArgs":0,"maxArgs":1},"highlight":{"minArgs":1,"maxArgs":1},"insertCSS":{"minArgs":1,"maxArgs":2},"move":{"minArgs":2,"maxArgs":2},"query":{"minArgs":1,"maxArgs":1},"reload":{"minArgs":0,"maxArgs":2},"remove":{"minArgs":1,"maxArgs":1},"removeCSS":{"minArgs":1,"maxArgs":2},"sendMessage":{"minArgs":2,"maxArgs":3},"setZoom":{"minArgs":1,"maxArgs":2},"setZoomSettings":{"minArgs":1,"maxArgs":2},"update":{"minArgs":1,"maxArgs":2}},"topSites":{"get":{"minArgs":0,"maxArgs":0}},"webNavigation":{"getAllFrames":{"minArgs":1,"maxArgs":1},"getFrame":{"minArgs":1,"maxArgs":1}},"webRequest":{"handlerBehaviorChanged":{"minArgs":0,"maxArgs":0}},"windows":{"create":{"minArgs":0,"maxArgs":1},"get":{"minArgs":1,"maxArgs":2},"getAll":{"minArgs":0,"maxArgs":1},"getCurrent":{"minArgs":0,"maxArgs":1},"getLastFocused":{"minArgs":0,"maxArgs":1},"remove":{"minArgs":1,"maxArgs":1},"update":{"minArgs":2,"maxArgs":2}}}');
            }
        });
        const __webpack_module_cache__ = {};
        function __nested_webpack_require_24729__(moduleId) {
            const cachedModule = __webpack_module_cache__[moduleId];
            if (cachedModule !== undefined) {
                return cachedModule.exports;
            }
            const module = __webpack_module_cache__[moduleId] = {
                exports: {}
            };
            __webpack_modules__[moduleId](module, module.exports, __nested_webpack_require_24729__);
            return module.exports;
        }
        (() => {
            __nested_webpack_require_24729__.d = (exports, definition) => {
                if (Array.isArray(definition)) {
                    var i = 0;
                    while (i < definition.length) {
                        var key = definition[i++];
                        var binding = definition[i++];
                        if (!__nested_webpack_require_24729__.o(exports, key)) {
                            if (binding === 0) {
                                Object.defineProperty(exports, key, { enumerable: true, value: definition[i++] });
                            }
                            else {
                                Object.defineProperty(exports, key, { enumerable: true, get: binding });
                            }
                        }
                        else if (binding === 0) {
                            i++;
                        }
                    }
                }
                else {
                    for (var key in definition) {
                        if (__nested_webpack_require_24729__.o(definition, key) && !__nested_webpack_require_24729__.o(exports, key)) {
                            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
                        }
                    }
                }
            };
        })();
        (() => {
            __nested_webpack_require_24729__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop));
        })();
        (() => {
            __nested_webpack_require_24729__.r = (exports) => {
                if (Symbol.toStringTag) {
                    Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
                }
                Object.defineProperty(exports, '__esModule', { value: true });
            };
        })();
        let __nested_webpack_exports__ = {};
        __nested_webpack_require_24729__.r(__nested_webpack_exports__);
        __nested_webpack_require_24729__.d(__nested_webpack_exports__, {
            account: () => (account),
            experiments: () => (experiments),
            sentry: () => (sentry),
            telemetry: () => (telemetry)
        });
        var browser_polyfill = __nested_webpack_require_24729__(7795);
        ;
        const ERROR_NO_CONNECTION = "Could not establish connection. " +
            "Receiving end does not exist.";
        const ERROR_CLOSED_CONNECTION = "A listener indicated an asynchronous " +
            "response by returning true, but the message channel closed before a " +
            "response was received";
        const ERROR_MANAGER_DISCONNECTED = "Message manager disconnected";
        function fromSerializableError(errorData) {
            const error = new Error(errorData.message);
            error.cause = errorData.cause;
            error.name = errorData.name;
            error.stack = errorData.stack;
            return error;
        }
        function ignoreNoConnectionError(promise) {
            return promise.catch(error => {
                if (typeof error == "object" &&
                    (error.message == ERROR_NO_CONNECTION ||
                        error.message == ERROR_CLOSED_CONNECTION ||
                        error.message == ERROR_MANAGER_DISCONNECTED)) {
                    return;
                }
                throw error;
            });
        }
        function toSerializableError(error) {
            return {
                cause: error.cause instanceof Error ?
                    toSerializableError(error.cause) :
                    error.cause,
                message: error.message,
                name: error.name,
                stack: error.stack
            };
        }
        ;
        async function forwardError(error) {
            ignoreNoConnectionError(browser_polyfill.runtime.sendMessage({
                type: "ewe:sentry-error",
                error: toSerializableError(error)
            }));
        }
        const sentry = ({
            async reportError(error) {
                return await forwardError(error);
            },
            start() {
                self.addEventListener("error", event => {
                    const { error } = event;
                    if (!(error instanceof Error)) {
                        return;
                    }
                    forwardError(error);
                });
                self.addEventListener("unhandledrejection", event => {
                    const { reason } = event;
                    if (!(reason instanceof Error)) {
                        return;
                    }
                    forwardError(reason);
                });
            }
        });
        ;
        async function callAPI(methodName, ...params) {
            return await ignoreNoConnectionError(browser_polyfill.runtime.sendMessage({
                type: "ewe:api-call",
                apiName: "account",
                methodName,
                params
            }));
        }
        const account = ({
            async getProfile() {
                return await callAPI("getProfile");
            },
            async hasPremium() {
                return await callAPI("hasPremium");
            },
            async isTrial() {
                return await callAPI("isTrial");
            },
            async getPreferences() {
                return await callAPI("getPreferences");
            },
            async getTrialDaysLeft() {
                return await callAPI("getTrialDaysLeft");
            }
        });
        ;
        async function experiments_callAPI(methodName, ...params) {
            return await ignoreNoConnectionError(browser_polyfill.runtime.sendMessage({
                type: "ewe:api-call",
                apiName: "experiments",
                methodName,
                params
            }));
        }
        const experiments = ({
            async getFlag(flagId) {
                return await experiments_callAPI("getFlag", flagId);
            },
            async getFlags() {
                return await experiments_callAPI("getFlags");
            },
            async getAssignments() {
                return await experiments_callAPI("getAssignments");
            }
        });
        ;
        const events = ({
            adblock_ui: {
                options_clicked: {
                    description: "User clicked the gear icon"
                },
                support_icon_clicked: {
                    description: "User clicked the support icon on the header of the Adblock popup"
                },
                opt_out_acceptable_ads_clicked: {
                    description: "The user clicked the opt-out link to disable Acceptable Ads on the getadblock.com installed page"
                },
                cm_pause_on_site: {
                    description: "User right clicked on the page to open the context menu and selected 'Pause on this site' from the AdBlock section."
                },
                cm_pause_on_all_sites: {
                    description: "User right clicked on the page to open the context menu and selected 'Pause on all sites' from the AdBlock section."
                },
                cm_resume_adblock: {
                    description: "User right clicked on the page to open the context menu and selected 'Resume blocking ads' from the AdBlock section."
                },
                pause_on_site: {
                    description: "User clicked 'Pause on this site' on the Adblock popup"
                },
                resume_adblock: {
                    description: "User clicked 'Resume Ad blocking' on the Adblock popup"
                },
                popup_opened: {
                    description: "User clicked the AdBlock toolbar icon to open the popup menu",
                    data: {
                        description: "Data about the popup opened event",
                        type: "object",
                        properties: {
                            isBadgeTextNew: {
                                description: "The 'new' badge is shown on the popup icon",
                                type: "boolean"
                            },
                            reason: {
                                description: "The reason why the 'new' badge was shown",
                                type: "string"
                            }
                        }
                    }
                },
                hide_on_this_page_clicked: {
                    description: "User clicked on the three dots in the popup menu, then clicked the 'Hide something on this page' link"
                },
                titletext_clicked: {
                    description: "User clicked the AdBlock logo in the popup menu header"
                },
                more_pause_options_clicked: {
                    description: "User clicked on the three dots in the popup menu, then clicked 'More pause options' link"
                },
                help_flow_results: {
                    description: "Emitted when a user completes the help flow in the popup. The flow presents different options based on the user's issue (e.g., ads not blocked, site broken, etc.), and the emitted event includes the path representing the sequence of choices the user made",
                    data: {
                        description: "Data about the help flow results",
                        type: "object",
                        properties: {
                            helpFlowPath: {
                                description: "The path of the help flow (e.g. 'start,seeAd,seeAdEverywhere,link')",
                                type: "string"
                            }
                        }
                    }
                },
                premium_options_clicked: {
                    description: "Triggered when a premium user clicks the 'Premium' label in the popup header which is shown next to the Adblock logo. The label is only visible to premium users and opens the Premium tab in the settings page"
                },
                popup_sub_clicked_cookies_premium: {
                    description: "Triggered when a premium user clicks the toggle to enable the Premium Cookie Blocking filter list in the popup. The list is not enabled automatically when upgrading to premium"
                },
                popup_sub_clicked_distraction_control: {
                    description: "Triggered when a premium user clicks the toggle to enable the Premium Block Distractions filter list in the popup. The list is not enabled automatically when upgrading to premium"
                },
                skip_cookie_walls_learn_more_clicked: {
                    description: "A free user clicked the Learn More button on the 'Skip Cookie Walls' section in the AdBlock popup"
                },
                block_distractions_learn_more_clicked: {
                    description: "A free user clicked the Learn More button on the 'Block Distractions' section in the AdBlock popup"
                },
                options_page_tab_premium_cta: {
                    description: "User interacted with a premium CTA on a premium tab in the options page",
                    data: {
                        description: "Data about which tab the user was viewing",
                        type: "object",
                        properties: {
                            tab: {
                                description: "The name of the tab being viewed when the CTA was clicked",
                                type: "string",
                                enum: ["premium", "themes", "image_swap", "premium_filters"]
                            },
                            action: {
                                description: "Type of interaction with the Premium CTA",
                                type: "string",
                                enum: ["clicked"]
                            }
                        }
                    }
                },
                options_page_tab: {
                    description: "User clicked or opened a tab on the options page side bar",
                    data: {
                        description: "Data about the user interaction with the options page tab",
                        type: "object",
                        properties: {
                            tab: {
                                description: "The tab that the user interacted with",
                                type: "string",
                                enum: ["stats", "general", "filter_lists", "customize", "support", "premium", "themes", "image_swap", "premium_filters"]
                            },
                            action: {
                                description: "Type of interaction with the options page tab",
                                type: "string",
                                enum: ["opened", "clicked"]
                            }
                        }
                    }
                },
                vpn_cta: {
                    description: "User interacted with AdBlock VPN promotional banner in the popup menu. This CTA promotes the VPN with 'Introducing AdBlock VPN' message",
                    data: {
                        description: "Data about the user interaction with the AdBlock VPN promotional banner",
                        type: "object",
                        properties: {
                            action: {
                                description: "Type of interaction with the AdBlock VPN promotional banner",
                                type: "string",
                                enum: ["seen", "clicked", "closed"]
                            }
                        }
                    }
                },
                premium_themes_cta: {
                    description: "User interacted with themes customization CTA in the popup menu, opening the themes section in options page",
                    data: {
                        description: "Information about the theme that was being promoted when clicked",
                        type: "object",
                        properties: {
                            theme: {
                                description: "The name of the theme being showcased when the user clicked",
                                type: "string",
                                enum: ["solarized", "solarized_light", "watermelon", "sunshine", "ocean"]
                            },
                            action: {
                                description: "Type of interaction with the themes customization CTA",
                                type: "string",
                                enum: ["seen", "clicked", "closed"]
                            }
                        }
                    }
                },
                free_dc_cta: {
                    description: "User interacted with Distraction Control promotional banner in the popup menu. This CTA promotes the premium Distraction Control feature with 'Block Floating Videos' message",
                    data: {
                        description: "Data about the user interaction with the Distraction Control promotional banner",
                        type: "object",
                        properties: {
                            action: {
                                description: "Type of interaction with the Distraction Control promotional banner",
                                type: "string",
                                enum: ["seen", "clicked", "closed"]
                            }
                        }
                    }
                },
                premium_dc_cta: {
                    description: "Premium user interacted with the enhanced Distraction Control CTA in the popup menu. This CTA highlights 'New Premium feature available!' to promote advanced distraction blocking options",
                    data: {
                        description: "Data about the user interaction with the Distraction Control CTA",
                        type: "object",
                        properties: {
                            action: {
                                description: "Type of interaction with the Distraction Control CTA",
                                type: "string",
                                enum: ["seen", "clicked", "closed"]
                            }
                        }
                    }
                },
                premium_upsell_cta: {
                    description: "User interacted with Premium upsell upgrade banner in the popup menu. This CTA displays 'Upgrade your AdBlock' message to encourage premium subscription",
                    data: {
                        description: "Data about the user interaction with the Premium upsell upgrade banner",
                        type: "object",
                        properties: {
                            action: {
                                description: "Type of interaction with the Premium upsell upgrade banner",
                                type: "string",
                                enum: ["seen", "clicked", "closed"]
                            }
                        }
                    }
                },
                premium_filter_list_cta: {
                    description: "User interacted with Premium filter list banner in the popup menu. This CTA displays 'Upgrade your AdBlock' message to encourage premium subscription",
                    data: {
                        description: "Data about the user interaction with the premium filter list CTA",
                        type: "object",
                        properties: {
                            action: {
                                description: "Type of interaction with the premium filter list CTA",
                                type: "string",
                                enum: ["seen", "clicked"]
                            }
                        }
                    }
                },
                data_collection_opt_out: {
                    description: "User opted out of data collection in the options page"
                }
            },
            extensions_ui: {
                acceptable_ads_toggled: {
                    description: "User toggled the Acceptable Ads checkbox on the extension options page. This is a shared event fired by both AB and ABP.",
                    data: {
                        description: "Data about the acceptable ads toggle interaction",
                        type: "object",
                        properties: {
                            action: {
                                description: "Whether the user opted in or out of acceptable ads",
                                type: "string",
                                enum: ["opted_in", "opted_out"]
                            },
                            source: {
                                description: "Where the toggle occurred. This could be from the general or filter lists options tabs.",
                                type: "string",
                                enum: ["options_general", "options_filter_list"]
                            }
                        }
                    }
                }
            },
            adblockplus_ui: {
                issue_report_submitted: {
                    description: "Issue report was submitted"
                }
            },
            smart_allowlisting: {
                allowlisting_expired: {
                    description: "An allowlisting filter expired automatically",
                    data: {
                        description: "Details about the filter at the time of expiration.",
                        type: "object",
                        properties: {
                            allowlistExtendDuration: {
                                description: "The number of milliseconds to extend the allowlisting filter's expiry when the user navigated to a URL that matches the filter.",
                                type: "number"
                            }
                        }
                    }
                },
                allowlisting_renewed: {
                    description: "An allowlisting filter was renewed automatically",
                    data: {
                        description: "Details about the filter at the time of renewal.",
                        type: "object",
                        properties: {
                            allowlistExtendDuration: {
                                description: "The number of milliseconds to extend the allowlisting filter's expiry when the user navigated to a URL that matches the filter.",
                                type: "number"
                            }
                        }
                    }
                }
            },
            cdp: {
                built_cdp_payload: {
                    description: "A payload has been built with the intention of sending it to CDP. This is debug information, and will temporarily include the eventStats until the CDP server is ready to ingest them.",
                    data: {
                        description: "Data about the built payload",
                        type: "object",
                        properties: {
                            eventStats: {
                                description: "Counts of behavior event logs since the last payload.",
                                type: "any"
                            },
                            uncompressedPayloadSize: {
                                description: "Size in bytes of the uncompressed and unencrypted payload.",
                                type: "integer"
                            }
                        }
                    }
                }
            },
            detection_snippets: {
                snippet_detection_event: {
                    description: "Recorded when a snippet detects a condition on a page (e.g. wall detection). Each detection snippet calls this event from a single location with a unique type value. Other snippet concerns (blocking, breakage) should register separate events. Data is reliable from 2026-04-29 onwards; data before this date may have schema mismatches due to ongoing pipeline development.",
                    data: {
                        description: "Metadata about the detected condition",
                        type: "object",
                        properties: {
                            type: {
                                description: "Detection type identifier passed from the snippet filter, e.g. 'wall_detected'. Each snippet can have multiple types within a distinct type group for traceability.",
                                type: "string"
                            },
                            domain: {
                                description: "Domain where the condition was detected, e.g. 'example.com'",
                                type: "string"
                            },
                            specifier: {
                                description: "Optional additional context for filtering in BigQuery, e.g. the CSS selector that matched ('.overlay-wall-container') or a filter list identifier",
                                type: ["string", "null"]
                            }
                        }
                    }
                }
            },
            hit_snippets: {
                snippet_hit_event: {
                    description: "Recorded when a snippet successfully executes on a page.",
                    data: {
                        description: "Metadata about the snippet execution",
                        type: "object",
                        properties: {
                            filter: {
                                description: "Snippet filter body, e.g. 'json-prune ads userId'",
                                type: "string"
                            },
                            domain: {
                                description: "Domain where the snippet fired (document.location.hostname of the frame)",
                                type: "string"
                            },
                            topLevelDomain: {
                                description: "Top-level page domain. Equals domain for main-frame snippets; differs for cross-origin iframe snippets.",
                                type: "string"
                            }
                        }
                    }
                }
            },
            snippets: {
                context_tampering: {
                    description: "Recorded when the website is trying to disable the snippets"
                },
                local_storage_unavailable: {
                    description: "The extension intended to use localStorage as a cache, but localStorage was unavailable",
                    data: {
                        description: "Metadata about the context where localStorage was unavailable",
                        type: "object",
                        properties: {
                            isMainFrame: {
                                description: "This occurred in the main frame, not in an iframe",
                                type: "boolean"
                            }
                        }
                    }
                },
                zero_delay_cleanup: {
                    description: "Recorded when we cleaned up zero-delay storage key from previous extension versions.",
                    data: {
                        description: "Metadata about the cleanup operation",
                        type: "object",
                        properties: {
                            key: {
                                description: "The storage key that was cleaned up",
                                type: "string"
                            }
                        }
                    }
                },
                snippet_detection_domainless: {
                    description: "Domain omitted intentionally to support user-level retention signals without per-domain identification. Introduced on 2026-04-29; no data exists before this date.",
                    data: {
                        description: "Metadata about the detected condition",
                        type: "object",
                        properties: {
                            type: {
                                description: "Detection type identifier passed from the snippet filter, e.g. 'wall_detected'.",
                                type: "string"
                            },
                            specifier: {
                                description: "Extra context from the detection snippet, e.g. a matched CSS selector or filter rule identifier. null when no specifier is available.",
                                type: ["string", "null"]
                            }
                        }
                    }
                }
            },
            youtube: {
                yt_site_navigation: {
                    description: "Recorded 5 seconds after a user navigates to a YouTube page. This event is sent only once per session. Refreshing or opening a new tab will start a new session. Navigating through videos without refreshing (aka SPA navigation) will not trigger another event.",
                    data: {
                        description: "Data about the YouTube navigation event",
                        type: "object",
                        properties: {
                            userLoggedIn: {
                                description: "Indicates whether the user is logged in to a YouTube account. '1' for logged in, '0' for not logged in.",
                                type: "string",
                                enum: ["1", "0"]
                            }
                        }
                    }
                },
                yt_site_ad_shown: {
                    description: "Recorded when a video ad on YouTube stops playing, either because it was skipped, the user navigated away, or it finished playing",
                    data: {
                        description: "Data for the YouTube ad shown event",
                        type: "object",
                        properties: {
                            isAllowListed: {
                                description: "Indicates whether the page is allowlisted. '1' for allowlisted, '0' for not allowlisted.",
                                type: "string",
                                enum: ["1", "0"]
                            },
                            isPremium: {
                                description: "Specifies whether the user has a Premium subscription. Used to be called 'p' in getadblock.logs_unified.logs_fact",
                                type: "boolean"
                            },
                            adFormat: {
                                description: "Format ID of the displayed ad. Used to be called 'category' in getadblock.logs_unified.logs_fact",
                                type: "string"
                            },
                            totalAdDurationMs: {
                                description: "Total duration of the ad, in milliseconds. Used to be called 'bc' in getadblock.logs_unified.logs_fact",
                                type: "number"
                            },
                            adShownDurationMs: {
                                description: "Actual playback duration of the ad, in milliseconds. Used to be called 'amount' in getadblock.logs_unified.logs_fact",
                                type: "number"
                            }
                        }
                    }
                },
                yt_site_ad_wall_detected: {
                    description: "Recorded when the YouTube ad wall is detected and the page is not yet allowlisted.",
                    data: {
                        description: "Data for YouTube ad wall detection when the page is not yet allowlisted",
                        type: "object",
                        properties: {
                            adwallCategory: {
                                description: "The ad wall type: 'soft' (dismiss button) or 'hard' (no dismiss button).",
                                type: "string",
                                enum: ["soft", "hard"]
                            },
                            userLoggedIn: {
                                description: "String flag indicating whether the user is logged in to a YouTube account ('1' if logged in, otherwise '0').",
                                type: "string",
                                enum: ["1", "0"]
                            },
                            isAllowListed: {
                                description: "String flag indicating whether the page is allowlisted ('1' if allowlisted, otherwise '0'). Should always be '0' for this event.",
                                type: "string",
                                enum: ["1", "0"]
                            },
                            allowlistScope: {
                                description: "Scope of the applied allowlist rule: 'video' (single video url) or 'tab' (all videos until the tab is closed).",
                                type: "string",
                                enum: ["video", "tab"]
                            }
                        }
                    }
                },
                yt_site_already_allowlisted: {
                    description: "Recorded when the YouTube ad wall is detected, but the page was already allowlisted.",
                    data: {
                        description: "Data for YouTube ad wall detection when the page is already allowlisted",
                        type: "object",
                        properties: {
                            adwallCategory: {
                                description: "The ad wall type: 'soft' (dismiss button) or 'hard' (no dismiss button).",
                                type: "string",
                                enum: ["soft", "hard"]
                            },
                            userLoggedIn: {
                                description: "String flag indicating whether the user is logged in to a YouTube account ('1' if logged in, otherwise '0').",
                                type: "string",
                                enum: ["1", "0"]
                            },
                            isAllowListed: {
                                description: "String flag indicating whether the page is allowlisted ('1' if allowlisted, otherwise '0'). Should always be '1' for this event.",
                                type: "string",
                                enum: ["1", "0"]
                            },
                            allowlistScope: {
                                description: "Scope of the applied allowlist rule: 'video' (single video url) or 'tab' (all videos until the tab is closed).",
                                type: "string",
                                enum: ["video", "tab"]
                            }
                        }
                    }
                },
                yt_auto_allowlisted: {
                    description: "Recorded immediately after the extension automatically allowlists a YouTube page in response to an ad wall.",
                    data: {
                        description: "Data for the YouTube auto allowlisted event",
                        type: "object",
                        properties: {
                            allowlistScope: {
                                description: "Scope of the applied allowlist rule: 'video' (single video url) or 'tab' (all videos until the tab is closed).",
                                type: "string",
                                enum: ["video", "tab"]
                            }
                        }
                    }
                },
                yt_site_toast_shown: {
                    description: "Recorded when the YouTube 'ad blocker' toast notification appears in the DOM. This is an experiment ran by YouTube that only appears for certain adblocking users, warning them that their adblocker might be causing interruptions.",
                    data: {
                        description: "Data for the YouTube toast shown event",
                        type: "object",
                        properties: {
                            isAllowListed: {
                                description: "String flag indicating whether the page is allowlisted ('1' if allowlisted, otherwise '0').",
                                type: "string",
                                enum: ["1", "0"]
                            },
                            isPremium: {
                                description: "Specifies whether the user has a Premium subscription",
                                type: "boolean"
                            }
                        }
                    }
                },
                yt_site_context_tampering: {
                    description: "Recorded when the YouTube error_204 beacon indicates a possible script conflict that could interfere with the extension.",
                    data: {
                        description: "Data for the YouTube context tampering event",
                        type: "object",
                        properties: {
                            isAllowListed: {
                                description: "String flag indicating whether the page is allowlisted ('1' if allowlisted, otherwise '0').",
                                type: "string",
                                enum: ["1", "0"]
                            },
                            isPremium: {
                                description: "Specifies whether the user has a Premium subscription",
                                type: "boolean"
                            },
                            applicationVersion: {
                                description: "YouTube client version from the client.version query param on the error_204 request.",
                                type: "string"
                            }
                        }
                    }
                },
                yt_site_yt_error: {
                    description: "This event is triggered in the event of an error on YouTube. There could be multiple types of errors happening on the page, so we try to differentiate them via the category parameter.",
                    data: {
                        description: "Data for the YouTube error event",
                        type: "object",
                        properties: {
                            category: {
                                description: "Indicates the error type as defined in our extension code. It can be one of the following: 'uncaught_exception', 'player_error' or 'sww_error'.",
                                type: "string",
                                enum: ["uncaught_exception", "player_error", "sww_error"]
                            },
                            applicationVersion: {
                                description: "The client version of the YouTube application (e.g., '2.20251020.01.00').",
                                type: "string"
                            },
                            error: {
                                description: "Indicates the exception type of JavaScript error, captured by the YouTube error handler (e.g., 'TypeError').",
                                type: "string"
                            },
                            errorMsg: {
                                description: "Either the stack trace of the error or an empty string.",
                                type: "string"
                            },
                            isAllowListed: {
                                description: "String flag indicating whether the site is allowlisted ('1' if allowlisted, otherwise '0').",
                                type: "string",
                                enum: ["1", "0"]
                            },
                            isPremium: {
                                description: "Specifies whether the user has a Premium subscription.",
                                type: "boolean"
                            }
                        }
                    }
                }
            },
            conflict_detection: {
                bt_loader_blocked: {
                    description: "Recorded on every website when the script from Blockthrough fails to load. BTLoader initiates ad recovery for users who allow Acceptable Ads, enabling monetization. This event indicates the script was blocked, which can happen when the user has disabled Acceptable Ads, installed another ad blocker that blocks BTLoader, or allowlisted the page. When BTLoader is blocked, ad recovery cannot occur and monetization is lost.",
                    data: {
                        description: "Data about why BTLoader was blocked",
                        type: "object",
                        properties: {
                            isPageAllowlisted: {
                                description: "Whether the page is allowlisted",
                                type: "boolean"
                            },
                            aaListsStatus: {
                                description: "The status of the Acceptable Ads lists. 0: none, 1: AA, 2: AA Privacy, 3: both",
                                type: "number"
                            },
                            errorMsg: {
                                description: "Browser string indicating the error that occurred",
                                type: "string"
                            }
                        }
                    }
                },
                bt_loader_success: {
                    description: "Recorded on every website when the script from Blockthrough successfully loads. BTLoader initiates ad recovery for users who allow Acceptable Ads, enabling monetization. This event confirms that ad recovery can proceed normally on this page.",
                    data: {
                        description: "Data about the BTLoader success event",
                        type: "object",
                        properties: {
                            isPageAllowlisted: {
                                description: "Whether the page is allowlisted",
                                type: "boolean"
                            },
                            aaListsStatus: {
                                description: "The status of the Acceptable Ads lists. 0: none, 1: AA, 2: AA Privacy, 3: both",
                                type: "number"
                            }
                        }
                    }
                },
                aa_bait1_blocked: {
                    description: "Acceptable Ads bait 1 was blocked",
                    data: {
                        description: "Data about why Acceptable Ads bait 1 was blocked",
                        type: "object",
                        properties: {
                            isPageAllowlisted: {
                                description: "Whether the page is allowlisted",
                                type: "boolean"
                            },
                            aaListsStatus: {
                                description: "The status of the Acceptable Ads lists. 0: none, 1: AA, 2: AA Privacy, 3: both",
                                type: "number"
                            },
                            errorMsg: {
                                description: "Browser string indicating the error that occurred",
                                type: "string"
                            }
                        }
                    }
                },
                aa_bait1_success: {
                    description: "Acceptable Ads bait 1 was successfully loaded",
                    data: {
                        description: "Data about the Acceptable Ads bait 1 success event",
                        type: "object",
                        properties: {
                            isPageAllowlisted: {
                                description: "Whether the page is allowlisted",
                                type: "boolean"
                            },
                            aaListsStatus: {
                                description: "The status of the Acceptable Ads lists. 0: none, 1: AA, 2: AA Privacy, 3: both",
                                type: "number"
                            }
                        }
                    }
                },
                aa_bait2_blocked: {
                    description: "Acceptable Ads bait 2 was blocked",
                    data: {
                        description: "Data about why Acceptable Ads bait 2 was blocked",
                        type: "object",
                        properties: {
                            isPageAllowlisted: {
                                description: "Whether the page is allowlisted",
                                type: "boolean"
                            },
                            aaListsStatus: {
                                description: "The status of the Acceptable Ads lists. 0: none, 1: AA, 2: AA Privacy, 3: both",
                                type: "number"
                            },
                            errorMsg: {
                                description: "Browser string indicating the error that occurred",
                                type: "string"
                            }
                        }
                    }
                },
                aa_bait2_success: {
                    description: "Acceptable Ads bait 2 was successfully loaded",
                    data: {
                        description: "Data about the Acceptable Ads bait 2 success event",
                        type: "object",
                        properties: {
                            isPageAllowlisted: {
                                description: "Whether the page is allowlisted",
                                type: "boolean"
                            },
                            aaListsStatus: {
                                description: "The status of the Acceptable Ads lists. 0: none, 1: AA, 2: AA Privacy, 3: both",
                                type: "number"
                            }
                        }
                    }
                },
                aa_other_blocked: {
                    description: "Acceptable Ads filters on Amazon, Yahoo, LinkedIn, Outlook were blocked",
                    data: {
                        description: "Data about why Acceptable Ads filters were blocked",
                        type: "object",
                        properties: {
                            isPageAllowlisted: {
                                description: "Whether the page is allowlisted",
                                type: "boolean"
                            },
                            aaListsStatus: {
                                description: "The status of the Acceptable Ads lists. 0: none, 1: AA, 2: AA Privacy, 3: both",
                                type: "number"
                            },
                            errorMsg: {
                                description: "Browser string indicating the error that occurred",
                                type: "string"
                            }
                        }
                    }
                },
                aa_other_success: {
                    description: "Acceptable Ads filters on Amazon, Yahoo, LinkedIn, Outlook were successfully loaded",
                    data: {
                        description: "Data about the Acceptable Ads filters success event",
                        type: "object",
                        properties: {
                            isPageAllowlisted: {
                                description: "Whether the page is allowlisted",
                                type: "boolean"
                            },
                            aaListsStatus: {
                                description: "The status of the Acceptable Ads lists. 0: none, 1: AA, 2: AA Privacy, 3: both",
                                type: "number"
                            }
                        }
                    }
                }
            },
            cohorts: {
                facts_snapshot: {
                    description: "Cohorts facts snapshot used for cohort estimation",
                    data: {
                        description: "The updated facts",
                        type: "object",
                        properties: {
                            extName: {
                                description: "The name of the extension",
                                type: "string"
                            },
                            extVersion: {
                                description: "The version of the extension",
                                type: "string"
                            },
                            browserName: {
                                description: "The name of the browser",
                                type: "string"
                            },
                            browserVersion: {
                                description: "The version of the browser",
                                type: "string"
                            },
                            browserLanguage: {
                                description: "The language of the browser",
                                type: "string"
                            },
                            countryCode: {
                                description: "The 2-letter country code of the user",
                                type: "string"
                            },
                            aaEnabled: {
                                description: "Whether Acceptable Ads is enabled",
                                type: "boolean"
                            },
                            installType: {
                                description: "The installation type of the extension",
                                type: "string"
                            },
                            hasPremium: {
                                description: "Whether the user has a premium subscription",
                                type: "boolean"
                            },
                            installDate: {
                                description: "The timestamp when the extension was installed",
                                type: "number"
                            },
                            blockedCount: {
                                description: "The number of blocked requests",
                                type: "number"
                            },
                            isTrial: {
                                description: "Whether the user is on a trial",
                                type: "boolean"
                            },
                            trialDaysLeft: {
                                description: "Days left in trial",
                                type: ["number", "null"]
                            },
                            marketingConsent: {
                                description: "Whether the user consented to marketing emails",
                                type: "boolean"
                            },
                            dynamicRuleCount: {
                                description: "The number of dynamic DNR rules (MV3 only)",
                                type: "number"
                            },
                            staticRuleCount: {
                                description: "The number of static DNR rules (MV3 only)",
                                type: ["number", "null"]
                            },
                            filterLists: {
                                description: "Hashes of the first 10 active filter list URLs",
                                type: "array",
                                items: {
                                    type: "string"
                                }
                            },
                            clientIdStability: {
                                description: "Frequency of the most common client ID in the client ID history, as a percentage of all entries. 0 if there isn't enough history yet.",
                                type: "number"
                            },
                            clientIdRotationFrequency: {
                                description: "How often the client ID rotates, in days (e.g. 1 for daily, 7 for weekly). 0 if there isn't enough history yet, or no rotation was observed.",
                                type: "number"
                            }
                        }
                    }
                }
            },
            dnr_filters: {
                recreated_dnr_rules: {
                    description: "On extension upgrade, our DNR filter management module will compare the dynamic DNR rules that the browser has with the filters that we know about. If these do not match, we recreate the DNR rules and log this report.",
                    data: {
                        description: "Report on the before and after state of the recreation",
                        type: "object",
                        properties: {
                            recreateStats: {
                                description: "Stats on how many DNR rules were recreated",
                                type: "object",
                                properties: {
                                    recreatedRulesCount: {
                                        description: "How many DNR rules were recreated",
                                        type: "integer"
                                    },
                                    removedRulesCount: {
                                        description: "How many existing DNR rules were removed",
                                        type: "integer"
                                    }
                                }
                            },
                            checkResultBefore: {
                                description: "Results of the data integrity check done before recreating the DNR rules.",
                                type: "object",
                                properties: {
                                    valid: {
                                        description: "True if the data integrity check passed. We only do the recreation if it failed, so this would be expected to always be false.",
                                        type: "boolean"
                                    },
                                    extraRulesInDNRCount: {
                                        description: "Count of the number of active dynamic DNR rules which we do not expect to see",
                                        type: "integer"
                                    },
                                    missingRulesInDNRCount: {
                                        description: "Count of the number of rules that our filters expected to exist but didn't",
                                        type: "integer"
                                    }
                                }
                            },
                            checkResultAfter: {
                                description: "Results of the data integrity check done after recreating the DNR rules.",
                                type: "object",
                                properties: {
                                    valid: {
                                        description: "True if the data integrity check passed. We expect this to be true after the rule recreation has run.",
                                        type: "boolean"
                                    },
                                    extraRulesInDNRCount: {
                                        description: "Count of the number of active dynamic DNR rules which we do not expect to see. We expect this to be 0 after the rule recreation has run.",
                                        type: "integer"
                                    },
                                    missingRulesInDNRCount: {
                                        description: "Count of the number of rules that our filters expected to exist but didn't. We expect this to be 0 after the rule recreation has run.",
                                        type: "integer"
                                    }
                                }
                            }
                        }
                    }
                },
                exceeded_static_rule_count_limit: {
                    description: "Debug log when someone runs into the 'set of enabled rulesets exceeds the rule count limit' error when enabling static rulesets",
                    data: {
                        description: "Data on the current state of static rules and the rulesets being enabled or disabled. Rule counts refer to static DNR rules, bundled in the extension at build time in rulesets.",
                        type: "object",
                        properties: {
                            enableRulesetIds: {
                                description: "Ruleset IDs that were to be enabled",
                                type: "array",
                                items: {
                                    type: "string"
                                }
                            },
                            enableRuleCount: {
                                description: "Static rules that we are trying to enable",
                                type: "integer"
                            },
                            disableRulesetIds: {
                                description: "Ruleset IDs that were to be disabled",
                                type: "array",
                                items: {
                                    type: "string"
                                }
                            },
                            disableRuleCount: {
                                description: "Static rules that we are trying to disable",
                                type: "integer"
                            },
                            currentEnabledRulesetIdsBefore: {
                                description: "Currently enabled ruleset IDs, gathered before calling updateEnabledRulesets",
                                type: "array",
                                items: {
                                    type: "string"
                                }
                            },
                            currentEnabledRulesetIdsAfter: {
                                description: "Currently enabled ruleset IDs, gathered after calling updateEnabledRulesets",
                                type: "array",
                                items: {
                                    type: "string"
                                }
                            },
                            currentEnabledRuleCountBefore: {
                                description: "Used static rules, gathered before calling updateEnabledRulesets",
                                type: "integer"
                            },
                            currentEnabledRuleCountAfter: {
                                description: "Used static rules, gathered after calling updateEnabledRulesets",
                                type: "integer"
                            },
                            availableRuleCountBefore: {
                                description: "Available static rules, gathered before calling updateEnabledRulesets",
                                type: "integer"
                            },
                            availableRuleCountAfter: {
                                description: "Available static rules, gathered after calling updateEnabledRulesets",
                                type: "integer"
                            }
                        }
                    }
                }
            },
            in_product_messaging: {
                command_received: {
                    description: "Extension received a valid IPM command from the remote config",
                    data: {
                        description: "IPM command ID",
                        type: "string"
                    }
                }
            },
            startup: {
                startup_error: {
                    description: "Errors recorded during the initialization of the extension",
                    data: {
                        description: "Data about the initializion error",
                        type: "object",
                        properties: {
                            errorMsg: {
                                description: "The error message that was recorded",
                                type: "string"
                            },
                            hasInternalError: {
                                description: "Whether or not the error string matched 'internal error' which indicates that it is a browser error",
                                type: "boolean"
                            },
                            timings: {
                                description: "Profiling information about startup performance",
                                type: "object",
                                properties: {
                                    marks: {
                                        type: "array",
                                        description: "Specific points in time when something happened",
                                        items: {
                                            type: "object",
                                            properties: {
                                                name: {
                                                    description: "Name of the initialization step",
                                                    type: "string"
                                                },
                                                startTime: {
                                                    description: "Milliseconds elapsed since the service worker started",
                                                    type: "number"
                                                }
                                            }
                                        }
                                    },
                                    measures: {
                                        type: "array",
                                        description: "Measurements of how long steps took",
                                        items: {
                                            type: "object",
                                            properties: {
                                                name: {
                                                    description: "Name of the initialization step",
                                                    type: "string"
                                                },
                                                startTime: {
                                                    description: "When the measure started, in milliseconds elapsed since the service worker started",
                                                    type: "number"
                                                },
                                                duration: {
                                                    description: "Duration that the step took in milliseconds",
                                                    type: "number"
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                subscriptions_reset: {
                    description: "Event logged when subscriptions are reset to defaults due to zero enabled subscriptions",
                    data: {
                        description: "Debug metadata about the subscription reset",
                        type: "object",
                        properties: {
                            subs: {
                                description: "The total number of subscriptions after reset",
                                type: "number"
                            },
                            enabledSubs: {
                                description: "The number of enabled subscriptions after reset",
                                type: "number"
                            },
                            enabledRulesets: {
                                description: "The number of enabled DNR rulesets after reset",
                                type: "number"
                            },
                            totalUserFilters: {
                                description: "The total number of user filters after reset",
                                type: "number"
                            },
                            dynamicRules: {
                                description: "The number of dynamic DNR rules after reset",
                                type: "number"
                            },
                            dataCorrupted: {
                                description: "Whether the data is corrupted. True if the extension has detected that storage has thrown an error.",
                                type: "boolean"
                            },
                            firstRun: {
                                description: "Whether this is the first run of the extension based on the number of subscriptions and user filters.",
                                type: "boolean"
                            },
                            reinitialized: {
                                description: "Whether the extension was reinitialized before reset.",
                                type: "boolean"
                            },
                            errorMsg: {
                                description: "An error that occurred when readding subscriptions, if any",
                                type: ["string", "null"]
                            },
                            lastErrorMsg: {
                                description: "The last error in the browser runtime, if any",
                                type: ["string", "null"]
                            }
                        }
                    }
                }
            },
            customer_lifecycle: {
                new_install_normal: {
                    description: "The extension was installed from the browser's official web store (Chrome Web Store, Firefox Add-ons, Microsoft Edge Add-ons)"
                },
                new_install_development: {
                    description: "The extension was installed manually in development mode, either as an unpacked directory or from a local .zip/.crx/.xpi package"
                },
                new_install_admin: {
                    description: "The extension was installed and managed by an administrator through a policy setting"
                },
                new_install_sideload: {
                    description: "The extension was installed by other software on the user's computer"
                },
                new_install_other: {
                    description: "The extension was installed through an unrecognized method not covered by other install types(normal/development/admin/sideload)"
                },
                new_install_unknown: {
                    description: "The extension was installed but the installation type could not be determined"
                },
                trial_license_expired: {
                    description: "The premium trial license has expired"
                }
            },
            new_tab: {
                command_ready: {
                    description: "'create_tab' IPM command has passed all checks and new tab is going to be created at the next possible opportunity",
                    data: {
                        description: "IPM command ID",
                        type: "string"
                    }
                },
                tab_created: {
                    description: "A tab has been created for the IPM command",
                    data: {
                        description: "IPM command ID",
                        type: "string"
                    }
                },
                tab_loaded: {
                    description: "The contents of the tab for the IPM command have been loaded",
                    data: {
                        description: "IPM command ID",
                        type: "string"
                    }
                }
            },
            onpage_dialog: {
                command_ready: {
                    description: "'create_on_page_dialog' IPM command has passed all checks and on-page dialog is going to be created at the next possible opportunity",
                    data: {
                        description: "IPM command ID",
                        type: "string"
                    }
                }
            },
            onpage_dialog_ui: {
                dialog_button_clicked: {
                    description: "The user clicked on the button presented on the dialog",
                    data: {
                        description: "IPM command ID",
                        type: "string"
                    }
                },
                dialog_closed: {
                    description: "The user closed the dialog by clicking the close icon in the dialog header",
                    data: {
                        description: "IPM command ID",
                        type: "string"
                    }
                },
                dialog_ignored: {
                    description: "The user did not interact with the dialog while being injected into the page, and the dialog no longer can be interacted with",
                    data: {
                        description: "IPM command ID",
                        type: "string"
                    }
                },
                dialog_injected: {
                    description: "The extension injected the dialog into the page and rendered it. This doesn't mean that the dialog is visible to the user, or that it looks as expected",
                    data: {
                        description: "IPM command ID",
                        type: "string"
                    }
                },
                dialog_display_duration: {
                    description: "How long the dialog was visible in MS before it was dismissed",
                    data: {
                        description: "Information about the dismissal",
                        type: "object",
                        properties: {
                            terminationCause: {
                                description: "Termination reason closed: tab_navigated or tab_removed",
                                type: "string"
                            },
                            durationMs: {
                                description: "How long the OPD was displayed",
                                type: "number"
                            },
                            ipmId: {
                                description: "The ID of the IPM OPD campaign",
                                type: "string"
                            }
                        }
                    }
                }
            },
            test_ewe_background: {
                test_event: {
                    description: "TEST: A logging test event for various types of data",
                    data: {
                        description: "Arbitrary test data",
                        type: "any"
                    }
                },
                test_event_no_data: {
                    description: "TEST: A logging test event that has no associated data"
                }
            },
            test_ewe_content_api: {
                test_got_experiment_flag: {
                    description: "TEST: In the content test script, an experiment was loaded",
                    data: {
                        description: "Information about the loaded experiment",
                        type: "object",
                        properties: {
                            flagName: {
                                description: "The flag name that was loaded",
                                type: "string"
                            },
                            flag: {
                                description: "The loaded value",
                                type: "any"
                            }
                        }
                    }
                }
            },
            test_ewe_ui_api: {
                test_message_received: {
                    description: "TEST: A logger test event indicating the UI page received a request to log",
                    data: {
                        description: "The data sent to the test listener",
                        type: "any"
                    }
                },
                test_event: {
                    description: "TEST: A logging test event for various types of data",
                    data: {
                        description: "Arbitrary test data",
                        type: "any"
                    }
                },
                test_event_no_data: {
                    description: "TEST: A logging test event that has no associated data"
                }
            },
            reverse_trial: {
                dialog_shown: {
                    description: "The reverse trial dialog was shown to the user",
                    data: {
                        description: "Details about the dialog shown",
                        type: "object",
                        properties: {
                            touchPointStep: {
                                description: "The touch point step number of the dialog shown",
                                type: "number"
                            },
                            installDate: {
                                description: "The timestamp when the extension was installed",
                                type: "number"
                            },
                            reverseTrialStartDate: {
                                description: "The timestamp when the reverse trial started",
                                type: "number"
                            }
                        }
                    }
                },
                dialog_skipped_yt_premium: {
                    description: "The reverse trial dialog would have been shown but was skipped because the user has YouTube Premium",
                    data: {
                        description: "Details about the skipped dialog",
                        type: "object",
                        properties: {
                            touchPointStep: {
                                description: "The touch point step number of the dialog that was skipped",
                                type: "number"
                            },
                            installDate: {
                                description: "The timestamp when the extension was installed",
                                type: "number"
                            },
                            reverseTrialStartDate: {
                                description: "The timestamp when the reverse trial started",
                                type: "number"
                            }
                        }
                    }
                },
                dialog_should_still_show_checked: {
                    description: "The service worker checked whether a visible reverse trial dialog should still be shown after the tab became active",
                    data: {
                        description: "Details about the check",
                        type: "object",
                        properties: {
                            touchPointStep: {
                                description: "The touch point step number of the dialog being checked",
                                type: "number"
                            },
                            shouldStillShow: {
                                description: "Whether the dialog should remain visible",
                                type: "boolean"
                            },
                            installDate: {
                                description: "The timestamp when the extension was installed",
                                type: "number"
                            },
                            reverseTrialStartDate: {
                                description: "The timestamp when the reverse trial started",
                                type: "number"
                            }
                        }
                    }
                },
                dialog_action: {
                    description: "The user interacted with the reverse trial dialog",
                    data: {
                        description: "Details about the interaction",
                        type: "object",
                        properties: {
                            action: {
                                description: "Identifier of the clicked element: the i18n key of a configured ctaButton or link (e.g. 'mid_cta', 'mid_end_trial'), or an uppercase built-in value ('CLOSE' for the x button, 'AUTO_DISMISS' for the auto-dismiss timeout)",
                                type: "string"
                            },
                            touchPointStep: {
                                description: "The touch point step number of the dialog that was interacted with",
                                type: "number"
                            },
                            installDate: {
                                description: "The timestamp when the extension was installed",
                                type: "number"
                            },
                            reverseTrialStartDate: {
                                description: "The timestamp when the reverse trial started",
                                type: "number"
                            }
                        }
                    }
                },
                config_validation_failed: {
                    description: "The remote reverse-trial OPD config failed validation. Fires at load time when the experiment flag is present but the schema is invalid (e.g. missing field, unknown action type, URL not on the allowlist), and at runtime when a NAVIGATE URL fails the allowlist check after template substitution. The full URL is intentionally not logged because template variables may contain PII.",
                    data: {
                        description: "Details about the validation failure.",
                        type: "object",
                        properties: {
                            reason: {
                                description: "Why validation failed. Load-time reasons include 'config_missing' (flag absent despite the user being in a reverse-trial variant), 'trial_duration_days_invalid', 'require_opt_in_invalid', 'steps_invalid', 'step_id_invalid', 'step_title_invalid', 'step_body_invalid', 'step_i18n_en_missing', 'step_i18n_key_missing_in_en', 'navigate_url_missing', 'navigate_url_not_allowlisted', 'action_type_unknown'. Runtime reason is 'url_validation_failed_after_substitution'.",
                                type: "string"
                            },
                            hostname: {
                                description: "Hostname of the failing URL for runtime URL validation failures; absent for load-time schema failures.",
                                type: "string"
                            }
                        }
                    }
                }
            },
            remote_config: {
                validation_error: {
                    description: "The remote config failed validation and was not applied.",
                    data: {
                        description: "The error messages from the validator.",
                        type: "array",
                        items: {
                            type: "string"
                        }
                    }
                },
                invalid_condition: {
                    description: "The remote config contained conditions referencing facts or operators not recognized by this client version. The config was applied; affected conditions should be skipped at evaluation time.",
                    data: {
                        description: "The warning messages from the validator for each unrecognized fact or operator.",
                        type: "array",
                        items: {
                            type: "string"
                        }
                    }
                }
            }
        });
        ;
        const DEBUG = 1;
        const INFO = 2;
        const BEHAVIOR = 3;
        const WARN = 4;
        const OFF = 5;
        const logLevelNamesToNumbers = {
            debug: DEBUG,
            info: INFO,
            behavior: BEHAVIOR,
            warn: WARN,
            off: OFF
        };
        const logLevelNumbersToNames = Object.fromEntries(Object.entries(logLevelNamesToNumbers).map(([key, value]) => [value, key]));
        function isPlainObject(obj) {
            if (obj === null || typeof obj !== "object") {
                return false;
            }
            const proto = Object.getPrototypeOf(obj);
            return proto === Object.prototype || proto === null;
        }
        function isSerializableToJson(data, seen = new WeakSet()) {
            let type = typeof data;
            if (data === null || type == "undefined" || type == "string" || type == "boolean") {
                return true;
            }
            if (type == "number") {
                return Number.isFinite(data);
            }
            if (isPlainObject(data)) {
                if (seen.has(data)) {
                    return false;
                }
                seen.add(data);
                return Object.values(data).every(x => isSerializableToJson(x, seen));
            }
            if (Array.isArray(data)) {
                if (seen.has(data)) {
                    return false;
                }
                seen.add(data);
                return data.every(x => isSerializableToJson(x, seen));
            }
            return false;
        }
        function matchesEventSchema(data, dataSchema) {
            let dataType = typeof data;
            if (dataType === "undefined" || !dataSchema) {
                return (dataType === "undefined" || data === null) && !dataSchema;
            }
            let types = dataSchema.type;
            if (typeof types === "string") {
                types = [types];
            }
            let typeMatches = types.some(type => {
                switch (type) {
                    case "any":
                        return true;
                    case "boolean":
                    case "number":
                    case "string":
                        return dataType === type;
                    case "null":
                        return data === null;
                    case "integer":
                        return Number.isInteger(data);
                    case "object":
                        return isPlainObject(data) &&
                            Object.keys(dataSchema.properties).every(key => matchesEventSchema(data[key], dataSchema.properties[key]));
                    case "array":
                        return Array.isArray(data) && data.every(item => matchesEventSchema(item, dataSchema.items));
                }
                return false;
            });
            if (!typeMatches) {
                return false;
            }
            if (typeof dataSchema.enum !== "undefined") {
                if (!dataSchema.enum.includes(data)) {
                    return false;
                }
            }
            return true;
        }
        class AbstractLogger {
            constructor(module, defaultEvents = events) {
                this._module = module;
                this._events = defaultEvents;
                if (!this._events[this._module]) {
                    console.error(`Unknown module: ${module}. ` +
                        "Did you remember to add it to core/sdk/events.js?");
                }
            }
            _log(level, event, data, ipmId) {
                if (!this._events[this._module]) {
                    return;
                }
                if (!this._events[this._module][event]) {
                    console.error(`Unknown event: ${event} in module: ${this._module}. ` +
                        "Did you remember to add it to core/sdk/events.js?");
                    return;
                }
                if (!isSerializableToJson(data)) {
                    console.error(`Data for event: ${event} in module: ${this._module} cannot be serialized to JSON.`);
                    return;
                }
                const dataSchema = this._events[this._module][event].data;
                if (!matchesEventSchema(data, dataSchema)) {
                    console.error(`Data for event: ${event} in module: ${this._module} does not match the schema ` +
                        "provided in core/sdk/events.js. ", { data, dataSchema });
                    return;
                }
                const logTime = new Date().toISOString();
                this._validatedLog(logTime, level, event, data, ipmId);
            }
            _validatedLog(logTime, level, event, data, ipmId) {
            }
            debug(event, data) {
                this._log(DEBUG, event, data);
            }
            info(event, data) {
                this._log(INFO, event, data);
            }
            behavior(event, data, ipmId) {
                this._log(BEHAVIOR, event, data, ipmId);
            }
            warn(event, data) {
                this._log(WARN, event, data);
            }
        }
        ;
        class ServerLogger extends AbstractLogger {
            _validatedLog(logTime, level, event, data) {
                void ignoreNoConnectionError(browser_polyfill.runtime.sendMessage({
                    type: "ewe:telemetry-log",
                    logTime,
                    module: this._module,
                    level,
                    event,
                    data
                }));
            }
        }
        const telemetry = ({
            ServerLogger
        });
        ;
        return __nested_webpack_exports__;
    })();
});

});

;// ./js/dom.mjs
const $ = (selector, container) => {
    if (!container)
        container = document;
    return container.querySelector(selector);
};
const $$ = (selector, container) => {
    if (!container)
        container = document;
    return container.querySelectorAll(selector);
};
const clipboard = {
    copy(text) {
        const selection = document.getSelection();
        const selected = selection.rangeCount > 0 ? selection.getRangeAt(0) : null;
        const el = document.createElement("textarea");
        el.value = text;
        el.setAttribute("readonly", "");
        el.style.cssText = "position:fixed;top:-999px";
        document.body.appendChild(el).select();
        document.execCommand("copy");
        document.body.removeChild(el);
        if (selected) {
            selection.removeAllRanges();
            const range = document.createRange();
            range.setStart(selected.startContainer, selected.startOffset);
            range.setEnd(selected.endContainer, selected.endOffset);
            selection.addRange(range);
        }
    },
    paste(event) {
        if (!event)
            event = window;
        const clipboardData = event.clipboardData || window.clipboardData;
        return clipboardData ? clipboardData.getData("text") : "";
    }
};
function relativeCoordinates(event) {
    return { x: event.offsetX, y: event.offsetY };
}
function asIndentedString(element, indentation = 0) {
    if (!indentation) {
        if (element.nodeType === Node.DOCUMENT_NODE)
            element = element.documentElement;
        if (element.nodeType !== Node.ELEMENT_NODE)
            throw new Error("Unable to serialize " + element);
        element = element.cloneNode(true);
    }
    const before = "  ".repeat(indentation + 1);
    const after = "  ".repeat(indentation);
    const doc = element.ownerDocument;
    for (const child of Array.from(element.childNodes)) {
        const { nodeType } = child;
        if (nodeType === Node.ELEMENT_NODE || nodeType === Node.TEXT_NODE) {
            if (nodeType === Node.TEXT_NODE) {
                const content = child.textContent.trim();
                child.textContent = content.length ? `\n${before}${content}` : "";
            }
            else {
                element.insertBefore(doc.createTextNode(`\n${before}`), child);
                asIndentedString(child, indentation + 1);
            }
        }
        if (child === element.lastChild)
            element.appendChild(doc.createTextNode(`\n${after}`));
    }
    if (indentation)
        return "";
    if (/^https?:\/\/www\.w3\.org\/1999\/xhtml$/.test(element.namespaceURI))
        return element.outerHTML;
    return new XMLSerializer().serializeToString(element);
}

;// ./js/pages/desktop-options/add-filters-by-url.mjs

let ignoreFocus = false;
function closeAddFiltersByURL() {
    if (!isClosed()) {
        ignoreFocus = false;
        $("[data-action='open-filterlist-by-url']").focus();
    }
}
function setupAddFiltersByURL() {
    const wrapper = $("#filterlist-by-url-wrap");
    wrapper.addEventListener("blur", filtersBlur, true);
    wrapper.addEventListener("keydown", filtersKeydown);
    const opener = $("[data-action='open-filterlist-by-url']", wrapper);
    opener.addEventListener("mousedown", filtersToggle);
    opener.addEventListener("focus", filtersToggle);
    opener.addEventListener("keydown", openerKeys);
    const input = $("input[type='url']", wrapper);
    input.addEventListener("keyup", checkIfValid);
}
function checkIfValid(event) {
    const { currentTarget } = event;
    const isValid = currentTarget.checkValidity();
    currentTarget.setAttribute("aria-invalid", !isValid);
    let errorText = "";
    if (!isValid) {
        const url = currentTarget.value;
        if (url) {
            let errorId = null;
            if (!new RegExp(currentTarget.pattern).test(url)) {
                errorId = "options_dialog_import_subscription_location_error_protocol";
            }
            else {
                errorId = "options_dialog_import_subscription_location_error";
            }
            errorText = browser.i18n.getMessage(errorId);
        }
    }
    $("#import-list-url ~ .error-msg").textContent = errorText;
}
function filtersBlur() {
    setTimeout((wrapper) => {
        const { activeElement } = document;
        if (!activeElement || !wrapper.contains(activeElement)) {
            filtersClose();
        }
    }, 0, $("#filterlist-by-url-wrap"));
}
function filtersClose() {
    $("#filterlist-by-url").setAttribute("aria-hidden", "true");
}
function filtersKeydown(event) {
    if (isClosed())
        return;
    const { key } = event;
    if (key !== "Enter" && key !== "Escape")
        return;
    event.preventDefault();
    event.stopPropagation();
    switch (key) {
        case "Enter":
            $("[data-action='validate-import-subscription']").click();
            break;
        case "Escape":
            $("[data-action='open-filterlist-by-url']").focus();
            filtersClose();
            break;
    }
}
function filtersOpen() {
    const element = $("#filterlist-by-url");
    element.removeAttribute("aria-hidden");
    $("input[type='url']", element).focus();
}
function filtersToggle(event) {
    if (ignoreFocus) {
        ignoreFocus = false;
        return;
    }
    const { currentTarget } = event;
    const { activeElement } = document;
    ignoreFocus = event.type === "mousedown" && currentTarget !== activeElement;
    if (isClosed()) {
        event.preventDefault();
        filtersOpen();
    }
    else {
        filtersClose();
    }
}
function isClosed() {
    return $("#filterlist-by-url").getAttribute("aria-hidden") === "true";
}
function openerKeys(event) {
    switch (event.key) {
        case " ":
        case "Enter":
            ignoreFocus = false;
            filtersToggle(event);
            break;
    }
}

;// ./js/pages/desktop-options/titles.mjs
const { getMessage } = browser.i18n;
let languageNames = new Map();
function getRawItemTitle(item) {
    return item.title || item.originalTitle || item.url || item.text;
}
function getLanguageItemTitle(item) {
    const description = item.languages
        .map((langCode) => languageNames.get(langCode))
        .filter((langName, idx, arr) => arr.indexOf(langName) === idx)
        .reduce((acc, langName, idx) => {
        if (idx === 0)
            return langName;
        return getMessage("options_language_join", [acc, langName]);
    }, "");
    if (/\+EasyList$/.test(getRawItemTitle(item)))
        return `${description} + ${getMessage("options_english")}`;
    return description;
}
function getPrettyItemTitle(item, includeRaw) {
    const { recommended } = item;
    let description = null;
    if (recommended === "ads") {
        description = getLanguageItemTitle(item);
    }
    else {
        description = getMessage(`common_feature_${recommended.replace(/-/g, "_")}_title`);
    }
    if (!description)
        return getRawItemTitle(item);
    if (includeRaw)
        return `${getRawItemTitle(item)} (${description})`;
    return description;
}
async function loadLanguageNames() {
    const resp = await fetch("./data/locales.json");
    const localeData = await resp.json();
    languageNames = new Map(Object.entries(localeData.nativeNames));
}

;// ./src/core/messaging/shared/emitter.ts
class MessageEmitter {
    constructor() {
        this.listeners = new Set();
    }
    addListener(listener) {
        this.listeners.add(listener);
    }
    removeListener(listener) {
        this.listeners.delete(listener);
    }
    dispatch(message, sender) {
        const results = [];
        for (const listener of this.listeners) {
            results.push(listener(message, sender));
        }
        return results;
    }
}

;// ./src/core/messaging/shared/messaging.ts
function getMessageResponse(responses) {
    for (const response of responses) {
        if (typeof response !== "undefined") {
            return response;
        }
    }
}
function isEventMessage(candidate) {
    return isMessage(candidate) && "action" in candidate && "args" in candidate;
}
function isMessage(candidate) {
    return (candidate !== null && typeof candidate === "object" && "type" in candidate);
}
function isListenMessage(candidate) {
    return isMessage(candidate) && "filter" in candidate;
}
function isPremiumSubscriptionsAddRemoveOptions(candidate) {
    return (candidate !== null &&
        typeof candidate === "object" &&
        "subscriptionType" in candidate);
}

;// ./src/core/messaging/front/messaging.ts

let port;
const connectListeners = new Set();
const disconnectListeners = new Set();
const messageListeners = new Set();
const messageEmitter = new MessageEmitter();
function addConnectListener(listener) {
    connectListeners.add(listener);
    listener();
}
function addDisconnectListener(listener) {
    disconnectListeners.add(listener);
}
function addMessageListener(listener) {
    messageListeners.add(listener);
}
const connect = () => {
    if (port) {
        return port;
    }
    try {
        port = browser.runtime.connect({ name: "ui" });
    }
    catch (ex) {
        port = null;
        disconnectListeners.forEach((listener) => {
            listener();
        });
        return port;
    }
    port.onMessage.addListener((message) => {
        if (!isMessage(message)) {
            return;
        }
        onMessage(message);
    });
    port.onDisconnect.addListener(onDisconnect);
    connectListeners.forEach((listener) => {
        listener();
    });
    return port;
};
function isContentScript() {
    const extensionUrl = new URL(browser.runtime.getURL("/"));
    return location.protocol !== extensionUrl.protocol;
}
function listen({ type, filter, ...options }) {
    addConnectListener(() => {
        if (port) {
            port.postMessage({
                type: `${type}.listen`,
                filter,
                ...options
            });
        }
    });
}
function onDisconnect() {
    port = null;
    setTimeout(() => connect(), 100);
}
function onMessage(message) {
    if (!message.type.endsWith(".respond")) {
        return;
    }
    messageListeners.forEach((listener) => {
        listener(message);
    });
}
function removeDisconnectListener(listener) {
    disconnectListeners.delete(listener);
}
function start() {
    if (!isContentScript()) {
        connect();
    }
    if (typeof browser.devtools === "undefined") {
        browser.runtime.onMessage.addListener((message, sender) => {
            if (!isMessage(message)) {
                return;
            }
            const responses = messageEmitter.dispatch(message, sender);
            const response = getMessageResponse(responses);
            if (typeof response === "undefined") {
                return;
            }
            return Promise.resolve(response);
        });
    }
}
start();

;// ./src/core/messaging/front/utils.ts
async function send(sendType, options = {}) {
    const args = {
        ...options,
        type: sendType
    };
    return await browser.runtime.sendMessage(args);
}

;// ./src/core/messaging/front/category-app.ts


const platformToStore = new Map([
    ["chromium", "chrome"],
    ["edgehtml", "edge"],
    ["gecko", "firefox"]
]);
async function get(what) {
    const options = { what };
    return await send("app.get", options);
}
async function getInfo() {
    var _a;
    const [application, platform] = await Promise.all([
        get("application"),
        get("platform")
    ]);
    let store;
    if (application !== "edge" && application !== "opera") {
        store = (_a = platformToStore.get(platform)) !== null && _a !== void 0 ? _a : "chrome";
    }
    else {
        store = application;
    }
    return {
        application,
        manifestVersion: browser.runtime.getManifest().manifest_version,
        platform,
        store
    };
}
function category_app_listen(filter) {
    listen({ type: "app", filter });
}
async function category_app_open(what, parameters = {}) {
    const options = { what, ...parameters };
    await send("app.open", options);
}
async function getAdFilteringState() {
    return await send("app.getAdFilteringState");
}
async function category_app_close() {
    await send("app.close");
}

;// ./src/core/messaging/front/category-ctalinks.ts

async function category_ctalinks_get(link, queryParams = {}) {
    const options = {
        what: "ctalink",
        link,
        queryParams
    };
    return await send("app.get", options);
}

;// ./src/core/messaging/front/category-doclinks.ts

async function category_doclinks_get(link) {
    const options = { what: "doclink", link };
    return await send("app.get", options);
}

;// ./src/core/messaging/front/category-filters.ts


async function category_filters_get() {
    return await send("filters.get");
}
function category_filters_listen(filter) {
    listen({ type: "filters", filter });
}

;// ./src/core/messaging/front/category-prefs.ts


async function category_prefs_get(key) {
    const options = { key };
    return await send("prefs.get", options);
}
function category_prefs_listen(filter) {
    listen({ type: "prefs", filter });
}

;// ./src/core/messaging/front/category-premium.ts


async function add(subscriptionType) {
    const options = { subscriptionType };
    await send("premium.subscriptions.add", options);
}
async function category_premium_get() {
    return await send("premium.get");
}
async function getPremiumSubscriptionsState() {
    return await send("premium.subscriptions.getState");
}
function category_premium_listen(filter) {
    listen({ type: "premium", filter });
}
async function remove(subscriptionType) {
    const options = { subscriptionType };
    await send("premium.subscriptions.remove", options);
}

;// ./src/core/messaging/front/category-requests.ts
/* unused harmony import specifier */ var messaging;

function category_requests_listen(filter, tabId) {
    messaging.listen({ type: "requests", filter, tabId });
}

;// ./src/core/messaging/front/category-stats.ts
/* unused harmony import specifier */ var category_stats_messaging;
/* unused harmony import specifier */ var category_stats_send;


async function getBlockedPerPage(tab) {
    const options = { tab };
    return await category_stats_send("stats.getBlockedPerPage", options);
}
async function getBlockedTotal() {
    return await category_stats_send("stats.getBlockedTotal");
}
function category_stats_listen(filter) {
    category_stats_messaging.listen({ type: "stats", filter });
}

;// ./src/core/messaging/front/category-subscriptions.ts


async function category_subscriptions_add(url) {
    const options = { url };
    return await send("subscriptions.add", options);
}
async function category_subscriptions_get(options) {
    return await send("subscriptions.get", options !== null && options !== void 0 ? options : {});
}
async function getInitIssues() {
    return await send("subscriptions.getInitIssues");
}
async function getRecommendations() {
    return await send("subscriptions.getRecommendations");
}
function category_subscriptions_listen(filter) {
    listen({ type: "subscriptions", filter });
}
async function category_subscriptions_remove(url) {
    const options = { url };
    await send("subscriptions.remove", options);
}

;// ./src/core/messaging/front/category-debug.ts

async function category_debug_getInfo() {
    return await send("debug.getInfo");
}

;// ./src/core/messaging/front/index.ts




















;// ../../node_modules/@eyeo-fragments/filter-experiments/dist/shared/sync-filters.types.js
const ORIGIN_ID = "experiment";

;// ./src/filters/shared/filter.types.ts

var FilterOrigin;
(function (FilterOrigin) {
    FilterOrigin["popup"] = "popup";
    FilterOrigin["web"] = "web";
    FilterOrigin["devtools"] = "devtools";
    FilterOrigin["composer"] = "composer";
    FilterOrigin["optionsAllowlistedWebsites"] = "options-allowlisted-websites";
    FilterOrigin["optionsMobile"] = "options-mobile";
    FilterOrigin["optionsAdvanced"] = "options-advanced";
    FilterOrigin[FilterOrigin["experiment"] = ORIGIN_ID] = "experiment";
})(FilterOrigin || (FilterOrigin = {}));

;// ./src/filters/shared/index.ts


;// ./src/premium-subscriptions/shared/premium-subscriptions.types.ts
const ANNOYANCE_SUBSCRIPTION_TYPE = "annoyances";
const COOKIES_PREMIUM_SUBSCRIPTION_TYPE = "cookies-premium";

;// ./src/premium-subscriptions/shared/premium-subscriptions.ts

const premiumTypes = new Set([
    ANNOYANCE_SUBSCRIPTION_TYPE,
    COOKIES_PREMIUM_SUBSCRIPTION_TYPE
]);

;// ./src/premium-subscriptions/shared/index.ts



;// ./src/polyfills/ui/desktop-options.ts
function isInitialRecommendedSubscription(item) {
    return (item !== null &&
        typeof item === "object" &&
        "disabled" in item &&
        "downloadStatus" in item &&
        "homepage" in item &&
        "languages" in item &&
        "recommended" in item &&
        "title" in item &&
        "url" in item);
}
function isRecommendedSubscription(item) {
    return (item !== null &&
        typeof item === "object" &&
        "disabled" in item &&
        "languages" in item &&
        "recommended" in item &&
        "title" in item &&
        "updatable" in item &&
        "url" in item &&
        "version" in item);
}
function isCollectionSubscription(item) {
    return (isInitialRecommendedSubscription(item) || isRecommendedSubscription(item));
}

;// ./src/premium/shared/state.ts
function isPremiumState(candidate) {
    return (candidate !== null &&
        typeof candidate === "object" &&
        "isActive" in candidate);
}

;// ./src/premium-subscriptions/ui/desktop-options.ts






function updateListItem(listItem, premiumIsActive) {
    if (!listItem) {
        return;
    }
    const checkbox = $("button[role='checkbox']", listItem);
    if (!checkbox) {
        return;
    }
    checkbox.toggleAttribute("disabled", !premiumIsActive);
    const { recommended } = listItem.dataset;
    if (recommended === "cookies-premium") {
        const checked = checkbox.getAttribute("aria-checked") === "true";
        if (checked) {
            checkbox.setAttribute("data-action", "toggle-remove-subscription");
            checkbox.removeAttribute("data-dialog");
        }
        else {
            checkbox.setAttribute("data-action", "open-dialog");
            checkbox.setAttribute("data-dialog", "optIn-premium-subscription");
        }
    }
}
function updateListItems(premiumIsActive) {
    const premiumListItems = $$("#premium-list-table li");
    premiumListItems.forEach((listItem) => {
        updateListItem(listItem, premiumIsActive);
    });
}
function getRecommendedListItem(recommended) {
    const listItem = $(`#premium-list-table li[data-recommended="${recommended}"]`);
    if (!(listItem instanceof HTMLElement)) {
        return null;
    }
    return listItem;
}
async function onCollectionItemUpdated(item) {
    if (!isCollectionSubscription(item)) {
        return;
    }
    if (premiumTypes.has(item.recommended)) {
        const listItem = getRecommendedListItem(item.recommended);
        if (!listItem) {
            return;
        }
        const { isActive: premiumIsActive } = await category_premium_get();
        updateListItem(listItem, premiumIsActive);
        if (item.recommended === COOKIES_PREMIUM_SUBSCRIPTION_TYPE) {
            listItem.classList.add("new");
        }
    }
}
function onApiMessage(message) {
    if (!isEventMessage(message) ||
        message.type !== "premium.respond" ||
        !isPremiumState(message.args[0])) {
        return;
    }
    const premiumIsActive = message.args[0].isActive;
    updateListItems(premiumIsActive);
}
async function desktop_options_start(optionsPageEmitter) {
    const { isActive: premiumIsActive } = await category_premium_get();
    updateListItems(premiumIsActive);
    optionsPageEmitter.on("collectionItem.updated", onCollectionItemUpdated);
    addMessageListener(onApiMessage);
}

;// ./src/premium-subscriptions/ui/index.ts


;// ./js/common.mjs
function convertDoclinks() {
    const links = document.querySelectorAll("a[data-doclink]");
    for (const link of links) {
        getDoclink(link.dataset.doclink).then((url) => {
            link.target = link.target || "_blank";
            link.href = url;
        });
    }
}
function getDoclink(link) {
    return browser.runtime.sendMessage({
        type: "app.get",
        what: "doclink",
        link
    });
}
function getErrorMessage(error) {
    let message = null;
    if (error) {
        let messageId = error.reason || error.type;
        let placeholders = [];
        if (error.reason === "filter_unknown_option") {
            if (error.option)
                placeholders = [error.option];
            else
                messageId = "filter_invalid_option";
        }
        message = browser.i18n.getMessage(messageId, placeholders);
    }
    if (!message) {
        message = browser.i18n.getMessage("filter_action_failed");
    }
    if (!error || typeof error.lineno !== "number")
        return message;
    return browser.i18n.getMessage("line", [
        error.lineno.toLocaleString(),
        message
    ]);
}
function getSourceAttribute(element) {
    const sourceContainer = element.closest("[data-source]");
    if (!sourceContainer)
        return null;
    return sourceContainer.dataset.source;
}

;// ./adblockpluschrome/lib/events.js
class EventEmitter {
    constructor() {
        this._listeners = new Map();
    }
    on(name, listener) {
        let listeners = this._listeners.get(name);
        if (listeners)
            listeners.push(listener);
        else
            this._listeners.set(name, [listener]);
    }
    off(name, listener) {
        let listeners = this._listeners.get(name);
        if (listeners) {
            if (listeners.length > 1) {
                let idx = listeners.indexOf(listener);
                if (idx != -1)
                    listeners.splice(idx, 1);
            }
            else if (listeners[0] === listener) {
                this._listeners.delete(name);
            }
        }
    }
    listeners(name) {
        let listeners = this._listeners.size > 0 ? this._listeners.get(name) : null;
        return listeners ? listeners.slice() : [];
    }
    hasListeners(name) {
        return (this._listeners.size > 0 &&
            (typeof name == "undefined" || this._listeners.has(name)));
    }
    emit(name, ...args) {
        let listeners = this._listeners.size > 0 ? this._listeners.get(name) : null;
        if (listeners)
            for (let listener of listeners.slice())
                listener(...args);
    }
}

// EXTERNAL MODULE: ../../node_modules/webextension-polyfill/src/browser-polyfill.js
var browser_polyfill = __webpack_require__(3651);
var browser_polyfill_default = /*#__PURE__*/__webpack_require__.n(browser_polyfill);
;// ./src/i18n/ui/i18n.ts

const i18nAttributes = ["alt", "placeholder", "title", "value"];
function assignAction(elements, action) {
    for (const element of elements) {
        switch (typeof action) {
            case "string":
                element.href = action;
                element.target = "_blank";
                break;
            case "function":
                element.href = "#";
                element.addEventListener("click", (ev) => {
                    ev.preventDefault();
                    action();
                });
                break;
        }
    }
}
function* getRemainingLinks(parent) {
    const links = parent.querySelectorAll("a:not([data-i18n-index])");
    for (const link of links) {
        yield link;
    }
}
function setElementLinks(idOrElement, ...actions) {
    var _a;
    const element = typeof idOrElement === "string"
        ? document.getElementById(idOrElement)
        : idOrElement;
    if (element === null) {
        return;
    }
    const remainingLinks = getRemainingLinks(element);
    for (let i = 0; i < actions.length; i++) {
        const links = element.querySelectorAll(`a[data-i18n-index='${i}']`);
        if (links.length > 0) {
            assignAction(links, actions[i]);
            continue;
        }
        const link = remainingLinks.next();
        if ((_a = link.done) !== null && _a !== void 0 ? _a : false) {
            continue;
        }
        assignAction([link.value], actions[i]);
    }
}
function stripTagsUnsafe(text) {
    return text.replace(/<\/?[^>]+>/g, "");
}
function setElementText(element, stringName, args, children = []) {
    function processString(str, currentElement) {
        const match = /^(.*?)<(a|em|slot|strong)(\d)?>(.*?)<\/\2\3>(.*)$/.exec(str);
        if (match !== null) {
            const [, before, name, index, innerText, after] = match;
            processString(before, currentElement);
            if (name === "slot") {
                const e = children[Number(index)];
                if (e !== undefined) {
                    currentElement.appendChild(e);
                }
            }
            else {
                const e = document.createElement(name);
                if (typeof index !== "undefined") {
                    e.dataset.i18nIndex = index;
                }
                processString(innerText, e);
                currentElement.appendChild(e);
            }
            processString(after, currentElement);
        }
        else {
            currentElement.appendChild(document.createTextNode(str));
        }
    }
    while (element.lastChild !== null) {
        element.removeChild(element.lastChild);
    }
    processString(browser_polyfill_default().i18n.getMessage(stringName, args !== null && args !== void 0 ? args : undefined), element);
}
function loadI18nStrings() {
    function resolveStringNames(container) {
        var _a, _b;
        if (container === null || container === undefined) {
            return;
        }
        {
            const elements = container.querySelectorAll("[data-i18n]");
            for (const element of elements) {
                const children = Array.from(element.children);
                setElementText(element, (_a = element.dataset.i18n) !== null && _a !== void 0 ? _a : "", null, children);
            }
        }
        for (const attr of i18nAttributes) {
            const elements = container.querySelectorAll(`[data-i18n-${attr}]`);
            for (const element of elements) {
                const stringName = (_b = element.getAttribute(`data-i18n-${attr}`)) !== null && _b !== void 0 ? _b : "";
                element.setAttribute(attr, browser_polyfill_default().i18n.getMessage(stringName));
            }
        }
    }
    resolveStringNames(document);
    for (const template of document.querySelectorAll("template")) {
        resolveStringNames(template.content);
    }
}
function isLocaleInfo(candidate) {
    return (candidate !== null &&
        typeof candidate === "object" &&
        "bidiDir" in candidate &&
        "locale" in candidate);
}
async function setLanguageAttributes() {
    const localeInfo = await browser_polyfill_default().runtime.sendMessage({
        type: "app.get",
        what: "localeInfo"
    });
    if (!isLocaleInfo(localeInfo)) {
        return;
    }
    document.documentElement.lang = localeInfo.locale;
    document.documentElement.dir = localeInfo.bidiDir;
}
function initI18n() {
    void setLanguageAttributes();
    loadI18nStrings();
}

;// ./src/i18n/ui/index.ts


// EXTERNAL MODULE: ./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].use[1]!../../node_modules/postcss-loader/dist/cjs.js!./src/desktop-options/ui/desktop-options.css
var desktop_options = __webpack_require__(544);
;// ./src/desktop-options/ui/desktop-options.css

      
      
      
      
      
      
      
      
      

var desktop_options_options = {};

desktop_options_options.styleTagTransform = (styleTagTransform_default());
desktop_options_options.setAttributes = (setAttributesWithoutAttributes_default());

      desktop_options_options.insert = insertBySelector_default().bind(null, "head");
    
desktop_options_options.domAPI = (styleDomAPI_default());
desktop_options_options.insertStyleElement = (insertStyleElement_default());

var desktop_options_update = injectStylesIntoStyleTag_default()(desktop_options/* default */.A, desktop_options_options);




       /* harmony default export */ const ui_desktop_options = (desktop_options/* default */.A && desktop_options/* default */.A.locals ? desktop_options/* default */.A.locals : undefined);

;// ../../node_modules/@ungap/weakmap/esm/index.js
var esm_self = {};
try {
    esm_self.WeakMap = WeakMap;
}
catch (WeakMap) {
    esm_self.WeakMap = (function (id, Object) {
        'use strict';
        var dP = Object.defineProperty;
        var hOP = Object.hasOwnProperty;
        var proto = WeakMap.prototype;
        proto.delete = function (key) {
            return this.has(key) && delete key[this._];
        };
        proto.get = function (key) {
            return this.has(key) ? key[this._] : void 0;
        };
        proto.has = function (key) {
            return hOP.call(key, this._);
        };
        proto.set = function (key, value) {
            dP(key, this._, { configurable: true, value: value });
            return this;
        };
        return WeakMap;
        function WeakMap(iterable) {
            dP(this, '_', { value: '_@ungap/weakmap' + id++ });
            if (iterable)
                iterable.forEach(add, this);
        }
        function add(pair) {
            this.set(pair[0], pair[1]);
        }
    }(Math.random(), Object));
}
/* harmony default export */ const esm = (esm_self.WeakMap);

;// ../../node_modules/@ungap/essential-weakset/esm/index.js
var essential_weakset_esm_self = {};
try {
    essential_weakset_esm_self.WeakSet = WeakSet;
}
catch (WeakSet) {
    (function (id, dP) {
        var proto = WeakSet.prototype;
        proto.add = function (object) {
            if (!this.has(object))
                dP(object, this._, { value: true, configurable: true });
            return this;
        };
        proto.has = function (object) {
            return this.hasOwnProperty.call(object, this._);
        };
        proto.delete = function (object) {
            return this.has(object) && delete object[this._];
        };
        essential_weakset_esm_self.WeakSet = WeakSet;
        function WeakSet() {
            'use strict';
            dP(this, '_', { value: '_@ungap/weakmap' + id++ });
        }
    }(Math.random(), Object.defineProperty));
}
/* harmony default export */ const essential_weakset_esm = (essential_weakset_esm_self.WeakSet);

;// ../../node_modules/uarray/esm/index.js
const { isArray } = Array;
const { indexOf, slice } = [];


;// ../../node_modules/domdiff/esm/utils.js

const append = (get, parent, children, start, end, before) => {
    const isSelect = 'selectedIndex' in parent;
    let noSelection = isSelect;
    while (start < end) {
        const child = get(children[start], 1);
        parent.insertBefore(child, before);
        if (isSelect && noSelection && child.selected) {
            noSelection = !noSelection;
            let { selectedIndex } = parent;
            parent.selectedIndex = selectedIndex < 0 ?
                start :
                indexOf.call(parent.querySelectorAll('option'), child);
        }
        start++;
    }
};
const eqeq = (a, b) => a == b;
const identity = O => O;
const utils_indexOf = (moreNodes, moreStart, moreEnd, lessNodes, lessStart, lessEnd, compare) => {
    const length = lessEnd - lessStart;
    if (length < 1)
        return -1;
    while ((moreEnd - moreStart) >= length) {
        let m = moreStart;
        let l = lessStart;
        while (m < moreEnd &&
            l < lessEnd &&
            compare(moreNodes[m], lessNodes[l])) {
            m++;
            l++;
        }
        if (l === lessEnd)
            return moreStart;
        moreStart = m + 1;
    }
    return -1;
};
const isReversed = (futureNodes, futureEnd, currentNodes, currentStart, currentEnd, compare) => {
    while (currentStart < currentEnd &&
        compare(currentNodes[currentStart], futureNodes[futureEnd - 1])) {
        currentStart++;
        futureEnd--;
    }
    ;
    return futureEnd === 0;
};
const next = (get, list, i, length, before) => i < length ?
    get(list[i], 0) :
    (0 < i ?
        get(list[i - 1], -0).nextSibling :
        before);
const utils_remove = (get, children, start, end) => {
    while (start < end)
        drop(get(children[start++], -1));
};
const DELETION = -1;
const INSERTION = 1;
const SKIP = 0;
const SKIP_OND = 50;
const HS = (futureNodes, futureStart, futureEnd, futureChanges, currentNodes, currentStart, currentEnd, currentChanges) => {
    let k = 0;
    let minLen = futureChanges < currentChanges ? futureChanges : currentChanges;
    const link = Array(minLen++);
    const tresh = Array(minLen);
    tresh[0] = -1;
    for (let i = 1; i < minLen; i++)
        tresh[i] = currentEnd;
    const nodes = currentNodes.slice(currentStart, currentEnd);
    for (let i = futureStart; i < futureEnd; i++) {
        const index = nodes.indexOf(futureNodes[i]);
        if (-1 < index) {
            const idxInOld = index + currentStart;
            k = findK(tresh, minLen, idxInOld);
            if (-1 < k) {
                tresh[k] = idxInOld;
                link[k] = {
                    newi: i,
                    oldi: idxInOld,
                    prev: link[k - 1]
                };
            }
        }
    }
    k = --minLen;
    --currentEnd;
    while (tresh[k] > currentEnd)
        --k;
    minLen = currentChanges + futureChanges - k;
    const diff = Array(minLen);
    let ptr = link[k];
    --futureEnd;
    while (ptr) {
        const { newi, oldi } = ptr;
        while (futureEnd > newi) {
            diff[--minLen] = INSERTION;
            --futureEnd;
        }
        while (currentEnd > oldi) {
            diff[--minLen] = DELETION;
            --currentEnd;
        }
        diff[--minLen] = SKIP;
        --futureEnd;
        --currentEnd;
        ptr = ptr.prev;
    }
    while (futureEnd >= futureStart) {
        diff[--minLen] = INSERTION;
        --futureEnd;
    }
    while (currentEnd >= currentStart) {
        diff[--minLen] = DELETION;
        --currentEnd;
    }
    return diff;
};
const OND = (futureNodes, futureStart, rows, currentNodes, currentStart, cols, compare) => {
    const length = rows + cols;
    const v = [];
    let d, k, r, c, pv, cv, pd;
    outer: for (d = 0; d <= length; d++) {
        if (d > SKIP_OND)
            return null;
        pd = d - 1;
        pv = d ? v[d - 1] : [0, 0];
        cv = v[d] = [];
        for (k = -d; k <= d; k += 2) {
            if (k === -d || (k !== d && pv[pd + k - 1] < pv[pd + k + 1])) {
                c = pv[pd + k + 1];
            }
            else {
                c = pv[pd + k - 1] + 1;
            }
            r = c - k;
            while (c < cols &&
                r < rows &&
                compare(currentNodes[currentStart + c], futureNodes[futureStart + r])) {
                c++;
                r++;
            }
            if (c === cols && r === rows) {
                break outer;
            }
            cv[d + k] = c;
        }
    }
    const diff = Array(d / 2 + length / 2);
    let diffIdx = diff.length - 1;
    for (d = v.length - 1; d >= 0; d--) {
        while (c > 0 &&
            r > 0 &&
            compare(currentNodes[currentStart + c - 1], futureNodes[futureStart + r - 1])) {
            diff[diffIdx--] = SKIP;
            c--;
            r--;
        }
        if (!d)
            break;
        pd = d - 1;
        pv = d ? v[d - 1] : [0, 0];
        k = c - r;
        if (k === -d || (k !== d && pv[pd + k - 1] < pv[pd + k + 1])) {
            r--;
            diff[diffIdx--] = INSERTION;
        }
        else {
            c--;
            diff[diffIdx--] = DELETION;
        }
    }
    return diff;
};
const applyDiff = (diff, get, parentNode, futureNodes, futureStart, currentNodes, currentStart, currentLength, before) => {
    const live = [];
    const length = diff.length;
    let currentIndex = currentStart;
    let i = 0;
    while (i < length) {
        switch (diff[i++]) {
            case SKIP:
                futureStart++;
                currentIndex++;
                break;
            case INSERTION:
                live.push(futureNodes[futureStart]);
                append(get, parentNode, futureNodes, futureStart++, futureStart, currentIndex < currentLength ?
                    get(currentNodes[currentIndex], 0) :
                    before);
                break;
            case DELETION:
                currentIndex++;
                break;
        }
    }
    i = 0;
    while (i < length) {
        switch (diff[i++]) {
            case SKIP:
                currentStart++;
                break;
            case DELETION:
                if (-1 < live.indexOf(currentNodes[currentStart]))
                    currentStart++;
                else
                    utils_remove(get, currentNodes, currentStart++, currentStart);
                break;
        }
    }
};
const findK = (ktr, length, j) => {
    let lo = 1;
    let hi = length;
    while (lo < hi) {
        const mid = ((lo + hi) / 2) >>> 0;
        if (j < ktr[mid])
            hi = mid;
        else
            lo = mid + 1;
    }
    return lo;
};
const smartDiff = (get, parentNode, futureNodes, futureStart, futureEnd, futureChanges, currentNodes, currentStart, currentEnd, currentChanges, currentLength, compare, before) => {
    applyDiff(OND(futureNodes, futureStart, futureChanges, currentNodes, currentStart, currentChanges, compare) ||
        HS(futureNodes, futureStart, futureEnd, futureChanges, currentNodes, currentStart, currentEnd, currentChanges), get, parentNode, futureNodes, futureStart, currentNodes, currentStart, currentLength, before);
};
const drop = node => (node.remove || dropChild).call(node);
function dropChild() {
    const { parentNode } = this;
    if (parentNode)
        parentNode.removeChild(this);
}

;// ../../node_modules/domdiff/esm/index.js
/*! (c) 2018 Andrea Giammarchi (ISC) */

const domdiff = (parentNode, currentNodes, futureNodes, options) => {
    if (!options)
        options = {};
    const compare = options.compare || eqeq;
    const get = options.node || identity;
    const before = options.before == null ? null : get(options.before, 0);
    const currentLength = currentNodes.length;
    let currentEnd = currentLength;
    let currentStart = 0;
    let futureEnd = futureNodes.length;
    let futureStart = 0;
    while (currentStart < currentEnd &&
        futureStart < futureEnd &&
        compare(currentNodes[currentStart], futureNodes[futureStart])) {
        currentStart++;
        futureStart++;
    }
    while (currentStart < currentEnd &&
        futureStart < futureEnd &&
        compare(currentNodes[currentEnd - 1], futureNodes[futureEnd - 1])) {
        currentEnd--;
        futureEnd--;
    }
    const currentSame = currentStart === currentEnd;
    const futureSame = futureStart === futureEnd;
    if (currentSame && futureSame)
        return futureNodes;
    if (currentSame && futureStart < futureEnd) {
        append(get, parentNode, futureNodes, futureStart, futureEnd, next(get, currentNodes, currentStart, currentLength, before));
        return futureNodes;
    }
    if (futureSame && currentStart < currentEnd) {
        utils_remove(get, currentNodes, currentStart, currentEnd);
        return futureNodes;
    }
    const currentChanges = currentEnd - currentStart;
    const futureChanges = futureEnd - futureStart;
    let i = -1;
    if (currentChanges < futureChanges) {
        i = utils_indexOf(futureNodes, futureStart, futureEnd, currentNodes, currentStart, currentEnd, compare);
        if (-1 < i) {
            append(get, parentNode, futureNodes, futureStart, i, get(currentNodes[currentStart], 0));
            append(get, parentNode, futureNodes, i + currentChanges, futureEnd, next(get, currentNodes, currentEnd, currentLength, before));
            return futureNodes;
        }
    }
    else if (futureChanges < currentChanges) {
        i = utils_indexOf(currentNodes, currentStart, currentEnd, futureNodes, futureStart, futureEnd, compare);
        if (-1 < i) {
            utils_remove(get, currentNodes, currentStart, i);
            utils_remove(get, currentNodes, i + futureChanges, currentEnd);
            return futureNodes;
        }
    }
    if ((currentChanges < 2 || futureChanges < 2)) {
        append(get, parentNode, futureNodes, futureStart, futureEnd, get(currentNodes[currentStart], 0));
        utils_remove(get, currentNodes, currentStart, currentEnd);
        return futureNodes;
    }
    if (currentChanges === futureChanges &&
        isReversed(futureNodes, futureEnd, currentNodes, currentStart, currentEnd, compare)) {
        append(get, parentNode, futureNodes, futureStart, futureEnd, next(get, currentNodes, currentEnd, currentLength, before));
        return futureNodes;
    }
    smartDiff(get, parentNode, futureNodes, futureStart, futureEnd, futureChanges, currentNodes, currentStart, currentEnd, currentChanges, currentLength, compare, before);
    return futureNodes;
};
/* harmony default export */ const domdiff_esm = (domdiff);

;// ../../node_modules/@ungap/custom-event/esm/index.js
var custom_event_esm_self = {};
custom_event_esm_self.CustomEvent = typeof CustomEvent === 'function' ?
    CustomEvent :
    (function (__p__) {
        CustomEvent[__p__] = new CustomEvent('').constructor[__p__];
        return CustomEvent;
        function CustomEvent(type, init) {
            if (!init)
                init = {};
            var e = document.createEvent('CustomEvent');
            e.initCustomEvent(type, !!init.bubbles, !!init.cancelable, init.detail);
            return e;
        }
    }('prototype'));
/* harmony default export */ const custom_event_esm = (custom_event_esm_self.CustomEvent);

;// ../../node_modules/@ungap/essential-map/esm/index.js
var essential_map_esm_self = {};
try {
    essential_map_esm_self.Map = Map;
}
catch (Map) {
    essential_map_esm_self.Map = function Map() {
        var i = 0;
        var k = [];
        var v = [];
        return {
            delete: function (key) {
                var had = contains(key);
                if (had) {
                    k.splice(i, 1);
                    v.splice(i, 1);
                }
                return had;
            },
            forEach: function forEach(callback, context) {
                k.forEach(function (key, i) {
                    callback.call(context, v[i], key, this);
                }, this);
            },
            get: function get(key) {
                return contains(key) ? v[i] : void 0;
            },
            has: function has(key) {
                return contains(key);
            },
            set: function set(key, value) {
                v[contains(key) ? i : (k.push(key) - 1)] = value;
                return this;
            }
        };
        function contains(v) {
            i = k.indexOf(v);
            return -1 < i;
        }
    };
}
/* harmony default export */ const essential_map_esm = (essential_map_esm_self.Map);

;// ../../node_modules/hyperhtml/esm/classes/Component.js



function Component() {
    return this;
}
function setup(content) {
    const children = new esm;
    const create = Object.create;
    const createEntry = (wm, id, component) => {
        wm.set(id, component);
        return component;
    };
    const get = (Class, info, context, id) => {
        const relation = info.get(Class) || relate(Class, info);
        switch (typeof id) {
            case 'object':
            case 'function':
                const wm = relation.w || (relation.w = new esm);
                return wm.get(id) || createEntry(wm, id, new Class(context));
            default:
                const sm = relation.p || (relation.p = create(null));
                return sm[id] || (sm[id] = new Class(context));
        }
    };
    const relate = (Class, info) => {
        const relation = { w: null, p: null };
        info.set(Class, relation);
        return relation;
    };
    const set = context => {
        const info = new essential_map_esm;
        children.set(context, info);
        return info;
    };
    Object.defineProperties(Component, {
        for: {
            configurable: true,
            value(context, id) {
                return get(this, children.get(context) || set(context), context, id == null ?
                    'default' : id);
            }
        }
    });
    Object.defineProperties(Component.prototype, {
        handleEvent: { value(e) {
                const ct = e.currentTarget;
                this[('getAttribute' in ct && ct.getAttribute('data-call')) ||
                    ('on' + e.type)](e);
            } },
        html: lazyGetter('html', content),
        svg: lazyGetter('svg', content),
        state: lazyGetter('state', function () { return this.defaultState; }),
        defaultState: { get() { return {}; } },
        dispatch: { value(type, detail) {
                const { _wire$ } = this;
                if (_wire$) {
                    const event = new custom_event_esm(type, {
                        bubbles: true,
                        cancelable: true,
                        detail
                    });
                    event.component = this;
                    return (_wire$.dispatchEvent ?
                        _wire$ :
                        _wire$.firstChild).dispatchEvent(event);
                }
                return false;
            } },
        setState: { value(state, render) {
                const target = this.state;
                const source = typeof state === 'function' ? state.call(this, target) : state;
                for (const key in source)
                    target[key] = source[key];
                if (render !== false)
                    this.render();
                return this;
            } }
    });
}
const lazyGetter = (type, fn) => {
    const secret = '_' + type + '$';
    return {
        get() {
            return this[secret] || setValue(this, secret, fn.call(this, type));
        },
        set(value) {
            setValue(this, secret, value);
        }
    };
};
const setValue = (self, secret, value) => Object.defineProperty(self, secret, {
    configurable: true,
    value: typeof value === 'function' ?
        function () {
            return (self._wire$ = value.apply(this, arguments));
        } :
        value
})[secret];
Object.defineProperties(Component.prototype, {
    ELEMENT_NODE: { value: 1 },
    nodeType: { value: -1 }
});

;// ../../node_modules/hyperhtml/esm/objects/Intent.js
const attributes = {};
const intents = {};
const keys = [];
const Intent_hasOwnProperty = intents.hasOwnProperty;
let Intent_length = 0;
/* harmony default export */ const Intent = ({
    attributes,
    define: (intent, callback) => {
        if (intent.indexOf('-') < 0) {
            if (!(intent in intents)) {
                Intent_length = keys.push(intent);
            }
            intents[intent] = callback;
        }
        else {
            attributes[intent] = callback;
        }
    },
    invoke: (object, callback) => {
        for (let i = 0; i < Intent_length; i++) {
            let key = keys[i];
            if (Intent_hasOwnProperty.call(object, key)) {
                return intents[key](object[key], callback);
            }
        }
    }
});

;// ../../node_modules/@ungap/is-array/esm/index.js
var esm_isArray = Array.isArray || (function (toString) {
    var $ = toString.call([]);
    return function isArray(object) {
        return toString.call(object) === $;
    };
}({}.toString));
/* harmony default export */ const is_array_esm = (esm_isArray);

;// ../../node_modules/@ungap/create-content/esm/index.js
var createContent = (function (document) {
    'use strict';
    var FRAGMENT = 'fragment';
    var TEMPLATE = 'template';
    var HAS_CONTENT = 'content' in create(TEMPLATE);
    var createHTML = HAS_CONTENT ?
        function (html) {
            var template = create(TEMPLATE);
            template.innerHTML = html;
            return template.content;
        } :
        function (html) {
            var content = create(FRAGMENT);
            var template = create(TEMPLATE);
            var childNodes = null;
            if (/^[^\S]*?<(col(?:group)?|t(?:head|body|foot|r|d|h))/i.test(html)) {
                var selector = RegExp.$1;
                template.innerHTML = '<table>' + html + '</table>';
                childNodes = template.querySelectorAll(selector);
            }
            else {
                template.innerHTML = html;
                childNodes = template.childNodes;
            }
            append(content, childNodes);
            return content;
        };
    return function createContent(markup, type) {
        return (type === 'svg' ? createSVG : createHTML)(markup);
    };
    function append(root, childNodes) {
        var length = childNodes.length;
        while (length--)
            root.appendChild(childNodes[0]);
    }
    function create(element) {
        return element === FRAGMENT ?
            document.createDocumentFragment() :
            document.createElementNS('http://www.w3.org/1999/xhtml', element);
    }
    function createSVG(svg) {
        var content = create(FRAGMENT);
        var template = create('div');
        template.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg">' + svg + '</svg>';
        append(content, template.firstChild.childNodes);
        return content;
    }
}(document));
/* harmony default export */ const create_content_esm = (createContent);

;// ../../node_modules/disconnected/esm/index.js
function disconnected(poly) {
    'use strict';
    var Event = poly.Event;
    var WeakSet = poly.WeakSet;
    var notObserving = true;
    var observer = null;
    return function observe(node) {
        if (notObserving) {
            notObserving = !notObserving;
            observer = new WeakSet;
            startObserving(node.ownerDocument);
        }
        observer.add(node);
        return node;
    };
    function startObserving(document) {
        var connected = new WeakSet;
        var disconnected = new WeakSet;
        try {
            (new MutationObserver(changes)).observe(document, { subtree: true, childList: true });
        }
        catch (o_O) {
            var timer = 0;
            var records = [];
            var reschedule = function (record) {
                records.push(record);
                clearTimeout(timer);
                timer = setTimeout(function () {
                    changes(records.splice(timer = 0, records.length));
                }, 0);
            };
            document.addEventListener('DOMNodeRemoved', function (event) {
                reschedule({ addedNodes: [], removedNodes: [event.target] });
            }, true);
            document.addEventListener('DOMNodeInserted', function (event) {
                reschedule({ addedNodes: [event.target], removedNodes: [] });
            }, true);
        }
        function changes(records) {
            for (var record, length = records.length, i = 0; i < length; i++) {
                record = records[i];
                dispatchAll(record.removedNodes, 'disconnected', disconnected, connected);
                dispatchAll(record.addedNodes, 'connected', connected, disconnected);
            }
        }
        function dispatchAll(nodes, type, wsin, wsout) {
            for (var node, event = new Event(type), length = nodes.length, i = 0; i < length; (node = nodes[i++]).nodeType === 1 &&
                dispatchTarget(node, event, type, wsin, wsout))
                ;
        }
        function dispatchTarget(node, event, type, wsin, wsout) {
            if (observer.has(node) && !wsin.has(node)) {
                wsout.delete(node);
                wsin.add(node);
                node.dispatchEvent(event);
            }
            for (var children = node.children || [], length = children.length, i = 0; i < length; dispatchTarget(children[i++], event, type, wsin, wsout))
                ;
        }
    }
}
/* harmony default export */ const disconnected_esm = (disconnected);

;// ../../node_modules/@ungap/import-node/esm/index.js
var importNode = (function (document, appendChild, cloneNode, createTextNode, importNode) {
    var native = importNode in document;
    var fragment = document.createDocumentFragment();
    fragment[appendChild](document[createTextNode]('g'));
    fragment[appendChild](document[createTextNode](''));
    var content = native ?
        document[importNode](fragment, true) :
        fragment[cloneNode](true);
    return content.childNodes.length < 2 ?
        function importNode(node, deep) {
            var clone = node[cloneNode]();
            for (var childNodes = node.childNodes || [], length = childNodes.length, i = 0; deep && i < length; i++) {
                clone[appendChild](importNode(childNodes[i], deep));
            }
            return clone;
        } :
        (native ?
            document[importNode] :
            function (node, deep) {
                return node[cloneNode](!!deep);
            });
}(document, 'appendChild', 'cloneNode', 'createTextNode', 'importNode'));
/* harmony default export */ const import_node_esm = (importNode);

;// ../../node_modules/@ungap/trim/esm/index.js
var trim = ''.trim || function () {
    return String(this).replace(/^\s+|\s+/g, '');
};
/* harmony default export */ const trim_esm = (trim);

;// ../../node_modules/domconstants/esm/index.js
/*! (c) Andrea Giammarchi - ISC */
var UID = '-' + Math.random().toFixed(6) + '%';
var UID_IE = false;
try {
    if (!(function (template, content, tabindex) {
        return content in template && ((template.innerHTML = '<p ' + tabindex + '="' + UID + '"></p>'),
            template[content].childNodes[0].getAttribute(tabindex) == UID);
    }(document.createElement('template'), 'content', 'tabindex'))) {
        UID = '_dt: ' + UID.slice(1, -1) + ';';
        UID_IE = true;
    }
}
catch (meh) { }
var UIDC = '<!--' + UID + '-->';
var COMMENT_NODE = 8;
var DOCUMENT_FRAGMENT_NODE = 11;
var ELEMENT_NODE = 1;
var TEXT_NODE = 3;
var SHOULD_USE_TEXT_CONTENT = /^(?:plaintext|script|style|textarea|title|xmp)$/i;
var VOID_ELEMENTS = /^(?:area|base|br|col|embed|hr|img|input|keygen|link|menuitem|meta|param|source|track|wbr)$/i;


;// ../../node_modules/domsanitizer/esm/index.js
__webpack_require__.dn(domsanitizer_esm);
/*! (c) Andrea Giammarchi - ISC */

/* harmony default export */ function domsanitizer_esm(template) {
    return template.join(UIDC)
        .replace(selfClosing, fullClosing)
        .replace(attrSeeker, attrReplacer);
}
var spaces = ' \\f\\n\\r\\t';
var almostEverything = '[^' + spaces + '\\/>"\'=]+';
var attrName = '[' + spaces + ']+' + almostEverything;
var tagName = '<([A-Za-z]+[A-Za-z0-9:._-]*)((?:';
var attrPartials = '(?:\\s*=\\s*(?:\'[^\']*?\'|"[^"]*?"|<[^>]*?>|' + almostEverything.replace('\\/', '') + '))?)';
var attrSeeker = new RegExp(tagName + attrName + attrPartials + '+)([' + spaces + ']*/?>)', 'g');
var selfClosing = new RegExp(tagName + attrName + attrPartials + '*)([' + spaces + ']*/>)', 'g');
var findAttributes = new RegExp('(' + attrName + '\\s*=\\s*)([\'"]?)' + UIDC + '\\2', 'gi');
function attrReplacer($0, $1, $2, $3) {
    return '<' + $1 + $2.replace(findAttributes, replaceAttributes) + $3;
}
function replaceAttributes($0, $1, $2) {
    return $1 + ($2 || '"') + UID + ($2 || '"');
}
function fullClosing($0, $1, $2) {
    return VOID_ELEMENTS.test($1) ? $0 : ('<' + $1 + $2 + '></' + $1 + '>');
}

;// ../../node_modules/umap/esm/index.js
/* harmony default export */ const umap_esm = (_ => ({
    get: key => _.get(key),
    set: (key, value) => (_.set(key, value), value)
}));
__webpack_require__.dn(umap_esm);

;// ../../node_modules/domtagger/esm/walker.js



var normalizeAttributes = UID_IE ?
    function (attributes, parts) {
        var html = parts.join(' ');
        return parts.slice.call(attributes, 0).sort(function (left, right) {
            return html.indexOf(left.name) <= html.indexOf(right.name) ? -1 : 1;
        });
    } :
    function (attributes, parts) {
        return parts.slice.call(attributes, 0);
    };
function find(node, path) {
    var length = path.length;
    var i = 0;
    while (i < length)
        node = node.childNodes[path[i++]];
    return node;
}
function parse(node, holes, parts, path) {
    var childNodes = node.childNodes;
    var length = childNodes.length;
    var i = 0;
    while (i < length) {
        var child = childNodes[i];
        switch (child.nodeType) {
            case ELEMENT_NODE:
                var childPath = path.concat(i);
                parseAttributes(child, holes, parts, childPath);
                parse(child, holes, parts, childPath);
                break;
            case COMMENT_NODE:
                var textContent = child.textContent;
                if (textContent === UID) {
                    parts.shift();
                    holes.push(SHOULD_USE_TEXT_CONTENT.test(node.nodeName) ?
                        Text(node, path) :
                        Any(child, path.concat(i)));
                }
                else {
                    switch (textContent.slice(0, 2)) {
                        case '/*':
                            if (textContent.slice(-2) !== '*/')
                                break;
                        case '\uD83D\uDC7B':
                            node.removeChild(child);
                            i--;
                            length--;
                    }
                }
                break;
            case TEXT_NODE:
                if (SHOULD_USE_TEXT_CONTENT.test(node.nodeName) &&
                    trim_esm.call(child.textContent) === UIDC) {
                    parts.shift();
                    holes.push(Text(node, path));
                }
                break;
        }
        i++;
    }
}
function parseAttributes(node, holes, parts, path) {
    var attributes = node.attributes;
    var cache = [];
    var remove = [];
    var array = normalizeAttributes(attributes, parts);
    var length = array.length;
    var i = 0;
    while (i < length) {
        var attribute = array[i++];
        var direct = attribute.value === UID;
        var sparse;
        if (direct || 1 < (sparse = attribute.value.split(UIDC)).length) {
            var name = attribute.name;
            if (cache.indexOf(name) < 0) {
                cache.push(name);
                var realName = parts.shift().replace(direct ?
                    /^(?:|[\S\s]*?\s)(\S+?)\s*=\s*('|")?$/ :
                    new RegExp('^(?:|[\\S\\s]*?\\s)(' + name + ')\\s*=\\s*(\'|")[\\S\\s]*', 'i'), '$1');
                var value = attributes[realName] ||
                    attributes[realName.toLowerCase()];
                if (direct)
                    holes.push(Attr(value, path, realName, null));
                else {
                    var skip = sparse.length - 2;
                    while (skip--)
                        parts.shift();
                    holes.push(Attr(value, path, realName, sparse));
                }
            }
            remove.push(attribute);
        }
    }
    length = remove.length;
    i = 0;
    var cleanValue = 0 < length && UID_IE && !('ownerSVGElement' in node);
    while (i < length) {
        var attr = remove[i++];
        if (cleanValue)
            attr.value = '';
        node.removeAttribute(attr.name);
    }
    var nodeName = node.nodeName;
    if (/^script$/i.test(nodeName)) {
        var script = document.createElement(nodeName);
        length = attributes.length;
        i = 0;
        while (i < length)
            script.setAttributeNode(attributes[i++].cloneNode(true));
        script.textContent = node.textContent;
        node.parentNode.replaceChild(script, node);
    }
}
function Any(node, path) {
    return {
        type: 'any',
        node: node,
        path: path
    };
}
function Attr(node, path, name, sparse) {
    return {
        type: 'attr',
        node: node,
        path: path,
        name: name,
        sparse: sparse
    };
}
function Text(node, path) {
    return {
        type: 'text',
        node: node,
        path: path
    };
}

;// ../../node_modules/domtagger/esm/index.js







/* harmony default export */ const domtagger_esm = (domtagger);
var parsed = umap_esm(new esm);
function createInfo(options, template) {
    var markup = (options.convert || domsanitizer_esm)(template);
    var transform = options.transform;
    if (transform)
        markup = transform(markup);
    var content = create_content_esm(markup, options.type);
    cleanContent(content);
    var holes = [];
    parse(content, holes, template.slice(0), []);
    return {
        content: content,
        updates: function (content) {
            var updates = [];
            var len = holes.length;
            var i = 0;
            var off = 0;
            while (i < len) {
                var info = holes[i++];
                var node = find(content, info.path);
                switch (info.type) {
                    case 'any':
                        updates.push({ fn: options.any(node, []), sparse: false });
                        break;
                    case 'attr':
                        var sparse = info.sparse;
                        var fn = options.attribute(node, info.name, info.node);
                        if (sparse === null)
                            updates.push({ fn: fn, sparse: false });
                        else {
                            off += sparse.length - 2;
                            updates.push({ fn: fn, sparse: true, values: sparse });
                        }
                        break;
                    case 'text':
                        updates.push({ fn: options.text(node), sparse: false });
                        node.textContent = '';
                        break;
                }
            }
            len += off;
            return function () {
                var length = arguments.length;
                if (len !== (length - 1)) {
                    throw new Error((length - 1) + ' values instead of ' + len + '\n' +
                        template.join('${value}'));
                }
                var i = 1;
                var off = 1;
                while (i < length) {
                    var update = updates[i - off];
                    if (update.sparse) {
                        var values = update.values;
                        var value = values[0];
                        var j = 1;
                        var l = values.length;
                        off += l - 2;
                        while (j < l)
                            value += arguments[i++] + values[j++];
                        update.fn(value);
                    }
                    else
                        update.fn(arguments[i++]);
                }
                return content;
            };
        }
    };
}
function createDetails(options, template) {
    var info = parsed.get(template) || parsed.set(template, createInfo(options, template));
    return info.updates(import_node_esm.call(document, info.content, true));
}
var empty = [];
function domtagger(options) {
    var previous = empty;
    var updates = cleanContent;
    return function (template) {
        if (previous !== template)
            updates = createDetails(options, (previous = template));
        return updates.apply(null, arguments);
    };
}
function cleanContent(fragment) {
    var childNodes = fragment.childNodes;
    var i = childNodes.length;
    while (i--) {
        var child = childNodes[i];
        if (child.nodeType !== 1 &&
            trim_esm.call(child.textContent).length === 0) {
            fragment.removeChild(child);
        }
    }
}

;// ../../node_modules/hyperhtml-style/esm/index.js
var hyperStyle = (function () {
    'use strict';
    var IS_NON_DIMENSIONAL = /acit|ex(?:s|g|n|p|$)|rph|ows|mnc|ntw|ine[ch]|zoo|^ord/i;
    var hyphen = /([^A-Z])([A-Z]+)/g;
    return function hyperStyle(node, original) {
        return 'ownerSVGElement' in node ? svg(node, original) : update(node.style, false);
    };
    function ized($0, $1, $2) {
        return $1 + '-' + $2.toLowerCase();
    }
    function svg(node, original) {
        var style;
        if (original)
            style = original.cloneNode(true);
        else {
            node.setAttribute('style', '--hyper:style;');
            style = node.getAttributeNode('style');
        }
        style.value = '';
        node.setAttributeNode(style);
        return update(style, true);
    }
    function toStyle(object) {
        var key, css = [];
        for (key in object)
            css.push(key.replace(hyphen, ized), ':', object[key], ';');
        return css.join('');
    }
    function update(style, isSVG) {
        var oldType, oldValue;
        return function (newValue) {
            var info, key, styleValue, value;
            switch (typeof newValue) {
                case 'object':
                    if (newValue) {
                        if (oldType === 'object') {
                            if (!isSVG) {
                                if (oldValue !== newValue) {
                                    for (key in oldValue) {
                                        if (!(key in newValue)) {
                                            style[key] = '';
                                        }
                                    }
                                }
                            }
                        }
                        else {
                            if (isSVG)
                                style.value = '';
                            else
                                style.cssText = '';
                        }
                        info = isSVG ? {} : style;
                        for (key in newValue) {
                            value = newValue[key];
                            styleValue = typeof value === 'number' &&
                                !IS_NON_DIMENSIONAL.test(key) ?
                                (value + 'px') : value;
                            if (!isSVG && /^--/.test(key))
                                info.setProperty(key, styleValue);
                            else
                                info[key] = styleValue;
                        }
                        oldType = 'object';
                        if (isSVG)
                            style.value = toStyle((oldValue = info));
                        else
                            oldValue = newValue;
                        break;
                    }
                default:
                    if (oldValue != newValue) {
                        oldType = 'string';
                        oldValue = newValue;
                        if (isSVG)
                            style.value = newValue || '';
                        else
                            style.cssText = newValue || '';
                    }
                    break;
            }
        };
    }
}());
/* harmony default export */ const hyperhtml_style_esm = (hyperStyle);

;// ../../node_modules/hyperhtml-wire/esm/index.js
var Wire = (function (slice, proto) {
    proto = Wire.prototype;
    proto.ELEMENT_NODE = 1;
    proto.nodeType = 111;
    proto.remove = function (keepFirst) {
        var childNodes = this.childNodes;
        var first = this.firstChild;
        var last = this.lastChild;
        this._ = null;
        if (keepFirst && childNodes.length === 2) {
            last.parentNode.removeChild(last);
        }
        else {
            var range = this.ownerDocument.createRange();
            range.setStartBefore(keepFirst ? childNodes[1] : first);
            range.setEndAfter(last);
            range.deleteContents();
        }
        return first;
    };
    proto.valueOf = function (forceAppend) {
        var fragment = this._;
        var noFragment = fragment == null;
        if (noFragment)
            fragment = (this._ = this.ownerDocument.createDocumentFragment());
        if (noFragment || forceAppend) {
            for (var n = this.childNodes, i = 0, l = n.length; i < l; i++)
                fragment.appendChild(n[i]);
        }
        return fragment;
    };
    return Wire;
    function Wire(childNodes) {
        var nodes = (this.childNodes = slice.call(childNodes, 0));
        this.firstChild = nodes[0];
        this.lastChild = nodes[nodes.length - 1];
        this.ownerDocument = nodes[0].ownerDocument;
        this._ = null;
    }
}([].slice));
/* harmony default export */ const hyperhtml_wire_esm = (Wire);

;// ../../node_modules/hyperhtml/esm/shared/constants.js
const constants_ELEMENT_NODE = 1;
const constants_DOCUMENT_FRAGMENT_NODE = 11;
const OWNER_SVG_ELEMENT = 'ownerSVGElement';
const CONNECTED = 'connected';
const DISCONNECTED = 'dis' + CONNECTED;

;// ../../node_modules/hyperhtml/esm/objects/Updates.js












const componentType = Component.prototype.nodeType;
const wireType = hyperhtml_wire_esm.prototype.nodeType;
const observe = disconnected_esm({ Event: custom_event_esm, WeakSet: essential_weakset_esm });

const asHTML = html => ({ html });
const asNode = (item, i) => {
    switch (item.nodeType) {
        case wireType:
            return (1 / i) < 0 ?
                (i ? item.remove(true) : item.lastChild) :
                (i ? item.valueOf(true) : item.firstChild);
        case componentType:
            return asNode(item.render(), i);
        default:
            return item;
    }
};
const canDiff = value => 'ELEMENT_NODE' in value;
const booleanSetter = (node, key, oldValue) => newValue => {
    if (oldValue !== !!newValue) {
        if ((oldValue = !!newValue))
            node.setAttribute(key, '');
        else
            node.removeAttribute(key);
    }
};
const hyperSetter = (node, name, svg) => svg ?
    value => {
        try {
            node[name] = value;
        }
        catch (nope) {
            node.setAttribute(name, value);
        }
    } :
    value => {
        node[name] = value;
    };
const invokeAtDistance = (value, callback) => {
    callback(value.placeholder);
    if ('text' in value) {
        Promise.resolve(value.text).then(String).then(callback);
    }
    else if ('any' in value) {
        Promise.resolve(value.any).then(callback);
    }
    else if ('html' in value) {
        Promise.resolve(value.html).then(asHTML).then(callback);
    }
    else {
        Promise.resolve(Intent.invoke(value, callback)).then(callback);
    }
};
const isPromise_ish = value => value != null && 'then' in value;
const readOnly = /^(?:form|list)$/i;
const Updates_slice = [].slice;
const Updates_text = (node, text) => node.ownerDocument.createTextNode(text);
function Tagger(type) {
    this.type = type;
    return domtagger_esm(this);
}
Tagger.prototype = {
    attribute(node, name, original) {
        const isSVG = OWNER_SVG_ELEMENT in node;
        let oldValue;
        if (name === 'style')
            return hyperhtml_style_esm(node, original, isSVG);
        else if (name.slice(0, 1) === '.')
            return hyperSetter(node, name.slice(1), isSVG);
        else if (name.slice(0, 1) === '?')
            return booleanSetter(node, name.slice(1));
        else if (/^on/.test(name)) {
            let type = name.slice(2);
            if (type === CONNECTED || type === DISCONNECTED) {
                observe(node);
            }
            else if (name.toLowerCase()
                in node) {
                type = type.toLowerCase();
            }
            return newValue => {
                if (oldValue !== newValue) {
                    if (oldValue)
                        node.removeEventListener(type, oldValue, false);
                    oldValue = newValue;
                    if (newValue)
                        node.addEventListener(type, newValue, false);
                }
            };
        }
        else if (name === 'data' ||
            (!isSVG && name in node && !readOnly.test(name))) {
            return newValue => {
                if (oldValue !== newValue) {
                    oldValue = newValue;
                    if (node[name] !== newValue && newValue == null) {
                        node[name] = '';
                        node.removeAttribute(name);
                    }
                    else
                        node[name] = newValue;
                }
            };
        }
        else if (name in Intent.attributes) {
            oldValue;
            return any => {
                const newValue = Intent.attributes[name](node, any);
                if (oldValue !== newValue) {
                    oldValue = newValue;
                    if (newValue == null)
                        node.removeAttribute(name);
                    else
                        node.setAttribute(name, newValue);
                }
            };
        }
        else {
            let owner = false;
            const attribute = original.cloneNode(true);
            return newValue => {
                if (oldValue !== newValue) {
                    oldValue = newValue;
                    if (attribute.value !== newValue) {
                        if (newValue == null) {
                            if (owner) {
                                owner = false;
                                node.removeAttributeNode(attribute);
                            }
                            attribute.value = newValue;
                        }
                        else {
                            attribute.value = newValue;
                            if (!owner) {
                                owner = true;
                                node.setAttributeNode(attribute);
                            }
                        }
                    }
                }
            };
        }
    },
    any(node, childNodes) {
        const diffOptions = { node: asNode, before: node };
        const nodeType = OWNER_SVG_ELEMENT in node ? 'svg' : 'html';
        let fastPath = false;
        let oldValue;
        const anyContent = value => {
            switch (typeof value) {
                case 'string':
                case 'number':
                case 'boolean':
                    if (fastPath) {
                        if (oldValue !== value) {
                            oldValue = value;
                            childNodes[0].textContent = value;
                        }
                    }
                    else {
                        fastPath = true;
                        oldValue = value;
                        childNodes = domdiff_esm(node.parentNode, childNodes, [Updates_text(node, value)], diffOptions);
                    }
                    break;
                case 'function':
                    anyContent(value(node));
                    break;
                case 'object':
                case 'undefined':
                    if (value == null) {
                        fastPath = false;
                        childNodes = domdiff_esm(node.parentNode, childNodes, [], diffOptions);
                        break;
                    }
                default:
                    fastPath = false;
                    oldValue = value;
                    if (is_array_esm(value)) {
                        if (value.length === 0) {
                            if (childNodes.length) {
                                childNodes = domdiff_esm(node.parentNode, childNodes, [], diffOptions);
                            }
                        }
                        else {
                            switch (typeof value[0]) {
                                case 'string':
                                case 'number':
                                case 'boolean':
                                    anyContent({ html: value });
                                    break;
                                case 'object':
                                    if (is_array_esm(value[0])) {
                                        value = value.concat.apply([], value);
                                    }
                                    if (isPromise_ish(value[0])) {
                                        Promise.all(value).then(anyContent);
                                        break;
                                    }
                                default:
                                    childNodes = domdiff_esm(node.parentNode, childNodes, value, diffOptions);
                                    break;
                            }
                        }
                    }
                    else if (canDiff(value)) {
                        childNodes = domdiff_esm(node.parentNode, childNodes, value.nodeType === (/* inlined export .DOCUMENT_FRAGMENT_NODE */11) ?
                            Updates_slice.call(value.childNodes) :
                            [value], diffOptions);
                    }
                    else if (isPromise_ish(value)) {
                        value.then(anyContent);
                    }
                    else if ('placeholder' in value) {
                        invokeAtDistance(value, anyContent);
                    }
                    else if ('text' in value) {
                        anyContent(String(value.text));
                    }
                    else if ('any' in value) {
                        anyContent(value.any);
                    }
                    else if ('html' in value) {
                        childNodes = domdiff_esm(node.parentNode, childNodes, Updates_slice.call(create_content_esm([].concat(value.html).join(''), nodeType).childNodes), diffOptions);
                    }
                    else if ('length' in value) {
                        anyContent(Updates_slice.call(value));
                    }
                    else {
                        anyContent(Intent.invoke(value, anyContent));
                    }
                    break;
            }
        };
        return anyContent;
    },
    text(node) {
        let oldValue;
        const textContent = value => {
            if (oldValue !== value) {
                oldValue = value;
                const type = typeof value;
                if (type === 'object' && value) {
                    if (isPromise_ish(value)) {
                        value.then(textContent);
                    }
                    else if ('placeholder' in value) {
                        invokeAtDistance(value, textContent);
                    }
                    else if ('text' in value) {
                        textContent(String(value.text));
                    }
                    else if ('any' in value) {
                        textContent(value.any);
                    }
                    else if ('html' in value) {
                        textContent([].concat(value.html).join(''));
                    }
                    else if ('length' in value) {
                        textContent(Updates_slice.call(value).join(''));
                    }
                    else {
                        textContent(Intent.invoke(value, textContent));
                    }
                }
                else if (type === 'function') {
                    textContent(value(node));
                }
                else {
                    node.textContent = value == null ? '' : value;
                }
            }
        };
        return textContent;
    }
};

;// ../../node_modules/@ungap/template-literal/esm/index.js

var isNoOp = typeof document !== 'object';
var templateLiteral = function (tl) {
    var RAW = 'raw';
    var isBroken = function (UA) {
        return /(Firefox|Safari)\/(\d+)/.test(UA) &&
            !/(Chrom[eium]+|Android)\/(\d+)/.test(UA);
    };
    var broken = isBroken((document.defaultView.navigator || {}).userAgent);
    var FTS = !(RAW in tl) ||
        tl.propertyIsEnumerable(RAW) ||
        !Object.isFrozen(tl[RAW]);
    if (broken || FTS) {
        var forever = {};
        var foreverCache = function (tl) {
            for (var key = '.', i = 0; i < tl.length; i++)
                key += tl[i].length + '.' + tl[i];
            return forever[key] || (forever[key] = tl);
        };
        if (FTS)
            templateLiteral = foreverCache;
        else {
            var wm = new esm;
            var set = function (tl, unique) {
                wm.set(tl, unique);
                return unique;
            };
            templateLiteral = function (tl) {
                return wm.get(tl) || set(tl, foreverCache(tl));
            };
        }
    }
    else {
        isNoOp = true;
    }
    return TL(tl);
};
/* harmony default export */ const template_literal_esm = (TL);
function TL(tl) {
    return isNoOp ? tl : templateLiteral(tl);
}

;// ../../node_modules/@ungap/template-tag-arguments/esm/index.js
__webpack_require__.dn(template_tag_arguments_esm);

/* harmony default export */ function template_tag_arguments_esm(template) {
    var length = arguments.length;
    var args = [template_literal_esm(template)];
    var i = 1;
    while (i < length)
        args.push(arguments[i++]);
    return args;
}
;

;// ../../node_modules/hyperhtml/esm/hyper/wire.js




const wires = new esm;
const wire = (obj, type) => obj == null ?
    content(type || 'html') :
    weakly(obj, type || 'html');
const content = type => {
    let wire, tagger, template;
    return function () {
        const args = template_tag_arguments_esm.apply(null, arguments);
        if (template !== args[0]) {
            template = args[0];
            tagger = new Tagger(type);
            wire = wireContent(tagger.apply(tagger, args));
        }
        else {
            tagger.apply(tagger, args);
        }
        return wire;
    };
};
const weakly = (obj, type) => {
    const i = type.indexOf(':');
    let wire = wires.get(obj);
    let id = type;
    if (-1 < i) {
        id = type.slice(i + 1);
        type = type.slice(0, i) || 'html';
    }
    if (!wire)
        wires.set(obj, wire = {});
    return wire[id] || (wire[id] = content(type));
};
const wireContent = node => {
    const childNodes = node.childNodes;
    const { length } = childNodes;
    return length === 1 ?
        childNodes[0] :
        (length ? new hyperhtml_wire_esm(childNodes) : node);
};

/* harmony default export */ const hyper_wire = (wire);

;// ../../node_modules/hyperhtml/esm/hyper/render.js




const bewitched = new esm;
function render() {
    const wicked = bewitched.get(this);
    const args = template_tag_arguments_esm.apply(null, arguments);
    if (wicked && wicked.template === args[0]) {
        wicked.tagger.apply(null, args);
    }
    else {
        upgrade.apply(this, args);
    }
    return this;
}
function upgrade(template) {
    const type = OWNER_SVG_ELEMENT in this ? 'svg' : 'html';
    const tagger = new Tagger(type);
    bewitched.set(this, { tagger, template: template });
    this.textContent = '';
    this.appendChild(tagger.apply(null, arguments));
}
/* harmony default export */ const hyper_render = (render);

;// ../../node_modules/hyperhtml/esm/index.js








const bind = context => hyper_render.bind(context);
const esm_define = Intent.define;
const tagger = Tagger.prototype;
hyper.Component = Component;
hyper.bind = bind;
hyper.define = esm_define;
hyper.diff = domdiff_esm;
hyper.hyper = hyper;
hyper.observe = observe;
hyper.tagger = tagger;
hyper.wire = hyper_wire;
hyper._ = {
    WeakMap: esm,
    WeakSet: essential_weakset_esm
};
setup(content);

function hyper(HTML) {
    return arguments.length < 2 ?
        (HTML == null ?
            content('html') :
            (typeof HTML === 'string' ?
                hyper.wire(null, HTML) :
                ('raw' in HTML ?
                    content('html')(HTML) :
                    ('nodeType' in HTML ?
                        hyper.bind(HTML) :
                        weakly(HTML, 'html'))))) :
        ('raw' in HTML ?
            content('html') : hyper.wire).apply(null, arguments);
}

;// ../../node_modules/hyperhtml-element/esm/index.js
/*! (C) 2017-2018 Andrea Giammarchi - ISC Style License */

const ATTRIBUTE_CHANGED_CALLBACK = 'attributeChangedCallback';
const O = Object;
const classes = [];
const defineProperty = O.defineProperty;
const getOwnPropertyDescriptor = O.getOwnPropertyDescriptor;
const getOwnPropertyNames = O.getOwnPropertyNames;
const getOwnPropertySymbols = O.getOwnPropertySymbols || (() => []);
const getPrototypeOf = O.getPrototypeOf || (o => o.__proto__);
const ownKeys = typeof Reflect === 'object' && Reflect.ownKeys ||
    (o => getOwnPropertyNames(o).concat(getOwnPropertySymbols(o)));
const setPrototypeOf = O.setPrototypeOf ||
    ((o, p) => (o.__proto__ = p, o));
const camel = name => name.replace(/-([a-z])/g, ($0, $1) => $1.toUpperCase());
const { attachShadow } = HTMLElement.prototype;
const sr = new WeakMap;
class HyperHTMLElement extends HTMLElement {
    static define(name, options) {
        const Class = this;
        const proto = Class.prototype;
        const onChanged = proto[ATTRIBUTE_CHANGED_CALLBACK];
        const hasChange = !!onChanged;
        const booleanAttributes = Class.booleanAttributes || [];
        booleanAttributes.forEach(attribute => {
            const name = camel(attribute);
            if (!(name in proto))
                defineProperty(proto, name, {
                    configurable: true,
                    get() {
                        return this.hasAttribute(attribute);
                    },
                    set(value) {
                        if (!value || value === 'false')
                            this.removeAttribute(attribute);
                        else
                            this.setAttribute(attribute, '');
                    }
                });
        });
        const observedAttributes = (Class.observedAttributes || []).filter(attribute => booleanAttributes.indexOf(attribute) < 0);
        observedAttributes.forEach(attribute => {
            const name = camel(attribute);
            if (!(name in proto))
                defineProperty(proto, name, {
                    configurable: true,
                    get() {
                        return this.getAttribute(attribute);
                    },
                    set(value) {
                        if (value == null)
                            this.removeAttribute(attribute);
                        else
                            this.setAttribute(attribute, value);
                    }
                });
        });
        const attributes = booleanAttributes.concat(observedAttributes);
        if (attributes.length)
            defineProperty(Class, 'observedAttributes', {
                get() { return attributes; }
            });
        const created = proto.created || function () {
            this.render();
        };
        defineProperty(proto, '_init$', {
            configurable: true,
            writable: true,
            value: true
        });
        defineProperty(proto, ATTRIBUTE_CHANGED_CALLBACK, {
            configurable: true,
            value: function aCC(name, prev, curr) {
                if (this._init$) {
                    checkReady.call(this, created, attributes, booleanAttributes);
                    if (this._init$)
                        return this._init$$.push(aCC.bind(this, name, prev, curr));
                }
                if (hasChange && prev !== curr) {
                    onChanged.apply(this, arguments);
                }
            }
        });
        const onConnected = proto.connectedCallback;
        const hasConnect = !!onConnected;
        defineProperty(proto, 'connectedCallback', {
            configurable: true,
            value: function cC() {
                if (this._init$) {
                    checkReady.call(this, created, attributes, booleanAttributes);
                    if (this._init$)
                        return this._init$$.push(cC.bind(this));
                }
                if (hasConnect) {
                    onConnected.apply(this, arguments);
                }
            }
        });
        getOwnPropertyNames(proto).forEach(key => {
            if (/^handle[A-Z]/.test(key)) {
                const _key$ = '_' + key + '$';
                const method = proto[key];
                defineProperty(proto, key, {
                    configurable: true,
                    get() {
                        return this[_key$] ||
                            (this[_key$] = method.bind(this));
                    }
                });
            }
        });
        if (!('handleEvent' in proto)) {
            defineProperty(proto, 'handleEvent', {
                configurable: true,
                value(event) {
                    this[(event.currentTarget.dataset || {}).call ||
                        ('on' + event.type)](event);
                }
            });
        }
        if (options && options.extends) {
            const Native = document.createElement(options.extends).constructor;
            const Intermediate = class extends Native {
            };
            const ckeys = ['length', 'name', 'arguments', 'caller', 'prototype'];
            const pkeys = [];
            let Super = null;
            let BaseClass = Class;
            while (Super = getPrototypeOf(BaseClass)) {
                [
                    { target: Intermediate, base: Super, keys: ckeys },
                    { target: Intermediate.prototype, base: Super.prototype, keys: pkeys }
                ]
                    .forEach(({ target, base, keys }) => {
                    ownKeys(base)
                        .filter(key => keys.indexOf(key) < 0)
                        .forEach((key) => {
                        keys.push(key);
                        defineProperty(target, key, getOwnPropertyDescriptor(base, key));
                    });
                });
                BaseClass = Super;
                if (Super === HyperHTMLElement)
                    break;
            }
            setPrototypeOf(Class, Intermediate);
            setPrototypeOf(proto, Intermediate.prototype);
            customElements.define(name, Class, options);
        }
        else {
            customElements.define(name, Class);
        }
        classes.push(Class);
        return Class;
    }
    attachShadow() {
        const shadowRoot = attachShadow.apply(this, arguments);
        sr.set(this, shadowRoot);
        return shadowRoot;
    }
    get refs() {
        const value = {};
        if ('_html$' in this) {
            const all = (sr.get(this) || this).querySelectorAll('[ref]');
            for (let { length } = all, i = 0; i < length; i++) {
                const node = all[i];
                value[node.getAttribute('ref')] = node;
            }
            Object.defineProperty(this, 'refs', { value });
            return value;
        }
        return value;
    }
    get html() {
        return this._html$ || (this.html = bind(this.shadowRoot || this._shadowRoot || sr.get(this) || this));
    }
    set html(value) {
        defineProperty(this, '_html$', { configurable: true, value: value });
    }
    render() { }
    get defaultState() { return {}; }
    get state() {
        return this._state$ || (this.state = this.defaultState);
    }
    set state(value) {
        defineProperty(this, '_state$', { configurable: true, value: value });
    }
    setState(state, render) {
        const target = this.state;
        const source = typeof state === 'function' ? state.call(this, target) : state;
        for (const key in source)
            target[key] = source[key];
        if (render !== false)
            this.render();
        return this;
    }
}
;
HyperHTMLElement.Component = Component;
HyperHTMLElement.bind = bind;
HyperHTMLElement.intent = esm_define;
HyperHTMLElement.wire = hyper_wire;
HyperHTMLElement.hyper = hyper;
try {
    if (Symbol.hasInstance)
        classes.push(defineProperty(HyperHTMLElement, Symbol.hasInstance, {
            enumerable: false,
            configurable: true,
            value(instance) {
                return classes.some(esm_isPrototypeOf, getPrototypeOf(instance));
            }
        }));
}
catch (meh) { }
/* harmony default export */ const hyperhtml_element_esm = (HyperHTMLElement);
const dom = {
    type: 'DOMContentLoaded',
    handleEvent() {
        if (dom.ready()) {
            document.removeEventListener(dom.type, dom, false);
            dom.list.splice(0).forEach(invoke);
        }
        else
            setTimeout(dom.handleEvent);
    },
    ready() {
        return document.readyState === 'complete';
    },
    list: []
};
if (!dom.ready()) {
    document.addEventListener(dom.type, dom, false);
}
function checkReady(created, attributes, booleanAttributes) {
    if (dom.ready() || isReady.call(this, created, attributes, booleanAttributes)) {
        if (this._init$) {
            const list = this._init$$ || [];
            delete this._init$$;
            const self = defineProperty(this, '_init$', { value: false });
            booleanAttributes.forEach(name => {
                if (self.getAttribute(name) === 'false')
                    self.removeAttribute(name);
            });
            attributes.forEach(name => {
                if (self.hasOwnProperty(name)) {
                    const curr = self[name];
                    delete self[name];
                    list.unshift(() => { self[name] = curr; });
                }
            });
            created.call(self);
            list.forEach(invoke);
        }
    }
    else {
        if (!this.hasOwnProperty('_init$$'))
            defineProperty(this, '_init$$', { configurable: true, value: [] });
        dom.list.push(checkReady.bind(this, created, attributes, booleanAttributes));
    }
}
function invoke(fn) {
    fn();
}
function esm_isPrototypeOf(Class) {
    return this === Class.prototype;
}
function isReady(created, attributes, booleanAttributes) {
    let el = this;
    do {
        if (el.nextSibling)
            return true;
    } while (el = el.parentNode);
    setTimeout(checkReady.bind(this, created, attributes, booleanAttributes));
    return false;
}

;// ./js/io-element.mjs


const DOMUtils = {
    boolean: {
        attribute(node, name, setAsTrue) {
            if (DOMUtils.boolean.value(setAsTrue)) {
                node.setAttribute(name, "true");
            }
            else {
                node.removeAttribute(name);
            }
        },
        value(value) {
            if (typeof value === "string" && value.length) {
                try {
                    value = JSON.parse(value);
                }
                catch (error) {
                }
            }
            return !!value;
        }
    },
    event: {
        isLeftClick(event) {
            const re = /^(?:click|mouse|touch|pointer)/;
            return re.test(event.type) && !event.button;
        }
    }
};
let counter = 0;
class IOElement extends hyperhtml_element_esm {
    static get utils() {
        return DOMUtils;
    }
    static getID(element) {
        return element.getAttribute("id") || IOElement.setID(element);
    }
    static setID(element) {
        const id = `${element.nodeName.toLowerCase()}-${counter++}`;
        element.setAttribute("id", id);
        return id;
    }
    get id() {
        return IOElement.getID(this);
    }
    get ready() {
        return !!this.offsetParent && this.isStyled();
    }
    created() {
        this.render();
    }
    isStyled() {
        const computed = window.getComputedStyle(this, null);
        const property = "--" + this.nodeName.toLowerCase();
        return computed.getPropertyValue(property).trim() !== "";
    }
    render() { }
    get child() {
        let element = this.firstElementChild;
        if (!element) {
            this.render();
            element = this.firstElementChild;
        }
        return element;
    }
}
IOElement.intent("i18n", (idOrArgs) => {
    const fragment = document.createDocumentFragment();
    if (typeof idOrArgs === "string")
        setElementText(fragment, idOrArgs);
    else if (idOrArgs instanceof Array)
        setElementText(fragment, ...idOrArgs);
    return fragment;
});
/* harmony default export */ const io_element = (IOElement);

;// ./js/io-scrollbar.mjs


const { isLeftClick } = io_element.utils.event;
class IOScrollbar extends io_element {
    static get observedAttributes() {
        return ["direction", "position", "size"];
    }
    created() {
        this.addEventListener("click", (event) => {
            if (event.target !== this || !isLeftClick(event))
                return;
            if (this._dragging) {
                this._dragging = false;
                return;
            }
            const { x, y } = relativeCoordinates(event);
            if (this.direction === "horizontal")
                setPosition.call(this, x - this._sliderSize / 2);
            else if (this.direction === "vertical")
                setPosition.call(this, y - this._sliderSize / 2);
            this.dispatchEvent(new CustomEvent("scroll"));
        });
        this.addEventListener("wheel", (event) => {
            stopEvent(event);
            let delta = 0;
            if (this.direction === "vertical")
                delta = event.deltaY;
            else if (this.direction === "horizontal")
                delta = event.deltaX;
            delta = (delta * this._sliderSize) / this.size;
            setPosition.call(this, this.position + delta);
            this.dispatchEvent(new CustomEvent("scroll"));
        }, { passive: false });
    }
    get defaultState() {
        return {
            direction: "",
            position: 0,
            size: 0
        };
    }
    get direction() {
        return this.state.direction;
    }
    set direction(value) {
        value = value.toLowerCase();
        this.setState({ direction: value });
        this.setAttribute("direction", value);
        sizeChange.call(this);
    }
    get position() {
        return this.state.position || 0;
    }
    set position(value) {
        if (!this._elSize)
            return;
        setPosition.call(this, value);
    }
    get range() {
        return this._elSize - this._sliderSize;
    }
    get size() {
        return this.state.size;
    }
    set size(value) {
        this.setState({ size: parseInt(value, 10) });
        sizeChange.call(this);
    }
    onmousedown(event) {
        if (!isLeftClick(event))
            return;
        this._dragging = true;
        this._coords = {
            x: event.clientX,
            y: event.clientY
        };
        const slider = event.currentTarget;
        const doc = slider.ownerDocument;
        doc.addEventListener("mousemove", this, true);
        doc.addEventListener("mouseup", this, true);
        doc.addEventListener("selectstart", stopEvent, true);
    }
    onmousemove(event) {
        const { x, y } = this._coords;
        if (this.direction === "horizontal") {
            const { clientX } = event;
            setPosition.call(this, this.position + clientX - x);
            this._coords.x = clientX;
        }
        else if (this.direction === "vertical") {
            const { clientY } = event;
            setPosition.call(this, this.position + clientY - y);
            this._coords.y = clientY;
        }
        this.dispatchEvent(new CustomEvent("scroll"));
    }
    onmouseup(event) {
        if (!isLeftClick(event))
            return;
        const { currentTarget: doc, target } = event;
        doc.removeEventListener("mousemove", this, true);
        doc.removeEventListener("mouseup", this, true);
        doc.removeEventListener("selectstart", stopEvent, true);
        if (target !== this || target === this.child)
            this._dragging = false;
    }
    render() {
        this.html `<div
      class="slider"
      onmousedown="${this}"
    />`;
    }
}
IOScrollbar.define("io-scrollbar");
function setPosition(value) {
    this.setState({
        position: Math.max(0, Math.min(parseFloat(value), this.range))
    });
    this.style.setProperty("--position", this.state.position + "px");
}
function sizeChange() {
    if (this.direction === "horizontal")
        this._elSize = this.clientWidth;
    else if (this.direction === "vertical")
        this._elSize = this.clientHeight;
    this._sliderSize = Math.floor(Math.min(1, this._elSize / this.state.size) * this._elSize);
    if (this.direction === "horizontal")
        this._sliderSize = Math.max(this._sliderSize, this.clientHeight);
    else if (this.direction === "vertical")
        this._sliderSize = Math.max(this._sliderSize, this.clientWidth);
    this.style.setProperty("--slider-size", this._sliderSize + "px");
    setPosition.call(this, this.position);
}
function stopEvent(event) {
    event.preventDefault();
    event.stopPropagation();
}
/* harmony default export */ const io_scrollbar = (IOScrollbar);

;// ./js/io-checkbox.mjs

class IOCheckbox extends io_element {
    static get booleanAttributes() {
        return ["checked", "disabled"];
    }
    attributeChangedCallback(name) {
        if (!this.disabled && name === "checked") {
            this.dispatchEvent(new CustomEvent("change", {
                bubbles: true,
                cancelable: true,
                detail: this.checked
            }));
        }
        this.render();
    }
    created() {
        this.addEventListener("click", this);
        this.render();
    }
    onclick(event) {
        if (this.disabled) {
            return;
        }
        this.checked = !this.checked;
    }
    render() {
        this.html `
    <button
      role="checkbox"
      disabled="${this.disabled}"
      aria-checked="${this.checked}"
      aria-disabled="${this.disabled}"
    />`;
    }
}
IOCheckbox.define("io-checkbox");
/* harmony default export */ const io_checkbox = ((/* unused pure expression or super */ null && (IOCheckbox)));

;// ./js/io-toggle.mjs

class IOToggle extends io_element {
    static get observedAttributes() {
        return ["checked", "disabled"];
    }
    static get booleanAttributes() {
        return ["checked", "disabled"];
    }
    attributeChangedCallback() {
        this.render();
    }
    created() {
        this.addEventListener("click", this);
        this.render();
    }
    onclick(event) {
        if (!this.disabled) {
            this.checked = !this.checked;
            if (this.ownerDocument.activeElement !== this.child) {
                this.child.focus();
            }
            this.firstElementChild.dispatchEvent(new CustomEvent("change", {
                bubbles: true,
                cancelable: true,
                detail: this.checked
            }));
        }
    }
    render() {
        this.html `
    <button
      role="checkbox"
      disabled="${this.disabled}"
      aria-checked="${this.checked}"
      aria-disabled="${this.disabled}"
    />`;
    }
}
IOToggle.define("io-toggle");
/* harmony default export */ const io_toggle = ((/* unused pure expression or super */ null && (IOToggle)));

;// ./js/io-filter-base.mjs





class IOFilterBase extends io_element {
    static get booleanAttributes() {
        return ["disabled"];
    }
    static get observedAttributes() {
        return ["filters"];
    }
    get selected() {
        return this._selected || (this._selected = new Set());
    }
    set selected(value) {
        this._selected = new Set(value);
        this.render();
    }
    get defaultState() {
        return {
            infinite: false,
            filters: [],
            viewHeight: 0,
            rowHeight: 0,
            scrollTop: 0,
            scrollHeight: 0,
            tbody: null
        };
    }
    get filters() {
        return this.state.filters || [];
    }
    set filters(value) {
        if (!this.ready) {
            this._filters = value;
            return;
        }
        this.selected = [];
        this.style.setProperty("--rule-width", "auto");
        this.setState({ infinite: false, filters: [] });
        this.style.setProperty("--rule-width", $('[data-column="rule"]', this).clientWidth + "px");
        if (value.length) {
            const tbody = $("tbody", this);
            const rowHeight = $("tr", tbody).clientHeight;
            const viewHeight = tbody.clientHeight;
            this.setState({
                infinite: true,
                filters: value,
                scrollTop: tbody.scrollTop,
                scrollHeight: rowHeight * (value.length + 1) - viewHeight,
                viewHeight,
                rowHeight
            });
            this.style.setProperty("--row-height", `${rowHeight}px`);
            this.scrollbar.size = rowHeight * value.length;
        }
    }
    created() {
        if (!this.ready)
            this.addEventListener("animationstart", function prepare(event) {
                this.removeEventListener(event.type, prepare);
                if (this._filters) {
                    this.filters = this._filters;
                    this._filters = null;
                }
            });
        this.scrollbar = new io_scrollbar();
        this.scrollbar.direction = "vertical";
        this.scrollbar.addEventListener("scroll", () => {
            const { position, range } = this.scrollbar;
            const { scrollHeight } = this.state;
            this.setState({
                scrollTop: getScrollTop((scrollHeight * position) / range)
            });
        });
        this.addEventListener("wheel", (event) => {
            event.preventDefault();
            const activeElement = this.ownerDocument.activeElement;
            if (activeElement && activeElement !== this.ownerDocument.body) {
                activeElement.blur();
                return;
            }
            const { scrollHeight, scrollTop, rowHeight, viewHeight } = this.state;
            const scrollFactors = {
                0: 1,
                1: rowHeight,
                2: viewHeight - Math.min(0.1 * viewHeight, 2 * rowHeight)
            };
            this.setState({
                scrollTop: getScrollTop(scrollTop + event.deltaY * scrollFactors[event.deltaMode], scrollHeight)
            });
            updateScrollbarPosition.call(this);
        }, { passive: false });
        setScrollbarReactiveOpacity.call(this);
    }
    scrollTo(row) {
        const { rowHeight, scrollHeight } = this.state;
        const index = typeof row === "string"
            ? this.filters.findIndex((filter) => filter.text === row)
            : this.filters.findIndex((filter) => filter === row);
        if (index < 0)
            console.error("invalid filter", row);
        else {
            this.setState({
                scrollTop: getScrollTop(index * rowHeight, scrollHeight)
            });
            updateScrollbarPosition.call(this);
        }
    }
    renderTable() {
        throw new Error("renderTable not implemented");
    }
    render() {
        let list = this.state.filters;
        if (this.state.infinite) {
            list = [];
            const { rowHeight, scrollTop, viewHeight } = this.state;
            const length = this.state.filters.length;
            let count = 0;
            let i = Math.floor(scrollTop / rowHeight);
            while (count * rowHeight < viewHeight + rowHeight) {
                list[count++] = i < length ? this.state.filters[i++] : null;
            }
        }
        this.renderTable(list);
        postRender.call(this, list);
    }
    updateScrollbar() {
        const { rowHeight, viewHeight } = this.state;
        const { length } = this.filters;
        this.scrollbar.size = rowHeight * length;
        this.setState({
            scrollHeight: rowHeight * (length + 1) - viewHeight
        });
    }
}
function getScrollTop(value, scrollHeight) {
    const scrollTop = Math.max(0, Math.min(scrollHeight || Infinity, value));
    return isNaN(scrollTop) ? 0 : scrollTop;
}
function postRender(list) {
    const { tbody, scrollTop, rowHeight } = this.state;
    if (this.state.infinite) {
        tbody.scrollTop = scrollTop % rowHeight;
    }
    else if (!tbody ||
        (tbody.scrollHeight <= tbody.clientHeight && tbody.clientHeight)) {
        this.setState({
            tbody: tbody || $("tbody", this),
            filters: list.concat({})
        });
    }
}
function setScrollbarReactiveOpacity() {
    const opacity = this.scrollbar.style.opacity;
    const cancelOpacity = () => {
        this.scrollbar.style.opacity = opacity;
        document.removeEventListener("pointerup", cancelOpacity);
        document.removeEventListener("pointercancel", cancelOpacity);
    };
    this.scrollbar.addEventListener("pointerdown", () => {
        this.scrollbar.style.opacity = 1;
        document.addEventListener("pointerup", cancelOpacity);
        document.addEventListener("pointercancel", cancelOpacity);
    });
}
function updateScrollbarPosition() {
    const { scrollbar, state } = this;
    const { scrollHeight, scrollTop } = state;
    scrollbar.position = (scrollTop * scrollbar.range) / scrollHeight;
}
/* harmony default export */ const io_filter_base = (IOFilterBase);

;// ./js/io-filter-list.mjs









const prevFilterText = new WeakMap();
class IOFilterList extends io_filter_base {
    get defaultState() {
        return Object.assign(super.defaultState, {
            sort: {
                current: "",
                asc: false
            },
            sortMap: {
                status: "disabled",
                rule: "text",
                warning: "slow"
            }
        });
    }
    created() {
        setupPort.call(this);
        super.created();
    }
    onheaderclick(event) {
        const th = event.target.closest("th");
        if (!io_element.utils.event.isLeftClick(event) || !th)
            return;
        const { column } = th.dataset;
        if (column === "selected") {
            const ioCheckbox = event.target.closest("io-checkbox");
            if (ioCheckbox)
                this.selected = ioCheckbox.checked ? this.filters : [];
            return;
        }
        event.preventDefault();
        const { sort, sortMap } = this.state;
        if (column !== sort.current) {
            sort.current = column;
            sort.asc = false;
        }
        sort.asc = !sort.asc;
        const sorter = sort.asc ? 1 : -1;
        const property = sortMap[column];
        const direction = property === "slow" ? -1 : 1;
        this.filters.sort((fa, fb) => {
            if (fa[property] === fb[property])
                return 0;
            return (fa[property] < fb[property] ? -sorter : sorter) * direction;
        });
        this.render();
        const dataset = th.closest("thead").dataset;
        dataset.sort = column;
        dataset.dir = sort.asc ? "asc" : "desc";
    }
    onpaste(event) {
        event.preventDefault();
        const data = event.clipboardData.getData("text/plain");
        const [text] = data.trim().split("\n", 1);
        document.execCommand("insertText", false, text);
    }
    onkeydown(event) {
        const { key } = event;
        if (key === "Enter" || key === "Escape") {
            event.preventDefault();
            if (key === "Escape" && this._filter) {
                const { currentTarget } = event;
                const text = prevFilterText.get(this._filter) || this._filter.text;
                currentTarget.textContent = text;
                currentTarget.blur();
                this._filter = null;
            }
        }
    }
    onkeyup(event) {
        const isEnter = event.key === "Enter";
        const update = isEnter || event.type === "blur";
        const { currentTarget } = event;
        const { title } = currentTarget;
        const text = currentTarget.textContent.trim();
        const filter = this._filter;
        if (!filter)
            return;
        if (!text) {
            if (!update)
                return;
            browser.runtime
                .sendMessage({
                type: "filters.remove",
                text: filter.text
            })
                .then((errors) => {
                if (!errors.length) {
                    this.selected.delete(filter);
                    this.render();
                    this.dispatchEvent(new CustomEvent("filter:removed", {
                        cancelable: false,
                        bubbles: true
                    }));
                }
            });
            this._filter = null;
            return;
        }
        if (!prevFilterText.has(filter))
            prevFilterText.set(filter, title);
        if (prevFilterText.get(filter) === text) {
            if (isEnter)
                focusTheNextFilterIfAny.call(this, currentTarget.closest("tr"));
            return;
        }
        if (update) {
            filter.text = text;
            currentTarget.title = text;
            this._validating = 0;
            if (this.filters.some((f) => f.text === filter.text && f !== filter)) {
                const { reason } = filter;
                filter.reason = { type: "filter_duplicated" };
                if (!isSameError(filter.reason, reason)) {
                    this.render();
                }
            }
            else {
                replaceFilter.call(this, filter, currentTarget);
                if (isEnter)
                    focusTheNextFilterIfAny.call(this, currentTarget.closest("tr"));
            }
            return;
        }
        if (this._validating > 0) {
            this._validating++;
            return;
        }
        this._validating = 1;
        browser.runtime
            .sendMessage({
            type: "filters.validate",
            text
        })
            .then((errors) => {
            if (this._validating < 1)
                return;
            if (this._validating > 1) {
                this._validating = 0;
                this.onkeyup({ currentTarget });
                return;
            }
            const { reason } = filter;
            if (errors.length)
                filter.reason = errors[0];
            else
                delete filter.reason;
            if (!isSameError(filter.reason, reason))
                this.render();
        });
    }
    onfocus(event) {
        const { currentTarget } = event;
        this._filter = currentTarget.data;
        currentTarget.closest("tr").classList.add("editing");
    }
    onblur(event) {
        const { currentTarget } = event;
        currentTarget.closest("tr").classList.remove("editing");
        currentTarget.scrollLeft = 0;
        if (this._changingFocus) {
            this._filter = null;
            return;
        }
        this.onkeyup(event);
        this._filter = null;
    }
    onclick(event) {
        const filter = getFilter(event);
        const { filters } = this;
        if (event.shiftKey && this.selected.size) {
            let start = filters.indexOf(this._lastFilter);
            const end = filters.indexOf(filter);
            const method = this.selected.has(this._lastFilter) ? "add" : "delete";
            if (start < end) {
                while (start++ < end)
                    this.selected[method](filters[start]);
            }
            else {
                while (start-- > end)
                    this.selected[method](filters[start]);
            }
        }
        else {
            this._lastFilter = filter;
            if (this.selected.has(filter))
                this.selected.delete(filter);
            else
                this.selected.add(filter);
        }
    }
    onchange(event) {
        const { currentTarget } = event;
        const td = currentTarget.closest("td");
        if (td.dataset.column === "status") {
            const checkbox = currentTarget.closest("io-toggle");
            const filter = getFilter(event);
            filter.disabled = !checkbox.checked;
            browser.runtime.sendMessage({
                type: "filters.toggle",
                text: filter.text,
                disabled: filter.disabled
            });
        }
        else {
            this.render();
        }
    }
    renderTable(visibleFilters) {
        const { length } = this.filters;
        this.html `<table cellpadding="0" cellspacing="0">
      <thead onclick="${this}" data-call="onheaderclick">
        <th data-column="selected">
          <io-checkbox ?checked=${!!length && this.selected.size === length} />
        </th>
        <th data-column="status"></th>
        <th data-column="rule">${{ i18n: "options_filter_list_rule" }}</th>
        <th data-column="warning">${warnings.get(this) ||
            warnings.set(this, createImageForType(false)).get(this)}</th>
      </thead>
      <tbody>${visibleFilters.map(getRow, this)}</tbody>
      ${this.scrollbar}
    </table>`;
    }
    sortBy(type, isAscending) {
        const th = $(`th[data-column="${type}"]`, this);
        if (!th) {
            console.error(`unable to sort by ${type}`);
            return;
        }
        const { sort } = this.state;
        sort.current = type;
        sort.asc = !isAscending;
        th.click();
    }
}
IOFilterList.define("io-filter-list");
function getRow(filter, i) {
    if (filter) {
        const selected = this.selected.has(filter);
        return io_element.wire(filter) `
    <tr class="${selected ? "selected" : ""}">
      <td data-column="selected">
        <io-checkbox
          ?checked=${selected}
          onclick="${this}" onchange="${this}"
        />
      </td>
      <td data-column="status">
        <!-- Not all filters can be en-/disabled (e.g. comments) -->
        <io-toggle
          ?checked=${!filter.disabled}
          ?disabled=${!("disabled" in filter)}
          aria-hidden="${!("disabled" in filter)}"
          onchange="${this}"
        />
      </td>
      <td data-column="rule">
        <div
          class="content"
          contenteditable="${!this.disabled}"
          title="${filter.text}"
          onpaste="${this}"
          onkeydown="${this}"
          onkeyup="${this}"
          onfocus="${this}"
          onblur="${this}"
          data="${filter}"
        >${filter.text}</div>
      </td>
      <td data-column="warning">
        ${getWarning(filter)}
      </td>
    </tr>`;
    }
    return io_element.wire(this, `:${i}`) `
    <tr class="empty">
      <td data-column="selected"></td>
      <td data-column="status"></td>
      <td data-column="rule"></td>
      <td data-column="warning"></td>
    </tr>`;
}
const issues = new WeakMap();
const warnings = new WeakMap();
const createImageForFilter = (isIssue, filter) => {
    const error = isIssue ? filter.reason : { type: "filter_slow" };
    const image = createImageForType(isIssue);
    image.title = stripTagsUnsafe(getErrorMessage(error));
    return image;
};
const createImageForType = (isIssue) => {
    const image = new Image();
    image.src = `skin/icons/${isIssue ? "error" : "alert"}.svg`;
    return image;
};
function focusTheNextFilterIfAny(tr) {
    const i = this.filters.indexOf(this._filter) + 1;
    if (i < this.filters.length) {
        const next = tr.nextElementSibling;
        const { rowHeight, scrollTop, viewHeight } = this.state;
        this._changingFocus = true;
        if (next.offsetTop > viewHeight) {
            this.setState({
                scrollTop: io_filter_list_getScrollTop(scrollTop + rowHeight)
            });
        }
        $(".content", next).focus();
        this._changingFocus = false;
    }
}
function animateAndDrop(target) {
    target.addEventListener("animationend", dropSavedClass);
    target.classList.add("saved");
}
function dropSavedClass(event) {
    const { currentTarget } = event;
    currentTarget.classList.remove("saved");
    currentTarget.removeEventListener(event.type, dropSavedClass);
}
function getFilter(event) {
    const el = event.currentTarget;
    const div = $('td[data-column="rule"] > .content', el.closest("tr"));
    return div.data;
}
function io_filter_list_getScrollTop(value, scrollHeight) {
    const scrollTop = Math.max(0, Math.min(scrollHeight || Infinity, value));
    return isNaN(scrollTop) ? 0 : scrollTop;
}
function getWarning(filter) {
    let map;
    if (filter.reason) {
        map = issues;
    }
    else if (filter.slow) {
        map = warnings;
    }
    else
        return "";
    let warning = map.get(filter);
    if (warning)
        return warning;
    warning = createImageForFilter(map === issues, filter);
    map.set(filter, warning);
    return warning;
}
function isSameError(errorA = {}, errorB = {}) {
    return errorA.type === errorB.type && errorA.reason === errorB.reason;
}
function replaceFilter(filter, currentTarget) {
    const { text } = filter;
    const old = prevFilterText.get(filter);
    if (old === text) {
        animateAndDrop(currentTarget);
        return;
    }
    browser.runtime
        .sendMessage({
        type: "filters.replace",
        new: text,
        old,
        origin: FilterOrigin.optionsAdvanced
    })
        .then((errors) => {
        if (errors.length) {
            filter.reason = errors[0];
        }
        else {
            const { filters } = this;
            let i = filters.length;
            let newFilter;
            while (i--) {
                newFilter = filters[i];
                if (newFilter.text === text)
                    break;
            }
            filters.splice(i, 1);
            delete filter.disabled;
            delete filter.reason;
            Object.assign(filter, newFilter);
            prevFilterText.set(filter, text);
            animateAndDrop(currentTarget);
        }
        this.render();
    });
}
function setupPort() {
    addMessageListener((message) => {
        if (message.type === "filters.respond" && message.action === "changed") {
            const { text, disabled } = message.args[0];
            const filter = this.filters.find((f) => f.text === text);
            if (!filter)
                return;
            const shownDisabled = filter.disabled;
            if (disabled !== shownDisabled) {
                filter.reason = { type: "filter_disabled" };
                filter.disabled = disabled;
            }
            this.render();
        }
    });
}
/* harmony default export */ const io_filter_list = (IOFilterList);

;// ./js/io-filter-search.mjs


const MINIMUM_SEARCH_LENGTH = 3;
class IOFilterSearch extends io_element {
    static get booleanAttributes() {
        return ["disabled"];
    }
    static get observedAttributes() {
        return ["match"];
    }
    get defaultState() {
        return {
            filterExists: true,
            filters: [],
            match: -1
        };
    }
    get filters() {
        return this.state.filters;
    }
    set filters(value) {
        this.setState({ filters: value || [] });
    }
    get match() {
        return this.state.match;
    }
    set match(value) {
        this.setState({
            match: Math.max(-1, Math.min(1, parseFloat(value) || 0))
        }, false);
    }
    get value() {
        return $("input", this).value.trim();
    }
    set value(text) {
        const value = String(text || "").trim();
        $("input", this).value = value;
        this.setState({
            filterExists: value.length
                ? this.state.filters.some(hasValue, value)
                : false
        });
    }
    attributeChangedCallback(name, previous, current) {
        if (name === "match")
            this.match = current;
        else
            this.render();
    }
    created() {
        const { i18n } = browser;
        this._placeholder = i18n.getMessage("options_filters_search_or_add");
        this._timer = 0;
        this.render();
    }
    onclick() {
        if (this.value)
            addFilter.call(this, this.value);
    }
    ondrop(event) {
        event.preventDefault();
        addFilter.call(this, event.dataTransfer.getData("text"));
    }
    onkeydown(event) {
        switch (event.key) {
            case "Enter":
                const { value } = this;
                if (value.length &&
                    !this.disabled &&
                    !this.state.filters.some(hasValue, value))
                    addFilter.call(this, value);
                break;
            case "Escape":
                dispatch.call(this, "filter:none");
                this.value = "";
                break;
        }
    }
    onkeyup() {
        clearTimeout(this._timer);
        this._timer = setTimeout(() => {
            this._timer = 0;
            const { match, value } = this;
            if (!value.length) {
                dispatch.call(this, "filter:none");
                this.value = "";
            }
            else if (!match ||
                value.length < MINIMUM_SEARCH_LENGTH ||
                isMultiLine(value)) {
                this.setState({
                    filterExists: this.state.filters.some(hasValue, value)
                });
                dispatch.call(this, "filter:none");
            }
            else {
                const result = search.call(this, value);
                if (result.accuracy && match <= result.accuracy)
                    dispatch.call(this, "filter:match", result);
                else
                    dispatch.call(this, "filter:none");
            }
        }, 100);
    }
    onpaste(event) {
        const clipboardData = event.clipboardData || window.clipboardData;
        const data = clipboardData.getData("text").trim();
        if (isMultiLine(data))
            addFilter.call(this, data);
    }
    render() {
        const { disabled } = this;
        this.html `
    <input
      placeholder="${this._placeholder}"
      onkeydown="${this}" onkeyup="${this}"
      ondrop="${this}" onpaste="${this}"
      disabled="${disabled}"
    >
    <button
      onclick="${this}"
      disabled="${disabled || this.state.filterExists || !this.value}">
      + ${{ i18n: "add" }}
    </button>`;
    }
}
IOFilterSearch.define("io-filter-search");
function addFilter(data) {
    dispatch.call(this, "filter:none");
    let value = data.trim();
    if (!value)
        return;
    if (isMultiLine(value)) {
        value = clearMultiLine(value);
        dispatch.call(this, "filter:add", value);
    }
    else {
        const result = search.call(this, value);
        if (result.accuracy < 1) {
            dispatch.call(this, "filter:add", value);
        }
        else if (result.accuracy && value.length >= MINIMUM_SEARCH_LENGTH)
            dispatch.call(this, "filter:match", result);
    }
}
function dispatch(type, detail) {
    if (type === "filter:add" || this.filters.length)
        this.dispatchEvent(new CustomEvent(type, { detail }));
}
function hasValue(filter) {
    return filter.text == this;
}
function clearMultiLine(data) {
    return data
        .split(/[\r\n]/)
        .map((text) => text.trim())
        .filter((text) => text.length)
        .join("\n");
}
function isMultiLine(data) {
    return /[\r\n]/.test(data.trim());
}
function search(value) {
    let accuracy = 0;
    let closerFilter = null;
    const matches = [];
    const searchLength = value.length;
    if (searchLength) {
        const match = this.match;
        const { filters } = this.state;
        const { length } = filters;
        for (let i = 0; i < length; i++) {
            const filter = filters[i];
            const filterLength = filter.text.length;
            if (searchLength > filterLength)
                continue;
            if (searchLength === filterLength) {
                if (filter.text === value) {
                    matches.push(filter);
                    closerFilter = filter;
                    accuracy = 1;
                }
                continue;
            }
            if (match < 1 && filter.text.includes(value)) {
                matches.push(filter);
                const tmpAccuracy = searchLength / filterLength;
                if (accuracy < tmpAccuracy) {
                    closerFilter = filter;
                    accuracy = tmpAccuracy;
                }
            }
        }
        this.setState({ filterExists: accuracy === 1 });
    }
    return { accuracy, matches, value, filter: closerFilter };
}
/* harmony default export */ const io_filter_search = (IOFilterSearch);

;// ./js/io-filter-table.mjs






class IOFilterTable extends io_element {
    static get booleanAttributes() {
        return ["disabled"];
    }
    static get observedAttributes() {
        return ["match"];
    }
    get defaultState() {
        return { filters: [], match: -1, ready: false };
    }
    created() {
        this._showing = null;
        this.search = this.appendChild(new io_filter_search());
        this.search.addEventListener("filter:add", (event) => this.onFilterAdd(event));
        this.search.addEventListener("filter:match", (event) => this.onFilterMatch(event));
        this.search.addEventListener("filter:none", () => {
            this.list.selected = [];
            this.updateFooter();
        });
        this.list = this.appendChild(new io_filter_list());
        this.list.addEventListener("filter:removed", (event) => this.onFilterRemoved(event));
        this.footer = this.appendChild(io_element.wire() `<div class="footer" />`);
        this.addEventListener("click", this);
        this.addEventListener("error", this);
        this.setState({ ready: true });
    }
    attributeChangedCallback(name, prev, value) {
        if (name === "match")
            this.setState({ match: value }, false);
        this.render();
    }
    get filters() {
        return this.state.filters;
    }
    set filters(value) {
        this.setState({ filters: value });
    }
    get match() {
        return this.state.match;
    }
    set match(value) {
        this.setState({ match: value });
    }
    onclick(event) {
        if (event.target.closest("io-checkbox")) {
            cleanErrors.call(this);
        }
    }
    onerror(event) {
        this.updateFooter();
        this.footer.classList.add("visible");
        const { errors } = event.detail;
        const footerError = $(".footer .error", this);
        const errorMessages = errors.map(getErrorMessage);
        io_element.bind(footerError) `
      ${errorMessages.map((mssg) => `<li>${mssg}</li>`)}`;
        footerError.removeAttribute("hidden");
    }
    onfooterclick(event) {
        const { classList } = event.currentTarget;
        switch (true) {
            case classList.contains("delete"):
                const filterTexts = [];
                for (const filter of this.list.selected) {
                    this.list.selected.delete(filter);
                    this.filters.splice(this.filters.indexOf(filter), 1);
                    filterTexts.push(filter.text);
                }
                void browser.runtime
                    .sendMessage({
                    type: "filters.removeBatch",
                    texts: filterTexts
                })
                    .then(() => updateList(this.list), (errors) => this.onerror({ detail: { errors } }));
                cleanErrors.call(this);
                break;
            case classList.contains("copy"):
                const filters = [];
                for (const filter of this.list.selected) {
                    filters.push(filter.text);
                }
                clipboard.copy(filters.join("\n"));
                break;
        }
    }
    onFilterAdd(event) {
        this.search.disabled = true;
        const filters = event.detail.split(/(?:\r\n|\n)/);
        cleanErrors.call(this);
        browser.runtime
            .sendMessage({
            type: "filters.importRaw",
            text: filters.join("\n"),
            origin: FilterOrigin.optionsAdvanced
        })
            .then(([errors, filterTexts]) => {
            if (!errors.length) {
                filterTexts.reverse();
                let added = false;
                for (const text of filterTexts) {
                    if (text[0] === "[")
                        continue;
                    added = true;
                    const i = this.filters.findIndex((flt) => flt.text === text);
                    const [filter] = i < 0 ? [{ text }] : this.filters.splice(i, 1);
                    this.filters.unshift(filter);
                }
                this.search.value = "";
                if (!added)
                    return;
                this.render();
                updateList(this.list);
                this.list.scrollTo(this.filters[0]);
                this.updateFooter();
            }
            else {
                this.onerror({ detail: { errors } });
            }
            this.search.disabled = false;
        });
    }
    onFilterMatch(event) {
        const { accuracy, filter, matches } = event.detail;
        this.list.selected = matches;
        this.list.scrollTo(accuracy === 1 ? filter : matches[0]);
        this.updateFooter();
    }
    onFilterRemoved() {
        cleanErrors.call(this);
        this.updateFooter();
    }
    render() {
        const { disabled } = this;
        const { filters, match, ready } = this.state;
        if (!ready || !filters.length)
            return;
        this.search.disabled = disabled;
        this.search.match = match;
        if (this.search.filters !== filters)
            this.search.filters = filters;
        this.list.disabled = disabled;
        if (this.list.filters !== filters)
            this.list.filters = filters;
        this.updateFooter();
    }
    updateFooter() {
        const disabled = !this.list.selected.size;
        io_element.bind(this.footer) `
      <button
        class="delete"
        onclick="${this}"
        disabled="${disabled}"
        data-call="onfooterclick"
      >${{ i18n: "delete" }}</button>
      <button
        class="copy"
        onclick="${this}"
        disabled="${disabled}"
        data-call="onfooterclick"
      >${{ i18n: "copy_selected" }}</button>
      <ul class="error" hidden></ul>
    `;
    }
}
IOFilterTable.define("io-filter-table");
function cleanErrors() {
    const footerError = $(".footer .error", this);
    if (footerError) {
        footerError.setAttribute("hidden", true);
        io_element.bind(footerError) ``;
    }
    this.updateFooter();
}
function updateList(list) {
    list.render();
    list.updateScrollbar();
}

;// ./js/io-list-box.mjs


const DELAY = 200;
const KeyCode = {
    ARROW_DOWN: "ArrowDown",
    ARROW_UP: "ArrowUp",
    BACKSPACE: "Backspace",
    DELETE: "Delete",
    ENTER: "Enter",
    ESCAPE: "Escape",
    END: "End",
    HOME: "Home",
    PAGE_DOWN: "PageDown",
    PAGE_UP: "PageUp",
    SPACE: " ",
    TAB: "Tab"
};
class IOListBox extends io_element {
    static get observedAttributes() {
        return ["action", "swap", "disabled", "expanded", "items"];
    }
    static get booleanAttributes() {
        return ["autoclose"];
    }
    created() {
        this._blurTimer = 0;
        this._bootstrap = true;
        if (this.hasOwnProperty("items")) {
            const items = this.items;
            delete this.items;
            this.items = items;
        }
        this.addEventListener("blur", this, true);
    }
    getItemTitle(item) {
        return item.title;
    }
    get swap() {
        return !!this._swap;
    }
    set swap(value) {
        this._swap = !!value;
    }
    get label() {
        return $(`#${this.id}label`, this);
    }
    get popup() {
        return $(`#${this.id}popup`, this);
    }
    get disabled() {
        return this.hasAttribute("disabled");
    }
    set disabled(value) {
        io_element.utils.boolean.attribute(this, "disabled", value);
        this.render();
    }
    get expanded() {
        return this.hasAttribute("expanded");
    }
    set expanded(value) {
        io_element.utils.boolean.attribute(this, "expanded", value);
        this.render();
        setTimeout(() => {
            if (!value && this.expanded)
                this.ownerDocument.activeElement.blur();
            this.dispatchEvent(new CustomEvent(value ? "open" : "close"));
        }, DELAY + 1);
    }
    get items() {
        return this._items || [];
    }
    set items(items) {
        this._items = items;
        this.render();
        if (!items.length) {
            this._bootstrap = true;
        }
        else if (this._bootstrap) {
            this._bootstrap = false;
            for (const item of items) {
                if (item.group)
                    continue;
                if (!item.disabled) {
                    hover.call(this, "items", item);
                    return;
                }
            }
            hover.call(this, "items", items.find((item) => !item.group));
        }
    }
    handleEvent(event) {
        if (!this.disabled) {
            this[`on${event.type}`](event);
        }
    }
    onblur(event) {
        if (event.relatedTarget && this.contains(event.relatedTarget))
            return;
        if (this.expanded)
            this._blurTimer = setTimeout(() => {
                this.expanded = false;
            }, DELAY);
    }
    onfocus(event) {
        clearTimeout(this._blurTimer);
        this.expanded = true;
    }
    onkeydown(event) {
        const hovered = $(".hover", this);
        switch (event.key) {
            case KeyCode.BACKSPACE:
            case KeyCode.DELETE:
                event.preventDefault();
                break;
            case KeyCode.ENTER:
            case KeyCode.SPACE:
                hovered.dispatchEvent(new CustomEvent("click", { bubbles: true }));
            case KeyCode.ESCAPE:
                event.preventDefault();
                this.expanded = false;
                break;
            case KeyCode.ARROW_UP:
                const prev = findNext.call(this, hovered, "previousElementSibling");
                if (prev)
                    hover.call(this, "key", getItem.call(this, prev.id));
                event.preventDefault();
                break;
            case KeyCode.ARROW_DOWN:
                const next = findNext.call(this, hovered, "nextElementSibling");
                if (next)
                    hover.call(this, "key", getItem.call(this, next.id));
                event.preventDefault();
                break;
        }
    }
    onclick(event) {
        if (!io_element.utils.event.isLeftClick(event))
            return;
        event.preventDefault();
        clearTimeout(this._blurTimer);
        const el = event.target.closest('[role="option"]');
        if (el) {
            const detail = getItem.call(this, el.id);
            const { unselectable } = detail;
            if (el.getAttribute("aria-disabled") !== "true") {
                this.dispatchEvent(new CustomEvent("change", { detail }));
                this.render();
            }
            if ((this.swap || this.autoclose) && !unselectable) {
                this.expanded = false;
            }
        }
    }
    onmousedown(event) {
        this.expanded = !this.expanded;
    }
    onmouseover(event) {
        const el = event.target.closest('[role="option"]');
        if (el && !el.classList.contains("hover")) {
            const item = getItem.call(this, el.id);
            if (item)
                hover.call(this, "mouse", item);
        }
    }
    render() {
        const { action, dataset, disabled, expanded, id, swap } = this;
        const enabled = this._items.filter((item) => !item.disabled).length;
        let buttonText = "";
        if (expanded && dataset.expanded)
            buttonText = dataset.expanded;
        else
            buttonText = dataset.text;
        const { i18n } = browser;
        this.html `
    <button
      role="combobox"
      aria-readonly="true"
      id="${id + "label"}"
      disabled="${disabled}"
      data-action="${action}"
      aria-owns="${id + "popup"}"
      aria-disabled="${disabled}"
      aria-expanded="${expanded}"
      aria-haspopup="${id + "popup"}"
      onblur="${this}" onfocus="${this}"
      onkeydown="${this}" onmousedown="${this}"
    >${"+ " + i18n.getMessage(buttonText)}</button>
    <ul
      role="listbox"
      tabindex="-1"
      id="${id + "popup"}"
      aria-labelledby="${id + "label"}"
      hidden="${!expanded}"
      onclick="${this}" onmouseover="${this}"
    >${this._items.map((item) => {
            if (item.group)
                return io_element.wire() `<li class="group">${item.description}</li>`;
            const itemID = getID(item);
            const selected = !swap && !item.disabled;
            const liDisabled = item.unselectable || (selected && enabled === 1);
            return io_element.wire(this, `html:${itemID}`) `
      <li
        id="${itemID}"
        class="${item.premium ? "premium" : ""}"
        role="option"
        aria-disabled="${swap ? !item.disabled : liDisabled}"
        aria-selected="${selected}"
      >${this.getItemTitle(item)}</li>`;
        })}</ul>`;
    }
}
IOListBox.define("io-list-box");
let resizeTimer = 0;
window.addEventListener("resize", () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
        resizeTimer = 0;
        for (const ioListBox of $$("io-list-box")) {
            if (!ioListBox.items || isVisible(ioListBox))
                return;
            ioListBox.style.setProperty("--width", "100%");
            requestAnimationFrame(() => {
                requestAnimationFrame(setWidth.bind(ioListBox));
            });
        }
    }, 1000 / 30);
});
function getID(item) {
    return `li-${item.url
        .split("")
        .map((c) => c.charCodeAt(0).toString(32))
        .join("")}`;
}
function getItem(id) {
    return this._items.find((item) => !item.group && getID(item) === id);
}
function hover(type, item) {
    const id = getID(item);
    if (!id)
        return;
    const hovered = $(".hover", this);
    if (hovered)
        hovered.classList.remove("hover");
    const option = $(`#${id}`, this);
    option.classList.add("hover");
    this.label.setAttribute("aria-activedescendant", id);
    const popup = this.popup;
    if (type !== "mouse" && popup.scrollHeight > popup.clientHeight) {
        const scrollBottom = popup.clientHeight + popup.scrollTop;
        const elementBottom = option.offsetTop + option.offsetHeight;
        if (elementBottom > scrollBottom) {
            popup.scrollTop = elementBottom - popup.clientHeight;
        }
        else if (option.offsetTop < popup.scrollTop) {
            popup.scrollTop = option.offsetTop;
        }
    }
}
function findNext(el, other) {
    const first = el;
    do {
        el = el[other];
    } while (el &&
        el !== first &&
        !isDisabled.call(this, el));
    return el === first ? null : el;
}
function isDisabled(el) {
    return el.id && getItem.call(this, el.id).disabled;
}
function isVisible(el) {
    const cstyle = window.getComputedStyle(el, null);
    return cstyle.getPropertyValue("display") !== "none";
}
function setWidth() {
    this.style.setProperty("--width", this.label.offsetWidth + "px");
}

;// ./js/io-popout.mjs



class IOPopout extends io_element {
    static get observedAttributes() {
        return ["anchor-icon", "expanded", "i18n-body", "i18n-doclinks", "type"];
    }
    created() {
        this._children = Array.from(this.children);
        this.addEventListener("blur", this);
        this.addEventListener("click", this);
        this.setAttribute("tabindex", 0);
    }
    attributeChangedCallback() {
        this.render();
    }
    onblur(ev) {
        if (ev.relatedTarget && this.contains(ev.relatedTarget))
            return;
        this.expanded = null;
    }
    onclick(ev) {
        const { target } = ev;
        if (target.classList.contains("wrapper")) {
            ev.preventDefault();
            if (this.expanded) {
                this.expanded = null;
            }
            else if (this.type == "dialog" || this.type == "tooltip") {
                const { bottom, top } = ev.target.getBoundingClientRect();
                const { clientHeight } = document.documentElement;
                this.expanded = clientHeight - bottom > top ? "below" : "above";
            }
            else {
                this.expanded = "start";
            }
        }
        else if (target.nodeName == "A" || target.nodeName == "BUTTON") {
            this.expanded = null;
        }
    }
    render() {
        const { wire } = IOPopout;
        const role = this.type || "tooltip";
        const content = [];
        if (role == "dialog" || role == "tooltip") {
            content.push(wire(this, ":close") `
        <button class="icon close secondary"></button>
      `);
        }
        if (this.i18nBody) {
            const body = wire(this, ":body") `
        <p>${{ i18n: this.i18nBody }}</p>
      `;
            const { i18nDoclinks } = this.dataset;
            if (i18nDoclinks) {
                Promise.all(i18nDoclinks.split(",").map(getDoclink)).then((links) => {
                    setElementLinks(body, ...links);
                });
            }
            content.push(body);
        }
        content.push(...this._children);
        this.html `
    <div class="wrapper icon">
      <div role="${role}" aria-hidden="${!this.expanded}">
        ${content}
      </div>
    </div>
    `;
    }
}
IOPopout.define("io-popout");

;// ./js/pages/desktop-options/index.mjs
















const extensionsUIServerLogger = new ewe_ui_namespaceObject.telemetry.ServerLogger("extensions_ui");
const ALLOWED_PROTOCOLS = /^(?:data|https):/;
const emitter = new EventEmitter();
let subscriptionsMap = Object.create(null);
let filtersMap = Object.create(null);
let acceptableAdsUrl = null;
let acceptableAdsPrivacyUrl = null;
let isCustomFiltersLoaded = false;
let additionalSubscriptions = [];
let premiumIsActive = null;
let focusedBeforeDialog = null;
let promisedDateFormat = null;
let promisedResources = null;
const collections = Object.create(null);
const { getMessage: desktop_options_getMessage } = browser.i18n;
const customFilters = [];
const syncErrorIds = new Map([
    ["synchronize_invalid_url", "options_filterList_lastDownload_invalidURL"],
    [
        "synchronize_connection_error",
        "options_filterList_lastDownload_connectionError"
    ],
    ["synchronize_invalid_data", "options_filterList_lastDownload_invalidData"],
    [
        "synchronize_checksum_mismatch",
        "options_filterList_lastDownload_checksumMismatch"
    ],
    ["synchronize_diff_error", "options_filterList_lastDownload_diffError"],
    [
        "synchronize_diff_too_many_filters",
        "options_filterList_lastDownload_diffTooManyFilters"
    ],
    [
        "synchronize_too_many_filters",
        "options_filterList_lastDownload_tooManyFilters"
    ],
    ["synchronize_diff_too_old", "options_filterList_lastDownload_diffTooOld"],
    ["synchronize_dnr_error", "options_filterList_lastDownload_dnrError"]
]);
const filtersDisabledErrorId = "options_filterList_filtersDisabled";
const subscriptionErrorIds = new Map();
const timestampUI = Symbol();
const allowlistedDomainRegexp = /^@@\|\|([^/:]+)\^\$document$/;
const allowlistedPageRegexp = /^@@\|([^?|]+(?:\?[^|]*)?)\|?\$document$/;
const minuteInMs = 60000;
const hourInMs = 3600000;
const fullDayInMs = 86400000;
function Collection(details) {
    this.details = details;
    this.items = [];
}
Collection.prototype._setEmpty = function (table, detail, removeEmpty) {
    if (removeEmpty) {
        const placeholders = $$(".empty-placeholder", table);
        for (const placeholder of placeholders)
            table.removeChild(placeholder);
        execAction(detail.removeEmptyAction, table);
    }
    else {
        const { emptyTexts = [] } = detail;
        for (const text of emptyTexts) {
            const placeholder = document.createElement("li");
            placeholder.className = "empty-placeholder";
            placeholder.textContent = desktop_options_getMessage(text);
            table.appendChild(placeholder);
        }
        execAction(detail.setEmptyAction, table);
    }
};
Collection.prototype._createElementQuery = function (item) {
    const access = (item.url || item.text).replace(/'/g, "\\'");
    return function (container) {
        return $(`[data-access="${access}"]`, container);
    };
};
Collection.prototype._getItemTitle = function (item, i) {
    if (this.details[i].getItemTitle)
        return this.details[i].getItemTitle(item);
    return getRawItemTitle(item);
};
Collection.prototype._sortItems = function () {
    this.items.sort((a, b) => {
        if (a.url && isAcceptableAds(a.url))
            return 1;
        if (b.url && isAcceptableAds(b.url))
            return -1;
        const aTimestamp = a[timestampUI] || 0;
        const bTimestamp = b[timestampUI] || 0;
        if (aTimestamp || bTimestamp)
            return bTimestamp - aTimestamp;
        const aTitle = this._getItemTitle(a, 0).toLowerCase();
        const bTitle = this._getItemTitle(b, 0).toLowerCase();
        return aTitle.localeCompare(bTitle);
    });
};
Collection.prototype.addItem = function (item) {
    if (this.items.indexOf(item) >= 0)
        return;
    this.items.push(item);
    this._sortItems();
    for (let j = 0; j < this.details.length; j++) {
        const detail = this.details[j];
        const table = $(`#${detail.id}`);
        const template = $("template", table) ||
            $("template", table.closest(".template-container"));
        const listItem = document.createElement("li");
        listItem.appendChild(document.importNode(template.content, true));
        listItem.setAttribute("aria-label", this._getItemTitle(item, j));
        listItem.setAttribute("data-recommended", item.recommended);
        listItem.setAttribute("data-access", item.url || item.text);
        const tooltip = $("io-popout[type='tooltip']", listItem);
        if (tooltip) {
            let tooltipId = tooltip.dataset.templateI18nBody;
            tooltipId = tooltipId.replace("%value%", item.recommended);
            if (desktop_options_getMessage(tooltipId)) {
                tooltip.setAttribute("i18n-body", tooltipId);
            }
        }
        const descriptionNode = $(".description", listItem);
        if (descriptionNode) {
            let descriptionId = descriptionNode.dataset.templateI18nBody;
            descriptionId = descriptionId.replace("%value%", item.recommended.replace(/-/g, "_"));
            const description = desktop_options_getMessage(descriptionId);
            descriptionNode.textContent = description;
        }
        this._setEmpty(table, detail, true);
        if (table.children.length > 0)
            table.insertBefore(listItem, table.children[this.items.indexOf(item)]);
        else
            table.appendChild(listItem);
        this.updateItem(item);
    }
    return length;
};
Collection.prototype.removeItem = function (item) {
    const index = this.items.indexOf(item);
    if (index == -1)
        return;
    this.items.splice(index, 1);
    const getListElement = this._createElementQuery(item);
    for (const detail of this.details) {
        const table = $(`#${detail.id}`);
        const element = getListElement(table);
        const control = $(".control", element);
        if (control && control == document.activeElement) {
            if (!focusNextElement(element.parentElement, control)) {
                let focusableElement = element.parentElement;
                while (focusableElement) {
                    if (focusableElement.classList.contains("tab-content") ||
                        focusableElement.classList.contains("dialog-content"))
                        break;
                    focusableElement = focusableElement.parentElement;
                }
                focusNextElement(focusableElement || document, control);
            }
        }
        element.parentElement.removeChild(element);
        if (this.items.length == 0)
            this._setEmpty(table, detail);
    }
};
Collection.prototype.updateItem = function (item) {
    const oldIndex = this.items.indexOf(item);
    if (oldIndex === -1)
        return;
    this._sortItems();
    const access = (item.url || item.text).replace(/'/g, "\\'");
    for (let i = 0; i < this.details.length; i++) {
        const table = $(`#${this.details[i].id}`);
        const element = $(`[data-access="${access}"]`, table);
        const title = this._getItemTitle(item, i);
        const displays = $$("[data-display]", element);
        for (let j = 0; j < displays.length; j++) {
            if (item[displays[j].dataset.display])
                displays[j].textContent = item[displays[j].dataset.display];
            else
                displays[j].textContent = title;
        }
        element.setAttribute("aria-label", title);
        if (this.details[i].searchable)
            element.setAttribute("data-search", title.toLowerCase());
        const controls = $$(`.control[role='checkbox'],
      io-toggle.control`, element);
        for (const control of controls) {
            const checked = !item.disabled;
            if (control.matches("io-toggle"))
                control.checked = checked;
            else
                control.setAttribute("aria-checked", checked);
            if (isAcceptableAds(item.url) && this == collections.filterLists) {
                control.disabled = true;
                control.setAttribute("aria-hidden", true);
            }
        }
        if (additionalSubscriptions.includes(item.url)) {
            element.classList.add("preconfigured");
            const disablePreconfigures = $$("[data-disable~='preconfigured']", element);
            for (const disablePreconfigure of disablePreconfigures)
                disablePreconfigure.disabled = true;
        }
        const lastUpdateElement = $(".last-update", element);
        if (lastUpdateElement) {
            element.classList.remove("show-message");
            cleanSyncErrorIdsFromSubscription(item.url);
            if (!item.updatable) {
                const text = desktop_options_getMessage("options_filterList_lastDownload_bundled");
                $(".message", element).textContent = text;
                element.classList.add("show-message");
            }
            else if (item.downloading) {
                const text = desktop_options_getMessage("options_filterList_lastDownload_inProgress");
                $(".message", element).textContent = text;
                element.classList.add("show-message");
            }
            else if (item.downloadStatus != "synchronize_ok") {
                if (item.downloadStatus === "synchronize_invalid_url" &&
                    !ALLOWED_PROTOCOLS.test(item.url)) {
                    addErrorIdToSubscription(item.url, "options_filterList_lastDownload_invalidURLProtocol");
                }
                else {
                    const errorId = syncErrorIds.get(item.downloadStatus) || item.downloadStatus;
                    if (errorId)
                        addErrorIdToSubscription(item.url, errorId);
                }
            }
            else if (item.lastDownload > 0) {
                const lastUpdate = item.lastDownload * 1000;
                const sinceUpdate = Date.now() - lastUpdate;
                if (sinceUpdate > fullDayInMs) {
                    const lastUpdateDate = new Date(item.lastDownload * 1000);
                    promisedDateFormat.then((dateFormat) => {
                        lastUpdateElement.textContent = dateFormat.format(lastUpdateDate);
                    });
                }
                else if (sinceUpdate > hourInMs) {
                    lastUpdateElement.textContent = desktop_options_getMessage("options_filterList_hours");
                }
                else if (sinceUpdate > minuteInMs) {
                    lastUpdateElement.textContent = desktop_options_getMessage("options_filterList_minutes");
                }
                else {
                    lastUpdateElement.textContent = desktop_options_getMessage("options_filterList_now");
                }
            }
            updateErrorTooltip(element, subscriptionErrorIds.get(item.url));
        }
        const updateElement = $("io-popout .update-subscription", element);
        if (updateElement) {
            updateElement.setAttribute("aria-hidden", !item.updatable);
        }
        const websiteElement = $("io-popout .website", element);
        if (websiteElement) {
            if (item.homepage)
                websiteElement.setAttribute("href", item.homepage);
            websiteElement.setAttribute("aria-hidden", !item.homepage);
        }
        const sourceElement = $("io-popout .source", element);
        if (sourceElement)
            sourceElement.setAttribute("href", item.url);
        const newIndex = this.items.indexOf(item);
        if (oldIndex != newIndex)
            table.insertBefore(element, table.childNodes[newIndex]);
    }
    emitter.emit("collectionItem.updated", item);
};
Collection.prototype.clearAll = function () {
    this.items = [];
    for (const detail of this.details) {
        const table = $(`#${detail.id}`);
        let element = table.firstChild;
        while (element) {
            if (element.tagName == "LI" && !element.classList.contains("static"))
                table.removeChild(element);
            element = element.nextElementSibling;
        }
        this._setEmpty(table, detail);
    }
};
function focusNextElement(container, currentElement) {
    let focusables = $$("a, button, input, .control", container);
    focusables = Array.prototype.slice.call(focusables);
    let index = focusables.indexOf(currentElement);
    index += index == focusables.length - 1 ? -1 : 1;
    const nextElement = focusables[index];
    if (!nextElement)
        return false;
    nextElement.focus();
    return true;
}
function addSubscription(subscription) {
    const { disabled, recommended, url } = subscription;
    let collection = null;
    switch (recommended) {
        case "ads":
            if (disabled == false)
                collection = collections.langs;
            const ioListBox = $("#languages-box");
            ioListBox.items = ioListBox.items.concat(subscription);
            break;
        case "notifications":
        case "privacy":
        case "social":
        case "videos":
            collection = collections.recommendedFreeList;
            break;
        default:
            if (typeof recommended === "undefined" &&
                !isAcceptableAds(url) &&
                disabled == false)
                collection = collections.more;
            else if (premiumTypes.has(recommended)) {
                collection = collections.recommendedPremiumList;
            }
            break;
    }
    if (collection) {
        collection.addItem(subscription);
    }
    subscriptionsMap[url] = subscription;
}
function updateSubscription(subscription) {
    for (const name in collections)
        collections[name].updateItem(subscription);
    if (subscription.recommended == "ads") {
        if (subscription.disabled)
            collections.langs.removeItem(subscription);
        else
            collections.langs.addItem(subscription);
    }
    else if (!subscription.recommended && !isAcceptableAds(subscription.url)) {
        if (subscription.disabled == false) {
            collections.more.addItem(subscription);
        }
        else {
            collections.more.removeItem(subscription);
        }
    }
    if (!(subscription.url in subscriptionsMap)) {
        subscriptionsMap[subscription.url] = subscription;
    }
}
function updateFilter(filter) {
    var _a;
    if (((_a = filter.metadata) === null || _a === void 0 ? void 0 : _a.origin) === FilterOrigin.experiment) {
        return;
    }
    let allowlistTitle = null;
    const domainMatch = filter.text.match(allowlistedDomainRegexp);
    if (domainMatch && !filtersMap[filter.text]) {
        allowlistTitle = domainMatch[1];
    }
    else {
        const pageMatch = filter.text.match(allowlistedPageRegexp);
        if (pageMatch && !filtersMap[filter.text]) {
            const url = pageMatch[1];
            allowlistTitle = url.replace(/^[\w-]+:\/+(?:www\.)?/, "");
            if (/\?$/.test(allowlistTitle)) {
                allowlistTitle += "…";
            }
        }
    }
    if (allowlistTitle) {
        filter.title = allowlistTitle;
        collections.allowlist.addItem(filter);
        if (isCustomFiltersLoaded) {
            const text = desktop_options_getMessage("options_allowlist_notification", [filter.title]);
            showNotification(text, "info");
        }
    }
    else {
        customFilters.push(filter);
    }
    filtersMap[filter.text] = filter;
}
function loadCustomFilters(filters) {
    for (const filter of filters)
        updateFilter(filter);
    const cfTable = $("#custom-filters io-filter-table");
    cfTable.filters = customFilters;
}
function removeCustomFilter(text) {
    const index = customFilters.findIndex((filter) => filter.text === text);
    if (index >= 0)
        customFilters.splice(index, 1);
}
async function loadResources() {
    const subscriptions = [];
    try {
        await loadLanguageNames();
        const recommendations = await get("recommendations");
        for (const recommendation of recommendations) {
            const subscription = {
                disabled: true,
                downloadStatus: null,
                homepage: null,
                languages: recommendation.languages,
                recommended: recommendation.type,
                title: recommendation.title,
                url: recommendation.url
            };
            subscriptions.push(subscription);
            addSubscription(subscription);
        }
    }
    catch (ex) {
        dispatchError(ex);
    }
    return { recommendations: subscriptions };
}
function findParentData(element, dataName, returnElement) {
    element = element.closest(`[data-${dataName}]`);
    if (!element)
        return null;
    if (returnElement)
        return element;
    return element.getAttribute(`data-${dataName}`);
}
function sendMessageHandleErrors(message, onSuccess) {
    browser.runtime.sendMessage(message).then((errors) => {
        if (errors.length > 0) {
            errors = errors.map(getErrorMessage);
            alert(stripTagsUnsafe(errors.join("\n")));
        }
        else if (onSuccess)
            onSuccess();
    });
}
function switchTab(id) {
    location.hash = id;
}
function isAcceptableAds(url) {
    return url == acceptableAdsUrl || url == acceptableAdsPrivacyUrl;
}
function hasPrivacyConflict() {
    const acceptableAdsList = subscriptionsMap[acceptableAdsUrl];
    let privacyList = null;
    for (const url in subscriptionsMap) {
        const subscription = subscriptionsMap[url];
        if (subscription.recommended == "privacy") {
            privacyList = subscription;
            break;
        }
    }
    return (acceptableAdsList &&
        acceptableAdsList.disabled == false &&
        privacyList &&
        privacyList.disabled == false);
}
const setAcceptableAds = async (options = {}) => {
    const { firstLoad } = options;
    const subscriptions = await category_subscriptions_get();
    const activeSubscriptionUrls = subscriptions
        .map(({ disabled, url }) => !disabled && url)
        .filter(Boolean);
    const acceptableAds = $("#acceptable-ads-allow");
    const acceptableAdsPrivacy = $("#acceptable-ads-privacy-allow");
    const acceptableAdsWhyNot = $("#acceptable-ads-why-not");
    if (activeSubscriptionUrls.includes(acceptableAdsUrl)) {
        acceptableAds.checked = true;
        acceptableAdsPrivacy.disabled = false;
        toggleDntNotification(false);
        acceptableAdsWhyNot.setAttribute("aria-hidden", true);
    }
    else if (activeSubscriptionUrls.includes(acceptableAdsPrivacyUrl)) {
        acceptableAds.checked = true;
        acceptableAdsPrivacy.checked = true;
        acceptableAdsPrivacy.disabled = false;
        if (navigator.doNotTrack !== "1") {
            toggleDntNotification(true);
        }
        acceptableAdsWhyNot.setAttribute("aria-hidden", true);
    }
    else {
        acceptableAds.checked = false;
        acceptableAdsPrivacy.checked = false;
        acceptableAdsPrivacy.disabled = true;
        if (!firstLoad) {
            acceptableAdsWhyNot.setAttribute("aria-hidden", false);
        }
        toggleDntNotification(false);
    }
};
function setPrivacyConflict() {
    const acceptableAdsForm = $("#acceptable-ads");
    if (hasPrivacyConflict()) {
        getPref("ui_warn_tracking").then((showTrackingWarning) => {
            acceptableAdsForm.classList.toggle("show-warning", showTrackingWarning);
        });
    }
    else {
        acceptableAdsForm.classList.remove("show-warning");
    }
}
const switchAcceptableAds = (e) => {
    e.stopPropagation();
    const { checked, dataset: { value } } = e.target;
    if (value === "ads") {
        const acceptableAdsPrivacy = $("#acceptable-ads-privacy-allow");
        const aaSurvey = $("#acceptable-ads-why-not");
        if (acceptableAdsPrivacy.checked) {
            void browser.runtime.sendMessage({
                type: "subscriptions.remove",
                url: acceptableAdsPrivacyUrl
            });
        }
        else {
            aaSurvey.setAttribute("aria-hidden", checked);
            void browser.runtime.sendMessage({
                type: checked ? "subscriptions.add" : "subscriptions.remove",
                url: acceptableAdsUrl
            });
        }
        extensionsUIServerLogger.behavior("acceptable_ads_toggled", {
            action: checked ? "opted_in" : "opted_out",
            source: "options_general"
        });
    }
    else {
        void browser.runtime.sendMessage({
            type: !checked ? "subscriptions.add" : "subscriptions.remove",
            url: acceptableAdsUrl
        });
        void browser.runtime.sendMessage({
            type: checked ? "subscriptions.add" : "subscriptions.remove",
            url: acceptableAdsPrivacyUrl
        });
    }
};
const toggleDntNotification = (show) => {
    const acceptableAdsForm = $("#acceptable-ads");
    if (show === false) {
        acceptableAdsForm.classList.remove("show-dnt-notification");
    }
    else {
        acceptableAdsForm.classList.add("show-dnt-notification");
    }
};
const downloadDebugData = (data) => {
    if (!data) {
        data = "Error: no debug data was returned";
    }
    const myBlob = new Blob([JSON.stringify(data, null, 4)], {
        type: "application/json"
    });
    const blobURL = URL.createObjectURL(myBlob);
    const a = document.createElement("a");
    a.setAttribute("href", blobURL);
    const currentLocalTimeNoSpecialChars = new Date()
        .toISOString()
        .split(".")[0]
        .slice(0, -2)
        .replace(/[-T:]/g, "");
    a.setAttribute("download", `adblockplus-data-${currentLocalTimeNoSpecialChars}.json`);
    a.style.display = "none";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(blobURL);
};
function execAction(action, element) {
    if (element.getAttribute("aria-disabled") === "true" ||
        element.disabled === true ||
        !action) {
        return false;
    }
    switch (action) {
        case "add-domain-exception":
            addAllowlistedDomain();
            return true;
        case "add-language-subscription":
            addEnableSubscription(findParentData(element, "access", false));
            return true;
        case "add-predefined-subscription": {
            const dialog = $("#dialog-content-predefined");
            const title = $(".title > span", dialog).textContent;
            const url = $(".url > a", dialog).textContent;
            addEnableSubscription(url, title);
            closeDialog();
            return true;
        }
        case "change-language-subscription":
            changeLanguageSubscription(findParentData(element, "access", false));
            return true;
        case "add-subscription": {
            const url = findParentData(element, "access", false);
            addEnableSubscription(url);
            closeDialog();
            return true;
        }
        case "close-dialog":
            closeDialog();
            return true;
        case "hide-more-filters-section":
            $("#more-filters").setAttribute("aria-hidden", true);
            return true;
        case "hide-acceptable-ads-survey":
            $("#acceptable-ads-why-not").setAttribute("aria-hidden", true);
            return false;
        case "hide-notification":
            hideNotification();
            return true;
        case "import-subscription": {
            const url = $("#blockingList-textbox").value;
            addEnableSubscription(url);
            closeDialog();
            return true;
        }
        case "open-dialog": {
            const url = findParentData(element, "access", false);
            const dialog = findParentData(element, "dialog", false);
            openDialog(dialog, { subscriptionUrl: url });
            return true;
        }
        case "close-filterlist-by-url":
            closeAddFiltersByURL();
            return true;
        case "open-languages-box":
            const ioListBox = $("#languages-box");
            ioListBox.swap = true;
            $("button", ioListBox).focus();
            return true;
        case "remove-filter":
            browser.runtime.sendMessage({
                type: "filters.remove",
                text: findParentData(element, "access", false)
            });
            return true;
        case "remove-subscription": {
            const removedUrl = findParentData(element, "access", false);
            browser.runtime.sendMessage({
                type: "subscriptions.remove",
                url: removedUrl
            });
            if (isAcceptableAds(removedUrl)) {
                extensionsUIServerLogger.behavior("acceptable_ads_toggled", {
                    action: "opted_out",
                    source: "options_filter_list"
                });
            }
            return true;
        }
        case "show-more-filters-section":
            $("#more-filters").setAttribute("aria-hidden", false);
            return true;
        case "switch-tab":
            switchTab(element.getAttribute("href").substr(1));
            return true;
        case "enable-filters":
            const url = findParentData(element, "access", false);
            const subscription = subscriptionsMap[url];
            browser.runtime
                .sendMessage({
                type: "subscriptions.enableAllFilters",
                url
            })
                .then(() => updateSubscription(subscription));
            return true;
        case "toggle-disable-subscription":
            browser.runtime.sendMessage({
                type: "subscriptions.toggle",
                keepInstalled: true,
                url: findParentData(element, "access", false)
            });
            return true;
        case "toggle-pref":
            browser.runtime.sendMessage({
                type: "prefs.toggle",
                key: findParentData(element, "pref", false)
            });
            return true;
        case "toggle-remove-subscription":
            const subscriptionUrl = findParentData(element, "access", false);
            if (element.getAttribute("aria-checked") == "true") {
                browser.runtime.sendMessage({
                    type: "subscriptions.remove",
                    url: subscriptionUrl
                });
            }
            else
                addEnableSubscription(subscriptionUrl);
            return true;
        case "update-all-subscriptions":
            browser.runtime.sendMessage({
                type: "subscriptions.update"
            });
            return true;
        case "update-subscription":
            browser.runtime.sendMessage({
                type: "subscriptions.update",
                url: findParentData(element, "access", false)
            });
            return true;
        case "validate-import-subscription":
            const form = findParentData(element, "validation", true);
            if (!form)
                return;
            if (form.checkValidity()) {
                addEnableSubscription($("#import-list-url", form).value);
                form.reset();
                closeAddFiltersByURL();
            }
            else {
                $(":invalid", form).focus();
            }
            return true;
    }
    return false;
}
function execActions(actions, element) {
    actions = actions.split(",");
    let foundAction = false;
    for (const action of actions) {
        foundAction |= execAction(action, element);
    }
    return !!foundAction;
}
function changeLanguageSubscription(url) {
    for (const key in subscriptionsMap) {
        const subscription = subscriptionsMap[key];
        const subscriptionType = subscription.recommended;
        if (subscriptionType == "ads" && subscription.disabled == false) {
            browser.runtime.sendMessage({
                type: "subscriptions.remove",
                url: subscription.url
            });
            browser.runtime.sendMessage({
                type: "subscriptions.add",
                url
            });
            break;
        }
    }
}
function onClick(e) {
    const actions = findParentData(e.target, "action", false);
    if (!actions)
        return;
    const foundAction = execActions(actions, e.target);
    if (foundAction) {
        e.preventDefault();
    }
}
function onKeyUp(event) {
    const { key } = event;
    let element = document.activeElement;
    if (!key || !element)
        return;
    const container = findParentData(element, "action", true);
    if (!container || !container.hasAttribute("data-keys"))
        return;
    const keys = container.getAttribute("data-keys").split(" ");
    if (keys.indexOf(key) < 0)
        return;
    if (element.getAttribute("role") == "tab") {
        let parent = element.parentElement;
        if (key == "ArrowLeft" || key == "ArrowUp")
            parent = parent.previousElementSibling || container.lastElementChild;
        else if (key == "ArrowRight" || key == "ArrowDown")
            parent = parent.nextElementSibling || container.firstElementChild;
        element = parent.firstElementChild;
    }
    const actions = container.getAttribute("data-action");
    const foundAction = execActions(actions, element);
    if (foundAction) {
        event.preventDefault();
    }
}
function selectTabItem(tabId, container, focus) {
    document.body.setAttribute("data-tab", tabId);
    const tabList = $("[role='tablist']", container);
    if (!tabList)
        return null;
    const previousTab = $("[aria-selected]", tabList);
    previousTab.removeAttribute("aria-selected");
    previousTab.setAttribute("tabindex", -1);
    const tab = $(`a[href="#${tabId}"]`, tabList);
    tab.setAttribute("aria-selected", true);
    tab.setAttribute("tabindex", 0);
    const tabContentId = tab.getAttribute("aria-controls");
    const tabContent = document.getElementById(tabContentId);
    if (tab && focus)
        tab.focus();
    if (tabId === "advanced") {
        setupFiltersBox();
        setupAddFiltersByURL();
    }
    document.dispatchEvent(new CustomEvent("tabActivated", { detail: { tabId } }));
    return tabContent;
}
function onHashChange() {
    const hash = location.hash.substr(1);
    if (!hash)
        return;
    const tabIds = hash.split("-");
    let tabContent = document.body;
    for (let i = 0; i < tabIds.length; i++) {
        const tabId = tabIds.slice(0, i + 1).join("-");
        tabContent = selectTabItem(tabId, tabContent, true);
        if (!tabContent)
            break;
    }
}
function setupFiltersBox() {
    const ioListBox = $("#filters-box");
    if (!ioListBox.items.length) {
        ioListBox.getItemTitle = (item) => getPrettyItemTitle(item, true);
        ioListBox.addEventListener("change", (event) => {
            const item = event.detail;
            addEnableSubscription(item.url, item.title, item.homepage);
        });
    }
    promisedResources.then(({ recommendations }) => {
        ioListBox.items = getListBoxItems(recommendations);
    });
}
function getListBoxItems(subscriptions) {
    const urls = new Set();
    for (const subscription of collections.filterLists.items)
        urls.add(subscription.url);
    const groups = {
        ads: [],
        others: []
    };
    for (const subscription of subscriptions) {
        const { recommended, url } = subscription;
        if (recommended === "allowing")
            continue;
        const key = recommended === "ads" ? recommended : "others";
        const label = getPrettyItemTitle(subscription, true);
        const selected = urls.has(url);
        const premium = premiumTypes.has(recommended);
        const overrides = { unselectable: selected, label, selected, premium };
        groups[key].push(Object.assign({}, subscription, overrides));
    }
    return [
        ...groups.others,
        {
            type: "ads",
            group: true,
            description: browser.i18n.getMessage("options_language_filter_list")
        },
        ...groups.ads
    ];
}
function startLanguagesBox() {
    const ioListBox = $("#languages-box");
    ioListBox.getItemTitle = (item) => getPrettyItemTitle(item, false);
    ioListBox.addEventListener("close", (event) => {
        ioListBox.swap = false;
    });
    ioListBox.addEventListener("change", (event) => {
        const item = event.detail;
        if (ioListBox.swap)
            changeLanguageSubscription(item.url);
        else {
            item.disabled = !item.disabled;
            addEnableSubscription(item.url, item.title, item.homepage);
        }
    });
}
function openDialog(name, options) {
    const dialog = $("#dialog");
    dialog.setAttribute("aria-hidden", false);
    dialog.setAttribute("aria-labelledby", `dialog-title-${name}`);
    dialog.setAttribute("aria-describedby", `dialog-description-${name}`);
    document.body.setAttribute("data-dialog", name);
    if (options && options.subscriptionUrl) {
        dialog.setAttribute("data-access", options.subscriptionUrl);
    }
    let defaultFocus = $(`#dialog-content-${name} .default-focus`);
    if (!defaultFocus)
        defaultFocus = $(".focus-first", dialog);
    focusedBeforeDialog = document.activeElement;
    defaultFocus.focus();
}
function closeDialog() {
    const dialog = $("#dialog");
    dialog.setAttribute("aria-hidden", true);
    dialog.removeAttribute("aria-labelledby");
    document.body.removeAttribute("data-dialog");
    focusedBeforeDialog.focus();
}
function showNotification(text, kind) {
    const notification = $("#notification");
    notification.setAttribute("aria-hidden", false);
    $("#notification-text", notification).textContent = text;
    notification.classList.add(kind);
    notification.addEventListener("animationend", hideNotification);
}
function hideNotification() {
    const notification = $("#notification");
    notification.classList.remove("info", "error");
    notification.setAttribute("aria-hidden", true);
    $("#notification-text", notification).textContent = "";
}
async function populateFilters() {
    const filters = await category_filters_get();
    loadCustomFilters([].concat(...filters));
    isCustomFiltersLoaded = true;
}
async function populateLists() {
    subscriptionsMap = Object.create(null);
    filtersMap = Object.create(null);
    for (const property in collections)
        collections[property].clearAll();
    const [url, privacyUrl, additionalSubscriptionUrls, subscriptions] = await Promise.all([
        get("acceptableAdsUrl"),
        get("acceptableAdsPrivacyUrl"),
        category_prefs_get("additional_subscriptions"),
        category_subscriptions_get()
    ]);
    acceptableAdsUrl = url;
    acceptableAdsPrivacyUrl = privacyUrl;
    additionalSubscriptions = additionalSubscriptionUrls;
    setAcceptableAds({ firstLoad: true });
    for (const subscription of subscriptions)
        onSubscriptionMessage("added", subscription);
}
function addAllowlistedDomain() {
    const domain = $("#allowlisting-textbox");
    const value = domain.value.trim();
    if (!value)
        return;
    for (const allowlistItem of collections.allowlist.items) {
        if (allowlistItem.title == value) {
            allowlistItem[timestampUI] = Date.now();
            collections.allowlist.updateItem(allowlistItem);
            domain.value = "";
            break;
        }
    }
    try {
        const { host } = new URL(/^https?:/.test(value) ? value : `http://${value}`);
        sendMessageHandleErrors({
            type: "filters.add",
            text: "@@||" + host.toLowerCase() + "^$document",
            origin: FilterOrigin.optionsAllowlistedWebsites
        });
        domain.value = "";
        $("#allowlisting-add-button").disabled = true;
    }
    catch (error) {
        dispatchError(error);
    }
}
function addEnableSubscription(url, title, homepage) {
    let messageType = null;
    const knownSubscription = subscriptionsMap[url];
    if (knownSubscription && knownSubscription.disabled == true)
        messageType = "subscriptions.toggle";
    else
        messageType = "subscriptions.add";
    const message = {
        type: messageType,
        url
    };
    if (title)
        message.title = title;
    if (homepage)
        message.homepage = homepage;
    browser.runtime.sendMessage(message);
}
function cleanSyncErrorIdsFromSubscription(url) {
    for (const syncErrorId of syncErrorIds.values()) {
        removeErrorIdFromSubscription(url, syncErrorId);
    }
}
function addErrorIdToSubscription(url, errorId) {
    let errorIds = subscriptionErrorIds.get(url);
    if (!errorIds) {
        errorIds = new Set();
        subscriptionErrorIds.set(url, errorIds);
    }
    errorIds.add(errorId);
}
function removeErrorIdFromSubscription(url, errorId) {
    const errorIds = subscriptionErrorIds.get(url);
    if (!errorIds)
        return;
    errorIds.delete(errorId);
    if (errorIds.size === 0)
        subscriptionErrorIds.delete(url);
}
function updateErrorTooltip(element, errorIds) {
    const errorTooltip = $("io-popout[anchor-icon='error']", element);
    const errorList = $(".error-list", errorTooltip);
    errorList.innerHTML = "";
    if (!errorIds || element.classList.contains("show-message")) {
        element.classList.remove("error");
        return;
    }
    for (const errorId of errorIds) {
        const listItem = document.createElement("li");
        listItem.textContent = desktop_options_getMessage(errorId) || errorId;
        if (errorId === filtersDisabledErrorId) {
            const enableFiltersButton = document.createElement("a");
            enableFiltersButton.textContent = desktop_options_getMessage("options_filterList_enableFilters");
            enableFiltersButton.setAttribute("data-action", "enable-filters");
            listItem.appendChild(enableFiltersButton);
        }
        errorList.appendChild(listItem);
    }
    element.classList.add("error");
}
function wait(ms) {
    return new Promise((resolve) => {
        setTimeout(resolve, ms);
    });
}
async function startPremium(retryCount = 0) {
    if (retryCount === 0) {
        startPremiumBanners();
        startPremiumInRecommended();
    }
    const premium = await category_premium_get();
    if (!premium) {
        if (retryCount > 4) {
            throw new Error("Failed to initialize Premium");
        }
        retryCount += 1;
        await wait(200);
        startPremium(retryCount);
        return;
    }
    premiumIsActive = premium.isActive;
    updatePremiumStateInPage();
    void desktop_options_start(emitter);
}
async function startPremiumBanners() {
    const premiumUpgradeBanner = $(".premium-upgrade.banner");
    const upgradeCTA = $(".upgrade.button", premiumUpgradeBanner);
    const upgradeDescription = $("#premium-upgrade-description");
    const source = getSourceAttribute(premiumUpgradeBanner);
    const manageUrl = await category_ctalinks_get("premium-manage", { source });
    const upgradeUrl = await category_ctalinks_get("premium-upgrade", {
        source
    });
    $$(".premium-manage.banner a, .premium.login.button").forEach((cta) => {
        cta.setAttribute("href", manageUrl);
    });
    upgradeCTA.setAttribute("href", upgradeUrl);
    setElementLinks(upgradeDescription, upgradeUrl);
}
async function startPremiumInRecommended() {
    const upgradeCTA = $(".recommended-features .upgrade.button");
    const source = getSourceAttribute(upgradeCTA);
    const upgradeUrl = await category_ctalinks_get("premium-upgrade", {
        source
    });
    upgradeCTA.setAttribute("href", upgradeUrl);
}
function updatePremiumStateInPage() {
    document.body.classList.toggle("premium", premiumIsActive);
    setupFiltersBox();
    showUserAccount();
}
function onFilterMessage(action, filter) {
    switch (action) {
        case "added":
            filter[timestampUI] = Date.now();
            updateFilter(filter);
            break;
        case "removed":
            const knownFilter = filtersMap[filter.text];
            if (!knownFilter) {
                break;
            }
            if (allowlistedDomainRegexp.test(knownFilter.text) ||
                allowlistedPageRegexp.test(knownFilter.text))
                collections.allowlist.removeItem(knownFilter);
            else
                removeCustomFilter(filter.text);
            delete filtersMap[filter.text];
            break;
    }
}
function onSubscriptionMessage(action, subscription, ...args) {
    promisedResources
        .then(() => {
        if (subscription.url in subscriptionsMap) {
            const knownSubscription = subscriptionsMap[subscription.url];
            for (const property in subscription) {
                knownSubscription[property] = subscription[property];
            }
            subscription = knownSubscription;
        }
        switch (action) {
            case "added":
                const { url } = subscription;
                if (/^~user/.test(url)) {
                    loadCustomFilters(subscription.filters);
                    return;
                }
                else if (url in subscriptionsMap) {
                    updateSubscription(subscription);
                }
                else {
                    addSubscription(subscription);
                }
                if (isAcceptableAds(url)) {
                    setAcceptableAds();
                }
                browser.runtime
                    .sendMessage({
                    type: "subscriptions.getDisabledFilterCount",
                    url: subscription.url
                })
                    .then((disabledFilterCount) => {
                    if (disabledFilterCount > 0)
                        addErrorIdToSubscription(subscription.url, filtersDisabledErrorId);
                    collections.filterLists.addItem(subscription);
                    setPrivacyConflict();
                });
                break;
            case "changed":
                updateSubscription(subscription);
                setPrivacyConflict();
                break;
            case "filtersDisabled":
                const filtersDisabled = args[0];
                if (filtersDisabled)
                    addErrorIdToSubscription(subscription.url, filtersDisabledErrorId);
                else {
                    removeErrorIdFromSubscription(subscription.url, filtersDisabledErrorId);
                }
                updateSubscription(subscription);
                break;
            case "removed":
                if (subscription.recommended &&
                    subscription.recommended !== "allowing") {
                    subscription.disabled = true;
                    onSubscriptionMessage("changed", subscription);
                }
                else {
                    delete subscriptionsMap[subscription.url];
                    if (isAcceptableAds(subscription.url)) {
                        setAcceptableAds();
                    }
                    else {
                        collections.more.removeItem(subscription);
                    }
                }
                subscriptionErrorIds.delete(subscription.url);
                collections.filterLists.removeItem(subscription);
                setPrivacyConflict();
                break;
        }
    })
        .catch(dispatchError);
}
function hidePref(key, value) {
    const element = getPrefElement(key);
    if (element)
        element.setAttribute("aria-hidden", value);
}
function getPrefElement(key) {
    return $(`[data-pref="${key}"]`);
}
function getPref(key) {
    return browser.runtime.sendMessage({
        type: "prefs.get",
        key
    });
}
function onPrefMessage(key, value, initial) {
    switch (key) {
        case "notifications_ignoredcategories":
            value = value.indexOf("*") == -1;
            break;
        case "ui_warn_tracking":
            setPrivacyConflict();
            break;
    }
    const checkbox = $(`[data-pref="${key}"] button[role="checkbox"]`);
    if (checkbox)
        checkbox.setAttribute("aria-checked", value);
}
function handleMessage(message) {
    switch (message.type) {
        case "app.respond":
            switch (message.action) {
                case "addSubscription":
                    const subscription = message.args[0];
                    let { title, url } = subscription;
                    if (!title || title == url) {
                        title = "";
                    }
                    if (ALLOWED_PROTOCOLS.test(url)) {
                        const dialog = $("#dialog-content-predefined");
                        $(".title > span", dialog).textContent = title;
                        $(".title", dialog).hidden = !title;
                        const link = $(".url > a", dialog);
                        link.href = url;
                        link.textContent = url;
                        openDialog("predefined");
                    }
                    else {
                        openDialog("invalid");
                    }
                    break;
                case "focusSection":
                    let section = message.args[0];
                    if (section == "notifications") {
                        section = "advanced";
                        const elem = getPrefElement("notifications_ignoredcategories");
                        elem.classList.add("highlight-animate");
                        const onAnimationEnd = () => {
                            elem.classList.remove("highlight-animate");
                            elem.removeEventListener("animationcancel", onAnimationEnd);
                            elem.removeEventListener("animationend", onAnimationEnd);
                        };
                        elem.addEventListener("animationcancel", onAnimationEnd);
                        elem.addEventListener("animationend", onAnimationEnd);
                        $("button", elem).focus();
                    }
                    selectTabItem(section, document.body, false);
                    break;
            }
            break;
        case "filters.respond":
            onFilterMessage(message.action, message.args[0]);
            break;
        case "prefs.respond":
            onPrefMessage(message.action, message.args[0], false);
            break;
        case "premium.respond":
            premiumIsActive = message.args[0].isActive;
            startPremiumBanners();
            updatePremiumStateInPage();
            break;
        case "subscriptions.respond":
            onSubscriptionMessage(message.action, ...message.args);
            setupFiltersBox();
            break;
    }
}
function dispatchError(error) {
    if (error)
        window.console.error(error);
    window.dispatchEvent(new CustomEvent("error"));
}
async function startAdditionalSidebar() {
    const info = await getInfo();
    document.documentElement.dataset.application = info.application;
    document.documentElement.dataset.manifestVersion = info.manifestVersion;
    if (!["chrome", "chromium", "opera", "firefox"].includes(info.application)) {
        $("#support-us").setAttribute("aria-hidden", true);
    }
    else {
        const url = await category_doclinks_get(`${info.store}_review`);
        $("#support-us a[data-i18n='options_rating_button']").href = url;
    }
}
function startCollections() {
    collections.recommendedFreeList = new Collection([
        {
            id: "free-list-table",
            getItemTitle: (item) => getPrettyItemTitle(item, false)
        }
    ]);
    collections.recommendedPremiumList = new Collection([
        {
            id: "premium-list-table",
            getItemTitle: (item) => getPrettyItemTitle(item, false)
        }
    ]);
    collections.langs = new Collection([
        {
            id: "blocking-languages-table",
            emptyTexts: ["options_language_empty"],
            getItemTitle: (item) => getPrettyItemTitle(item, false)
        }
    ]);
    collections.more = new Collection([
        {
            id: "more-list-table",
            setEmptyAction: "hide-more-filters-section",
            removeEmptyAction: "show-more-filters-section"
        }
    ]);
    collections.allowlist = new Collection([
        {
            id: "allowlisting-table",
            emptyTexts: ["options_allowlist_empty_1", "options_allowlist_empty_2"]
        }
    ]);
    collections.filterLists = new Collection([
        {
            id: "all-filter-lists-table",
            emptyTexts: ["options_filterList_empty"]
        }
    ]);
}
function startDialog() {
    $("#dialog").addEventListener("keydown", function (event) {
        const { key, shiftKey, target } = event;
        switch (key) {
            case "Escape":
                closeDialog();
                break;
            case "Tab":
                if (shiftKey) {
                    if (target.classList.contains("focus-first")) {
                        event.preventDefault();
                        $(".focus-last", this).focus();
                    }
                }
                else if (target.classList.contains("focus-last")) {
                    event.preventDefault();
                    $(".focus-first", this).focus();
                }
                break;
        }
    }, false);
}
function startMessageListeners() {
    addMessageListener(handleMessage);
    category_app_listen(["addSubscription", "focusSection"]);
    category_filters_listen(["added", "changed", "removed"]);
    category_prefs_listen([
        "elemhide_debug",
        "notifications_ignoredcategories",
        "recommend_language_subscriptions",
        "shouldShowBlockElementMenu",
        "show_devtools_panel",
        "show_statsinicon",
        "ui_warn_tracking",
        "data_collection_opt_out"
    ]);
    category_premium_listen(["changed"]);
    category_subscriptions_listen([
        "added",
        "changed",
        "filtersDisabled",
        "removed"
    ]);
}
async function startNavigationSidebar() {
    const addonVersion = await get("addonVersion");
    $("#version").textContent = `v${addonVersion}`;
    $("#abp-version").textContent = desktop_options_getMessage("options_dialog_about_version", [
        addonVersion
    ]);
}
async function startPrefOptions() {
    const options = Array.from($$("li[data-pref]"));
    await Promise.all(options.map(async (option) => {
        const key = option.dataset.pref;
        const value = await category_prefs_get(key);
        onPrefMessage(key, value, true);
    }));
}
async function startTabAdvanced() {
    await Promise.all([
        get("features").then((features) => {
            hidePref("show_devtools_panel", !features.devToolsPanel);
        }),
        category_doclinks_get("filterdoc").then((link) => {
            setElementLinks("custom-filters-description", link);
        })
    ]);
}
async function startTabGeneral() {
    await Promise.all([
        category_doclinks_get("acceptable_ads_criteria").then((link) => {
            setElementLinks("enable-acceptable-ads-description", link);
        }),
        category_doclinks_get("imprint").then((url) => {
            setElementText($("#copyright"), "options_dialog_about_copyright", [
                new Date().getFullYear()
            ]);
            setElementLinks("copyright", url);
        }),
        category_doclinks_get("privacy").then((url) => {
            $("#privacy-policy").href = url;
        }),
        category_doclinks_get("language_subscription").then((url) => {
            setElementLinks("blocking-languages-description", url);
        }),
        category_doclinks_get("adblock_plus_{browser}_dnt").then((url) => {
            setElementLinks("dnt", url);
        }),
        category_doclinks_get("acceptable_ads_survey").then((url) => {
            $("#acceptable-ads-why-not a.primary").href = url;
        })
    ]);
    setElementText($("#tracking-warning-1"), "options_tracking_warning_1", [
        desktop_options_getMessage("common_feature_privacy_title"),
        desktop_options_getMessage("options_acceptableAds_ads_label")
    ]);
    setElementText($("#tracking-warning-3"), "options_tracking_warning_3", [
        desktop_options_getMessage("options_acceptableAds_privacy_label")
    ]);
}
async function startTabHelp() {
    await Promise.all([
        category_doclinks_get("help_center_abp_en").then((link) => {
            setElementLinks("help-center", link);
        }),
        category_doclinks_get("adblock_plus_report_bug").then((link) => {
            setElementLinks("report-bug", link);
        })
    ]);
    setElementLinks("download-debug-data", async () => {
        const granted = await browser.permissions.request({
            permissions: ["management"]
        });
        const debugData = await category_debug_getInfo();
        if (granted) {
            const installedExtensionsData = await browser.management.getAll();
            debugData.installedExtensions = installedExtensionsData.map(({ name, id, version, enabled, installType, type }) => ({
                name,
                id,
                version,
                enabled,
                installType,
                type
            }));
        }
        downloadDebugData(debugData);
    });
    const loadExtensionState = async () => {
        try {
            const state = await getAdFilteringState();
            if (!state) {
                $("#extension-state").textContent = "Failed to load extension state.";
                return;
            }
            const subscriptions = state.subscriptions || [];
            const isMV3 = state.manifestVersion === 3;
            const totalFilters = subscriptions.reduce((sum, sub) => { var _a; return sum + ((_a = sub.filterCount) !== null && _a !== void 0 ? _a : 0); }, 0);
            const makeDefinitionList = (entries) => {
                const list = document.createElement("dl");
                for (const [label, value] of entries) {
                    const term = document.createElement("dt");
                    term.textContent = label;
                    const definition = document.createElement("dd");
                    definition.textContent = value;
                    list.append(term, definition);
                }
                return list;
            };
            const makeTable = (rows) => {
                var _a, _b;
                const table = document.createElement("table");
                const thead = table.createTHead();
                const headerRow = thead.insertRow();
                const columns = [
                    ["Filter List", ""],
                    ["Version", ""],
                    ["Filters", "num"]
                ];
                if (isMV3)
                    columns.push(["Rules", "num"]);
                for (const [text, className] of columns) {
                    const header = document.createElement("th");
                    header.textContent = text;
                    if (className)
                        header.className = className;
                    headerRow.appendChild(header);
                }
                const tbody = table.createTBody();
                for (const sub of rows) {
                    const row = tbody.insertRow();
                    const nameCell = row.insertCell();
                    nameCell.textContent = sub.title;
                    if (isMV3 && sub.rulesetId) {
                        const rulesetLabel = document.createElement("small");
                        rulesetLabel.textContent = sub.rulesetId;
                        nameCell.appendChild(rulesetLabel);
                    }
                    row.insertCell().textContent = sub.version || "";
                    const filtersCell = row.insertCell();
                    filtersCell.textContent = ((_a = sub.filterCount) !== null && _a !== void 0 ? _a : 0).toLocaleString();
                    filtersCell.className = "num";
                    if (isMV3) {
                        const rulesCell = row.insertCell();
                        rulesCell.textContent = ((_b = sub.ruleCount) !== null && _b !== void 0 ? _b : 0).toLocaleString();
                        rulesCell.className = "num";
                    }
                }
                return table;
            };
            const userFiltersValue = state.experimentFiltersCount > 0
                ? `${state.userFiltersCount.toLocaleString()} (experimental: ${state.experimentFiltersCount.toLocaleString()})`
                : state.userFiltersCount.toLocaleString();
            const totals = [
                ["Filters", totalFilters.toLocaleString()],
                ["User Filters", userFiltersValue]
            ];
            if (isMV3) {
                const totalRules = subscriptions.reduce((sum, sub) => { var _a; return sum + ((_a = sub.ruleCount) !== null && _a !== void 0 ? _a : 0); }, 0);
                const enabledRulesets = subscriptions.filter((sub) => sub.rulesetId).length;
                totals.push(["Static Rules", totalRules.toLocaleString()], [
                    "Static Rulesets",
                    `${enabledRulesets.toLocaleString()} of ${state.maxEnabledRulesets.toLocaleString()}`
                ], [
                    "Dynamic Rules",
                    `${state.dnrDynamicRulesCount.toLocaleString()} of ${state.maxDynamicRules.toLocaleString()}`
                ]);
            }
            const copyButton = document.createElement("button");
            copyButton.type = "button";
            copyButton.className = "button secondary";
            copyButton.textContent = "Copy";
            copyButton.addEventListener("click", async () => {
                var _a, _b;
                const lines = [...totals.map(([key, value]) => `${key}\t${value}`), ""];
                const headers = ["Filter List", "Version", "Filters"];
                if (isMV3)
                    headers.push("Rules");
                lines.push(headers.join("\t"));
                for (const sub of subscriptions) {
                    const values = [sub.title, sub.version || "", (_a = sub.filterCount) !== null && _a !== void 0 ? _a : 0];
                    if (isMV3)
                        values.push((_b = sub.ruleCount) !== null && _b !== void 0 ? _b : 0);
                    lines.push(values.join("\t"));
                }
                const originalText = copyButton.textContent;
                try {
                    await navigator.clipboard.writeText(lines.join("\n"));
                    copyButton.textContent = "Copied!";
                }
                catch (err) {
                    copyButton.textContent = "Failed to copy";
                    ewe_ui_namespaceObject.sentry.reportError(err);
                }
                setTimeout(() => {
                    copyButton.textContent = originalText;
                }, 1500);
            });
            const container = $("#extension-state");
            container.replaceChildren(makeDefinitionList(totals), makeTable(subscriptions), copyButton);
        }
        catch (error) {
            $("#extension-state").textContent = "Failed to load extension state.";
            ewe_ui_namespaceObject.sentry.reportError(error);
        }
    };
    loadExtensionState();
    document.addEventListener("tabActivated", (e) => {
        if (e.detail.tabId === "help")
            loadExtensionState();
    });
}
async function showUserAccount() {
    const user = await ewe_ui_namespaceObject.account.getProfile();
    const loginBtn = $("#user-account-login");
    const loginCTABtn = $("#user-account-login-cta");
    const manageBtn = $("#user-account-manage");
    const source = getSourceAttribute(loginBtn);
    const manageUrl = await category_ctalinks_get("premium-manage", { source });
    loginBtn.setAttribute("href", manageUrl);
    manageBtn.setAttribute("href", manageUrl);
    if (user && user.email) {
        loginBtn.style.display = "none";
        loginCTABtn.style.display = "none";
        manageBtn.style.display = "flex";
    }
    else {
        loginBtn.style.display = "flex";
        loginCTABtn.style.display = "block";
        manageBtn.style.display = "none";
    }
}
async function startUnsupportedBrowserBanner() {
    const isUnsupported = await ewe_ui_namespaceObject.experiments.getFlag("unsupportedBrowserVersion");
    document.body.classList.toggle("unsupported-browser", isUnsupported !== null);
}
function pages_desktop_options_start() {
    convertDoclinks();
    initI18n();
    void startUnsupportedBrowserBanner();
    promisedDateFormat = get("localeInfo")
        .then((addonLocale) => {
        return new Intl.DateTimeFormat(addonLocale.locale);
    })
        .catch(dispatchError);
    promisedResources = loadResources();
    startCollections();
    startMessageListeners();
    void startPremium();
    void showUserAccount();
    startLanguagesBox();
    void populateLists().catch(dispatchError);
    void populateFilters().catch(dispatchError);
    void startNavigationSidebar();
    document.body.addEventListener("click", onClick, false);
    $("#acceptable-ads-allow").addEventListener("click", switchAcceptableAds);
    $("#acceptable-ads-privacy-allow").addEventListener("click", switchAcceptableAds);
    document.body.addEventListener("keyup", onKeyUp, false);
    $("#allowlisting-textbox").addEventListener("keyup", (e) => {
        $("#allowlisting-add-button").disabled = !e.target.value;
    }, false);
    void startPrefOptions();
    void startTabGeneral();
    void startTabAdvanced();
    void startTabHelp();
    void startAdditionalSidebar();
    startDialog();
    onHashChange();
    window.addEventListener("hashchange", onHashChange, false);
    window.addEventListener("error", showNotification.bind(null, browser.i18n.getMessage("options_generic_error"), "error"));
    document.body.hidden = false;
}

;// ./src/globals/front/index.ts

function front_start() {
    Object.assign(self, {
        ewe: ewe_ui_namespaceObject
    });
}
front_start();

;// ./src/desktop-options/ui/bootstrap.entry.ts





async function bootstrap() {
    ewe_ui_namespaceObject.sentry.start();
    pages_desktop_options_start();
    front_start();
}
void bootstrap();


/***/ },

/***/ 1046
(module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2929);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1287);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `*, ::before, ::after {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}

::backdrop {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}/*
! tailwindcss v3.4.17 | MIT License | https://tailwindcss.com
*//*
1. Prevent padding and border from affecting element width. (https://github.com/mozdevs/cssremedy/issues/4)
2. Allow adding a border to an element by just adding a border-width. (https://github.com/tailwindcss/tailwindcss/pull/116)
*/

*,
::before,
::after {
  box-sizing: border-box; /* 1 */
  border-width: 0; /* 2 */
  border-style: solid; /* 2 */
  border-color: #e5e7eb; /* 2 */
}

::before,
::after {
  --tw-content: '';
}

/*
1. Use a consistent sensible line-height in all browsers.
2. Prevent adjustments of font size after orientation changes in iOS.
3. Use a more readable tab size.
4. Use the user's configured \`sans\` font-family by default.
5. Use the user's configured \`sans\` font-feature-settings by default.
6. Use the user's configured \`sans\` font-variation-settings by default.
7. Disable tap highlights on iOS
*/

html,
:host {
  line-height: 1.5; /* 1 */
  -webkit-text-size-adjust: 100%; /* 2 */ /* 3 */
  tab-size: 4; /* 3 */
  font-family: var(--extension-font-family); /* 4 */
  font-feature-settings: normal; /* 5 */
  font-variation-settings: normal; /* 6 */
  -webkit-tap-highlight-color: transparent; /* 7 */
}

/*
1. Remove the margin in all browsers.
2. Inherit line-height from \`html\` so users can set them as a class directly on the \`html\` element.
*/

body {
  margin: 0; /* 1 */
  line-height: inherit; /* 2 */
}

/*
1. Add the correct height in Firefox.
2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)
3. Ensure horizontal rules are visible by default.
*/

hr {
  height: 0; /* 1 */
  color: inherit; /* 2 */
  border-top-width: 1px; /* 3 */
}

/*
Add the correct text decoration in Chrome, Edge, and Safari.
*/

abbr:where([title]) {
  text-decoration: underline dotted;
}

/*
Remove the default font size and weight for headings.
*/

h1,
h2,
h3,
h4,
h5,
h6 {
  font-size: inherit;
  font-weight: inherit;
}

/*
Reset links to optimize for opt-in styling instead of opt-out.
*/

a {
  color: inherit;
  text-decoration: inherit;
}

/*
Add the correct font weight in Edge and Safari.
*/

b,
strong {
  font-weight: bolder;
}

/*
1. Use the user's configured \`mono\` font-family by default.
2. Use the user's configured \`mono\` font-feature-settings by default.
3. Use the user's configured \`mono\` font-variation-settings by default.
4. Correct the odd \`em\` font sizing in all browsers.
*/

code,
kbd,
samp,
pre {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; /* 1 */
  font-feature-settings: normal; /* 2 */
  font-variation-settings: normal; /* 3 */
  font-size: 1em; /* 4 */
}

/*
Add the correct font size in all browsers.
*/

small {
  font-size: 80%;
}

/*
Prevent \`sub\` and \`sup\` elements from affecting the line height in all browsers.
*/

sub,
sup {
  font-size: 75%;
  line-height: 0;
  position: relative;
  vertical-align: baseline;
}

sub {
  bottom: -0.25em;
}

sup {
  top: -0.5em;
}

/*
1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)
2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)
3. Remove gaps between table borders by default.
*/

table {
  text-indent: 0; /* 1 */
  border-color: inherit; /* 2 */
  border-collapse: collapse; /* 3 */
}

/*
1. Change the font styles in all browsers.
2. Remove the margin in Firefox and Safari.
3. Remove default padding in all browsers.
*/

button,
input,
optgroup,
select,
textarea {
  font-family: inherit; /* 1 */
  font-feature-settings: inherit; /* 1 */
  font-variation-settings: inherit; /* 1 */
  font-size: 100%; /* 1 */
  font-weight: inherit; /* 1 */
  line-height: inherit; /* 1 */
  letter-spacing: inherit; /* 1 */
  color: inherit; /* 1 */
  margin: 0; /* 2 */
  padding: 0; /* 3 */
}

/*
Remove the inheritance of text transform in Edge and Firefox.
*/

button,
select {
  text-transform: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Remove default button styles.
*/

button,
input:where([type='button']),
input:where([type='reset']),
input:where([type='submit']) {
  -webkit-appearance: button; /* 1 */
  background-color: transparent; /* 2 */
  background-image: none; /* 2 */
}

/*
Use the modern Firefox focus style for all focusable elements.
*/

:-moz-focusring {
  outline: auto;
}

/*
Remove the additional \`:invalid\` styles in Firefox. (https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737)
*/

:-moz-ui-invalid {
  box-shadow: none;
}

/*
Add the correct vertical alignment in Chrome and Firefox.
*/

progress {
  vertical-align: baseline;
}

/*
Correct the cursor style of increment and decrement buttons in Safari.
*/

::-webkit-inner-spin-button,
::-webkit-outer-spin-button {
  height: auto;
}

/*
1. Correct the odd appearance in Chrome and Safari.
2. Correct the outline style in Safari.
*/

[type='search'] {
  -webkit-appearance: textfield; /* 1 */
  outline-offset: -2px; /* 2 */
}

/*
Remove the inner padding in Chrome and Safari on macOS.
*/

::-webkit-search-decoration {
  -webkit-appearance: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Change font properties to \`inherit\` in Safari.
*/

::-webkit-file-upload-button {
  -webkit-appearance: button; /* 1 */
  font: inherit; /* 2 */
}

/*
Add the correct display in Chrome and Safari.
*/

summary {
  display: list-item;
}

/*
Removes the default spacing and border for appropriate elements.
*/

blockquote,
dl,
dd,
h1,
h2,
h3,
h4,
h5,
h6,
hr,
figure,
p,
pre {
  margin: 0;
}

fieldset {
  margin: 0;
  padding: 0;
}

legend {
  padding: 0;
}

ol,
ul,
menu {
  list-style: none;
  margin: 0;
  padding: 0;
}

/*
Reset default styling for dialogs.
*/
dialog {
  padding: 0;
}

/*
Prevent resizing textareas horizontally by default.
*/

textarea {
  resize: vertical;
}

/*
1. Reset the default placeholder opacity in Firefox. (https://github.com/tailwindlabs/tailwindcss/issues/3300)
2. Set the default placeholder color to the user's configured gray 400 color.
*/

input::placeholder,
textarea::placeholder {
  opacity: 1; /* 1 */
  color: #9ca3af; /* 2 */
}

/*
Set the default cursor for buttons.
*/

button,
[role="button"] {
  cursor: pointer;
}

/*
Make sure disabled buttons don't get the pointer cursor.
*/
:disabled {
  cursor: default;
}

/*
1. Make replaced elements \`display: block\` by default. (https://github.com/mozdevs/cssremedy/issues/14)
2. Add \`vertical-align: middle\` to align replaced elements more sensibly by default. (https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210)
   This can trigger a poorly considered lint error in some tools but is included by design.
*/

img,
svg,
video,
canvas,
audio,
iframe,
embed,
object {
  display: block; /* 1 */
  vertical-align: middle; /* 2 */
}

/*
Constrain images and videos to the parent width and preserve their intrinsic aspect ratio. (https://github.com/mozdevs/cssremedy/issues/14)
*/

img,
video {
  max-width: 100%;
  height: auto;
}

/* Make elements with the HTML hidden attribute stay hidden by default */
[hidden]:where(:not([hidden="until-found"])) {
  display: none;
}

[type='text'],input:where(:not([type])),[type='email'],[type='url'],[type='password'],[type='number'],[type='date'],[type='datetime-local'],[type='month'],[type='search'],[type='tel'],[type='time'],[type='week'],[multiple],textarea,select {
  appearance: none;
  background-color: #fff;
  border-color: #6b7280;
  border-width: 1px;
  border-radius: 0px;
  padding-top: 0.5rem;
  padding-right: 0.75rem;
  padding-bottom: 0.5rem;
  padding-left: 0.75rem;
  font-size: 1rem;
  line-height: 1.5rem;
  --tw-shadow: 0 0 #0000;
}

[type='text']:focus, input:where(:not([type])):focus, [type='email']:focus, [type='url']:focus, [type='password']:focus, [type='number']:focus, [type='date']:focus, [type='datetime-local']:focus, [type='month']:focus, [type='search']:focus, [type='tel']:focus, [type='time']:focus, [type='week']:focus, [multiple]:focus, textarea:focus, select:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
  --tw-ring-inset: var(--tw-empty,/*!*/ /*!*/);
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: #2563eb;
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
  border-color: #2563eb;
}

input::placeholder,textarea::placeholder {
  color: #6b7280;
  opacity: 1;
}

::-webkit-datetime-edit-fields-wrapper {
  padding: 0;
}

::-webkit-date-and-time-value {
  min-height: 1.5em;
  text-align: inherit;
}

::-webkit-datetime-edit {
  display: inline-flex;
}

::-webkit-datetime-edit,::-webkit-datetime-edit-year-field,::-webkit-datetime-edit-month-field,::-webkit-datetime-edit-day-field,::-webkit-datetime-edit-hour-field,::-webkit-datetime-edit-minute-field,::-webkit-datetime-edit-second-field,::-webkit-datetime-edit-millisecond-field,::-webkit-datetime-edit-meridiem-field {
  padding-top: 0;
  padding-bottom: 0;
}

select {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e");
  background-position: right 0.5rem center;
  background-repeat: no-repeat;
  background-size: 1.5em 1.5em;
  padding-right: 2.5rem;
  -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
}

[multiple],[size]:where(select:not([size="1"])) {
  background-image: initial;
  background-position: initial;
  background-repeat: unset;
  background-size: initial;
  padding-right: 0.75rem;
  -webkit-print-color-adjust: unset;
          print-color-adjust: unset;
}

[type='checkbox'],[type='radio'] {
  appearance: none;
  padding: 0;
  -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
  display: inline-block;
  vertical-align: middle;
  background-origin: border-box;
  user-select: none;
  flex-shrink: 0;
  height: 1rem;
  width: 1rem;
  color: #2563eb;
  background-color: #fff;
  border-color: #6b7280;
  border-width: 1px;
  --tw-shadow: 0 0 #0000;
}

[type='checkbox'] {
  border-radius: 0px;
}

[type='radio'] {
  border-radius: 100%;
}

[type='checkbox']:focus,[type='radio']:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
  --tw-ring-inset: var(--tw-empty,/*!*/ /*!*/);
  --tw-ring-offset-width: 2px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: #2563eb;
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
}

[type='checkbox']:checked,[type='radio']:checked {
  border-color: transparent;
  background-color: currentColor;
  background-size: 100% 100%;
  background-position: center;
  background-repeat: no-repeat;
}

[type='checkbox']:checked {
  background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.207 4.793a1 1 0 010 1.414l-5 5a1 1 0 01-1.414 0l-2-2a1 1 0 011.414-1.414L6.5 9.086l4.293-4.293a1 1 0 011.414 0z'/%3e%3c/svg%3e");
}

@media (forced-colors: active)  {

  [type='checkbox']:checked {
    appearance: auto;
  }
}

[type='radio']:checked {
  background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3ccircle cx='8' cy='8' r='3'/%3e%3c/svg%3e");
}

@media (forced-colors: active)  {

  [type='radio']:checked {
    appearance: auto;
  }
}

[type='checkbox']:checked:hover,[type='checkbox']:checked:focus,[type='radio']:checked:hover,[type='radio']:checked:focus {
  border-color: transparent;
  background-color: currentColor;
}

[type='checkbox']:indeterminate {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 16 16'%3e%3cpath stroke='white' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M4 8h8'/%3e%3c/svg%3e");
  border-color: transparent;
  background-color: currentColor;
  background-size: 100% 100%;
  background-position: center;
  background-repeat: no-repeat;
}

@media (forced-colors: active)  {

  [type='checkbox']:indeterminate {
    appearance: auto;
  }
}

[type='checkbox']:indeterminate:hover,[type='checkbox']:indeterminate:focus {
  border-color: transparent;
  background-color: currentColor;
}

[type='file'] {
  background: unset;
  border-color: inherit;
  border-width: 0;
  border-radius: 0;
  padding: 0;
  font-size: unset;
  line-height: inherit;
}

[type='file']:focus {
  outline: 1px solid ButtonText;
  outline: 1px auto -webkit-focus-ring-color;
}
  h1 {
  font-size: 3rem;
  line-height: 1;
}

  h2 {
  font-size: 1.125rem;
  line-height: 1.75rem;
}

  h3 {
  font-size: 1rem;
  line-height: 1.5rem;
  font-weight: 700;
}

  body {
  margin: 0px;
  font-size: 1rem;
  line-height: 1.5rem;
}
.container {
  width: 100%;
}
@media (min-width: 640px) {

  .container {
    max-width: 640px;
  }
}
@media (min-width: 768px) {

  .container {
    max-width: 768px;
  }
}
@media (min-width: 1024px) {

  .container {
    max-width: 1024px;
  }
}
@media (min-width: 1280px) {

  .container {
    max-width: 1280px;
  }
}
@media (min-width: 1536px) {

  .container {
    max-width: 1536px;
  }
}
  /**
  * Checkbox styling
  */
  input[type="checkbox"] {
  border-radius: 0.25rem;
}

  input[type="checkbox"]:not(:checked, :hover, :focus) {
  background-color: transparent;
}

  /**
  * Link styling
  */
  a:not(.button):not([role="tab"]) {
  font-family: var(--extension-font-family);
  text-decoration-line: underline;
}
.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}
.visible {
  visibility: visible;
}
.invisible {
  visibility: hidden;
}
.fixed {
  position: fixed;
}
.absolute {
  position: absolute;
}
.block {
  display: block;
}
.flex {
  display: flex;
}
.table {
  display: table;
}
.contents {
  display: contents;
}
.hidden {
  display: none;
}
.size-6 {
  width: 1.5rem;
  height: 1.5rem;
}
.w-full {
  width: 100%;
}
.resize {
  resize: both;
}
.list-disc {
  list-style-type: disc;
}
.flex-col {
  flex-direction: column;
}
.items-center {
  align-items: center;
}
.justify-center {
  justify-content: center;
}
.gap-2 {
  gap: 0.5rem;
}
.gap-4 {
  gap: 1rem;
}
.border {
  border-width: 1px;
}
.px-5 {
  padding-left: 1.25rem;
  padding-right: 1.25rem;
}
.text-center {
  text-align: center;
}
.text-right {
  text-align: right;
}
.filter {
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}

:root {
  /** Variables */
  --extension-font-family: "Source Sans Pro", Arial, sans-serif;

  /** Font compatibility */
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
`, "",{"version":3,"sources":["webpack://./assets/styles/globals.css"],"names":[],"mappings":"AAAA;EAAA,wBAAc;EAAd,wBAAc;EAAd,mBAAc;EAAd,mBAAc;EAAd,cAAc;EAAd,cAAc;EAAd,cAAc;EAAd,eAAc;EAAd,eAAc;EAAd,aAAc;EAAd,aAAc;EAAd,kBAAc;EAAd,sCAAc;EAAd,8BAAc;EAAd,6BAAc;EAAd,4BAAc;EAAd,eAAc;EAAd,oBAAc;EAAd,sBAAc;EAAd,uBAAc;EAAd,wBAAc;EAAd,kBAAc;EAAd,2BAAc;EAAd,4BAAc;EAAd,sCAAc;EAAd,kCAAc;EAAd,2BAAc;EAAd,sBAAc;EAAd,8BAAc;EAAd,YAAc;EAAd,kBAAc;EAAd,gBAAc;EAAd,iBAAc;EAAd,kBAAc;EAAd,cAAc;EAAd,gBAAc;EAAd,aAAc;EAAd,mBAAc;EAAd,qBAAc;EAAd,2BAAc;EAAd,yBAAc;EAAd,0BAAc;EAAd,2BAAc;EAAd,uBAAc;EAAd,wBAAc;EAAd,yBAAc;EAAd,sBAAc;EAAd,oBAAc;EAAd,sBAAc;EAAd,qBAAc;EAAd;AAAc;;AAAd;EAAA,wBAAc;EAAd,wBAAc;EAAd,mBAAc;EAAd,mBAAc;EAAd,cAAc;EAAd,cAAc;EAAd,cAAc;EAAd,eAAc;EAAd,eAAc;EAAd,aAAc;EAAd,aAAc;EAAd,kBAAc;EAAd,sCAAc;EAAd,8BAAc;EAAd,6BAAc;EAAd,4BAAc;EAAd,eAAc;EAAd,oBAAc;EAAd,sBAAc;EAAd,uBAAc;EAAd,wBAAc;EAAd,kBAAc;EAAd,2BAAc;EAAd,4BAAc;EAAd,sCAAc;EAAd,kCAAc;EAAd,2BAAc;EAAd,sBAAc;EAAd,8BAAc;EAAd,YAAc;EAAd,kBAAc;EAAd,gBAAc;EAAd,iBAAc;EAAd,kBAAc;EAAd,cAAc;EAAd,gBAAc;EAAd,aAAc;EAAd,mBAAc;EAAd,qBAAc;EAAd,2BAAc;EAAd,yBAAc;EAAd,0BAAc;EAAd,2BAAc;EAAd,uBAAc;EAAd,wBAAc;EAAd,yBAAc;EAAd,sBAAc;EAAd,oBAAc;EAAd,sBAAc;EAAd,qBAAc;EAAd;AAAc,CAAd;;CAAc,CAAd;;;CAAc;;AAAd;;;EAAA,sBAAc,EAAd,MAAc;EAAd,eAAc,EAAd,MAAc;EAAd,mBAAc,EAAd,MAAc;EAAd,qBAAc,EAAd,MAAc;AAAA;;AAAd;;EAAA,gBAAc;AAAA;;AAAd;;;;;;;;CAAc;;AAAd;;EAAA,gBAAc,EAAd,MAAc;EAAd,8BAAc,EAAd,MAAc,EAAd,MAAc;EAAd,WAAc,EAAd,MAAc;EAAd,yCAAc,EAAd,MAAc;EAAd,6BAAc,EAAd,MAAc;EAAd,+BAAc,EAAd,MAAc;EAAd,wCAAc,EAAd,MAAc;AAAA;;AAAd;;;CAAc;;AAAd;EAAA,SAAc,EAAd,MAAc;EAAd,oBAAc,EAAd,MAAc;AAAA;;AAAd;;;;CAAc;;AAAd;EAAA,SAAc,EAAd,MAAc;EAAd,cAAc,EAAd,MAAc;EAAd,qBAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,iCAAc;AAAA;;AAAd;;CAAc;;AAAd;;;;;;EAAA,kBAAc;EAAd,oBAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,cAAc;EAAd,wBAAc;AAAA;;AAAd;;CAAc;;AAAd;;EAAA,mBAAc;AAAA;;AAAd;;;;;CAAc;;AAAd;;;;EAAA,+GAAc,EAAd,MAAc;EAAd,6BAAc,EAAd,MAAc;EAAd,+BAAc,EAAd,MAAc;EAAd,cAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,cAAc;AAAA;;AAAd;;CAAc;;AAAd;;EAAA,cAAc;EAAd,cAAc;EAAd,kBAAc;EAAd,wBAAc;AAAA;;AAAd;EAAA,eAAc;AAAA;;AAAd;EAAA,WAAc;AAAA;;AAAd;;;;CAAc;;AAAd;EAAA,cAAc,EAAd,MAAc;EAAd,qBAAc,EAAd,MAAc;EAAd,yBAAc,EAAd,MAAc;AAAA;;AAAd;;;;CAAc;;AAAd;;;;;EAAA,oBAAc,EAAd,MAAc;EAAd,8BAAc,EAAd,MAAc;EAAd,gCAAc,EAAd,MAAc;EAAd,eAAc,EAAd,MAAc;EAAd,oBAAc,EAAd,MAAc;EAAd,oBAAc,EAAd,MAAc;EAAd,uBAAc,EAAd,MAAc;EAAd,cAAc,EAAd,MAAc;EAAd,SAAc,EAAd,MAAc;EAAd,UAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;;EAAA,oBAAc;AAAA;;AAAd;;;CAAc;;AAAd;;;;EAAA,0BAAc,EAAd,MAAc;EAAd,6BAAc,EAAd,MAAc;EAAd,sBAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,aAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,gBAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,wBAAc;AAAA;;AAAd;;CAAc;;AAAd;;EAAA,YAAc;AAAA;;AAAd;;;CAAc;;AAAd;EAAA,6BAAc,EAAd,MAAc;EAAd,oBAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,wBAAc;AAAA;;AAAd;;;CAAc;;AAAd;EAAA,0BAAc,EAAd,MAAc;EAAd,aAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,kBAAc;AAAA;;AAAd;;CAAc;;AAAd;;;;;;;;;;;;;EAAA,SAAc;AAAA;;AAAd;EAAA,SAAc;EAAd,UAAc;AAAA;;AAAd;EAAA,UAAc;AAAA;;AAAd;;;EAAA,gBAAc;EAAd,SAAc;EAAd,UAAc;AAAA;;AAAd;;CAAc;AAAd;EAAA,UAAc;AAAA;;AAAd;;CAAc;;AAAd;EAAA,gBAAc;AAAA;;AAAd;;;CAAc;;AAAd;;EAAA,UAAc,EAAd,MAAc;EAAd,cAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;;EAAA,eAAc;AAAA;;AAAd;;CAAc;AAAd;EAAA,eAAc;AAAA;;AAAd;;;;CAAc;;AAAd;;;;;;;;EAAA,cAAc,EAAd,MAAc;EAAd,sBAAc,EAAd,MAAc;AAAA;;AAAd;;CAAc;;AAAd;;EAAA,eAAc;EAAd,YAAc;AAAA;;AAAd,wEAAc;AAAd;EAAA,aAAc;AAAA;;AAAd;EAAA,gBAAc;EAAd,sBAAc;EAAd,qBAAc;EAAd,iBAAc;EAAd,kBAAc;EAAd,mBAAc;EAAd,sBAAc;EAAd,sBAAc;EAAd,qBAAc;EAAd,eAAc;EAAd,mBAAc;EAAd,sBAAc;AAAA;;AAAd;EAAA,8BAAc;EAAd,mBAAc;EAAd,4CAAc;EAAd,2BAAc;EAAd,4BAAc;EAAd,wBAAc;EAAd,2GAAc;EAAd,yGAAc;EAAd,iFAAc;EAAd;AAAc;;AAAd;EAAA,cAAc;EAAd;AAAc;;AAAd;EAAA;AAAc;;AAAd;EAAA,iBAAc;EAAd;AAAc;;AAAd;EAAA;AAAc;;AAAd;EAAA,cAAc;EAAd;AAAc;;AAAd;EAAA,mPAAc;EAAd,wCAAc;EAAd,4BAAc;EAAd,4BAAc;EAAd,qBAAc;EAAd,iCAAc;UAAd;AAAc;;AAAd;EAAA,yBAAc;EAAd,4BAAc;EAAd,wBAAc;EAAd,wBAAc;EAAd,sBAAc;EAAd,iCAAc;UAAd;AAAc;;AAAd;EAAA,gBAAc;EAAd,UAAc;EAAd,iCAAc;UAAd,yBAAc;EAAd,qBAAc;EAAd,sBAAc;EAAd,6BAAc;EAAd,iBAAc;EAAd,cAAc;EAAd,YAAc;EAAd,WAAc;EAAd,cAAc;EAAd,sBAAc;EAAd,qBAAc;EAAd,iBAAc;EAAd;AAAc;;AAAd;EAAA;AAAc;;AAAd;EAAA;AAAc;;AAAd;EAAA,8BAAc;EAAd,mBAAc;EAAd,4CAAc;EAAd,2BAAc;EAAd,4BAAc;EAAd,wBAAc;EAAd,2GAAc;EAAd,yGAAc;EAAd;AAAc;;AAAd;EAAA,yBAAc;EAAd,8BAAc;EAAd,0BAAc;EAAd,2BAAc;EAAd;AAAc;;AAAd;EAAA,sQAAc;AAAA;;AAAd;;EAAA;IAAA;EAAc;AAAA;;AAAd;EAAA,oKAAc;AAAA;;AAAd;;EAAA;IAAA;EAAc;AAAA;;AAAd;EAAA,yBAAc;EAAd;AAAc;;AAAd;EAAA,uOAAc;EAAd,yBAAc;EAAd,8BAAc;EAAd,0BAAc;EAAd,2BAAc;EAAd,4BAAc;AAAA;;AAAd;;EAAA;IAAA;EAAc;AAAA;;AAAd;EAAA,yBAAc;EAAd;AAAc;;AAAd;EAAA,iBAAc;EAAd,qBAAc;EAAd,eAAc;EAAd,gBAAc;EAAd,UAAc;EAAd,gBAAc;EAAd;AAAc;;AAAd;EAAA,6BAAc;EAAd;AAAc;EAAd;EAAA,eAAc;EAAd;AAAc;;EAAd;EAAA,mBAAc;EAAd;AAAc;;EAAd;EAAA,eAAc;EAAd,mBAAc;EAAd;AAAc;;EAAd;EAAA,WAAc;EAAd,eAAc;EAAd;AAAc;AACd;EAAA;AAAoB;AAApB;;EAAA;IAAA;EAAoB;AAAA;AAApB;;EAAA;IAAA;EAAoB;AAAA;AAApB;;EAAA;IAAA;EAAoB;AAAA;AAApB;;EAAA;IAAA;EAAoB;AAAA;AAApB;;EAAA;IAAA;EAAoB;AAAA;EAgClB;;GAEC;EAEC;EAAA;AAAc;;EAId;EAAA;AAAqB;;EAGvB;;GAEC;EAEC;EAAA,yCAA0B;EAA1B;AAA0B;AA9C9B;EAAA,kBAAmB;EAAnB,UAAmB;EAAnB,WAAmB;EAAnB,UAAmB;EAAnB,YAAmB;EAAnB,gBAAmB;EAAnB,sBAAmB;EAAnB,mBAAmB;EAAnB;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA,aAAmB;EAAnB;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA,qBAAmB;EAAnB;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;AAAnB;EAAA;AAAmB;;AAEnB;EACE,eAAe;EACf,6DAA6D;;EAE7D,wBAAwB;EACxB,kCAAkC;EAClC,mCAAmC;EACnC,kCAAkC;AACpC","sourcesContent":["@tailwind base;\n@tailwind components;\n@tailwind utilities;\n\n:root {\n  /** Variables */\n  --extension-font-family: \"Source Sans Pro\", Arial, sans-serif;\n\n  /** Font compatibility */\n  text-rendering: optimizeLegibility;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n}\n\n@layer base {\n  h1 {\n    @apply text-5xl;\n  }\n\n  h2 {\n    @apply text-lg;\n  }\n\n  h3 {\n    @apply text-base font-bold;\n  }\n\n  body {\n    @apply m-0 text-base;\n  }\n}\n\n@layer components {\n  /**\n  * Checkbox styling\n  */\n  input[type=\"checkbox\"] {\n    @apply rounded;\n  }\n\n  input[type=\"checkbox\"]:not(:checked, :hover, :focus) {\n    @apply bg-transparent;\n  }\n\n  /**\n  * Link styling\n  */\n  a:not(.button):not([role=\"tab\"]) {\n    @apply underline font-sans;\n  }\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ 544
(module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2929);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1287);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_theme_ui_font_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6054);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_theme_ui_z_index_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9956);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_theme_ui_common_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6350);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_theme_ui_light_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4341);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_components_ui_io_filter_table_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7702);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_components_ui_io_list_box_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7783);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_components_ui_io_popout_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6708);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_components_ui_io_popout_fixes_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1254);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_components_ui_io_toggle_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3107);
// Imports











var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_theme_ui_font_css__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A);
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_theme_ui_z_index_css__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A);
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_theme_ui_common_css__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A);
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_theme_ui_light_css__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A);
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_components_ui_io_filter_table_css__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A);
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_components_ui_io_list_box_css__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .A);
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_components_ui_io_popout_css__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .A);
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_components_ui_io_popout_fixes_css__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .A);
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_components_ui_io_toggle_css__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .A);
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/*
 * This file is part of Adblock Plus <https://adblockplus.org/>,
 * Copyright (C) 2006-present eyeo GmbH
 *
 * Adblock Plus is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * Adblock Plus is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.
 */

html {
  font-size: 16px;
}

body {
  display: grid;
  /* We force vertical scrollbars to keep the content centered */
  overflow-y: scroll;
  margin: 1rem 0.3rem;
  color: #4a4a4a;
  background-color: #f3f3f3;
  font-size: 1rem;
  line-height: 1.3rem;
  justify-content: center;
  grid-template-areas:
    "sidebar premium-banner"
    "sidebar main";
  grid-template-columns: auto 46.3rem auto;
}

h1 {
  font-size: 3rem;
  font-weight: 300;
  line-height: 3rem;
}

h2 {
  font-size: 1.125rem;
  font-weight: 700;
}

a {
  color: #0797e1;
}

a:hover {
  color: #5cbce1;
}

ul {
  margin: 0rem;
}

main h3 {
  margin-top: 0rem;
  margin-bottom: 0.5rem;
}

.description {
  font-size: 0.9rem;
}

[aria-hidden="true"],
[hidden] {
  display: none !important;
}

input[type="text"],
input[type="url"],
textarea,
main {
  box-sizing: border-box;
}

/*
  Normalization
 */

button {
  font-family: inherit;
  border-radius: 0rem;
}

/*
  Buttons and links
 */

button,
.button {
  display: block;
  padding: 0.6rem 0.8rem;
  border-radius: var(--border-radius);
  background-color: transparent;
  font-size: 1rem;
  font-weight: 700;
  text-decoration: none;
  text-transform: uppercase;
  cursor: pointer;
}

button:disabled,
button[aria-disabled="true"] {
  cursor: not-allowed;
}

button.primary:not(.icon),
.button.primary:not(.icon),
button.secondary:not(.icon),
.button.secondary:not(.icon) {
  padding: 8px 20px;
}

/* Ignore .icon to avoid overriding "specific" (primary, secondary) styles */
button.primary:not(.icon),
.button.primary:not(.icon) {
  border: 0px;
  color: #fff;
  background-color: #0797e1;
}

button.primary:not([disabled]):not(.icon):hover,
.button.primary:not(.icon):hover {
  box-shadow: inset 0 0 0 3px #005d80;
}

button.primary[disabled]:not(.icon) {
  background-color: #5cbce1;
}

button.secondary:not(.icon),
.button.secondary:not(.icon) {
  border: 2px solid #0797e1;
  color: #0797e1;
}

button.secondary:not(:disabled):not(.icon):hover,
.button.secondary:not(:disabled):not(.icon):hover {
  box-shadow: inset 0 0 0 1px #0797e1;
}

button.secondary:disabled:not(.icon) {
  color: #bbb;
  background-color: #f3f3f3;
}

button.secondary:disabled:not(.icon):hover {
  border-color: inherit;
}

button.link,
button.list {
  color: #0797e1;
}

button.link {
  padding: 0.2rem;
  border: 0px;
  background-color: transparent;
  font-family: inherit;
  font-weight: 400;
  text-decoration: underline;
  text-transform: none;
}

button.link:hover {
  color: #5cbce1;
}

button.list {
  width: 100%;
  border-width: 1px;
  border-style: solid;
  border-color: #cdcdcd;
  background-color: #e1f2fa;
  text-align: initial;
}

button.list:hover {
  border-color: #0797e1;
  box-shadow: inset 0 0 0 3px #0797e1;
}

button.add.secondary {
  width: 100%;
  border: 1px solid #bcbcbc;
}

button.add.secondary:not(:disabled):hover {
  border-color: #0797e1;
}

button.add::before {
  content: "+ ";
}

#filters-box li[aria-selected="true"] {
  background-color: #e1f2fa;
}

#filterlist-by-url-wrap {
  position: relative;
}

#filterlist-by-url {
  position: absolute;
  /* ensures it overlaps same popout z-indexes */
  z-index: var(--z-popout-active);
  top: -260px;
  width: 100%;
  height: 260px;
  border-radius: var(--border-radius) var(--border-radius) 0 0;
  background: #fff;
  box-shadow: 0 -4px 20px 0 rgba(0, 0, 0, 0.11);
}

button[data-action="open-filterlist-by-url"] {
  /* needed to avoid being shadowed by #filterlist-by-url */
  position: relative;
  z-index: 1;
  background-color: #fff;
}

.side-controls:not(.wrap) {
  display: flex;
  margin: 0.8rem 0rem;
  justify-content: flex-end;
}

.side-controls > * {
  margin: 0rem;
}

#filterlist-by-url .main-input,
#filterlist-by-url h3 {
  margin: 0.8rem;
}

#filterlist-by-url h3 {
  text-transform: uppercase;
}

#filterlist-by-url .side-controls {
  justify-content: flex-start;
}

/*
  Due to Edge adoption as new target browser
  we cannot use -moz/webkit-margin-start
  or -moz/webkit-margin-end because
  these lack Edge support.
  Yet we need to preserve html direction
  and potential UI that might swap right to left.
*/
html:not([dir="rtl"]) .side-controls > * {
  margin-left: 0.8rem;
}

html[dir="rtl"] .side-controls > * {
  margin-right: 0.8rem;
}

.side-controls.wrap > * {
  margin: 0.6rem 0;
}

html:not([dir="rtl"]) .side-controls.wrap > * {
  margin-left: auto;
}

html[dir="rtl"] .side-controls.wrap > * {
  margin-right: auto;
}

/*
  icons
 */

.icon {
  padding: 0px;
  border: 0px;
  background-color: transparent;
}

.icon:hover {
  box-shadow: none;
}

.icon::before {
  display: block;
  background-repeat: no-repeat;
  content: "";
}

input[type="checkbox"].icon {
  margin-top: -1px;
  margin-left: 2px;
  appearance: none;
}

input[type="checkbox"].icon:not(:disabled),
input[type="checkbox"].icon:not(:disabled) + label[for] {
  cursor: pointer;
}

input[type="checkbox"].icon::before {
  border-width: 0.05rem;
}

/*
 all button[role="checkbox"] styles can be removed once the html and js are
 updated to use input[type="checkbox"]. I started improving the code I touched
 but generally speaking, accessibility properties should not be used for
 styling.

 For now I have just made sure both types work
*/

button[role="checkbox"].icon::before,
input[type="checkbox"].icon::before {
  width: 1.2rem;
  height: 1.2rem;
  padding: 0px;
}

button[role="checkbox"][disabled].icon:not(.toggle)::before,
button[role="checkbox"][aria-disabled="true"].icon:not(.toggle)::before {
  margin: 0.2rem;
  border: 0rem;
  border-radius: 2px;
  background-color: #ccc;
}

button[role="checkbox"].icon:not(.toggle)::before,
input[type="checkbox"].icon:not(.toggle)::before {
  /* Using ?query as a workaround to chromium bug #643716 */
  background-image: url(/skin/icons/checkbox.svg?off#off);
}

input[type="checkbox"].icon:disabled::before {
  background-image: url(/skin/icons/checkbox.svg?off-disabled#off-disabled);
}

button[role="checkbox"][aria-checked="true"].icon:not(.toggle)::before,
input[type="checkbox"].icon:checked:not(.toggle)::before {
  background-image: url(/skin/icons/checkbox.svg?on#on);
}

button[role="checkbox"][aria-checked="true"].icon:disabled:not(.toggle)::before,
input[type="checkbox"].icon:checked:disabled:not(.toggle)::before {
  background-image: url(/skin/icons/checkbox.svg?on-disabled#on-disabled);
}

button[role="checkbox"].icon.toggle::before,
input[type="checkbox"].icon.toggle::before {
  width: 1.9rem;
  height: 1rem;
  background-image: url(/skin/icons/toggle.svg?on#on);
}

button[role="checkbox"][aria-checked="false"].icon.toggle::before,
input[type="checkbox"].icon.toggle:not(:checked)::before {
  background-image: url(/skin/icons/toggle.svg?off#off);
}

button[role="checkbox"][disabled].icon.toggle::before,
input[type="checkbox"].icon.toggle:disabled::before {
  background: none;
}

.icon.delete::before {
  background-image: url(/skin/icons/trash.svg?default#default);
}

.icon.delete:hover::before {
  background-image: url(/skin/icons/trash.svg?hover#hover);
}

.icon.delete::before {
  width: 1rem;
  height: 1rem;
}

[data-validation] .main-input input:focus:invalid ~ .icon.attention::before {
  background-image: url(/skin/icons/attention.svg);
}

[data-validation] .main-input input:valid ~ .icon.attention::before {
  background-image: url(/skin/icons/checkmark.svg?approved#approved);
}

.icon.update-subscription::before {
  background-image: url(/skin/icons/reload.svg);
}

.icon.website::before {
  background-image: url(/skin/icons/globe.svg);
}

.icon.source::before {
  background-image: url(/skin/icons/code.svg);
}

.icon.delete::before {
  background-image: url(/skin/icons/trash.svg?default#default);
}

.close {
  margin: 0;
  cursor: pointer;
}

.close.icon::before {
  width: 1rem;
  height: 1rem;
}

.icon.close.primary::before {
  background-image: url(/skin/icons/close.svg?primary#primary);
}

.icon.close.primary:hover::before {
  background-image: url(/skin/icons/close.svg?primary-hover#primary-hover);
}

.icon.close.secondary::before {
  background-image: url(/skin/icons/close.svg?secondary#secondary);
}

.icon.close.tertiary::before {
  background-image: url(/skin/icons/close.svg?tertiary#tertiary);
}

.icon.close.secondary:hover::before {
  background-image: url(/skin/icons/close.svg?secondary-hover#secondary-hover);
}

.icon.close.tertiary:hover::before {
  background-image: url(/skin/icons/close.svg?tertiary-hover#tertiary-hover);
}

#dialog .table.list li button.icon::before {
  width: 1.3rem;
  height: 1.3rem;
  margin: 0rem;
  border: 0rem;
  background-image: none;
}

#dialog .table.list li button[aria-checked="true"].icon::before {
  background-image: url(/skin/icons/checkmark.svg?default#default);
}

#social ul li .icon::before {
  width: 2.5rem;
  height: 2.5rem;
  margin: 0em auto;
}

.icon.twitter::before {
  background-image: url(/skin/icons/twitter.svg);
}

.icon.facebook::before {
  background-image: url(/skin/icons/facebook.svg);
}

/*
  Forms
 */

.main-input {
  position: relative;
  margin: 1.8rem 0rem 0.5rem;
  padding-top: 0.7rem;
}

.main-input input {
  width: 100%;
  padding: var(--padding-primary);
  border: 1px solid #cdcdcd;
  outline: none;
  font-size: 1rem;
}

[data-validation] .main-input input ~ .error-msg {
  display: none;
  position: absolute;
  top: calc(var(--padding-primary) * -2);
  right: 0;
  z-index: 10;
  color: var(--color-error);
}

[data-validation] .side-controls {
  margin-top: 1.2rem;
}

html[dir="rtl"] [data-validation] .main-input input ~ .error-msg {
  right: auto;
  left: 0;
}

[data-validation] .main-input input:focus:invalid ~ .error-msg {
  display: block;
}

[data-validation] .main-input input:focus:invalid {
  border-color: var(--color-error);
}

[data-validation] .main-input input:focus:invalid ~ .attention::before,
[data-validation] .main-input input ~ .attention::before {
  position: absolute;
  top: 0.8rem;
  right: 0rem;
  width: 1.2rem;
  height: 1.2rem;
  margin: 0.8rem;
}

/* stylelint-disable indentation */
html[dir="rtl"]
  [data-validation]
  .main-input
  input:focus:invalid
  ~ .attention::before,
html[dir="rtl"] [data-validation] .main-input input ~ .attention::before {
  right: auto;
  left: 0rem;
}
/* stylelint-enable indentation */

/*
  Animations
*/

.highlight-animate {
  animation: highlight 1s 3;
}

@keyframes highlight {
  0% {
    background-color: transparent;
  }

  30% {
    background-color: #ffd7a3;
  }

  70% {
    background-color: #ffd7a3;
  }

  100% {
    background-color: transparent;
  }
}

/*
  Sidebar
 */

#sidebar,
#sidebar .fixed,
[role="tablist"] {
  width: 14.3rem;
}

#sidebar {
  grid-area: sidebar;
  flex-shrink: 0;
}

#sidebar .fixed {
  top: 1.2rem;
  bottom: 0rem;
  height: auto;
}

html[dir="ltr"] #sidebar header {
  margin-right: 2rem;
}

html[dir="rtl"] #sidebar header {
  margin-left: 2rem;
}

#sidebar header h1,
#sidebar header p {
  margin: 0rem;
  user-select: none;
}

#sidebar header h1 {
  font-size: 0;
  line-height: 48px;
  color: transparent;
  background-image: url(/skin/icons/logo/abp-full.svg);
  background-size: contain;
  background-repeat: no-repeat;
}

#sidebar header p {
  margin-top: 30px;
  line-height: 2.6rem;
  opacity: 0.6;
  font-weight: 600;
  text-transform: uppercase;
}

html[dir="rtl"] #sidebar header {
  text-align: left;
}

html[dir="rtl"] #sidebar header p {
  text-align: right;
}

html[dir="rtl"] #sidebar header h1 {
  background-position: center left;
}

#sidebar nav,
#sidebar footer {
  margin: 1.4rem 0rem;
}

[role="tablist"] {
  position: relative;
  margin: 0rem;
  padding: 0rem;
  font-size: 1rem;
  list-style: none;
}

li a[role="tab"] {
  display: flex;
  margin-right: -1px;
  margin-left: -1px;
  padding: 1rem 0.8rem;
  border: 1px solid transparent;
  border-radius: var(--border-radius) 0 0 var(--border-radius);
  color: inherit;
  text-decoration: none;
  cursor: pointer;
}

li a[role="tab"]:hover {
  background-color: #eaeaea;
}

li a[role="tab"][aria-selected] {
  border-color: #cdcdcd;
  background-color: #fff;
  font-weight: 700;
}

html[dir="rtl"] li a[role="tab"] {
  border-radius: 0 var(--border-radius) var(--border-radius) 0;
}

html:not([dir="rtl"]) li a[role="tab"]:hover {
  border-right-color: #cdcdcd;
}

html[dir="rtl"] li a[role="tab"]:hover {
  border-left-color: #cdcdcd;
}

html:not([dir="rtl"]) li a[role="tab"][aria-selected] {
  border-right-color: transparent;
}

html[dir="rtl"] li a[role="tab"][aria-selected] {
  border-left-color: transparent;
}

#sidebar footer {
  width: 100%;
}

#sidebar button,
#sidebar .button {
  display: flex;
}

#support-us {
  position: fixed;
  bottom: 40px;
  margin: 0 40px;
}

#support-us .h2-icon {
  /* Align icon with edges of text based on text's line height and font size */
  width: 2em;
  height: 2em;
  margin-top: 0.3em;
}

html:not([dir="rtl"]) #support-us .h2-icon {
  float: left;
  margin-right: 0.5em;
}

html[dir="rtl"] #support-us .h2-icon {
  float: right;
  margin-left: 0.5em;
}

#support-us h2 {
  margin: 0;
  font-size: 1rem;
}

#support-us p {
  text-align: center;
}

#support-us a.button {
  width: 100%;
  margin-bottom: 0.5rem;
  padding: 2px;
  border: 1px solid var(--border-color-ternary);
  font-size: var(--font-size-primary);
  color: #0797e1;
  text-transform: uppercase;
  text-align: center;
  transition: background-color 0.2s ease-out;
}

#support-us a.button:last-of-type {
  margin-bottom: 0;
}

#support-us a.button:hover,
#support-us a.button:focus {
  background-color: #e9f6fc;
}

/* This is a stopgap solution of footer overlapping tabs on low resolutions */
@media (min-height: 37rem) {
  #sidebar .fixed {
    position: fixed;
  }

  #sidebar footer {
    position: absolute;
    bottom: 0px;
  }
}

/*
  Premium
 */

.premium.icon::before {
  border: none;
  content: none;
}

body.premium .premium.icon::before {
  display: block;
  width: 20px;
  height: 20px;
  margin-right: 0.5rem;
  background-image: url(/skin/icons/premium-crown.svg);
  background-repeat: no-repeat;
  background-size: contain;
  background-position: 0 3px;
  content: "";
}

body.premium .premium.upgrade.button {
  display: none;
}

.premium.upgrade.button {
  display: inline-block;
  padding: 8px 20px;
  border: 2px solid var(--color-premium);
  background-color: var(--color-premium);
  color: var(--background-color-primary);
  text-transform: none;
  white-space: nowrap;
}

.premium.upgrade.button:hover,
.premium.upgrade.button:focus {
  background-color: var(--color-premium-hover);
  border-color: var(--color-premium-hover);
}

.premium.list button.icon[role="checkbox"]:disabled::before {
  margin-top: 0;
  background-color: transparent;
  background-image: url(/skin/icons/premium-lock.svg);
  background-position: center;
}

.premium-banner-container {
  grid-area: premium-banner;
}

.premium-banner-container .banner {
  display: flex;
  padding: 1.4rem;
  margin-bottom: 1.4rem;
  align-items: center;
  justify-content: space-between;
  border-radius: var(--border-radius);
  box-sizing: border-box;
}

.premium-banner-container .banner.background {
  padding-left: 0;
  padding-right: 0;
}

.premium-banner-container .banner.foreground {
  background-color: var(--background-color-primary);
}

.premium-banner-container .premium-label {
  display: flex;
  font-weight: 700;
}

.premium-banner-container a {
  white-space: nowrap;
}

.premium-banner-container .button {
  padding: 0;
  text-transform: none;
}

body.premium .premium-upgrade.banner {
  display: none;
}

.premium-upgrade.banner .premium-label {
  align-items: baseline;
  font-size: 20px;
}

.premium-upgrade.banner .premium-label::before {
  margin: 0 7px;
  width: 25px;
  height: 17px;
  background-image: url(/skin/icons/premium-crown.svg);
  background-repeat: no-repeat;
  background-size: contain;
  background-position: center;
  content: "";
}

.premium-upgrade.banner p {
  margin: 0 1rem;
}

body:not(.premium) .premium-manage.banner {
  display: none;
}

.premium-manage.banner {
  justify-content: flex-end;
}

.premium-manage.banner > * {
  margin-right: 10px;
}

html:not([dir="rtl"]) .premium-manage.banner > *:last-child,
html[dir="rtl"] .premium-manage.banner > *:first-child {
  margin-right: 0;
}

.premium-manage.banner .premium-label {
  --button-primary-color: var(--color-premium);
  align-items: baseline;
  padding: 5px 11px;
  border: 1px solid;
  border-radius: var(--border-radius);
  color: var(--button-primary-color);
  font-size: var(--font-size-primary);
  line-height: 16px;
}

.premium-manage.banner .premium-label:hover,
.premium-manage.banner .premium-label:focus {
  --button-primary-color: var(--color-premium-hover);
}

.premium-manage.banner .premium-label::before {
  width: 15px;
  height: 10px;
  margin-right: 3px;
  mask-image: url(/skin/icons/premium-crown.svg);
  mask-repeat: no-repeat;
  mask-size: contain;
  mask-position: center;
  background-color: var(--button-primary-color);
  content: "";
}

/*
  Main content
 */

body[data-tab|="general"] #content-general,
body[data-tab|="advanced"] #content-advanced,
body[data-tab|="allowlist"] #content-allowlist,
body[data-tab|="help"] #content-help {
  display: block;
}

main {
  grid-area: main;
  padding: 0px 0rem 1.4rem;
  border: 1px solid #cdcdcd;
  border-radius: var(--border-radius);
  background-color: #fff;
}

main > div {
  display: none;
}

main p {
  margin: 0.8rem 0rem;
}

/*
  Sections
 */

[role="tabpanel"] > section,
[role="tabpanel"] > .section {
  margin: 0 2rem;
  padding: 1.4rem 0;
  border-top: 1px solid #cdcdcd;
}

[role="tabpanel"] > header h1,
[role="tabpanel"] > header p {
  margin: 1.4rem 0rem;
  padding: 0rem 2rem;
}

section h2,
.section h2 {
  margin: 0rem;
}

section h2 {
  text-transform: uppercase;
}

section,
.section {
  clear: both;
}

section.cols {
  display: flex;
}

section.cols > *:first-child {
  flex: 1;
}

html:not([dir="rtl"]) section.cols > *:first-child {
  margin-right: 2rem;
}

html[dir="rtl"] section.cols > *:first-child {
  margin-left: 2rem;
}

section.cols > *:last-child {
  flex: 3;
}

/*
  Acceptable ads
 */

#tracking-warning {
  position: relative;
  margin-bottom: 1rem;
  padding: 1.5rem;
  border: 2px solid #ffd7a3;
  background-color: #fefbe3;
}

#acceptable-ads:not(.show-warning) #tracking-warning {
  display: none;
}

#hide-tracking-warning {
  position: absolute;
  top: 0.8rem;
}

html[dir="ltr"] #hide-tracking-warning {
  left: auto;
  right: 0.8rem;
}

html[dir="rtl"] #hide-tracking-warning {
  left: 1rem;
  right: auto;
}

#tracking-warning .link {
  color: inherit;
  font-weight: 700;
  text-decoration: underline;
}

#acceptable-ads ul {
  position: relative;
  padding-left: 2.2rem;
  list-style: none;
}

html[dir="rtl"] #acceptable-ads ul {
  padding-right: 2.2rem;
  padding-left: 0rem;
}

#acceptable-ads ul button,
#acceptable-ads ul input {
  position: absolute;
}

html[dir="ltr"] button,
html[dir="ltr"] input {
  left: 0rem;
}

html[dir="rtl"] button,
html[dir="rtl"] input {
  right: 0rem;
}

#acceptable-ads label {
  font-size: 1rem;
  font-weight: 700;
}

#acceptable-ads #acceptable-ads-why-not {
  --background-color: #fff;
  --border-color: #099cd0;
  position: absolute;
  z-index: 1;
  width: 260px;
  margin-top: 15px;
  padding: 16px;
  box-sizing: border-box;
  border: 1px solid var(--border-color);
  border-radius: var(--border-radius);
  background-color: var(--background-color);
  text-align: center;
}

html[dir="ltr"] #acceptable-ads #acceptable-ads-why-not {
  left: -117px;
}

html[dir="rtl"] #acceptable-ads #acceptable-ads-why-not {
  right: -117px;
}

#acceptable-ads #acceptable-ads-why-not::before {
  display: block;
  position: absolute;
  top: -6px;
  left: calc(50% - 5px);
  width: 10px;
  height: 10px;
  border: 1px solid var(--border-color);
  border-right: none;
  border-bottom: none;
  background-color: var(--background-color);
  content: "";
  transform: rotate(45deg);
}

#acceptable-ads #acceptable-ads-why-not > a,
#acceptable-ads #acceptable-ads-why-not > button {
  font-size: 0.9rem;
}

#acceptable-ads #acceptable-ads-why-not > button {
  position: initial;
  margin: auto;
  border: 0;
  color: #0797e1;
}

html:not([dir="rtl"]) #acceptable-ads label {
  margin-right: 0.5rem;
}

html[dir="rtl"] #acceptable-ads label {
  margin-left: 0.5rem;
}

#dnt {
  padding: 0.8rem;
  border: 1px solid #0797e1;
}

/*
  Tables
 */

ul.table,
ul.list {
  margin: 0rem;
  padding: 0rem;
  list-style: none;
}

.table li,
.list li {
  display: flex;
  align-items: center;
}

.table li {
  margin: 0rem;
  border-width: 0px 1px 1px;
  border-style: solid;
  border-color: #cdcdcd;
}

.list li {
  margin-bottom: 0.8rem;
  padding: 0rem;
}

.list li [role="checkbox"] {
  flex-shrink: 0;
}

.table li:first-of-type {
  border-top: 1px solid #cdcdcd;
  border-radius: var(--border-radius) var(--border-radius) 0 0;
}

.table.list li {
  margin: 0rem;
  padding: 0.5rem 1rem;
}

.table.list.bottom-control li:last-of-type {
  border-bottom: 0px;
}

.list li > span {
  margin: 0rem 1rem;
}

.table.list li > span {
  overflow: hidden;
  margin: 0rem;
  flex: 1;
  text-overflow: ellipsis;
}

#content-allowlist .table.list li > span {
  white-space: nowrap;
}

.table.list li[aria-label^="https://"] > span,
.table.list li[aria-label^="data:"] > span {
  white-space: initial;
  word-break: break-all;
}

.table.list li.empty-placeholder,
#all-filter-lists-table .empty-placeholder {
  padding: 1rem 1.4rem;
}

.table.list li.empty-placeholder:not(:last-of-type) {
  border-bottom: 0px;
}

.table.list button.link {
  font-weight: 700;
  text-decoration: none;
  text-transform: uppercase;
}

.table:not(.list):not(.cols) li {
  padding-top: 0px;
  padding-bottom: 6px;
}

.table li [data-single="visible"],
.table li:first-of-type:last-of-type [data-single="hidden"] {
  display: none;
}

.table li:first-of-type:last-of-type [data-single="visible"] {
  display: block;
}

.th {
  display: flex;
}

.col5 > * {
  display: inline-block;
  vertical-align: middle;
}

.cols .col5,
.th .col5 {
  margin: 0rem 1rem;
  align-self: center;
}

.th .col5:nth-of-type(1),
.table .col5:nth-of-type(1) {
  flex: 3;
  text-align: center;
}

.th .col5:nth-of-type(2),
.table .col5:nth-of-type(2) {
  flex: 8;
}

.table [aria-label^="https://"] .col5:nth-of-type(2),
.table [aria-label^="data:"] .col5:nth-of-type(2) {
  word-break: break-all;
}

.th .col5:nth-of-type(3),
.table .col5:nth-of-type(3) {
  flex: 4;
}

.th .col5:nth-of-type(4),
.table .col5:nth-of-type(4) {
  flex: 1;
}

.th .col5:nth-of-type(5),
.table .col5:nth-of-type(5) {
  flex: 1;
}

html:not([dir="rtl"]) .th .col5:nth-of-type(5),
html:not([dir="rtl"]) .table .col5:nth-of-type(5) {
  margin-right: 1.8rem;
  margin-left: 0;
}

html[dir="rtl"] .th .col5:nth-of-type(5),
html[dir="rtl"] .table .col5:nth-of-type(5) {
  margin-right: 0;
  margin-left: 1.8rem;
}

.table.cols > span {
  margin: 0rem;
}

.table.cols li {
  padding: 0.5rem 0rem;
}

.table.cols li.error .col5:nth-of-type(2) {
  color: var(--color-error);
  font-style: italic;
}

.table.cols .toggle {
  -moz-margin-end: 0.5rem;
  -webkit-margin-end: 0.5rem;
}

#dialog .table.list li {
  display: block;
  padding: 0rem;
  border-width: 1px 0px 0px;
}

#dialog .table.list li:first-of-type {
  border: 0px;
}

#dialog .table.list li button {
  display: flex;
  width: 100%;
  height: auto;
  padding: 1.1rem 1rem;
  background-image: none;
}

#dialog .table.list li button:hover,
#dialog .table.list li button:focus {
  background-color: #e1f2fa;
}

#dialog .table.list li button[aria-checked="true"],
.table.list li .dimmed {
  color: #bbb;
}

#dialog .table.list li button > span {
  margin: 0rem 0.8rem;
  font-weight: 400;
  text-transform: none;
  flex: none;
}

li.preconfigured [data-hide="preconfigured"] {
  display: none !important;
}

/*
  Tooltips
*/

.tooltip {
  position: relative;
  margin: 0rem;
  line-height: 1.5rem;
  text-decoration: none;
  cursor: help;
}

html:not([dir="rtl"]) .tooltip {
  margin-right: 1rem;
}

html[dir="rtl"] .tooltip {
  margin-left: 1rem;
}

/*
  General tab content
*/

section.recommended-features {
  display: flex;
  padding-top: 2rem;
}

section.recommended-features > :not(template) {
  flex: 1;
  margin-right: 24px;
}

/* stylelint-disable indentation */
html:not([dir="rtl"])
  section.recommended-features
  > :not(template):last-of-type,
html[dir="rtl"] section.recommended-features > :not(template):first-of-type {
  margin-right: 0;
}
/* stylelint-enable indentation */

section.recommended-features h2 {
  display: flex;
  margin-bottom: 1.75rem;
}

section.recommended-features .premium.list-header {
  display: flex;
  align-items: flex-start;
}

section.recommended-features .premium.list-header > * {
  margin-right: 1.4rem;
}

/* stylelint-disable indentation */
html:not([dir="rtl"])
  section.recommended-features
  .premium.list-header
  > *:last-child,
html[dir="rtl"]
  section.recommended-features
  .premium.list-header
  > *:first-child {
  margin-right: 0;
}
/* stylelint-enable indentation */

section.recommended-features .premium.list-header a.button {
  transform: translateY(-25%);
}

section.recommended-features li {
  align-items: flex-start;
}

section.recommended-features .description-container {
  margin: 0 0.5rem;
}

section.recommended-features h3 {
  display: inline-block;
  margin: 0;
  font-size: 1rem;
}

section.recommended-features li .label.new {
  display: none;
  margin: 0 4px;
  padding: 0 4px;
  border-radius: 4px;
  text-transform: uppercase;
  font-size: var(--font-size-small);
  color: #fff;
  background-color: var(--background-color-info);
}

section.recommended-features li.new .label.new {
  display: inline-block;
}

section.recommended-features .description {
  margin: 0.25rem 0;
}

#blocking-languages li button[data-single] {
  padding: 0;
}

#languages-box {
  margin-bottom: 0.8rem;
}

html[lang^="de"] #language-recommend,
html[lang^="fr"] #language-recommend,
/*
  Hide language recommendation feature for Opera users
  due to problems with its language detection
  https://gitlab.com/adblockinc/ext/adblockplus/adblockplus/-/issues/960
*/
html[data-application="opera"] #language-recommend {
  display: none;
}

/*
  Allowlist tab
 */

#content-allowlist form {
  display: flex;
  margin-bottom: 1.4rem;
}

#content-allowlist form input {
  padding: 0.5rem 1rem;
  border: 2px solid #0797e1;
  border-radius: var(--border-radius);
  font-size: 1rem;
  flex: 1;
}

html:not([dir="rtl"]) #content-allowlist form button {
  margin-left: 0.7rem;
}

html[dir="rtl"] #content-allowlist form button {
  margin-right: 0.7rem;
}

#allowlisting-table li {
  padding-right: 1.4rem;
  padding-left: 1.4rem;
  border-right: 0rem;
  border-left: 0rem;
}

/*
  Advanced tab content
*/

#custom-filters {
  margin-top: 3rem;
}

#custom-filters h3 {
  font-size: 1.125rem;
  font-weight: 400;
  text-transform: uppercase;
}

#custom-filters .io-filter-table-title {
  font-weight: 600;
}

html:not([dir="rtl"]) #custom-filters .io-filter-table-title {
  margin-right: 2rem;
}

html[dir="rtl"] #custom-filters .io-filter-table-title {
  margin-left: 2rem;
}

#update-all-subscriptions button {
  display: initial;
}

#update-all-subscriptions {
  margin: 2rem auto;
  text-align: right;
}

html[dir="rtl"] #update-all-subscriptions {
  text-align: left;
}

#all-filter-lists-table li.show-message .last-update,
#all-filter-lists-table li:not(.show-message) .message,
#all-filter-lists-table li.error .last-update,
#all-filter-lists-table li:not(.error) io-popout[appearance="error"],
#acceptable-ads:not(.show-dnt-notification) #dnt {
  display: none;
}

#all-filter-lists-table li.show-message .message.error {
  color: var(--color-error);
}

#all-filter-lists-table li.show-message .message.error::before {
  display: inline-block;
  width: 1em;
  height: 1em;
  margin-right: 0.5em;
  vertical-align: middle;
  background-image: url(/skin/icons/attention.svg);
  background-size: contain;
  content: "";
}

html[dir="rtl"] #all-filter-lists-table li.show-message .message.error::before {
  margin-right: 0;
  margin-left: 0.5em;
}

#all-filter-lists-table {
  margin-bottom: 0.8rem;
}

/*
  Help tab content
*/

#social ul {
  padding: 0px;
  list-style: none;
}

#social ul li {
  display: inline-block;
}

html:not([dir="rtl"]) #social ul li {
  margin-right: 1rem;
}

html[dir="rtl"] #social ul li {
  margin-left: 1rem;
}

#social ul li a {
  display: block;
  text-align: center;
  text-decoration: none;
}

/*
  Extension State Debug Section
*/

.extension-state-debug dl {
  display: grid;
  grid-template-columns: max-content 1fr;
  gap: 4px 12px;
  margin: 0;
}

.extension-state-debug dt {
  font-weight: 700;
}
.extension-state-debug dd {
  margin: 0;
}

.extension-state-debug table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 12px;
}

.extension-state-debug th,
.extension-state-debug td {
  padding: 4px 8px;
  text-align: left;
  border-bottom: var(--border-width-thin) solid var(--border-color-secondary);
  vertical-align: top;
}

.extension-state-debug th:first-child,
.extension-state-debug td:first-child {
  padding-left: 0;
}

.extension-state-debug th {
  border-bottom-color: var(--border-color-primary);
}

.extension-state-debug td.num,
.extension-state-debug th.num {
  text-align: right;
}

.extension-state-debug td small {
  display: block;
  font-size: var(--font-size-small);
  color: var(--color-dimmed);
}

.extension-state-debug button {
  margin-top: 12px;
  margin-left: auto;
}

/*
  Dialog
*/

#dialog-background {
  display: none;
  position: fixed;
  z-index: var(--z-dialog);
  top: 0px;
  right: 0px;
  bottom: 0px;
  left: 0px;
  opacity: 0.2;
  background-color: #000;
}

body[data-dialog] #dialog-background {
  display: block;
}

#dialog {
  overflow: hidden;
  position: fixed;
  z-index: var(--z-dialog);
  top: 50%;
  right: 0;
  left: 0;
  width: 700px;
  margin: auto;
  padding: 20px;
  border-radius: var(--border-radius);
  background-color: #fff;
  box-shadow: 0 -4px 20px 0 rgba(255, 255, 255, 0.11);
  transform: translateY(-50%);
}

#dialog-title h3 {
  margin: 0 0 1.2em;
  text-transform: uppercase;
}

#dialog-body {
  overflow: auto;
  max-height: 60vh;
}

#dialog-body h3 {
  margin: 0 0 0.5em;
  line-height: 0.9em;
  font-size: 0.9em;
}

#dialog-body h3::before {
  position: absolute;
  width: 18px;
  height: 11px;
  background-size: contain;
  background-repeat: no-repeat;
  content: "";
}

html[dir="ltr"] #dialog-body h3::before {
  margin-left: -26px;
}

html[dir="rtl"] #dialog-body h3::before {
  margin-right: -26px;
}

#dialog-body .field.title h3::before {
  background-image: url(/skin/icons/filter-list-title.svg);
}

#dialog-body .field.url h3::before {
  background-image: url(/skin/icons/filter-list-url.svg);
}

#dialog-body p {
  margin: 0;
}

#dialog-body .ctas {
  display: flex;
  justify-content: end;
  margin-top: 1.2em;
}

html:not([dir="rtl"]) #dialog-body .ctas > *:not(:last-child),
html[dir="rtl"] #dialog-body .ctas > *:not(:first-child) {
  margin-right: 1.5em;
}

#dialog-body .ctas button {
  min-width: 150px;
  padding: 0.5em 1em;
  border: 1px solid var(--border-color-cta-secondary);
  border-radius: 6px;
  font-size: var(--font-size-primary);
  font-weight: 700;
  color: var(--color-cta-secondary);
  background-color: var(--background-color-cta-secondary);
  box-shadow: none;
  text-transform: capitalize;
  transition: 100ms background-color;
  cursor: pointer;
}

#dialog-body .ctas button:hover {
  background-color: var(--background-color-cta-secondary-hover);
}

#dialog-body .ctas button.primary {
  border-color: var(--border-color-cta-primary);
  color: var(--color-cta-primary);
  background-color: var(--background-color-cta-primary);
  box-shadow: 0 5px 20px rgba(0, 0, 0, 0.15);
}

#dialog-body .ctas button.primary:hover {
  background-color: var(--background-color-cta-primary-hover);
}

#dialog-body .ctas button.primary:disabled {
  background-color: #5cbce1;
  cursor: not-allowed;
}

#dialog-body .ctas button.premium {
  border-color: var(--color-premium);
  background-color: var(--color-premium);
  color: #000;
}

#dialog-body .ctas button.premium:hover {
  border-color: var(--color-premium-hover);
  background-color: var(--color-premium-hover);
}

#dialog-content-language-add {
  margin: 0rem;
}

#dialog-content-about,
#dialog-content-invalid,
#filters-box button[role="combobox"] {
  text-align: center;
}

#dialog-content-about p {
  margin: 0.5rem 0rem;
}

#dialog-content-about .ctas,
#dialog-content-invalid .ctas {
  justify-content: center;
}

#dialog-content-import .side-controls {
  margin-top: 2.45rem;
}

#dialog-content-invalid {
  color: var(--color-error);
}

#dialog-content-invalid .error {
  width: 50px;
  height: 50px;
  margin: 0 auto 1em;
  border-radius: 50%;
  font-size: 25px;
  font-weight: 600;
  line-height: 50px;
  background-color: var(--background-color-error);
}

#dialog-content-invalid strong {
  padding: 2px 5px;
  border-radius: var(--border-radius);
  font-style: italic;
  background-color: var(--background-color-error);
}

#dialog .field {
  margin-bottom: 1.5em;
}

html[dir="ltr"] #dialog .field {
  margin-left: 28px;
}

html[dir="rtl"] #dialog .field {
  margin-right: 28px;
}

#dialog .field:last-of-type {
  margin-bottom: 0;
}

#dialog .table {
  width: 100%;
}

#dialog .section:not(:first-child) {
  margin-top: 24px;
}

#dialog .url > a {
  word-wrap: break-word;
  text-decoration: none;
}

#dialog .url > a:hover {
  text-decoration: underline;
}

#dialog .url > a::after {
  display: inline-block;
  width: 0.7em;
  height: 0.7em;
  vertical-align: middle;
  background-image: url(/skin/icons/open-link.svg);
  background-size: contain;
  background-repeat: no-repeat;
  content: "";
}

html[dir="ltr"] #dialog .url > a::after {
  margin-left: 0.3em;
}

html[dir="rtl"] #dialog .url > a::after {
  margin-right: 0.3em;
  transform: scaleX(-1);
}

/* stylelint-disable indentation */
body:not([data-dialog="about"]) #dialog-title-about,
body:not([data-dialog="about"]) #dialog-content-about,
body:not([data-dialog="import"]) #dialog-title-import,
body:not([data-dialog="import"]) #dialog-content-import,
body:not([data-dialog="language-add"]) #dialog-title-language-add,
body:not([data-dialog="language-change"]) #dialog-title-language-change,
body:not([data-dialog="language-add"]):not([data-dialog="language-change"])
  #dialog-content-language-add,
body:not([data-dialog="language-add"]) #dialog-body button.add,
body:not([data-dialog="language-change"]) #dialog-body button.change,
body:not([data-dialog="predefined"]) #dialog-title-predefined,
body:not([data-dialog="predefined"]) #dialog-content-predefined,
body:not([data-dialog="invalid"]) #dialog-title-invalid,
body:not([data-dialog="invalid"]) #dialog-content-invalid,
body:not([data-dialog="optIn-premium-subscription"])
  #dialog-title-optIn-premium-subscription,
body:not([data-dialog="optIn-premium-subscription"])
  #dialog-content-optIn-premium-subscription,
body:not([data-dialog]) #dialog {
  display: none;
}
/* stylelint-enable indentation */

/*
  Notification
*/

#notification {
  display: flex;
  position: fixed;
  top: 0rem;
  left: 0rem;
  box-sizing: border-box;
  width: 100%;
  padding: 1rem 1.9rem;
  font-size: 1rem;
}

#notification strong {
  text-align: center;
  flex: 1;
}

#notification.info {
  color: #0797e1;
  background-color: rgba(225, 242, 250, 0.8);
}

#notification.error {
  color: var(--color-error);
  background-color: rgba(235, 199, 203, 0.8);
}

#notification.error .close {
  display: none;
}

#notification[aria-hidden="false"] {
  animation: show-notification 3s;
  will-change: transform;
}

html[data-application="firefox"] #data-collection {
  /*
   * We need to temporarily force-disable data collection in Firefox, while
   * we're working on improving our data collection opt-out mechanism based
   * on Mozilla's requirements
   * https://gitlab.com/adblockinc/ext/adblockplus/adblockplus/-/issues/1621
   */
  display: none;
}

@keyframes show-notification {
  0% {
    transform: translateY(-4.8rem);
  }

  25% {
    transform: translateY(0);
  }

  75% {
    transform: translateY(0);
  }

  100% {
    transform: translateY(-4.8rem);
  }
}
`, "",{"version":3,"sources":["webpack://./src/desktop-options/ui/desktop-options.css"],"names":[],"mappings":"AAAA;;;;;;;;;;;;;;;EAeE;;AAYF;EACE,eAAe;AACjB;;AAEA;EACE,aAAa;EACb,8DAA8D;EAC9D,kBAAkB;EAClB,mBAAmB;EACnB,cAAc;EACd,yBAAyB;EACzB,eAAe;EACf,mBAAmB;EACnB,uBAAuB;EACvB;;kBAEgB;EAChB,wCAAwC;AAC1C;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,iBAAiB;AACnB;;AAEA;EACE,mBAAmB;EACnB,gBAAgB;AAClB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,YAAY;AACd;;AAEA;EACE,gBAAgB;EAChB,qBAAqB;AACvB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;;EAEE,wBAAwB;AAC1B;;AAEA;;;;EAME,sBAAsB;AACxB;;AAEA;;EAEE;;AAEF;EACE,oBAAoB;EAIpB,mBAAmB;AAHrB;;AAMA;;EAEE;;AAEF;;EAEE,cAAc;EACd,sBAAsB;EACtB,mCAAmC;EACnC,6BAA6B;EAC7B,eAAe;EACf,gBAAgB;EAChB,qBAAqB;EACrB,yBAAyB;EACzB,eAAe;AACjB;;AAEA;;EAEE,mBAAmB;AACrB;;AAEA;;;;EAIE,iBAAiB;AACnB;;AAEA,4EAA4E;AAC5E;;EAEE,WAAW;EACX,WAAW;EACX,yBAAyB;AAC3B;;AAEA;;EAEE,mCAAmC;AACrC;;AAEA;EACE,yBAAyB;AAC3B;;AAEA;;EAEE,yBAAyB;EACzB,cAAc;AAChB;;AAEA;;EAEE,mCAAmC;AACrC;;AAEA;EACE,WAAW;EACX,yBAAyB;AAC3B;;AAEA;EACE,qBAAqB;AACvB;;AAEA;;EAEE,cAAc;AAChB;;AAEA;EACE,eAAe;EACf,WAAW;EACX,6BAA6B;EAC7B,oBAAoB;EACpB,gBAAgB;EAChB,0BAA0B;EAC1B,oBAAoB;AACtB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,WAAW;EACX,iBAAiB;EACjB,mBAAmB;EACnB,qBAAqB;EACrB,yBAAyB;EACzB,mBAAmB;AACrB;;AAEA;EACE,qBAAqB;EACrB,mCAAmC;AACrC;;AAEA;EACE,WAAW;EACX,yBAAyB;AAC3B;;AAEA;EACE,qBAAqB;AACvB;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,yBAAyB;AAC3B;;AAEA;EACE,kBAAkB;AACpB;;AAEA;EACE,kBAAkB;EAClB,8CAA8C;EAC9C,+BAA+B;EAC/B,WAAW;EACX,WAAW;EACX,aAAa;EACb,4DAA4D;EAC5D,gBAAgB;EAChB,6CAA6C;AAC/C;;AAEA;EACE,yDAAyD;EACzD,kBAAkB;EAClB,UAAU;EACV,sBAAsB;AACxB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,yBAAyB;AAC3B;;AAEA;EACE,YAAY;AACd;;AAEA;;EAEE,cAAc;AAChB;;AAEA;EACE,yBAAyB;AAC3B;;AAEA;EACE,2BAA2B;AAC7B;;AAEA;;;;;;;CAOC;AACD;EACE,mBAAmB;AACrB;;AAEA;EACE,oBAAoB;AACtB;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,kBAAkB;AACpB;;AAEA;;EAEE;;AAEF;EACE,YAAY;EACZ,WAAW;EACX,6BAA6B;AAC/B;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,cAAc;EACd,4BAA4B;EAC5B,WAAW;AACb;;AAEA;EACE,gBAAgB;EAChB,gBAAgB;EAGhB,gBAAgB;AAClB;;AAEA;;EAEE,eAAe;AACjB;;AAEA;EACE,qBAAqB;AACvB;;AAEA;;;;;;;CAOC;;AAED;;EAEE,aAAa;EACb,cAAc;EACd,YAAY;AACd;;AAEA;;EAEE,cAAc;EACd,YAAY;EACZ,kBAAkB;EAClB,sBAAsB;AACxB;;AAEA;;EAEE,yDAAyD;EACzD,uDAAuD;AACzD;;AAEA;EACE,yEAAyE;AAC3E;;AAEA;;EAEE,qDAAqD;AACvD;;AAEA;;EAEE,uEAAuE;AACzE;;AAEA;;EAEE,aAAa;EACb,YAAY;EACZ,mDAAmD;AACrD;;AAEA;;EAEE,qDAAqD;AACvD;;AAEA;;EAEE,gBAAgB;AAClB;;AAEA;EACE,4DAA4D;AAC9D;;AAEA;EACE,wDAAwD;AAC1D;;AAEA;EACE,WAAW;EACX,YAAY;AACd;;AAEA;EACE,gDAAgD;AAClD;;AAEA;EACE,kEAAkE;AACpE;;AAEA;EACE,6CAA6C;AAC/C;;AAEA;EACE,4CAA4C;AAC9C;;AAEA;EACE,2CAA2C;AAC7C;;AAEA;EACE,4DAA4D;AAC9D;;AAEA;EACE,SAAS;EACT,eAAe;AACjB;;AAEA;EACE,WAAW;EACX,YAAY;AACd;;AAEA;EACE,4DAA4D;AAC9D;;AAEA;EACE,wEAAwE;AAC1E;;AAEA;EACE,gEAAgE;AAClE;;AAEA;EACE,8DAA8D;AAChE;;AAEA;EACE,4EAA4E;AAC9E;;AAEA;EACE,0EAA0E;AAC5E;;AAEA;EACE,aAAa;EACb,cAAc;EACd,YAAY;EACZ,YAAY;EACZ,sBAAsB;AACxB;;AAEA;EACE,gEAAgE;AAClE;;AAEA;EACE,aAAa;EACb,cAAc;EACd,gBAAgB;AAClB;;AAEA;EACE,8CAA8C;AAChD;;AAEA;EACE,+CAA+C;AACjD;;AAEA;;EAEE;;AAEF;EACE,kBAAkB;EAClB,0BAA0B;EAC1B,mBAAmB;AACrB;;AAEA;EACE,WAAW;EACX,+BAA+B;EAC/B,yBAAyB;EACzB,aAAa;EACb,eAAe;AACjB;;AAEA;EACE,aAAa;EACb,kBAAkB;EAClB,sCAAsC;EACtC,QAAQ;EACR,WAAW;EACX,yBAAyB;AAC3B;;AAEA;EACE,kBAAkB;AACpB;;AAEA;EACE,WAAW;EACX,OAAO;AACT;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,gCAAgC;AAClC;;AAEA;;EAEE,kBAAkB;EAClB,WAAW;EACX,WAAW;EACX,aAAa;EACb,cAAc;EACd,cAAc;AAChB;;AAEA,kCAAkC;AAClC;;;;;;EAME,WAAW;EACX,UAAU;AACZ;AACA,iCAAiC;;AAEjC;;CAEC;;AAED;EACE,yBAAyB;AAC3B;;AAEA;EACE;IACE,6BAA6B;EAC/B;;EAEA;IACE,yBAAyB;EAC3B;;EAEA;IACE,yBAAyB;EAC3B;;EAEA;IACE,6BAA6B;EAC/B;AACF;;AAEA;;EAEE;;AAEF;;;EAGE,cAAc;AAChB;;AAEA;EACE,kBAAkB;EAClB,cAAc;AAChB;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,YAAY;AACd;;AAEA;EACE,kBAAkB;AACpB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;;EAEE,YAAY;EACZ,iBAAiB;AACnB;;AAEA;EACE,YAAY;EACZ,iBAAiB;EACjB,kBAAkB;EAClB,oDAAoD;EACpD,wBAAwB;EACxB,4BAA4B;AAC9B;;AAEA;EACE,gBAAgB;EAChB,mBAAmB;EACnB,YAAY;EACZ,gBAAgB;EAChB,yBAAyB;AAC3B;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,gCAAgC;AAClC;;AAEA;;EAEE,mBAAmB;AACrB;;AAEA;EACE,kBAAkB;EAClB,YAAY;EACZ,aAAa;EACb,eAAe;EACf,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,kBAAkB;EAClB,iBAAiB;EACjB,oBAAoB;EACpB,6BAA6B;EAC7B,4DAA4D;EAC5D,cAAc;EACd,qBAAqB;EACrB,eAAe;AACjB;;AAEA;EACE,yBAAyB;AAC3B;;AAEA;EACE,qBAAqB;EACrB,sBAAsB;EACtB,gBAAgB;AAClB;;AAEA;EACE,4DAA4D;AAC9D;;AAEA;EACE,2BAA2B;AAC7B;;AAEA;EACE,0BAA0B;AAC5B;;AAEA;EACE,+BAA+B;AACjC;;AAEA;EACE,8BAA8B;AAChC;;AAEA;EACE,WAAW;AACb;;AAEA;;EAEE,aAAa;AACf;;AAEA;EACE,eAAe;EACf,YAAY;EACZ,cAAc;AAChB;;AAEA;EACE,4EAA4E;EAC5E,UAAU;EACV,WAAW;EACX,iBAAiB;AACnB;;AAEA;EACE,WAAW;EACX,mBAAmB;AACrB;;AAEA;EACE,YAAY;EACZ,kBAAkB;AACpB;;AAEA;EACE,SAAS;EACT,eAAe;AACjB;;AAEA;EACE,kBAAkB;AACpB;;AAEA;EACE,WAAW;EACX,qBAAqB;EACrB,YAAY;EACZ,6CAA6C;EAC7C,mCAAmC;EACnC,cAAc;EACd,yBAAyB;EACzB,kBAAkB;EAClB,0CAA0C;AAC5C;;AAEA;EACE,gBAAgB;AAClB;;AAEA;;EAEE,yBAAyB;AAC3B;;AAEA,6EAA6E;AAC7E;EACE;IACE,eAAe;EACjB;;EAEA;IACE,kBAAkB;IAClB,WAAW;EACb;AACF;;AAEA;;EAEE;;AAEF;EACE,YAAY;EACZ,aAAa;AACf;;AAEA;EACE,cAAc;EACd,WAAW;EACX,YAAY;EACZ,oBAAoB;EACpB,oDAAoD;EACpD,4BAA4B;EAC5B,wBAAwB;EACxB,0BAA0B;EAC1B,WAAW;AACb;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,qBAAqB;EACrB,iBAAiB;EACjB,sCAAsC;EACtC,sCAAsC;EACtC,sCAAsC;EACtC,oBAAoB;EACpB,mBAAmB;AACrB;;AAEA;;EAEE,4CAA4C;EAC5C,wCAAwC;AAC1C;;AAEA;EACE,aAAa;EACb,6BAA6B;EAC7B,mDAAmD;EACnD,2BAA2B;AAC7B;;AAEA;EACE,yBAAyB;AAC3B;;AAEA;EACE,aAAa;EACb,eAAe;EACf,qBAAqB;EACrB,mBAAmB;EACnB,8BAA8B;EAC9B,mCAAmC;EACnC,sBAAsB;AACxB;;AAEA;EACE,eAAe;EACf,gBAAgB;AAClB;;AAEA;EACE,iDAAiD;AACnD;;AAEA;EACE,aAAa;EACb,gBAAgB;AAClB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,UAAU;EACV,oBAAoB;AACtB;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,qBAAqB;EACrB,eAAe;AACjB;;AAEA;EACE,aAAa;EACb,WAAW;EACX,YAAY;EACZ,oDAAoD;EACpD,4BAA4B;EAC5B,wBAAwB;EACxB,2BAA2B;EAC3B,WAAW;AACb;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,yBAAyB;AAC3B;;AAEA;EACE,kBAAkB;AACpB;;AAEA;;EAEE,eAAe;AACjB;;AAEA;EACE,4CAA4C;EAC5C,qBAAqB;EACrB,iBAAiB;EACjB,iBAAiB;EACjB,mCAAmC;EACnC,kCAAkC;EAClC,mCAAmC;EACnC,iBAAiB;AACnB;;AAEA;;EAEE,kDAAkD;AACpD;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,iBAAiB;EAEjB,8CAA8C;EAE9C,sBAAsB;EAEtB,kBAAkB;EAElB,qBAAqB;EACrB,6CAA6C;EAC7C,WAAW;AACb;;AAEA;;EAEE;;AAEF;;;;EAIE,cAAc;AAChB;;AAEA;EACE,eAAe;EACf,wBAAwB;EACxB,yBAAyB;EACzB,mCAAmC;EACnC,sBAAsB;AACxB;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,mBAAmB;AACrB;;AAEA;;EAEE;;AAEF;;EAEE,cAAc;EACd,iBAAiB;EACjB,6BAA6B;AAC/B;;AAEA;;EAEE,mBAAmB;EACnB,kBAAkB;AACpB;;AAEA;;EAEE,YAAY;AACd;;AAEA;EACE,yBAAyB;AAC3B;;AAEA;;EAEE,WAAW;AACb;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,OAAO;AACT;;AAEA;EACE,kBAAkB;AACpB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,OAAO;AACT;;AAEA;;EAEE;;AAEF;EACE,kBAAkB;EAClB,mBAAmB;EACnB,eAAe;EACf,yBAAyB;EACzB,yBAAyB;AAC3B;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,kBAAkB;EAClB,WAAW;AACb;;AAEA;EACE,UAAU;EACV,aAAa;AACf;;AAEA;EACE,UAAU;EACV,WAAW;AACb;;AAEA;EACE,cAAc;EACd,gBAAgB;EAChB,0BAA0B;AAC5B;;AAEA;EACE,kBAAkB;EAClB,oBAAoB;EACpB,gBAAgB;AAClB;;AAEA;EACE,qBAAqB;EACrB,kBAAkB;AACpB;;AAEA;;EAEE,kBAAkB;AACpB;;AAEA;;EAEE,UAAU;AACZ;;AAEA;;EAEE,WAAW;AACb;;AAEA;EACE,eAAe;EACf,gBAAgB;AAClB;;AAEA;EACE,wBAAwB;EACxB,uBAAuB;EACvB,kBAAkB;EAClB,UAAU;EACV,YAAY;EACZ,gBAAgB;EAChB,aAAa;EACb,sBAAsB;EACtB,qCAAqC;EACrC,mCAAmC;EACnC,yCAAyC;EACzC,kBAAkB;AACpB;;AAEA;EACE,YAAY;AACd;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,cAAc;EACd,kBAAkB;EAClB,SAAS;EACT,qBAAqB;EACrB,WAAW;EACX,YAAY;EACZ,qCAAqC;EACrC,kBAAkB;EAClB,mBAAmB;EACnB,yCAAyC;EACzC,WAAW;EACX,wBAAwB;AAC1B;;AAEA;;EAEE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;EACjB,YAAY;EACZ,SAAS;EACT,cAAc;AAChB;;AAEA;EACE,oBAAoB;AACtB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,eAAe;EACf,yBAAyB;AAC3B;;AAEA;;EAEE;;AAEF;;EAEE,YAAY;EACZ,aAAa;EACb,gBAAgB;AAClB;;AAEA;;EAEE,aAAa;EACb,mBAAmB;AACrB;;AAEA;EACE,YAAY;EACZ,yBAAyB;EACzB,mBAAmB;EACnB,qBAAqB;AACvB;;AAEA;EACE,qBAAqB;EACrB,aAAa;AACf;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,6BAA6B;EAC7B,4DAA4D;AAC9D;;AAEA;EACE,YAAY;EACZ,oBAAoB;AACtB;;AAEA;EACE,kBAAkB;AACpB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,gBAAgB;EAChB,YAAY;EACZ,OAAO;EACP,uBAAuB;AACzB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;;EAEE,oBAAoB;EACpB,qBAAqB;AACvB;;AAEA;;EAEE,oBAAoB;AACtB;;AAEA;EACE,kBAAkB;AACpB;;AAEA;EACE,gBAAgB;EAChB,qBAAqB;EACrB,yBAAyB;AAC3B;;AAEA;EACE,gBAAgB;EAChB,mBAAmB;AACrB;;AAEA;;EAEE,aAAa;AACf;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,qBAAqB;EACrB,sBAAsB;AACxB;;AAEA;;EAEE,iBAAiB;EACjB,kBAAkB;AACpB;;AAEA;;EAEE,OAAO;EACP,kBAAkB;AACpB;;AAEA;;EAEE,OAAO;AACT;;AAEA;;EAEE,qBAAqB;AACvB;;AAEA;;EAEE,OAAO;AACT;;AAEA;;EAEE,OAAO;AACT;;AAEA;;EAEE,OAAO;AACT;;AAEA;;EAEE,oBAAoB;EACpB,cAAc;AAChB;;AAEA;;EAEE,eAAe;EACf,mBAAmB;AACrB;;AAEA;EACE,YAAY;AACd;;AAEA;EACE,oBAAoB;AACtB;;AAEA;EACE,yBAAyB;EACzB,kBAAkB;AACpB;;AAEA;EACE,uBAAuB;EACvB,0BAA0B;AAC5B;;AAEA;EACE,cAAc;EACd,aAAa;EACb,yBAAyB;AAC3B;;AAEA;EACE,WAAW;AACb;;AAEA;EACE,aAAa;EACb,WAAW;EACX,YAAY;EACZ,oBAAoB;EACpB,sBAAsB;AACxB;;AAEA;;EAEE,yBAAyB;AAC3B;;AAEA;;EAEE,WAAW;AACb;;AAEA;EACE,mBAAmB;EACnB,gBAAgB;EAChB,oBAAoB;EACpB,UAAU;AACZ;;AAEA;EACE,wBAAwB;AAC1B;;AAEA;;CAEC;;AAED;EACE,kBAAkB;EAClB,YAAY;EACZ,mBAAmB;EACnB,qBAAqB;EACrB,YAAY;AACd;;AAEA;EACE,kBAAkB;AACpB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;;CAEC;;AAED;EACE,aAAa;EACb,iBAAiB;AACnB;;AAEA;EACE,OAAO;EACP,kBAAkB;AACpB;;AAEA,kCAAkC;AAClC;;;;EAIE,eAAe;AACjB;AACA,iCAAiC;;AAEjC;EACE,aAAa;EACb,sBAAsB;AACxB;;AAEA;EACE,aAAa;EACb,uBAAuB;AACzB;;AAEA;EACE,oBAAoB;AACtB;;AAEA,kCAAkC;AAClC;;;;;;;;EAQE,eAAe;AACjB;AACA,iCAAiC;;AAEjC;EACE,2BAA2B;AAC7B;;AAEA;EACE,uBAAuB;AACzB;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,qBAAqB;EACrB,SAAS;EACT,eAAe;AACjB;;AAEA;EACE,aAAa;EACb,aAAa;EACb,cAAc;EACd,kBAAkB;EAClB,yBAAyB;EACzB,iCAAiC;EACjC,WAAW;EACX,8CAA8C;AAChD;;AAEA;EACE,qBAAqB;AACvB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,UAAU;AACZ;;AAEA;EACE,qBAAqB;AACvB;;AAEA;;;;;;;;EAQE,aAAa;AACf;;AAEA;;EAEE;;AAEF;EACE,aAAa;EACb,qBAAqB;AACvB;;AAEA;EACE,oBAAoB;EACpB,yBAAyB;EACzB,mCAAmC;EACnC,eAAe;EACf,OAAO;AACT;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,oBAAoB;AACtB;;AAEA;EACE,qBAAqB;EACrB,oBAAoB;EACpB,kBAAkB;EAClB,iBAAiB;AACnB;;AAEA;;CAEC;;AAED;EACE,gBAAgB;AAClB;;AAEA;EACE,mBAAmB;EACnB,gBAAgB;EAChB,yBAAyB;AAC3B;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,kBAAkB;AACpB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,iBAAiB;EACjB,iBAAiB;AACnB;;AAEA;EACE,gBAAgB;AAClB;;AAEA;;;;;EAKE,aAAa;AACf;;AAEA;EACE,yBAAyB;AAC3B;;AAEA;EACE,qBAAqB;EACrB,UAAU;EACV,WAAW;EACX,mBAAmB;EACnB,sBAAsB;EACtB,gDAAgD;EAChD,wBAAwB;EACxB,WAAW;AACb;;AAEA;EACE,eAAe;EACf,kBAAkB;AACpB;;AAEA;EACE,qBAAqB;AACvB;;AAEA;;CAEC;;AAED;EACE,YAAY;EACZ,gBAAgB;AAClB;;AAEA;EACE,qBAAqB;AACvB;;AAEA;EACE,kBAAkB;AACpB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,cAAc;EACd,kBAAkB;EAClB,qBAAqB;AACvB;;AAEA;;CAEC;;AAED;EACE,aAAa;EACb,sCAAsC;EACtC,aAAa;EACb,SAAS;AACX;;AAEA;EACE,gBAAgB;AAClB;AACA;EACE,SAAS;AACX;;AAEA;EACE,WAAW;EACX,yBAAyB;EACzB,gBAAgB;AAClB;;AAEA;;EAEE,gBAAgB;EAChB,gBAAgB;EAChB,2EAA2E;EAC3E,mBAAmB;AACrB;;AAEA;;EAEE,eAAe;AACjB;;AAEA;EACE,gDAAgD;AAClD;;AAEA;;EAEE,iBAAiB;AACnB;;AAEA;EACE,cAAc;EACd,iCAAiC;EACjC,0BAA0B;AAC5B;;AAEA;EACE,gBAAgB;EAChB,iBAAiB;AACnB;;AAEA;;CAEC;;AAED;EACE,aAAa;EACb,eAAe;EACf,wBAAwB;EACxB,QAAQ;EACR,UAAU;EACV,WAAW;EACX,SAAS;EACT,YAAY;EACZ,sBAAsB;AACxB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,gBAAgB;EAChB,eAAe;EACf,wBAAwB;EACxB,QAAQ;EACR,QAAQ;EACR,OAAO;EACP,YAAY;EACZ,YAAY;EACZ,aAAa;EACb,mCAAmC;EACnC,sBAAsB;EACtB,mDAAmD;EACnD,2BAA2B;AAC7B;;AAEA;EACE,iBAAiB;EACjB,yBAAyB;AAC3B;;AAEA;EACE,cAAc;EACd,gBAAgB;AAClB;;AAEA;EACE,iBAAiB;EACjB,kBAAkB;EAClB,gBAAgB;AAClB;;AAEA;EACE,kBAAkB;EAClB,WAAW;EACX,YAAY;EACZ,wBAAwB;EACxB,4BAA4B;EAC5B,WAAW;AACb;;AAEA;EACE,kBAAkB;AACpB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,wDAAwD;AAC1D;;AAEA;EACE,sDAAsD;AACxD;;AAEA;EACE,SAAS;AACX;;AAEA;EACE,aAAa;EACb,oBAAoB;EACpB,iBAAiB;AACnB;;AAEA;;EAEE,mBAAmB;AACrB;;AAEA;EACE,gBAAgB;EAChB,kBAAkB;EAClB,mDAAmD;EACnD,kBAAkB;EAClB,mCAAmC;EACnC,gBAAgB;EAChB,iCAAiC;EACjC,uDAAuD;EACvD,gBAAgB;EAChB,0BAA0B;EAC1B,kCAAkC;EAClC,eAAe;AACjB;;AAEA;EACE,6DAA6D;AAC/D;;AAEA;EACE,6CAA6C;EAC7C,+BAA+B;EAC/B,qDAAqD;EACrD,0CAA0C;AAC5C;;AAEA;EACE,2DAA2D;AAC7D;;AAEA;EACE,yBAAyB;EACzB,mBAAmB;AACrB;;AAEA;EACE,kCAAkC;EAClC,sCAAsC;EACtC,WAAW;AACb;;AAEA;EACE,wCAAwC;EACxC,4CAA4C;AAC9C;;AAEA;EACE,YAAY;AACd;;AAEA;;;EAGE,kBAAkB;AACpB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;;EAEE,uBAAuB;AACzB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,yBAAyB;AAC3B;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,kBAAkB;EAClB,kBAAkB;EAClB,eAAe;EACf,gBAAgB;EAChB,iBAAiB;EACjB,+CAA+C;AACjD;;AAEA;EACE,gBAAgB;EAChB,mCAAmC;EACnC,kBAAkB;EAClB,+CAA+C;AACjD;;AAEA;EACE,oBAAoB;AACtB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,kBAAkB;AACpB;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,WAAW;AACb;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,qBAAqB;EACrB,qBAAqB;AACvB;;AAEA;EACE,0BAA0B;AAC5B;;AAEA;EACE,qBAAqB;EACrB,YAAY;EACZ,aAAa;EACb,sBAAsB;EACtB,gDAAgD;EAChD,wBAAwB;EACxB,4BAA4B;EAC5B,WAAW;AACb;;AAEA;EACE,kBAAkB;AACpB;;AAEA;EACE,mBAAmB;EACnB,qBAAqB;AACvB;;AAEA,kCAAkC;AAClC;;;;;;;;;;;;;;;;;;;EAmBE,aAAa;AACf;AACA,iCAAiC;;AAEjC;;CAEC;;AAED;EACE,aAAa;EACb,eAAe;EACf,SAAS;EACT,UAAU;EACV,sBAAsB;EACtB,WAAW;EACX,oBAAoB;EACpB,eAAe;AACjB;;AAEA;EACE,kBAAkB;EAClB,OAAO;AACT;;AAEA;EACE,cAAc;EACd,0CAA0C;AAC5C;;AAEA;EACE,yBAAyB;EACzB,0CAA0C;AAC5C;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,+BAA+B;EAC/B,sBAAsB;AACxB;;AAEA;EACE;;;;;IAKE;EACF,aAAa;AACf;;AAEA;EACE;IACE,8BAA8B;EAChC;;EAEA;IACE,wBAAwB;EAC1B;;EAEA;IACE,wBAAwB;EAC1B;;EAEA;IACE,8BAA8B;EAChC;AACF","sourcesContent":["/*\n * This file is part of Adblock Plus <https://adblockplus.org/>,\n * Copyright (C) 2006-present eyeo GmbH\n *\n * Adblock Plus is free software: you can redistribute it and/or modify\n * it under the terms of the GNU General Public License version 3 as\n * published by the Free Software Foundation.\n *\n * Adblock Plus is distributed in the hope that it will be useful,\n * but WITHOUT ANY WARRANTY; without even the implied warranty of\n * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n * GNU General Public License for more details.\n *\n * You should have received a copy of the GNU General Public License\n * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.\n */\n\n@import \"../../theme/ui/font.css\";\n@import \"../../theme/ui/z-index.css\";\n@import \"../../theme/ui/common.css\";\n@import \"../../theme/ui/light.css\";\n@import \"../../components/ui/io-filter-table.css\";\n@import \"../../components/ui/io-list-box.css\";\n@import \"../../components/ui/io-popout.css\";\n@import \"../../components/ui/io-popout-fixes.css\";\n@import \"../../components/ui/io-toggle.css\";\n\nhtml {\n  font-size: 16px;\n}\n\nbody {\n  display: grid;\n  /* We force vertical scrollbars to keep the content centered */\n  overflow-y: scroll;\n  margin: 1rem 0.3rem;\n  color: #4a4a4a;\n  background-color: #f3f3f3;\n  font-size: 1rem;\n  line-height: 1.3rem;\n  justify-content: center;\n  grid-template-areas:\n    \"sidebar premium-banner\"\n    \"sidebar main\";\n  grid-template-columns: auto 46.3rem auto;\n}\n\nh1 {\n  font-size: 3rem;\n  font-weight: 300;\n  line-height: 3rem;\n}\n\nh2 {\n  font-size: 1.125rem;\n  font-weight: 700;\n}\n\na {\n  color: #0797e1;\n}\n\na:hover {\n  color: #5cbce1;\n}\n\nul {\n  margin: 0rem;\n}\n\nmain h3 {\n  margin-top: 0rem;\n  margin-bottom: 0.5rem;\n}\n\n.description {\n  font-size: 0.9rem;\n}\n\n[aria-hidden=\"true\"],\n[hidden] {\n  display: none !important;\n}\n\ninput[type=\"text\"],\ninput[type=\"url\"],\ntextarea,\nmain {\n  -webkit-box-sizing: border-box;\n  -moz-box-sizing: border-box;\n  box-sizing: border-box;\n}\n\n/*\n  Normalization\n */\n\nbutton {\n  font-family: inherit;\n}\n\nbutton {\n  border-radius: 0rem;\n}\n\n/*\n  Buttons and links\n */\n\nbutton,\n.button {\n  display: block;\n  padding: 0.6rem 0.8rem;\n  border-radius: var(--border-radius);\n  background-color: transparent;\n  font-size: 1rem;\n  font-weight: 700;\n  text-decoration: none;\n  text-transform: uppercase;\n  cursor: pointer;\n}\n\nbutton:disabled,\nbutton[aria-disabled=\"true\"] {\n  cursor: not-allowed;\n}\n\nbutton.primary:not(.icon),\n.button.primary:not(.icon),\nbutton.secondary:not(.icon),\n.button.secondary:not(.icon) {\n  padding: 8px 20px;\n}\n\n/* Ignore .icon to avoid overriding \"specific\" (primary, secondary) styles */\nbutton.primary:not(.icon),\n.button.primary:not(.icon) {\n  border: 0px;\n  color: #fff;\n  background-color: #0797e1;\n}\n\nbutton.primary:not([disabled]):not(.icon):hover,\n.button.primary:not(.icon):hover {\n  box-shadow: inset 0 0 0 3px #005d80;\n}\n\nbutton.primary[disabled]:not(.icon) {\n  background-color: #5cbce1;\n}\n\nbutton.secondary:not(.icon),\n.button.secondary:not(.icon) {\n  border: 2px solid #0797e1;\n  color: #0797e1;\n}\n\nbutton.secondary:not(:disabled):not(.icon):hover,\n.button.secondary:not(:disabled):not(.icon):hover {\n  box-shadow: inset 0 0 0 1px #0797e1;\n}\n\nbutton.secondary:disabled:not(.icon) {\n  color: #bbb;\n  background-color: #f3f3f3;\n}\n\nbutton.secondary:disabled:not(.icon):hover {\n  border-color: inherit;\n}\n\nbutton.link,\nbutton.list {\n  color: #0797e1;\n}\n\nbutton.link {\n  padding: 0.2rem;\n  border: 0px;\n  background-color: transparent;\n  font-family: inherit;\n  font-weight: 400;\n  text-decoration: underline;\n  text-transform: none;\n}\n\nbutton.link:hover {\n  color: #5cbce1;\n}\n\nbutton.list {\n  width: 100%;\n  border-width: 1px;\n  border-style: solid;\n  border-color: #cdcdcd;\n  background-color: #e1f2fa;\n  text-align: initial;\n}\n\nbutton.list:hover {\n  border-color: #0797e1;\n  box-shadow: inset 0 0 0 3px #0797e1;\n}\n\nbutton.add.secondary {\n  width: 100%;\n  border: 1px solid #bcbcbc;\n}\n\nbutton.add.secondary:not(:disabled):hover {\n  border-color: #0797e1;\n}\n\nbutton.add::before {\n  content: \"+ \";\n}\n\n#filters-box li[aria-selected=\"true\"] {\n  background-color: #e1f2fa;\n}\n\n#filterlist-by-url-wrap {\n  position: relative;\n}\n\n#filterlist-by-url {\n  position: absolute;\n  /* ensures it overlaps same popout z-indexes */\n  z-index: var(--z-popout-active);\n  top: -260px;\n  width: 100%;\n  height: 260px;\n  border-radius: var(--border-radius) var(--border-radius) 0 0;\n  background: #fff;\n  box-shadow: 0 -4px 20px 0 rgba(0, 0, 0, 0.11);\n}\n\nbutton[data-action=\"open-filterlist-by-url\"] {\n  /* needed to avoid being shadowed by #filterlist-by-url */\n  position: relative;\n  z-index: 1;\n  background-color: #fff;\n}\n\n.side-controls:not(.wrap) {\n  display: flex;\n  margin: 0.8rem 0rem;\n  justify-content: flex-end;\n}\n\n.side-controls > * {\n  margin: 0rem;\n}\n\n#filterlist-by-url .main-input,\n#filterlist-by-url h3 {\n  margin: 0.8rem;\n}\n\n#filterlist-by-url h3 {\n  text-transform: uppercase;\n}\n\n#filterlist-by-url .side-controls {\n  justify-content: flex-start;\n}\n\n/*\n  Due to Edge adoption as new target browser\n  we cannot use -moz/webkit-margin-start\n  or -moz/webkit-margin-end because\n  these lack Edge support.\n  Yet we need to preserve html direction\n  and potential UI that might swap right to left.\n*/\nhtml:not([dir=\"rtl\"]) .side-controls > * {\n  margin-left: 0.8rem;\n}\n\nhtml[dir=\"rtl\"] .side-controls > * {\n  margin-right: 0.8rem;\n}\n\n.side-controls.wrap > * {\n  margin: 0.6rem 0;\n}\n\nhtml:not([dir=\"rtl\"]) .side-controls.wrap > * {\n  margin-left: auto;\n}\n\nhtml[dir=\"rtl\"] .side-controls.wrap > * {\n  margin-right: auto;\n}\n\n/*\n  icons\n */\n\n.icon {\n  padding: 0px;\n  border: 0px;\n  background-color: transparent;\n}\n\n.icon:hover {\n  box-shadow: none;\n}\n\n.icon::before {\n  display: block;\n  background-repeat: no-repeat;\n  content: \"\";\n}\n\ninput[type=\"checkbox\"].icon {\n  margin-top: -1px;\n  margin-left: 2px;\n  -webkit-appearance: none;\n  -moz-appearance: none;\n  appearance: none;\n}\n\ninput[type=\"checkbox\"].icon:not(:disabled),\ninput[type=\"checkbox\"].icon:not(:disabled) + label[for] {\n  cursor: pointer;\n}\n\ninput[type=\"checkbox\"].icon::before {\n  border-width: 0.05rem;\n}\n\n/*\n all button[role=\"checkbox\"] styles can be removed once the html and js are\n updated to use input[type=\"checkbox\"]. I started improving the code I touched\n but generally speaking, accessibility properties should not be used for\n styling.\n\n For now I have just made sure both types work\n*/\n\nbutton[role=\"checkbox\"].icon::before,\ninput[type=\"checkbox\"].icon::before {\n  width: 1.2rem;\n  height: 1.2rem;\n  padding: 0px;\n}\n\nbutton[role=\"checkbox\"][disabled].icon:not(.toggle)::before,\nbutton[role=\"checkbox\"][aria-disabled=\"true\"].icon:not(.toggle)::before {\n  margin: 0.2rem;\n  border: 0rem;\n  border-radius: 2px;\n  background-color: #ccc;\n}\n\nbutton[role=\"checkbox\"].icon:not(.toggle)::before,\ninput[type=\"checkbox\"].icon:not(.toggle)::before {\n  /* Using ?query as a workaround to chromium bug #643716 */\n  background-image: url(/skin/icons/checkbox.svg?off#off);\n}\n\ninput[type=\"checkbox\"].icon:disabled::before {\n  background-image: url(/skin/icons/checkbox.svg?off-disabled#off-disabled);\n}\n\nbutton[role=\"checkbox\"][aria-checked=\"true\"].icon:not(.toggle)::before,\ninput[type=\"checkbox\"].icon:checked:not(.toggle)::before {\n  background-image: url(/skin/icons/checkbox.svg?on#on);\n}\n\nbutton[role=\"checkbox\"][aria-checked=\"true\"].icon:disabled:not(.toggle)::before,\ninput[type=\"checkbox\"].icon:checked:disabled:not(.toggle)::before {\n  background-image: url(/skin/icons/checkbox.svg?on-disabled#on-disabled);\n}\n\nbutton[role=\"checkbox\"].icon.toggle::before,\ninput[type=\"checkbox\"].icon.toggle::before {\n  width: 1.9rem;\n  height: 1rem;\n  background-image: url(/skin/icons/toggle.svg?on#on);\n}\n\nbutton[role=\"checkbox\"][aria-checked=\"false\"].icon.toggle::before,\ninput[type=\"checkbox\"].icon.toggle:not(:checked)::before {\n  background-image: url(/skin/icons/toggle.svg?off#off);\n}\n\nbutton[role=\"checkbox\"][disabled].icon.toggle::before,\ninput[type=\"checkbox\"].icon.toggle:disabled::before {\n  background: none;\n}\n\n.icon.delete::before {\n  background-image: url(/skin/icons/trash.svg?default#default);\n}\n\n.icon.delete:hover::before {\n  background-image: url(/skin/icons/trash.svg?hover#hover);\n}\n\n.icon.delete::before {\n  width: 1rem;\n  height: 1rem;\n}\n\n[data-validation] .main-input input:focus:invalid ~ .icon.attention::before {\n  background-image: url(/skin/icons/attention.svg);\n}\n\n[data-validation] .main-input input:valid ~ .icon.attention::before {\n  background-image: url(/skin/icons/checkmark.svg?approved#approved);\n}\n\n.icon.update-subscription::before {\n  background-image: url(/skin/icons/reload.svg);\n}\n\n.icon.website::before {\n  background-image: url(/skin/icons/globe.svg);\n}\n\n.icon.source::before {\n  background-image: url(/skin/icons/code.svg);\n}\n\n.icon.delete::before {\n  background-image: url(/skin/icons/trash.svg?default#default);\n}\n\n.close {\n  margin: 0;\n  cursor: pointer;\n}\n\n.close.icon::before {\n  width: 1rem;\n  height: 1rem;\n}\n\n.icon.close.primary::before {\n  background-image: url(/skin/icons/close.svg?primary#primary);\n}\n\n.icon.close.primary:hover::before {\n  background-image: url(/skin/icons/close.svg?primary-hover#primary-hover);\n}\n\n.icon.close.secondary::before {\n  background-image: url(/skin/icons/close.svg?secondary#secondary);\n}\n\n.icon.close.tertiary::before {\n  background-image: url(/skin/icons/close.svg?tertiary#tertiary);\n}\n\n.icon.close.secondary:hover::before {\n  background-image: url(/skin/icons/close.svg?secondary-hover#secondary-hover);\n}\n\n.icon.close.tertiary:hover::before {\n  background-image: url(/skin/icons/close.svg?tertiary-hover#tertiary-hover);\n}\n\n#dialog .table.list li button.icon::before {\n  width: 1.3rem;\n  height: 1.3rem;\n  margin: 0rem;\n  border: 0rem;\n  background-image: none;\n}\n\n#dialog .table.list li button[aria-checked=\"true\"].icon::before {\n  background-image: url(/skin/icons/checkmark.svg?default#default);\n}\n\n#social ul li .icon::before {\n  width: 2.5rem;\n  height: 2.5rem;\n  margin: 0em auto;\n}\n\n.icon.twitter::before {\n  background-image: url(/skin/icons/twitter.svg);\n}\n\n.icon.facebook::before {\n  background-image: url(/skin/icons/facebook.svg);\n}\n\n/*\n  Forms\n */\n\n.main-input {\n  position: relative;\n  margin: 1.8rem 0rem 0.5rem;\n  padding-top: 0.7rem;\n}\n\n.main-input input {\n  width: 100%;\n  padding: var(--padding-primary);\n  border: 1px solid #cdcdcd;\n  outline: none;\n  font-size: 1rem;\n}\n\n[data-validation] .main-input input ~ .error-msg {\n  display: none;\n  position: absolute;\n  top: calc(var(--padding-primary) * -2);\n  right: 0;\n  z-index: 10;\n  color: var(--color-error);\n}\n\n[data-validation] .side-controls {\n  margin-top: 1.2rem;\n}\n\nhtml[dir=\"rtl\"] [data-validation] .main-input input ~ .error-msg {\n  right: auto;\n  left: 0;\n}\n\n[data-validation] .main-input input:focus:invalid ~ .error-msg {\n  display: block;\n}\n\n[data-validation] .main-input input:focus:invalid {\n  border-color: var(--color-error);\n}\n\n[data-validation] .main-input input:focus:invalid ~ .attention::before,\n[data-validation] .main-input input ~ .attention::before {\n  position: absolute;\n  top: 0.8rem;\n  right: 0rem;\n  width: 1.2rem;\n  height: 1.2rem;\n  margin: 0.8rem;\n}\n\n/* stylelint-disable indentation */\nhtml[dir=\"rtl\"]\n  [data-validation]\n  .main-input\n  input:focus:invalid\n  ~ .attention::before,\nhtml[dir=\"rtl\"] [data-validation] .main-input input ~ .attention::before {\n  right: auto;\n  left: 0rem;\n}\n/* stylelint-enable indentation */\n\n/*\n  Animations\n*/\n\n.highlight-animate {\n  animation: highlight 1s 3;\n}\n\n@keyframes highlight {\n  0% {\n    background-color: transparent;\n  }\n\n  30% {\n    background-color: #ffd7a3;\n  }\n\n  70% {\n    background-color: #ffd7a3;\n  }\n\n  100% {\n    background-color: transparent;\n  }\n}\n\n/*\n  Sidebar\n */\n\n#sidebar,\n#sidebar .fixed,\n[role=\"tablist\"] {\n  width: 14.3rem;\n}\n\n#sidebar {\n  grid-area: sidebar;\n  flex-shrink: 0;\n}\n\n#sidebar .fixed {\n  top: 1.2rem;\n  bottom: 0rem;\n  height: auto;\n}\n\nhtml[dir=\"ltr\"] #sidebar header {\n  margin-right: 2rem;\n}\n\nhtml[dir=\"rtl\"] #sidebar header {\n  margin-left: 2rem;\n}\n\n#sidebar header h1,\n#sidebar header p {\n  margin: 0rem;\n  user-select: none;\n}\n\n#sidebar header h1 {\n  font-size: 0;\n  line-height: 48px;\n  color: transparent;\n  background-image: url(/skin/icons/logo/abp-full.svg);\n  background-size: contain;\n  background-repeat: no-repeat;\n}\n\n#sidebar header p {\n  margin-top: 30px;\n  line-height: 2.6rem;\n  opacity: 0.6;\n  font-weight: 600;\n  text-transform: uppercase;\n}\n\nhtml[dir=\"rtl\"] #sidebar header {\n  text-align: left;\n}\n\nhtml[dir=\"rtl\"] #sidebar header p {\n  text-align: right;\n}\n\nhtml[dir=\"rtl\"] #sidebar header h1 {\n  background-position: center left;\n}\n\n#sidebar nav,\n#sidebar footer {\n  margin: 1.4rem 0rem;\n}\n\n[role=\"tablist\"] {\n  position: relative;\n  margin: 0rem;\n  padding: 0rem;\n  font-size: 1rem;\n  list-style: none;\n}\n\nli a[role=\"tab\"] {\n  display: flex;\n  margin-right: -1px;\n  margin-left: -1px;\n  padding: 1rem 0.8rem;\n  border: 1px solid transparent;\n  border-radius: var(--border-radius) 0 0 var(--border-radius);\n  color: inherit;\n  text-decoration: none;\n  cursor: pointer;\n}\n\nli a[role=\"tab\"]:hover {\n  background-color: #eaeaea;\n}\n\nli a[role=\"tab\"][aria-selected] {\n  border-color: #cdcdcd;\n  background-color: #fff;\n  font-weight: 700;\n}\n\nhtml[dir=\"rtl\"] li a[role=\"tab\"] {\n  border-radius: 0 var(--border-radius) var(--border-radius) 0;\n}\n\nhtml:not([dir=\"rtl\"]) li a[role=\"tab\"]:hover {\n  border-right-color: #cdcdcd;\n}\n\nhtml[dir=\"rtl\"] li a[role=\"tab\"]:hover {\n  border-left-color: #cdcdcd;\n}\n\nhtml:not([dir=\"rtl\"]) li a[role=\"tab\"][aria-selected] {\n  border-right-color: transparent;\n}\n\nhtml[dir=\"rtl\"] li a[role=\"tab\"][aria-selected] {\n  border-left-color: transparent;\n}\n\n#sidebar footer {\n  width: 100%;\n}\n\n#sidebar button,\n#sidebar .button {\n  display: flex;\n}\n\n#support-us {\n  position: fixed;\n  bottom: 40px;\n  margin: 0 40px;\n}\n\n#support-us .h2-icon {\n  /* Align icon with edges of text based on text's line height and font size */\n  width: 2em;\n  height: 2em;\n  margin-top: 0.3em;\n}\n\nhtml:not([dir=\"rtl\"]) #support-us .h2-icon {\n  float: left;\n  margin-right: 0.5em;\n}\n\nhtml[dir=\"rtl\"] #support-us .h2-icon {\n  float: right;\n  margin-left: 0.5em;\n}\n\n#support-us h2 {\n  margin: 0;\n  font-size: 1rem;\n}\n\n#support-us p {\n  text-align: center;\n}\n\n#support-us a.button {\n  width: 100%;\n  margin-bottom: 0.5rem;\n  padding: 2px;\n  border: 1px solid var(--border-color-ternary);\n  font-size: var(--font-size-primary);\n  color: #0797e1;\n  text-transform: uppercase;\n  text-align: center;\n  transition: background-color 0.2s ease-out;\n}\n\n#support-us a.button:last-of-type {\n  margin-bottom: 0;\n}\n\n#support-us a.button:hover,\n#support-us a.button:focus {\n  background-color: #e9f6fc;\n}\n\n/* This is a stopgap solution of footer overlapping tabs on low resolutions */\n@media (min-height: 37rem) {\n  #sidebar .fixed {\n    position: fixed;\n  }\n\n  #sidebar footer {\n    position: absolute;\n    bottom: 0px;\n  }\n}\n\n/*\n  Premium\n */\n\n.premium.icon::before {\n  border: none;\n  content: none;\n}\n\nbody.premium .premium.icon::before {\n  display: block;\n  width: 20px;\n  height: 20px;\n  margin-right: 0.5rem;\n  background-image: url(/skin/icons/premium-crown.svg);\n  background-repeat: no-repeat;\n  background-size: contain;\n  background-position: 0 3px;\n  content: \"\";\n}\n\nbody.premium .premium.upgrade.button {\n  display: none;\n}\n\n.premium.upgrade.button {\n  display: inline-block;\n  padding: 8px 20px;\n  border: 2px solid var(--color-premium);\n  background-color: var(--color-premium);\n  color: var(--background-color-primary);\n  text-transform: none;\n  white-space: nowrap;\n}\n\n.premium.upgrade.button:hover,\n.premium.upgrade.button:focus {\n  background-color: var(--color-premium-hover);\n  border-color: var(--color-premium-hover);\n}\n\n.premium.list button.icon[role=\"checkbox\"]:disabled::before {\n  margin-top: 0;\n  background-color: transparent;\n  background-image: url(/skin/icons/premium-lock.svg);\n  background-position: center;\n}\n\n.premium-banner-container {\n  grid-area: premium-banner;\n}\n\n.premium-banner-container .banner {\n  display: flex;\n  padding: 1.4rem;\n  margin-bottom: 1.4rem;\n  align-items: center;\n  justify-content: space-between;\n  border-radius: var(--border-radius);\n  box-sizing: border-box;\n}\n\n.premium-banner-container .banner.background {\n  padding-left: 0;\n  padding-right: 0;\n}\n\n.premium-banner-container .banner.foreground {\n  background-color: var(--background-color-primary);\n}\n\n.premium-banner-container .premium-label {\n  display: flex;\n  font-weight: 700;\n}\n\n.premium-banner-container a {\n  white-space: nowrap;\n}\n\n.premium-banner-container .button {\n  padding: 0;\n  text-transform: none;\n}\n\nbody.premium .premium-upgrade.banner {\n  display: none;\n}\n\n.premium-upgrade.banner .premium-label {\n  align-items: baseline;\n  font-size: 20px;\n}\n\n.premium-upgrade.banner .premium-label::before {\n  margin: 0 7px;\n  width: 25px;\n  height: 17px;\n  background-image: url(/skin/icons/premium-crown.svg);\n  background-repeat: no-repeat;\n  background-size: contain;\n  background-position: center;\n  content: \"\";\n}\n\n.premium-upgrade.banner p {\n  margin: 0 1rem;\n}\n\nbody:not(.premium) .premium-manage.banner {\n  display: none;\n}\n\n.premium-manage.banner {\n  justify-content: flex-end;\n}\n\n.premium-manage.banner > * {\n  margin-right: 10px;\n}\n\nhtml:not([dir=\"rtl\"]) .premium-manage.banner > *:last-child,\nhtml[dir=\"rtl\"] .premium-manage.banner > *:first-child {\n  margin-right: 0;\n}\n\n.premium-manage.banner .premium-label {\n  --button-primary-color: var(--color-premium);\n  align-items: baseline;\n  padding: 5px 11px;\n  border: 1px solid;\n  border-radius: var(--border-radius);\n  color: var(--button-primary-color);\n  font-size: var(--font-size-primary);\n  line-height: 16px;\n}\n\n.premium-manage.banner .premium-label:hover,\n.premium-manage.banner .premium-label:focus {\n  --button-primary-color: var(--color-premium-hover);\n}\n\n.premium-manage.banner .premium-label::before {\n  width: 15px;\n  height: 10px;\n  margin-right: 3px;\n  -webkit-mask-image: url(/skin/icons/premium-crown.svg);\n  mask-image: url(/skin/icons/premium-crown.svg);\n  -webkit-mask-repeat: no-repeat;\n  mask-repeat: no-repeat;\n  -webkit-mask-size: contain;\n  mask-size: contain;\n  -webkit-mask-position: center;\n  mask-position: center;\n  background-color: var(--button-primary-color);\n  content: \"\";\n}\n\n/*\n  Main content\n */\n\nbody[data-tab|=\"general\"] #content-general,\nbody[data-tab|=\"advanced\"] #content-advanced,\nbody[data-tab|=\"allowlist\"] #content-allowlist,\nbody[data-tab|=\"help\"] #content-help {\n  display: block;\n}\n\nmain {\n  grid-area: main;\n  padding: 0px 0rem 1.4rem;\n  border: 1px solid #cdcdcd;\n  border-radius: var(--border-radius);\n  background-color: #fff;\n}\n\nmain > div {\n  display: none;\n}\n\nmain p {\n  margin: 0.8rem 0rem;\n}\n\n/*\n  Sections\n */\n\n[role=\"tabpanel\"] > section,\n[role=\"tabpanel\"] > .section {\n  margin: 0 2rem;\n  padding: 1.4rem 0;\n  border-top: 1px solid #cdcdcd;\n}\n\n[role=\"tabpanel\"] > header h1,\n[role=\"tabpanel\"] > header p {\n  margin: 1.4rem 0rem;\n  padding: 0rem 2rem;\n}\n\nsection h2,\n.section h2 {\n  margin: 0rem;\n}\n\nsection h2 {\n  text-transform: uppercase;\n}\n\nsection,\n.section {\n  clear: both;\n}\n\nsection.cols {\n  display: flex;\n}\n\nsection.cols > *:first-child {\n  flex: 1;\n}\n\nhtml:not([dir=\"rtl\"]) section.cols > *:first-child {\n  margin-right: 2rem;\n}\n\nhtml[dir=\"rtl\"] section.cols > *:first-child {\n  margin-left: 2rem;\n}\n\nsection.cols > *:last-child {\n  flex: 3;\n}\n\n/*\n  Acceptable ads\n */\n\n#tracking-warning {\n  position: relative;\n  margin-bottom: 1rem;\n  padding: 1.5rem;\n  border: 2px solid #ffd7a3;\n  background-color: #fefbe3;\n}\n\n#acceptable-ads:not(.show-warning) #tracking-warning {\n  display: none;\n}\n\n#hide-tracking-warning {\n  position: absolute;\n  top: 0.8rem;\n}\n\nhtml[dir=\"ltr\"] #hide-tracking-warning {\n  left: auto;\n  right: 0.8rem;\n}\n\nhtml[dir=\"rtl\"] #hide-tracking-warning {\n  left: 1rem;\n  right: auto;\n}\n\n#tracking-warning .link {\n  color: inherit;\n  font-weight: 700;\n  text-decoration: underline;\n}\n\n#acceptable-ads ul {\n  position: relative;\n  padding-left: 2.2rem;\n  list-style: none;\n}\n\nhtml[dir=\"rtl\"] #acceptable-ads ul {\n  padding-right: 2.2rem;\n  padding-left: 0rem;\n}\n\n#acceptable-ads ul button,\n#acceptable-ads ul input {\n  position: absolute;\n}\n\nhtml[dir=\"ltr\"] button,\nhtml[dir=\"ltr\"] input {\n  left: 0rem;\n}\n\nhtml[dir=\"rtl\"] button,\nhtml[dir=\"rtl\"] input {\n  right: 0rem;\n}\n\n#acceptable-ads label {\n  font-size: 1rem;\n  font-weight: 700;\n}\n\n#acceptable-ads #acceptable-ads-why-not {\n  --background-color: #fff;\n  --border-color: #099cd0;\n  position: absolute;\n  z-index: 1;\n  width: 260px;\n  margin-top: 15px;\n  padding: 16px;\n  box-sizing: border-box;\n  border: 1px solid var(--border-color);\n  border-radius: var(--border-radius);\n  background-color: var(--background-color);\n  text-align: center;\n}\n\nhtml[dir=\"ltr\"] #acceptable-ads #acceptable-ads-why-not {\n  left: -117px;\n}\n\nhtml[dir=\"rtl\"] #acceptable-ads #acceptable-ads-why-not {\n  right: -117px;\n}\n\n#acceptable-ads #acceptable-ads-why-not::before {\n  display: block;\n  position: absolute;\n  top: -6px;\n  left: calc(50% - 5px);\n  width: 10px;\n  height: 10px;\n  border: 1px solid var(--border-color);\n  border-right: none;\n  border-bottom: none;\n  background-color: var(--background-color);\n  content: \"\";\n  transform: rotate(45deg);\n}\n\n#acceptable-ads #acceptable-ads-why-not > a,\n#acceptable-ads #acceptable-ads-why-not > button {\n  font-size: 0.9rem;\n}\n\n#acceptable-ads #acceptable-ads-why-not > button {\n  position: initial;\n  margin: auto;\n  border: 0;\n  color: #0797e1;\n}\n\nhtml:not([dir=\"rtl\"]) #acceptable-ads label {\n  margin-right: 0.5rem;\n}\n\nhtml[dir=\"rtl\"] #acceptable-ads label {\n  margin-left: 0.5rem;\n}\n\n#dnt {\n  padding: 0.8rem;\n  border: 1px solid #0797e1;\n}\n\n/*\n  Tables\n */\n\nul.table,\nul.list {\n  margin: 0rem;\n  padding: 0rem;\n  list-style: none;\n}\n\n.table li,\n.list li {\n  display: flex;\n  align-items: center;\n}\n\n.table li {\n  margin: 0rem;\n  border-width: 0px 1px 1px;\n  border-style: solid;\n  border-color: #cdcdcd;\n}\n\n.list li {\n  margin-bottom: 0.8rem;\n  padding: 0rem;\n}\n\n.list li [role=\"checkbox\"] {\n  flex-shrink: 0;\n}\n\n.table li:first-of-type {\n  border-top: 1px solid #cdcdcd;\n  border-radius: var(--border-radius) var(--border-radius) 0 0;\n}\n\n.table.list li {\n  margin: 0rem;\n  padding: 0.5rem 1rem;\n}\n\n.table.list.bottom-control li:last-of-type {\n  border-bottom: 0px;\n}\n\n.list li > span {\n  margin: 0rem 1rem;\n}\n\n.table.list li > span {\n  overflow: hidden;\n  margin: 0rem;\n  flex: 1;\n  text-overflow: ellipsis;\n}\n\n#content-allowlist .table.list li > span {\n  white-space: nowrap;\n}\n\n.table.list li[aria-label^=\"https://\"] > span,\n.table.list li[aria-label^=\"data:\"] > span {\n  white-space: initial;\n  word-break: break-all;\n}\n\n.table.list li.empty-placeholder,\n#all-filter-lists-table .empty-placeholder {\n  padding: 1rem 1.4rem;\n}\n\n.table.list li.empty-placeholder:not(:last-of-type) {\n  border-bottom: 0px;\n}\n\n.table.list button.link {\n  font-weight: 700;\n  text-decoration: none;\n  text-transform: uppercase;\n}\n\n.table:not(.list):not(.cols) li {\n  padding-top: 0px;\n  padding-bottom: 6px;\n}\n\n.table li [data-single=\"visible\"],\n.table li:first-of-type:last-of-type [data-single=\"hidden\"] {\n  display: none;\n}\n\n.table li:first-of-type:last-of-type [data-single=\"visible\"] {\n  display: block;\n}\n\n.th {\n  display: flex;\n}\n\n.col5 > * {\n  display: inline-block;\n  vertical-align: middle;\n}\n\n.cols .col5,\n.th .col5 {\n  margin: 0rem 1rem;\n  align-self: center;\n}\n\n.th .col5:nth-of-type(1),\n.table .col5:nth-of-type(1) {\n  flex: 3;\n  text-align: center;\n}\n\n.th .col5:nth-of-type(2),\n.table .col5:nth-of-type(2) {\n  flex: 8;\n}\n\n.table [aria-label^=\"https://\"] .col5:nth-of-type(2),\n.table [aria-label^=\"data:\"] .col5:nth-of-type(2) {\n  word-break: break-all;\n}\n\n.th .col5:nth-of-type(3),\n.table .col5:nth-of-type(3) {\n  flex: 4;\n}\n\n.th .col5:nth-of-type(4),\n.table .col5:nth-of-type(4) {\n  flex: 1;\n}\n\n.th .col5:nth-of-type(5),\n.table .col5:nth-of-type(5) {\n  flex: 1;\n}\n\nhtml:not([dir=\"rtl\"]) .th .col5:nth-of-type(5),\nhtml:not([dir=\"rtl\"]) .table .col5:nth-of-type(5) {\n  margin-right: 1.8rem;\n  margin-left: 0;\n}\n\nhtml[dir=\"rtl\"] .th .col5:nth-of-type(5),\nhtml[dir=\"rtl\"] .table .col5:nth-of-type(5) {\n  margin-right: 0;\n  margin-left: 1.8rem;\n}\n\n.table.cols > span {\n  margin: 0rem;\n}\n\n.table.cols li {\n  padding: 0.5rem 0rem;\n}\n\n.table.cols li.error .col5:nth-of-type(2) {\n  color: var(--color-error);\n  font-style: italic;\n}\n\n.table.cols .toggle {\n  -moz-margin-end: 0.5rem;\n  -webkit-margin-end: 0.5rem;\n}\n\n#dialog .table.list li {\n  display: block;\n  padding: 0rem;\n  border-width: 1px 0px 0px;\n}\n\n#dialog .table.list li:first-of-type {\n  border: 0px;\n}\n\n#dialog .table.list li button {\n  display: flex;\n  width: 100%;\n  height: auto;\n  padding: 1.1rem 1rem;\n  background-image: none;\n}\n\n#dialog .table.list li button:hover,\n#dialog .table.list li button:focus {\n  background-color: #e1f2fa;\n}\n\n#dialog .table.list li button[aria-checked=\"true\"],\n.table.list li .dimmed {\n  color: #bbb;\n}\n\n#dialog .table.list li button > span {\n  margin: 0rem 0.8rem;\n  font-weight: 400;\n  text-transform: none;\n  flex: none;\n}\n\nli.preconfigured [data-hide=\"preconfigured\"] {\n  display: none !important;\n}\n\n/*\n  Tooltips\n*/\n\n.tooltip {\n  position: relative;\n  margin: 0rem;\n  line-height: 1.5rem;\n  text-decoration: none;\n  cursor: help;\n}\n\nhtml:not([dir=\"rtl\"]) .tooltip {\n  margin-right: 1rem;\n}\n\nhtml[dir=\"rtl\"] .tooltip {\n  margin-left: 1rem;\n}\n\n/*\n  General tab content\n*/\n\nsection.recommended-features {\n  display: flex;\n  padding-top: 2rem;\n}\n\nsection.recommended-features > :not(template) {\n  flex: 1;\n  margin-right: 24px;\n}\n\n/* stylelint-disable indentation */\nhtml:not([dir=\"rtl\"])\n  section.recommended-features\n  > :not(template):last-of-type,\nhtml[dir=\"rtl\"] section.recommended-features > :not(template):first-of-type {\n  margin-right: 0;\n}\n/* stylelint-enable indentation */\n\nsection.recommended-features h2 {\n  display: flex;\n  margin-bottom: 1.75rem;\n}\n\nsection.recommended-features .premium.list-header {\n  display: flex;\n  align-items: flex-start;\n}\n\nsection.recommended-features .premium.list-header > * {\n  margin-right: 1.4rem;\n}\n\n/* stylelint-disable indentation */\nhtml:not([dir=\"rtl\"])\n  section.recommended-features\n  .premium.list-header\n  > *:last-child,\nhtml[dir=\"rtl\"]\n  section.recommended-features\n  .premium.list-header\n  > *:first-child {\n  margin-right: 0;\n}\n/* stylelint-enable indentation */\n\nsection.recommended-features .premium.list-header a.button {\n  transform: translateY(-25%);\n}\n\nsection.recommended-features li {\n  align-items: flex-start;\n}\n\nsection.recommended-features .description-container {\n  margin: 0 0.5rem;\n}\n\nsection.recommended-features h3 {\n  display: inline-block;\n  margin: 0;\n  font-size: 1rem;\n}\n\nsection.recommended-features li .label.new {\n  display: none;\n  margin: 0 4px;\n  padding: 0 4px;\n  border-radius: 4px;\n  text-transform: uppercase;\n  font-size: var(--font-size-small);\n  color: #fff;\n  background-color: var(--background-color-info);\n}\n\nsection.recommended-features li.new .label.new {\n  display: inline-block;\n}\n\nsection.recommended-features .description {\n  margin: 0.25rem 0;\n}\n\n#blocking-languages li button[data-single] {\n  padding: 0;\n}\n\n#languages-box {\n  margin-bottom: 0.8rem;\n}\n\nhtml[lang^=\"de\"] #language-recommend,\nhtml[lang^=\"fr\"] #language-recommend,\n/*\n  Hide language recommendation feature for Opera users\n  due to problems with its language detection\n  https://gitlab.com/adblockinc/ext/adblockplus/adblockplus/-/issues/960\n*/\nhtml[data-application=\"opera\"] #language-recommend {\n  display: none;\n}\n\n/*\n  Allowlist tab\n */\n\n#content-allowlist form {\n  display: flex;\n  margin-bottom: 1.4rem;\n}\n\n#content-allowlist form input {\n  padding: 0.5rem 1rem;\n  border: 2px solid #0797e1;\n  border-radius: var(--border-radius);\n  font-size: 1rem;\n  flex: 1;\n}\n\nhtml:not([dir=\"rtl\"]) #content-allowlist form button {\n  margin-left: 0.7rem;\n}\n\nhtml[dir=\"rtl\"] #content-allowlist form button {\n  margin-right: 0.7rem;\n}\n\n#allowlisting-table li {\n  padding-right: 1.4rem;\n  padding-left: 1.4rem;\n  border-right: 0rem;\n  border-left: 0rem;\n}\n\n/*\n  Advanced tab content\n*/\n\n#custom-filters {\n  margin-top: 3rem;\n}\n\n#custom-filters h3 {\n  font-size: 1.125rem;\n  font-weight: 400;\n  text-transform: uppercase;\n}\n\n#custom-filters .io-filter-table-title {\n  font-weight: 600;\n}\n\nhtml:not([dir=\"rtl\"]) #custom-filters .io-filter-table-title {\n  margin-right: 2rem;\n}\n\nhtml[dir=\"rtl\"] #custom-filters .io-filter-table-title {\n  margin-left: 2rem;\n}\n\n#update-all-subscriptions button {\n  display: initial;\n}\n\n#update-all-subscriptions {\n  margin: 2rem auto;\n  text-align: right;\n}\n\nhtml[dir=\"rtl\"] #update-all-subscriptions {\n  text-align: left;\n}\n\n#all-filter-lists-table li.show-message .last-update,\n#all-filter-lists-table li:not(.show-message) .message,\n#all-filter-lists-table li.error .last-update,\n#all-filter-lists-table li:not(.error) io-popout[appearance=\"error\"],\n#acceptable-ads:not(.show-dnt-notification) #dnt {\n  display: none;\n}\n\n#all-filter-lists-table li.show-message .message.error {\n  color: var(--color-error);\n}\n\n#all-filter-lists-table li.show-message .message.error::before {\n  display: inline-block;\n  width: 1em;\n  height: 1em;\n  margin-right: 0.5em;\n  vertical-align: middle;\n  background-image: url(/skin/icons/attention.svg);\n  background-size: contain;\n  content: \"\";\n}\n\nhtml[dir=\"rtl\"] #all-filter-lists-table li.show-message .message.error::before {\n  margin-right: 0;\n  margin-left: 0.5em;\n}\n\n#all-filter-lists-table {\n  margin-bottom: 0.8rem;\n}\n\n/*\n  Help tab content\n*/\n\n#social ul {\n  padding: 0px;\n  list-style: none;\n}\n\n#social ul li {\n  display: inline-block;\n}\n\nhtml:not([dir=\"rtl\"]) #social ul li {\n  margin-right: 1rem;\n}\n\nhtml[dir=\"rtl\"] #social ul li {\n  margin-left: 1rem;\n}\n\n#social ul li a {\n  display: block;\n  text-align: center;\n  text-decoration: none;\n}\n\n/*\n  Extension State Debug Section\n*/\n\n.extension-state-debug dl {\n  display: grid;\n  grid-template-columns: max-content 1fr;\n  gap: 4px 12px;\n  margin: 0;\n}\n\n.extension-state-debug dt {\n  font-weight: 700;\n}\n.extension-state-debug dd {\n  margin: 0;\n}\n\n.extension-state-debug table {\n  width: 100%;\n  border-collapse: collapse;\n  margin-top: 12px;\n}\n\n.extension-state-debug th,\n.extension-state-debug td {\n  padding: 4px 8px;\n  text-align: left;\n  border-bottom: var(--border-width-thin) solid var(--border-color-secondary);\n  vertical-align: top;\n}\n\n.extension-state-debug th:first-child,\n.extension-state-debug td:first-child {\n  padding-left: 0;\n}\n\n.extension-state-debug th {\n  border-bottom-color: var(--border-color-primary);\n}\n\n.extension-state-debug td.num,\n.extension-state-debug th.num {\n  text-align: right;\n}\n\n.extension-state-debug td small {\n  display: block;\n  font-size: var(--font-size-small);\n  color: var(--color-dimmed);\n}\n\n.extension-state-debug button {\n  margin-top: 12px;\n  margin-left: auto;\n}\n\n/*\n  Dialog\n*/\n\n#dialog-background {\n  display: none;\n  position: fixed;\n  z-index: var(--z-dialog);\n  top: 0px;\n  right: 0px;\n  bottom: 0px;\n  left: 0px;\n  opacity: 0.2;\n  background-color: #000;\n}\n\nbody[data-dialog] #dialog-background {\n  display: block;\n}\n\n#dialog {\n  overflow: hidden;\n  position: fixed;\n  z-index: var(--z-dialog);\n  top: 50%;\n  right: 0;\n  left: 0;\n  width: 700px;\n  margin: auto;\n  padding: 20px;\n  border-radius: var(--border-radius);\n  background-color: #fff;\n  box-shadow: 0 -4px 20px 0 rgba(255, 255, 255, 0.11);\n  transform: translateY(-50%);\n}\n\n#dialog-title h3 {\n  margin: 0 0 1.2em;\n  text-transform: uppercase;\n}\n\n#dialog-body {\n  overflow: auto;\n  max-height: 60vh;\n}\n\n#dialog-body h3 {\n  margin: 0 0 0.5em;\n  line-height: 0.9em;\n  font-size: 0.9em;\n}\n\n#dialog-body h3::before {\n  position: absolute;\n  width: 18px;\n  height: 11px;\n  background-size: contain;\n  background-repeat: no-repeat;\n  content: \"\";\n}\n\nhtml[dir=\"ltr\"] #dialog-body h3::before {\n  margin-left: -26px;\n}\n\nhtml[dir=\"rtl\"] #dialog-body h3::before {\n  margin-right: -26px;\n}\n\n#dialog-body .field.title h3::before {\n  background-image: url(/skin/icons/filter-list-title.svg);\n}\n\n#dialog-body .field.url h3::before {\n  background-image: url(/skin/icons/filter-list-url.svg);\n}\n\n#dialog-body p {\n  margin: 0;\n}\n\n#dialog-body .ctas {\n  display: flex;\n  justify-content: end;\n  margin-top: 1.2em;\n}\n\nhtml:not([dir=\"rtl\"]) #dialog-body .ctas > *:not(:last-child),\nhtml[dir=\"rtl\"] #dialog-body .ctas > *:not(:first-child) {\n  margin-right: 1.5em;\n}\n\n#dialog-body .ctas button {\n  min-width: 150px;\n  padding: 0.5em 1em;\n  border: 1px solid var(--border-color-cta-secondary);\n  border-radius: 6px;\n  font-size: var(--font-size-primary);\n  font-weight: 700;\n  color: var(--color-cta-secondary);\n  background-color: var(--background-color-cta-secondary);\n  box-shadow: none;\n  text-transform: capitalize;\n  transition: 100ms background-color;\n  cursor: pointer;\n}\n\n#dialog-body .ctas button:hover {\n  background-color: var(--background-color-cta-secondary-hover);\n}\n\n#dialog-body .ctas button.primary {\n  border-color: var(--border-color-cta-primary);\n  color: var(--color-cta-primary);\n  background-color: var(--background-color-cta-primary);\n  box-shadow: 0 5px 20px rgba(0, 0, 0, 0.15);\n}\n\n#dialog-body .ctas button.primary:hover {\n  background-color: var(--background-color-cta-primary-hover);\n}\n\n#dialog-body .ctas button.primary:disabled {\n  background-color: #5cbce1;\n  cursor: not-allowed;\n}\n\n#dialog-body .ctas button.premium {\n  border-color: var(--color-premium);\n  background-color: var(--color-premium);\n  color: #000;\n}\n\n#dialog-body .ctas button.premium:hover {\n  border-color: var(--color-premium-hover);\n  background-color: var(--color-premium-hover);\n}\n\n#dialog-content-language-add {\n  margin: 0rem;\n}\n\n#dialog-content-about,\n#dialog-content-invalid,\n#filters-box button[role=\"combobox\"] {\n  text-align: center;\n}\n\n#dialog-content-about p {\n  margin: 0.5rem 0rem;\n}\n\n#dialog-content-about .ctas,\n#dialog-content-invalid .ctas {\n  justify-content: center;\n}\n\n#dialog-content-import .side-controls {\n  margin-top: 2.45rem;\n}\n\n#dialog-content-invalid {\n  color: var(--color-error);\n}\n\n#dialog-content-invalid .error {\n  width: 50px;\n  height: 50px;\n  margin: 0 auto 1em;\n  border-radius: 50%;\n  font-size: 25px;\n  font-weight: 600;\n  line-height: 50px;\n  background-color: var(--background-color-error);\n}\n\n#dialog-content-invalid strong {\n  padding: 2px 5px;\n  border-radius: var(--border-radius);\n  font-style: italic;\n  background-color: var(--background-color-error);\n}\n\n#dialog .field {\n  margin-bottom: 1.5em;\n}\n\nhtml[dir=\"ltr\"] #dialog .field {\n  margin-left: 28px;\n}\n\nhtml[dir=\"rtl\"] #dialog .field {\n  margin-right: 28px;\n}\n\n#dialog .field:last-of-type {\n  margin-bottom: 0;\n}\n\n#dialog .table {\n  width: 100%;\n}\n\n#dialog .section:not(:first-child) {\n  margin-top: 24px;\n}\n\n#dialog .url > a {\n  word-wrap: break-word;\n  text-decoration: none;\n}\n\n#dialog .url > a:hover {\n  text-decoration: underline;\n}\n\n#dialog .url > a::after {\n  display: inline-block;\n  width: 0.7em;\n  height: 0.7em;\n  vertical-align: middle;\n  background-image: url(/skin/icons/open-link.svg);\n  background-size: contain;\n  background-repeat: no-repeat;\n  content: \"\";\n}\n\nhtml[dir=\"ltr\"] #dialog .url > a::after {\n  margin-left: 0.3em;\n}\n\nhtml[dir=\"rtl\"] #dialog .url > a::after {\n  margin-right: 0.3em;\n  transform: scaleX(-1);\n}\n\n/* stylelint-disable indentation */\nbody:not([data-dialog=\"about\"]) #dialog-title-about,\nbody:not([data-dialog=\"about\"]) #dialog-content-about,\nbody:not([data-dialog=\"import\"]) #dialog-title-import,\nbody:not([data-dialog=\"import\"]) #dialog-content-import,\nbody:not([data-dialog=\"language-add\"]) #dialog-title-language-add,\nbody:not([data-dialog=\"language-change\"]) #dialog-title-language-change,\nbody:not([data-dialog=\"language-add\"]):not([data-dialog=\"language-change\"])\n  #dialog-content-language-add,\nbody:not([data-dialog=\"language-add\"]) #dialog-body button.add,\nbody:not([data-dialog=\"language-change\"]) #dialog-body button.change,\nbody:not([data-dialog=\"predefined\"]) #dialog-title-predefined,\nbody:not([data-dialog=\"predefined\"]) #dialog-content-predefined,\nbody:not([data-dialog=\"invalid\"]) #dialog-title-invalid,\nbody:not([data-dialog=\"invalid\"]) #dialog-content-invalid,\nbody:not([data-dialog=\"optIn-premium-subscription\"])\n  #dialog-title-optIn-premium-subscription,\nbody:not([data-dialog=\"optIn-premium-subscription\"])\n  #dialog-content-optIn-premium-subscription,\nbody:not([data-dialog]) #dialog {\n  display: none;\n}\n/* stylelint-enable indentation */\n\n/*\n  Notification\n*/\n\n#notification {\n  display: flex;\n  position: fixed;\n  top: 0rem;\n  left: 0rem;\n  box-sizing: border-box;\n  width: 100%;\n  padding: 1rem 1.9rem;\n  font-size: 1rem;\n}\n\n#notification strong {\n  text-align: center;\n  flex: 1;\n}\n\n#notification.info {\n  color: #0797e1;\n  background-color: rgba(225, 242, 250, 0.8);\n}\n\n#notification.error {\n  color: var(--color-error);\n  background-color: rgba(235, 199, 203, 0.8);\n}\n\n#notification.error .close {\n  display: none;\n}\n\n#notification[aria-hidden=\"false\"] {\n  animation: show-notification 3s;\n  will-change: transform;\n}\n\nhtml[data-application=\"firefox\"] #data-collection {\n  /*\n   * We need to temporarily force-disable data collection in Firefox, while\n   * we're working on improving our data collection opt-out mechanism based\n   * on Mozilla's requirements\n   * https://gitlab.com/adblockinc/ext/adblockplus/adblockplus/-/issues/1621\n   */\n  display: none;\n}\n\n@keyframes show-notification {\n  0% {\n    transform: translateY(-4.8rem);\n  }\n\n  25% {\n    transform: translateY(0);\n  }\n\n  75% {\n    transform: translateY(0);\n  }\n\n  100% {\n    transform: translateY(-4.8rem);\n  }\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ 1276
(module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2929);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1287);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/*
 * This file is part of Adblock Plus <https://adblockplus.org/>,
 * Copyright (C) 2006-present eyeo GmbH
 *
 * Adblock Plus is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * Adblock Plus is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
  Unsupported browser banner
  Height = padding-top + line-height + padding-bottom + border
         = 0.75rem + 1.3rem + 0.75rem + 1px
*/

:root {
  --unsupported-banner-height: calc(2.8rem + 1px);
}

#unsupported-browser-banner {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1;
  display: none;
  align-items: center;
  justify-content: center;
  padding: 0.75rem 1.5rem;
  background-color: #f8d7da;
  border-bottom: 1px solid #f5c2c7;
  color: #842029;
  text-align: center;
}

body.unsupported-browser #unsupported-browser-banner {
  display: flex;
}

body.unsupported-browser {
  padding-top: var(--unsupported-banner-height);
}

body.unsupported-browser #sidebar .fixed {
  top: calc(1.2rem + var(--unsupported-banner-height));
}
`, "",{"version":3,"sources":["webpack://./src/desktop-options/ui/unsupported-browser-banner.css"],"names":[],"mappings":"AAAA;;;;;;;;;;;;;;;EAeE;;AAEF;;;;CAIC;;AAED;EACE,+CAA+C;AACjD;;AAEA;EACE,eAAe;EACf,MAAM;EACN,OAAO;EACP,QAAQ;EACR,UAAU;EACV,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,uBAAuB;EACvB,yBAAyB;EACzB,gCAAgC;EAChC,cAAc;EACd,kBAAkB;AACpB;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,6CAA6C;AAC/C;;AAEA;EACE,oDAAoD;AACtD","sourcesContent":["/*\n * This file is part of Adblock Plus <https://adblockplus.org/>,\n * Copyright (C) 2006-present eyeo GmbH\n *\n * Adblock Plus is free software: you can redistribute it and/or modify\n * it under the terms of the GNU General Public License version 3 as\n * published by the Free Software Foundation.\n *\n * Adblock Plus is distributed in the hope that it will be useful,\n * but WITHOUT ANY WARRANTY; without even the implied warranty of\n * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n * GNU General Public License for more details.\n *\n * You should have received a copy of the GNU General Public License\n * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.\n */\n\n/*\n  Unsupported browser banner\n  Height = padding-top + line-height + padding-bottom + border\n         = 0.75rem + 1.3rem + 0.75rem + 1px\n*/\n\n:root {\n  --unsupported-banner-height: calc(2.8rem + 1px);\n}\n\n#unsupported-browser-banner {\n  position: fixed;\n  top: 0;\n  left: 0;\n  right: 0;\n  z-index: 1;\n  display: none;\n  align-items: center;\n  justify-content: center;\n  padding: 0.75rem 1.5rem;\n  background-color: #f8d7da;\n  border-bottom: 1px solid #f5c2c7;\n  color: #842029;\n  text-align: center;\n}\n\nbody.unsupported-browser #unsupported-browser-banner {\n  display: flex;\n}\n\nbody.unsupported-browser {\n  padding-top: var(--unsupported-banner-height);\n}\n\nbody.unsupported-browser #sidebar .fixed {\n  top: calc(1.2rem + var(--unsupported-banner-height));\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ 6716
(module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2929);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1287);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/*
 * This file is part of Adblock Plus <https://adblockplus.org/>,
 * Copyright (C) 2006-present eyeo GmbH
 *
 * Adblock Plus is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * Adblock Plus is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.
 */

io-checkbox {
  display: inline-block;
  width: 1.2rem;
  height: 1.2rem;
  margin: 2px;
  padding: 0px;
  border: 0.2rem solid transparent;
  cursor: pointer;
}

io-checkbox[disabled] {
  cursor: default;
}

io-checkbox > button {
  width: 100%;
  height: 100%;
  margin: 0;
  padding: 0;
  border: 0;
  border-radius: 0;
  background-color: transparent;
  background-image: url(/skin/icons/checkbox.svg?off#off);
  background-repeat: no-repeat;
  background-size: contain;
  cursor: inherit;
}

io-checkbox[disabled] > button {
  outline: none;
  background-image: url(/skin/icons/checkbox.svg?off-disabled#off-disabled);
}

io-checkbox[checked] > button {
  background-image: url(/skin/icons/checkbox.svg?on#on);
}

io-checkbox[disabled][checked] > button {
  background-image: url(/skin/icons/checkbox.svg?on-disabled#on-disabled);
}
`, "",{"version":3,"sources":["webpack://./src/components/ui/io-checkbox.css"],"names":[],"mappings":"AAAA;;;;;;;;;;;;;;;EAeE;;AAEF;EACE,qBAAqB;EACrB,aAAa;EACb,cAAc;EACd,WAAW;EACX,YAAY;EACZ,gCAAgC;EAChC,eAAe;AACjB;;AAEA;EACE,eAAe;AACjB;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,SAAS;EACT,UAAU;EACV,SAAS;EACT,gBAAgB;EAChB,6BAA6B;EAC7B,uDAAuD;EACvD,4BAA4B;EAC5B,wBAAwB;EACxB,eAAe;AACjB;;AAEA;EACE,aAAa;EACb,yEAAyE;AAC3E;;AAEA;EACE,qDAAqD;AACvD;;AAEA;EACE,uEAAuE;AACzE","sourcesContent":["/*\n * This file is part of Adblock Plus <https://adblockplus.org/>,\n * Copyright (C) 2006-present eyeo GmbH\n *\n * Adblock Plus is free software: you can redistribute it and/or modify\n * it under the terms of the GNU General Public License version 3 as\n * published by the Free Software Foundation.\n *\n * Adblock Plus is distributed in the hope that it will be useful,\n * but WITHOUT ANY WARRANTY; without even the implied warranty of\n * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n * GNU General Public License for more details.\n *\n * You should have received a copy of the GNU General Public License\n * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.\n */\n\nio-checkbox {\n  display: inline-block;\n  width: 1.2rem;\n  height: 1.2rem;\n  margin: 2px;\n  padding: 0px;\n  border: 0.2rem solid transparent;\n  cursor: pointer;\n}\n\nio-checkbox[disabled] {\n  cursor: default;\n}\n\nio-checkbox > button {\n  width: 100%;\n  height: 100%;\n  margin: 0;\n  padding: 0;\n  border: 0;\n  border-radius: 0;\n  background-color: transparent;\n  background-image: url(/skin/icons/checkbox.svg?off#off);\n  background-repeat: no-repeat;\n  background-size: contain;\n  cursor: inherit;\n}\n\nio-checkbox[disabled] > button {\n  outline: none;\n  background-image: url(/skin/icons/checkbox.svg?off-disabled#off-disabled);\n}\n\nio-checkbox[checked] > button {\n  background-image: url(/skin/icons/checkbox.svg?on#on);\n}\n\nio-checkbox[disabled][checked] > button {\n  background-image: url(/skin/icons/checkbox.svg?on-disabled#on-disabled);\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ 1556
(module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2929);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1287);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_io_checkbox_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6716);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_io_toggle_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3107);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_io_scrollbar_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7769);
// Imports





var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_io_checkbox_css__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A);
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_io_toggle_css__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A);
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_io_scrollbar_css__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A);
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/*
 * This file is part of Adblock Plus <https://adblockplus.org/>,
 * Copyright (C) 2006-present eyeo GmbH
 *
 * Adblock Plus is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * Adblock Plus is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
  The component depends on its style and it will look for the
  --io-filter-list property to ensure the CSS has been loaded.
  The property is also named like the component on purpose,
  to be sure its an own property, not something inherited.
*/
io-filter-list {
  --io-filter-list: ready;
  width: 100%;
  padding: 0;
  /* used to bootstrap the component once it's visible */
  animation: -io-filter-list 0.001s;
}

/* used to bootstrap the component once it's visible */
@keyframes -io-filter-list {
  from {
    --io-filter-list: #fff;
  }

  to {
    --io-filter-list: #000;
  }
}

io-filter-list,
io-filter-list *,
io-filter-list *::before,
io-filter-list *::after {
  box-sizing: border-box;
}

io-filter-list[disabled] io-checkbox,
io-filter-list[disabled] io-toggle {
  pointer-events: none;
}

io-filter-list table {
  width: 100%;
  border: 1px solid #bcbcbc;
  border-radius: 0 0 var(--border-radius) var(--border-radius);
  color: #505050;
  background-color: #fff;
  user-select: none;
}

io-filter-list thead tr,
io-filter-list td {
  border-bottom: 1px solid #bcbcbc;
}

io-filter-list tr.empty td,
io-filter-list tr:last-child td {
  border-bottom: 0;
}

/* necessary to have scrollable tbody */
io-filter-list thead,
io-filter-list tbody {
  display: block;
}

io-filter-list tr {
  display: flex;
}

io-filter-list tbody {
  overflow: hidden;
  height: 300px;
}

io-filter-list th,
io-filter-list td {
  min-width: 24px;
  padding: 4px 8px;
  text-align: center;
}

io-filter-list th {
  display: flex;
  padding: 8px;
  cursor: pointer;
  transition: background 0.2s ease-in;
  align-items: center;
}

io-filter-list th:not([data-column="rule"]) {
  justify-content: center;
}

io-filter-list th:hover {
  background-color: #f6f6f6;
}

io-filter-list tbody tr {
  height: var(--row-height, auto);
  outline: none;
}

io-filter-list tbody tr.odd.selected,
io-filter-list tbody tr.selected {
  background-color: #f6f6f6;
}

io-filter-list [data-column="rule"] {
  width: var(--rule-width, auto);
  white-space: nowrap;
  flex-grow: 1;
}

io-filter-list [data-column="rule"] .content {
  overflow: hidden;
  height: 100%;
  text-overflow: ellipsis;
  font-family: monospace;
}

io-filter-list [data-column="rule"] .saved {
  animation-name: saved-animation;
  animation-duration: 0.2s;
}

io-filter-list [data-column="rule"] .content:focus {
  text-overflow: initial;
}

io-filter-list tbody tr.editing {
  height: auto;
}

io-filter-list tbody tr.editing [data-column="rule"] {
  overflow: initial;
  white-space: initial;
}

html:not([dir="rtl"]) io-filter-list [data-column="rule"] {
  text-align: left;
}

html[dir="rtl"] io-filter-list [data-column="rule"] {
  text-align: right;
}

/* stylelint-disable indentation */
io-filter-list
  tbody
  tr:not(.empty):not(.editing)
  [data-column="rule"]
  div:hover {
  outline: 1px dashed #d0d0d0;
  cursor: pointer;
}
/* stylelint-enable indentation */

io-filter-list [data-column="status"],
io-filter-list [data-column="selected"],
io-filter-list [data-column="warning"] {
  width: 72px;
}

io-filter-list [data-column="warning"] img {
  width: 1em;
  height: 1em;
}

io-filter-list td[data-column="warning"] img {
  opacity: 0.5;
}

io-filter-list thead th:not([data-column="selected"])::after {
  display: inline-block;
  width: 24px;
  padding: 4px;
  opacity: 0.3;
  font-size: 0.7em;
  line-height: 1rem;
}

io-filter-list thead th:not([data-column="selected"])::after {
  content: "▲";
}

io-filter-list thead[data-dir="desc"] th:not([data-column="selected"])::after {
  content: "▼";
}

io-filter-list thead[data-sort="status"] th[data-column="status"]::after,
io-filter-list thead[data-sort="rule"] th[data-column="rule"]::after,
io-filter-list thead[data-sort="warning"] th[data-column="warning"]::after {
  opacity: 1;
}

io-filter-list table {
  position: relative;
}

io-filter-list io-scrollbar {
  position: absolute;
  top: 46px;
  bottom: 8px;
  opacity: 0;
  transition: opacity 0.2s ease-in;
}

io-filter-list:hover io-scrollbar {
  opacity: 1;
}

html:not([dir="rtl"]) io-filter-list io-scrollbar {
  right: 12px;
}

html[dir="rtl"] io-filter-list io-scrollbar {
  left: 12px;
}

io-filter-list io-toggle {
  margin-top: 2px;
  vertical-align: top;
}

@keyframes saved-animation {
  from {
    background: #bcffbc;
  }

  to {
    background: default;
  }
}
`, "",{"version":3,"sources":["webpack://./src/components/ui/io-filter-list.css"],"names":[],"mappings":"AAAA;;;;;;;;;;;;;;;EAeE;;AAMF;;;;;CAKC;AACD;EACE,uBAAuB;EACvB,WAAW;EACX,UAAU;EACV,sDAAsD;EACtD,iCAAiC;AACnC;;AAEA,sDAAsD;AACtD;EACE;IACE,sBAAsB;EACxB;;EAEA;IACE,sBAAsB;EACxB;AACF;;AAEA;;;;EAIE,sBAAsB;AACxB;;AAEA;;EAEE,oBAAoB;AACtB;;AAEA;EACE,WAAW;EACX,yBAAyB;EACzB,4DAA4D;EAC5D,cAAc;EACd,sBAAsB;EACtB,iBAAiB;AACnB;;AAEA;;EAEE,gCAAgC;AAClC;;AAEA;;EAEE,gBAAgB;AAClB;;AAEA,uCAAuC;AACvC;;EAEE,cAAc;AAChB;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,gBAAgB;EAChB,aAAa;AACf;;AAEA;;EAEE,eAAe;EACf,gBAAgB;EAChB,kBAAkB;AACpB;;AAEA;EACE,aAAa;EACb,YAAY;EACZ,eAAe;EACf,mCAAmC;EACnC,mBAAmB;AACrB;;AAEA;EACE,uBAAuB;AACzB;;AAEA;EACE,yBAAyB;AAC3B;;AAEA;EACE,+BAA+B;EAC/B,aAAa;AACf;;AAEA;;EAEE,yBAAyB;AAC3B;;AAEA;EACE,8BAA8B;EAC9B,mBAAmB;EACnB,YAAY;AACd;;AAEA;EACE,gBAAgB;EAChB,YAAY;EACZ,uBAAuB;EACvB,sBAAsB;AACxB;;AAEA;EACE,+BAA+B;EAC/B,wBAAwB;AAC1B;;AAEA;EACE,sBAAsB;AACxB;;AAEA;EACE,YAAY;AACd;;AAEA;EACE,iBAAiB;EACjB,oBAAoB;AACtB;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,iBAAiB;AACnB;;AAEA,kCAAkC;AAClC;;;;;EAKE,2BAA2B;EAC3B,eAAe;AACjB;AACA,iCAAiC;;AAEjC;;;EAGE,WAAW;AACb;;AAEA;EACE,UAAU;EACV,WAAW;AACb;;AAEA;EACE,YAAY;AACd;;AAEA;EACE,qBAAqB;EACrB,WAAW;EACX,YAAY;EACZ,YAAY;EACZ,gBAAgB;EAChB,iBAAiB;AACnB;;AAEA;EACE,YAAY;AACd;;AAEA;EACE,YAAY;AACd;;AAEA;;;EAGE,UAAU;AACZ;;AAEA;EACE,kBAAkB;AACpB;;AAEA;EACE,kBAAkB;EAClB,SAAS;EACT,WAAW;EACX,UAAU;EACV,gCAAgC;AAClC;;AAEA;EACE,UAAU;AACZ;;AAEA;EACE,WAAW;AACb;;AAEA;EACE,UAAU;AACZ;;AAEA;EACE,eAAe;EACf,mBAAmB;AACrB;;AAEA;EACE;IACE,mBAAmB;EACrB;;EAEA;IACE,mBAAmB;EACrB;AACF","sourcesContent":["/*\n * This file is part of Adblock Plus <https://adblockplus.org/>,\n * Copyright (C) 2006-present eyeo GmbH\n *\n * Adblock Plus is free software: you can redistribute it and/or modify\n * it under the terms of the GNU General Public License version 3 as\n * published by the Free Software Foundation.\n *\n * Adblock Plus is distributed in the hope that it will be useful,\n * but WITHOUT ANY WARRANTY; without even the implied warranty of\n * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n * GNU General Public License for more details.\n *\n * You should have received a copy of the GNU General Public License\n * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.\n */\n\n@import \"./io-checkbox.css\";\n@import \"./io-toggle.css\";\n@import \"./io-scrollbar.css\";\n\n/*\n  The component depends on its style and it will look for the\n  --io-filter-list property to ensure the CSS has been loaded.\n  The property is also named like the component on purpose,\n  to be sure its an own property, not something inherited.\n*/\nio-filter-list {\n  --io-filter-list: ready;\n  width: 100%;\n  padding: 0;\n  /* used to bootstrap the component once it's visible */\n  animation: -io-filter-list 0.001s;\n}\n\n/* used to bootstrap the component once it's visible */\n@keyframes -io-filter-list {\n  from {\n    --io-filter-list: #fff;\n  }\n\n  to {\n    --io-filter-list: #000;\n  }\n}\n\nio-filter-list,\nio-filter-list *,\nio-filter-list *::before,\nio-filter-list *::after {\n  box-sizing: border-box;\n}\n\nio-filter-list[disabled] io-checkbox,\nio-filter-list[disabled] io-toggle {\n  pointer-events: none;\n}\n\nio-filter-list table {\n  width: 100%;\n  border: 1px solid #bcbcbc;\n  border-radius: 0 0 var(--border-radius) var(--border-radius);\n  color: #505050;\n  background-color: #fff;\n  user-select: none;\n}\n\nio-filter-list thead tr,\nio-filter-list td {\n  border-bottom: 1px solid #bcbcbc;\n}\n\nio-filter-list tr.empty td,\nio-filter-list tr:last-child td {\n  border-bottom: 0;\n}\n\n/* necessary to have scrollable tbody */\nio-filter-list thead,\nio-filter-list tbody {\n  display: block;\n}\n\nio-filter-list tr {\n  display: flex;\n}\n\nio-filter-list tbody {\n  overflow: hidden;\n  height: 300px;\n}\n\nio-filter-list th,\nio-filter-list td {\n  min-width: 24px;\n  padding: 4px 8px;\n  text-align: center;\n}\n\nio-filter-list th {\n  display: flex;\n  padding: 8px;\n  cursor: pointer;\n  transition: background 0.2s ease-in;\n  align-items: center;\n}\n\nio-filter-list th:not([data-column=\"rule\"]) {\n  justify-content: center;\n}\n\nio-filter-list th:hover {\n  background-color: #f6f6f6;\n}\n\nio-filter-list tbody tr {\n  height: var(--row-height, auto);\n  outline: none;\n}\n\nio-filter-list tbody tr.odd.selected,\nio-filter-list tbody tr.selected {\n  background-color: #f6f6f6;\n}\n\nio-filter-list [data-column=\"rule\"] {\n  width: var(--rule-width, auto);\n  white-space: nowrap;\n  flex-grow: 1;\n}\n\nio-filter-list [data-column=\"rule\"] .content {\n  overflow: hidden;\n  height: 100%;\n  text-overflow: ellipsis;\n  font-family: monospace;\n}\n\nio-filter-list [data-column=\"rule\"] .saved {\n  animation-name: saved-animation;\n  animation-duration: 0.2s;\n}\n\nio-filter-list [data-column=\"rule\"] .content:focus {\n  text-overflow: initial;\n}\n\nio-filter-list tbody tr.editing {\n  height: auto;\n}\n\nio-filter-list tbody tr.editing [data-column=\"rule\"] {\n  overflow: initial;\n  white-space: initial;\n}\n\nhtml:not([dir=\"rtl\"]) io-filter-list [data-column=\"rule\"] {\n  text-align: left;\n}\n\nhtml[dir=\"rtl\"] io-filter-list [data-column=\"rule\"] {\n  text-align: right;\n}\n\n/* stylelint-disable indentation */\nio-filter-list\n  tbody\n  tr:not(.empty):not(.editing)\n  [data-column=\"rule\"]\n  div:hover {\n  outline: 1px dashed #d0d0d0;\n  cursor: pointer;\n}\n/* stylelint-enable indentation */\n\nio-filter-list [data-column=\"status\"],\nio-filter-list [data-column=\"selected\"],\nio-filter-list [data-column=\"warning\"] {\n  width: 72px;\n}\n\nio-filter-list [data-column=\"warning\"] img {\n  width: 1em;\n  height: 1em;\n}\n\nio-filter-list td[data-column=\"warning\"] img {\n  opacity: 0.5;\n}\n\nio-filter-list thead th:not([data-column=\"selected\"])::after {\n  display: inline-block;\n  width: 24px;\n  padding: 4px;\n  opacity: 0.3;\n  font-size: 0.7em;\n  line-height: 1rem;\n}\n\nio-filter-list thead th:not([data-column=\"selected\"])::after {\n  content: \"▲\";\n}\n\nio-filter-list thead[data-dir=\"desc\"] th:not([data-column=\"selected\"])::after {\n  content: \"▼\";\n}\n\nio-filter-list thead[data-sort=\"status\"] th[data-column=\"status\"]::after,\nio-filter-list thead[data-sort=\"rule\"] th[data-column=\"rule\"]::after,\nio-filter-list thead[data-sort=\"warning\"] th[data-column=\"warning\"]::after {\n  opacity: 1;\n}\n\nio-filter-list table {\n  position: relative;\n}\n\nio-filter-list io-scrollbar {\n  position: absolute;\n  top: 46px;\n  bottom: 8px;\n  opacity: 0;\n  transition: opacity 0.2s ease-in;\n}\n\nio-filter-list:hover io-scrollbar {\n  opacity: 1;\n}\n\nhtml:not([dir=\"rtl\"]) io-filter-list io-scrollbar {\n  right: 12px;\n}\n\nhtml[dir=\"rtl\"] io-filter-list io-scrollbar {\n  left: 12px;\n}\n\nio-filter-list io-toggle {\n  margin-top: 2px;\n  vertical-align: top;\n}\n\n@keyframes saved-animation {\n  from {\n    background: #bcffbc;\n  }\n\n  to {\n    background: default;\n  }\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ 2660
(module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2929);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1287);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/*
 * This file is part of Adblock Plus <https://adblockplus.org/>,
 * Copyright (C) 2006-present eyeo GmbH
 *
 * Adblock Plus is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * Adblock Plus is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.
 */

io-filter-search {
  display: flex;
  flex-direction: row;
  height: 48px;
}

io-filter-search > input {
  padding: 0 8px;
  border: 1px solid #bcbcbc;
  border-radius: var(--border-radius) 0 0 0;
  font-size: inherit;
  flex-grow: 1;
}

html[dir="rtl"] io-filter-search > input {
  border-radius: 0 var(--border-radius) 0 0;
}

io-filter-search > button {
  padding: 0 32px;
  border: 0;
  border-radius: 0 var(--border-radius) 0 0;
  color: #fff;
  background-color: #3a97b9;
  font-weight: 400;
  text-transform: uppercase;
}

html[dir="rtl"] io-filter-search > button {
  border-radius: var(--border-radius) 0 0 0;
}

io-filter-search > button:disabled {
  opacity: 0.7;
}
`, "",{"version":3,"sources":["webpack://./src/components/ui/io-filter-search.css"],"names":[],"mappings":"AAAA;;;;;;;;;;;;;;;EAeE;;AAEF;EACE,aAAa;EACb,mBAAmB;EACnB,YAAY;AACd;;AAEA;EACE,cAAc;EACd,yBAAyB;EACzB,yCAAyC;EACzC,kBAAkB;EAClB,YAAY;AACd;;AAEA;EACE,yCAAyC;AAC3C;;AAEA;EACE,eAAe;EACf,SAAS;EACT,yCAAyC;EACzC,WAAW;EACX,yBAAyB;EACzB,gBAAgB;EAChB,yBAAyB;AAC3B;;AAEA;EACE,yCAAyC;AAC3C;;AAEA;EACE,YAAY;AACd","sourcesContent":["/*\n * This file is part of Adblock Plus <https://adblockplus.org/>,\n * Copyright (C) 2006-present eyeo GmbH\n *\n * Adblock Plus is free software: you can redistribute it and/or modify\n * it under the terms of the GNU General Public License version 3 as\n * published by the Free Software Foundation.\n *\n * Adblock Plus is distributed in the hope that it will be useful,\n * but WITHOUT ANY WARRANTY; without even the implied warranty of\n * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n * GNU General Public License for more details.\n *\n * You should have received a copy of the GNU General Public License\n * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.\n */\n\nio-filter-search {\n  display: flex;\n  flex-direction: row;\n  height: 48px;\n}\n\nio-filter-search > input {\n  padding: 0 8px;\n  border: 1px solid #bcbcbc;\n  border-radius: var(--border-radius) 0 0 0;\n  font-size: inherit;\n  flex-grow: 1;\n}\n\nhtml[dir=\"rtl\"] io-filter-search > input {\n  border-radius: 0 var(--border-radius) 0 0;\n}\n\nio-filter-search > button {\n  padding: 0 32px;\n  border: 0;\n  border-radius: 0 var(--border-radius) 0 0;\n  color: #fff;\n  background-color: #3a97b9;\n  font-weight: 400;\n  text-transform: uppercase;\n}\n\nhtml[dir=\"rtl\"] io-filter-search > button {\n  border-radius: var(--border-radius) 0 0 0;\n}\n\nio-filter-search > button:disabled {\n  opacity: 0.7;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ 7702
(module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2929);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1287);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_theme_ui_light_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4341);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_io_filter_search_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2660);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_io_filter_list_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1556);
// Imports





var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_theme_ui_light_css__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A);
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_io_filter_search_css__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A);
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_io_filter_list_css__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A);
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/*
 * This file is part of Adblock Plus <https://adblockplus.org/>,
 * Copyright (C) 2006-present eyeo GmbH
 *
 * Adblock Plus is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * Adblock Plus is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.
 */

io-filter-table {
  display: flex;
  flex-direction: column;
}

io-filter-table[disabled] {
  opacity: 0.6;
}

io-filter-table > io-filter-search {
  z-index: 1;
}

io-filter-table > io-filter-search > input {
  padding-right: 24px;
  padding-left: 24px;
}

io-filter-table > io-filter-list > table {
  border-top: 0;
}

io-filter-table .footer {
  display: flex;
  flex-direction: row;
  margin-top: 16px;
  align-items: center;
}

io-filter-table .footer > * {
  font-weight: 700;
}

io-filter-table .footer button {
  padding: 4px;
  text-transform: uppercase;
}

io-filter-table .footer button[disabled] {
  display: none;
}

io-filter-table .footer button:not(:first-child) {
  margin: auto 16px;
}

io-filter-table .footer .delete {
  border: 2px solid var(--color-brand-primary);
  color: var(--color-brand-primary);
}

io-filter-table .footer .copy {
  border: 2px solid #337ba2;
  color: #337ba2;
}

io-filter-table .footer button::before {
  display: inline-block;
  width: 1em;
  height: 1em;
  background-repeat: no-repeat;
  background-size: contain;
  content: "";
  transform: translateY(0.1em);
}

io-filter-table .footer .delete::before {
  background-image: url(/skin/icons/trash.svg?error#error);
}

io-filter-table .footer .copy::before {
  background-image: url(/skin/icons/copy.svg);
}

io-filter-table .footer ul.error {
  border: 0;
  padding: 0;
  color: var(--color-error);
  text-transform: none;
  flex-grow: 1;
  line-height: 1.9rem;
  list-style: none;
}

io-filter-table .footer ul.error li {
  padding: var(--padding-secondary) var(--padding-primary);
  margin-bottom: var(--margin-secondary);
  border-radius: 4px;
  background-color: #ed1e4526;
}

io-filter-table .footer .error strong {
  border: 1px dashed #bcbcbc;
  border-radius: 5px;
  padding: 5px;
  background-color: #f3f3f3;
  color: #000;
  font-family: monospace;
}

html:not([dir="rtl"]) io-filter-table .footer .delete::before,
html:not([dir="rtl"]) io-filter-table .footer .copy::before {
  margin-right: 4px;
}

html[dir="rtl"] io-filter-table .footer .delete::before,
html[dir="rtl"] io-filter-table .footer .copy::before {
  margin-left: 4px;
}
`, "",{"version":3,"sources":["webpack://./src/components/ui/io-filter-table.css"],"names":[],"mappings":"AAAA;;;;;;;;;;;;;;;EAeE;;AAMF;EACE,aAAa;EACb,sBAAsB;AACxB;;AAEA;EACE,YAAY;AACd;;AAEA;EACE,UAAU;AACZ;;AAEA;EACE,mBAAmB;EACnB,kBAAkB;AACpB;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,gBAAgB;EAChB,mBAAmB;AACrB;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,YAAY;EACZ,yBAAyB;AAC3B;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,4CAA4C;EAC5C,iCAAiC;AACnC;;AAEA;EACE,yBAAyB;EACzB,cAAc;AAChB;;AAEA;EACE,qBAAqB;EACrB,UAAU;EACV,WAAW;EACX,4BAA4B;EAC5B,wBAAwB;EACxB,WAAW;EACX,4BAA4B;AAC9B;;AAEA;EACE,wDAAwD;AAC1D;;AAEA;EACE,2CAA2C;AAC7C;;AAEA;EACE,SAAS;EACT,UAAU;EACV,yBAAyB;EACzB,oBAAoB;EACpB,YAAY;EACZ,mBAAmB;EACnB,gBAAgB;AAClB;;AAEA;EACE,wDAAwD;EACxD,sCAAsC;EACtC,kBAAkB;EAClB,2BAA2B;AAC7B;;AAEA;EACE,0BAA0B;EAC1B,kBAAkB;EAClB,YAAY;EACZ,yBAAyB;EACzB,WAAW;EACX,sBAAsB;AACxB;;AAEA;;EAEE,iBAAiB;AACnB;;AAEA;;EAEE,gBAAgB;AAClB","sourcesContent":["/*\n * This file is part of Adblock Plus <https://adblockplus.org/>,\n * Copyright (C) 2006-present eyeo GmbH\n *\n * Adblock Plus is free software: you can redistribute it and/or modify\n * it under the terms of the GNU General Public License version 3 as\n * published by the Free Software Foundation.\n *\n * Adblock Plus is distributed in the hope that it will be useful,\n * but WITHOUT ANY WARRANTY; without even the implied warranty of\n * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n * GNU General Public License for more details.\n *\n * You should have received a copy of the GNU General Public License\n * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.\n */\n\n@import \"../../theme/ui/light.css\";\n@import \"./io-filter-search.css\";\n@import \"./io-filter-list.css\";\n\nio-filter-table {\n  display: flex;\n  flex-direction: column;\n}\n\nio-filter-table[disabled] {\n  opacity: 0.6;\n}\n\nio-filter-table > io-filter-search {\n  z-index: 1;\n}\n\nio-filter-table > io-filter-search > input {\n  padding-right: 24px;\n  padding-left: 24px;\n}\n\nio-filter-table > io-filter-list > table {\n  border-top: 0;\n}\n\nio-filter-table .footer {\n  display: flex;\n  flex-direction: row;\n  margin-top: 16px;\n  align-items: center;\n}\n\nio-filter-table .footer > * {\n  font-weight: 700;\n}\n\nio-filter-table .footer button {\n  padding: 4px;\n  text-transform: uppercase;\n}\n\nio-filter-table .footer button[disabled] {\n  display: none;\n}\n\nio-filter-table .footer button:not(:first-child) {\n  margin: auto 16px;\n}\n\nio-filter-table .footer .delete {\n  border: 2px solid var(--color-brand-primary);\n  color: var(--color-brand-primary);\n}\n\nio-filter-table .footer .copy {\n  border: 2px solid #337ba2;\n  color: #337ba2;\n}\n\nio-filter-table .footer button::before {\n  display: inline-block;\n  width: 1em;\n  height: 1em;\n  background-repeat: no-repeat;\n  background-size: contain;\n  content: \"\";\n  transform: translateY(0.1em);\n}\n\nio-filter-table .footer .delete::before {\n  background-image: url(/skin/icons/trash.svg?error#error);\n}\n\nio-filter-table .footer .copy::before {\n  background-image: url(/skin/icons/copy.svg);\n}\n\nio-filter-table .footer ul.error {\n  border: 0;\n  padding: 0;\n  color: var(--color-error);\n  text-transform: none;\n  flex-grow: 1;\n  line-height: 1.9rem;\n  list-style: none;\n}\n\nio-filter-table .footer ul.error li {\n  padding: var(--padding-secondary) var(--padding-primary);\n  margin-bottom: var(--margin-secondary);\n  border-radius: 4px;\n  background-color: #ed1e4526;\n}\n\nio-filter-table .footer .error strong {\n  border: 1px dashed #bcbcbc;\n  border-radius: 5px;\n  padding: 5px;\n  background-color: #f3f3f3;\n  color: #000;\n  font-family: monospace;\n}\n\nhtml:not([dir=\"rtl\"]) io-filter-table .footer .delete::before,\nhtml:not([dir=\"rtl\"]) io-filter-table .footer .copy::before {\n  margin-right: 4px;\n}\n\nhtml[dir=\"rtl\"] io-filter-table .footer .delete::before,\nhtml[dir=\"rtl\"] io-filter-table .footer .copy::before {\n  margin-left: 4px;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ 7783
(module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2929);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1287);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_theme_ui_z_index_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9956);
// Imports



var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_theme_ui_z_index_css__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A);
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/*
 * This file is part of Adblock Plus <https://adblockplus.org/>,
 * Copyright (C) 2006-present eyeo GmbH
 *
 * Adblock Plus is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * Adblock Plus is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.
 */

io-list-box {
  display: block;
  position: relative;
  box-sizing: border-box;
}

body:not(.premium) io-list-box [role="option"].premium {
  display: none;
}

io-list-box,
io-list-box button,
io-list-box [role="listbox"],
io-list-box [role="option"],
io-list-box .group {
  margin: 0;
  padding: 0;
  color: #4a4a4a;
  background: #fff;
  font-family: inherit;
  font-size: inherit;
  text-align: inherit;
}

io-list-box button,
io-list-box [role="listbox"] {
  box-sizing: inherit;
  width: var(--width, 100%);
  border: 1px solid #bcbcbc;
  cursor: pointer;
}

io-list-box .group,
io-list-box [role="option"] {
  padding: 0.6rem 32px;
}

io-list-box button {
  padding: 0.6rem 0.8rem;
  border: 1px solid #bcbcbc;
  border-radius: 0 0 var(--border-radius) var(--border-radius);
}

io-list-box button[aria-expanded="false"] {
  color: #0797e1;
  background: #e9f6fc;
  text-transform: uppercase;
}

io-list-box[detached] button[aria-expanded="false"] {
  border-radius: var(--border-radius);
}

io-list-box button:focus {
  outline: none;
}

io-list-box [role="listbox"] {
  overflow: auto;
  position: absolute;
  z-index: var(--z-popout-active);
  bottom: 2.2em;
  max-height: 290px;
  border-radius: var(--border-radius) var(--border-radius) 0 0;
  box-shadow: 0 -4px 20px 0 rgba(0, 0, 0, 0.11);
}

io-list-box [role="option"].hover {
  background: #e1f2fa;
}

io-list-box .group,
io-list-box [role="option"][aria-disabled="true"],
io-list-box [role="option"][aria-disabled="true"].hover {
  background-color: #eee;
  cursor: default;
}

io-list-box [role="option"][aria-selected="true"] {
  background-image: url(/skin/icons/checkmark.svg?default#default);
  background-repeat: no-repeat;
  background-position: 8px center;
  background-size: 20px 20px;
}

io-list-box [role="combobox"] {
  z-index: 1;
}

html[dir="rtl"] io-list-box [role="option"][aria-selected="true"] {
  background-position: calc(100% - 8px) center;
}

io-list-box .group {
  font-weight: 600;
  text-transform: uppercase;
}
`, "",{"version":3,"sources":["webpack://./src/components/ui/io-list-box.css"],"names":[],"mappings":"AAAA;;;;;;;;;;;;;;;EAeE;;AAIF;EACE,cAAc;EACd,kBAAkB;EAClB,sBAAsB;AACxB;;AAEA;EACE,aAAa;AACf;;AAEA;;;;;EAKE,SAAS;EACT,UAAU;EACV,cAAc;EACd,gBAAgB;EAChB,oBAAoB;EACpB,kBAAkB;EAClB,mBAAmB;AACrB;;AAEA;;EAEE,mBAAmB;EACnB,yBAAyB;EACzB,yBAAyB;EACzB,eAAe;AACjB;;AAEA;;EAEE,oBAAoB;AACtB;;AAEA;EACE,sBAAsB;EACtB,yBAAyB;EACzB,4DAA4D;AAC9D;;AAEA;EACE,cAAc;EACd,mBAAmB;EACnB,yBAAyB;AAC3B;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,cAAc;EACd,kBAAkB;EAClB,+BAA+B;EAC/B,aAAa;EACb,iBAAiB;EACjB,4DAA4D;EAC5D,6CAA6C;AAC/C;;AAEA;EACE,mBAAmB;AACrB;;AAEA;;;EAGE,sBAAsB;EACtB,eAAe;AACjB;;AAEA;EACE,gEAAgE;EAChE,4BAA4B;EAC5B,+BAA+B;EAC/B,0BAA0B;AAC5B;;AAEA;EACE,UAAU;AACZ;;AAEA;EACE,4CAA4C;AAC9C;;AAEA;EACE,gBAAgB;EAChB,yBAAyB;AAC3B","sourcesContent":["/*\n * This file is part of Adblock Plus <https://adblockplus.org/>,\n * Copyright (C) 2006-present eyeo GmbH\n *\n * Adblock Plus is free software: you can redistribute it and/or modify\n * it under the terms of the GNU General Public License version 3 as\n * published by the Free Software Foundation.\n *\n * Adblock Plus is distributed in the hope that it will be useful,\n * but WITHOUT ANY WARRANTY; without even the implied warranty of\n * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n * GNU General Public License for more details.\n *\n * You should have received a copy of the GNU General Public License\n * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.\n */\n\n@import \"../../theme/ui/z-index.css\";\n\nio-list-box {\n  display: block;\n  position: relative;\n  box-sizing: border-box;\n}\n\nbody:not(.premium) io-list-box [role=\"option\"].premium {\n  display: none;\n}\n\nio-list-box,\nio-list-box button,\nio-list-box [role=\"listbox\"],\nio-list-box [role=\"option\"],\nio-list-box .group {\n  margin: 0;\n  padding: 0;\n  color: #4a4a4a;\n  background: #fff;\n  font-family: inherit;\n  font-size: inherit;\n  text-align: inherit;\n}\n\nio-list-box button,\nio-list-box [role=\"listbox\"] {\n  box-sizing: inherit;\n  width: var(--width, 100%);\n  border: 1px solid #bcbcbc;\n  cursor: pointer;\n}\n\nio-list-box .group,\nio-list-box [role=\"option\"] {\n  padding: 0.6rem 32px;\n}\n\nio-list-box button {\n  padding: 0.6rem 0.8rem;\n  border: 1px solid #bcbcbc;\n  border-radius: 0 0 var(--border-radius) var(--border-radius);\n}\n\nio-list-box button[aria-expanded=\"false\"] {\n  color: #0797e1;\n  background: #e9f6fc;\n  text-transform: uppercase;\n}\n\nio-list-box[detached] button[aria-expanded=\"false\"] {\n  border-radius: var(--border-radius);\n}\n\nio-list-box button:focus {\n  outline: none;\n}\n\nio-list-box [role=\"listbox\"] {\n  overflow: auto;\n  position: absolute;\n  z-index: var(--z-popout-active);\n  bottom: 2.2em;\n  max-height: 290px;\n  border-radius: var(--border-radius) var(--border-radius) 0 0;\n  box-shadow: 0 -4px 20px 0 rgba(0, 0, 0, 0.11);\n}\n\nio-list-box [role=\"option\"].hover {\n  background: #e1f2fa;\n}\n\nio-list-box .group,\nio-list-box [role=\"option\"][aria-disabled=\"true\"],\nio-list-box [role=\"option\"][aria-disabled=\"true\"].hover {\n  background-color: #eee;\n  cursor: default;\n}\n\nio-list-box [role=\"option\"][aria-selected=\"true\"] {\n  background-image: url(/skin/icons/checkmark.svg?default#default);\n  background-repeat: no-repeat;\n  background-position: 8px center;\n  background-size: 20px 20px;\n}\n\nio-list-box [role=\"combobox\"] {\n  z-index: 1;\n}\n\nhtml[dir=\"rtl\"] io-list-box [role=\"option\"][aria-selected=\"true\"] {\n  background-position: calc(100% - 8px) center;\n}\n\nio-list-box .group {\n  font-weight: 600;\n  text-transform: uppercase;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ 1254
(module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2929);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1287);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/*
 * This file is part of Adblock Plus <https://adblockplus.org/>,
 * Copyright (C) 2006-present eyeo GmbH
 *
 * Adblock Plus is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * Adblock Plus is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.
 */

io-popout ul {
  padding: 0;
}

io-popout li {
  list-style: none;
}

.table.cols io-popout li {
  padding: 0;
  border: 0;
}

.table.cols io-popout[type="menubar"] li > * {
  display: flex;
  width: 100%;
  padding: 0.7rem 0rem;
  border: 0rem;
  color: #0797e1;
  font-size: 1rem;
  font-weight: 400;
  text-decoration: none;
  text-transform: none;
  align-items: center;
}

io-popout[type="menubar"] li > *:hover,
io-popout[type="menubar"] li > *:focus {
  background-color: #e1f2fa;
  cursor: pointer;
}

io-popout li .icon::before {
  width: var(--icon-size-inner);
  height: var(--icon-size-inner);
  margin: 0 var(--icon-size-inner);
  border: none;
}
`, "",{"version":3,"sources":["webpack://./src/components/ui/io-popout-fixes.css"],"names":[],"mappings":"AAAA;;;;;;;;;;;;;;;EAeE;;AAEF;EACE,UAAU;AACZ;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,UAAU;EACV,SAAS;AACX;;AAEA;EACE,aAAa;EACb,WAAW;EACX,oBAAoB;EACpB,YAAY;EACZ,cAAc;EACd,eAAe;EACf,gBAAgB;EAChB,qBAAqB;EACrB,oBAAoB;EACpB,mBAAmB;AACrB;;AAEA;;EAEE,yBAAyB;EACzB,eAAe;AACjB;;AAEA;EACE,6BAA6B;EAC7B,8BAA8B;EAC9B,gCAAgC;EAChC,YAAY;AACd","sourcesContent":["/*\n * This file is part of Adblock Plus <https://adblockplus.org/>,\n * Copyright (C) 2006-present eyeo GmbH\n *\n * Adblock Plus is free software: you can redistribute it and/or modify\n * it under the terms of the GNU General Public License version 3 as\n * published by the Free Software Foundation.\n *\n * Adblock Plus is distributed in the hope that it will be useful,\n * but WITHOUT ANY WARRANTY; without even the implied warranty of\n * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n * GNU General Public License for more details.\n *\n * You should have received a copy of the GNU General Public License\n * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.\n */\n\nio-popout ul {\n  padding: 0;\n}\n\nio-popout li {\n  list-style: none;\n}\n\n.table.cols io-popout li {\n  padding: 0;\n  border: 0;\n}\n\n.table.cols io-popout[type=\"menubar\"] li > * {\n  display: flex;\n  width: 100%;\n  padding: 0.7rem 0rem;\n  border: 0rem;\n  color: #0797e1;\n  font-size: 1rem;\n  font-weight: 400;\n  text-decoration: none;\n  text-transform: none;\n  align-items: center;\n}\n\nio-popout[type=\"menubar\"] li > *:hover,\nio-popout[type=\"menubar\"] li > *:focus {\n  background-color: #e1f2fa;\n  cursor: pointer;\n}\n\nio-popout li .icon::before {\n  width: var(--icon-size-inner);\n  height: var(--icon-size-inner);\n  margin: 0 var(--icon-size-inner);\n  border: none;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ 6708
(module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2929);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1287);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_theme_ui_z_index_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9956);
// Imports



var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_theme_ui_z_index_css__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A);
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/*
 * This file is part of Adblock Plus <https://adblockplus.org/>,
 * Copyright (C) 2006-present eyeo GmbH
 *
 * Adblock Plus is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * Adblock Plus is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.
 */

io-popout {
  --background-color: #fff;
  --border-color: #0797e1;
  --border: 1px solid var(--border-color);
  --horizontal-padding: 1rem;
  --icon-margin: 0.4rem;
  --icon-size-inner: 1rem;
  --icon-size-outer: calc(var(--icon-size-inner) + var(--icon-margin));
  --pointer-size: 10px;
  --pointer-offset-out: calc(var(--pointer-size) / -2 - 1px);
  --pointer-offset-start: calc(
    var(--icon-size-outer) + var(--pointer-offset-out)
  );
  --content-offset-out: calc(-0.5 * var(--icon-size-outer));
  --content-offset-start: calc(var(--icon-size-outer) + 2 * var(--icon-margin));
}

io-popout[type="dialog"] {
  --icon-size-inner: 3rem;
}

/*
 * This component is not keyboard-accessible yet but we need it to be focusable
 * to detect when we can close it
 */
io-popout:focus {
  outline: none;
}

/* Prevent pre-rendered content to show up before component has loaded */
io-popout > :not(.wrapper) {
  display: none;
}

/*******************************************************************************
 * Z-Index
 ******************************************************************************/

/*
 * z-index on custom elements seem to be ignored, so that
 * this extra z-index for io-popout > .wrapper is needed to avoid issues
 */
io-popout,
io-popout > .wrapper {
  z-index: var(--z-popout);
}

/* Ensures that expanded popouts are always shown on top of other popouts */
io-popout[expanded],
io-popout[expanded] > .wrapper {
  /*
   * We can't use calc() for setting the z-index yet because support for it was
   * only added in Firefox 57. Therefore we have to hardcode its value for now.
   * https://developer.mozilla.org/en-US/docs/Mozilla/Firefox/Releases/57#Quantum_CSS_notes
   */
  z-index: var(--z-popout-active);
}

/*
 * We need to ensure that any content overlays the anchor pointer or otherwise
 * its inner half becomes visible when the content's background color changes
 */
io-popout > .wrapper > [role] * {
  z-index: 1;
}

/*******************************************************************************
 * Anchor
 ******************************************************************************/

io-popout > .wrapper {
  display: inline-block;
  position: relative;
  vertical-align: middle;
}

io-popout > .wrapper::before {
  width: var(--icon-size-inner);
  height: var(--icon-size-inner);
  cursor: pointer;
}

io-popout[anchor-icon="heart"] > .wrapper::before {
  border-radius: 50%;
  background-color: #0797e1;
  background-repeat: no-repeat;
  background-size: 40%;
  background-position: center;
  box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
  transition:
    background-color 100ms,
    box-shadow 100ms;
}

io-popout[anchor-icon="heart"][expanded] > .wrapper::before {
  background-color: #4a4a4a;
  box-shadow: none;
  animation-name: tap;
  animation-duration: 500ms;
}

io-popout[type="menubar"] > .wrapper::before {
  background-image: url(/skin/icons/gear.svg?default#default);
}

io-popout[type="tooltip"] > .wrapper::before {
  background-image: url(/skin/icons/tooltip.svg);
}

io-popout[anchor-icon="heart"] > .wrapper::before {
  background-image: url(/skin/icons/heart.svg);
}

io-popout[anchor-icon="error"] > .wrapper::before {
  background-image: url(/skin/icons/error-round.svg);
}

/*******************************************************************************
 * Anchor pointer
 ******************************************************************************/

io-popout > .wrapper > [role]::before {
  display: block;
  position: absolute;
  width: var(--pointer-size);
  height: var(--pointer-size);
  border: var(--border);
  border-right: none;
  border-bottom: none;
  background-color: var(--background-color);
  content: "";
}

io-popout:not([expanded]) > .wrapper > [role]::before,
io-popout[expanded="above"] > .wrapper > [role]::before,
io-popout[expanded="below"] > .wrapper > [role]::before {
  right: var(--pointer-offset-start);
}

html[dir="rtl"] io-popout:not([expanded]) > .wrapper > [role]::before,
html[dir="rtl"] io-popout[expanded="above"] > .wrapper > [role]::before,
html[dir="rtl"] io-popout[expanded="below"] > .wrapper > [role]::before {
  right: auto;
  left: var(--pointer-offset-start);
}

io-popout:not([expanded]) > .wrapper > [role]::before,
io-popout[expanded="below"] > .wrapper > [role]::before {
  top: var(--pointer-offset-out);
  transform: rotate(45deg);
}

io-popout[expanded="above"] > .wrapper > [role]::before {
  bottom: var(--pointer-offset-out);
  transform: rotate(-135deg);
}

io-popout[expanded="start"] > .wrapper > [role]::before {
  top: var(--pointer-offset-start);
  right: var(--pointer-offset-out);
  transform: rotate(135deg);
}

html[dir="rtl"] io-popout[expanded="start"] > .wrapper > [role]::before {
  right: auto;
  left: var(--pointer-offset-out);
  transform: rotate(-45deg);
}

/*******************************************************************************
 * Content
 ******************************************************************************/

io-popout > .wrapper > [role] {
  position: absolute;
  box-sizing: border-box;
  border: var(--border);
  border-radius: var(--border-radius);
  background-color: var(--background-color);
  box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
  cursor: default;
}

io-popout [aria-hidden="true"] {
  display: none;
}

io-popout:not([expanded]) > .wrapper > [role],
io-popout[expanded="above"] > .wrapper > [role],
io-popout[expanded="below"] > .wrapper > [role] {
  right: var(--content-offset-out);
}

html[dir="rtl"] io-popout:not([expanded]) > .wrapper > [role],
html[dir="rtl"] io-popout[expanded="above"] > .wrapper > [role],
html[dir="rtl"] io-popout[expanded="below"] > .wrapper > [role] {
  right: auto;
  left: var(--content-offset-out);
}

io-popout:not([expanded]) > .wrapper > [role],
io-popout[expanded="below"] > .wrapper > [role] {
  top: var(--content-offset-start);
}

io-popout[expanded="above"] > .wrapper > [role] {
  bottom: var(--content-offset-start);
}

io-popout[expanded="start"] > .wrapper > [role] {
  top: var(--content-offset-out);
  right: var(--content-offset-start);
}

html[dir="rtl"] io-popout[expanded="start"] > .wrapper > [role] {
  right: auto;
  left: var(--content-offset-start);
}

io-popout > .wrapper > [role="dialog"] {
  width: 12rem;
  padding: 20px;
}

io-popout > .wrapper > [role="menubar"] {
  width: 12.2rem;
}

io-popout > .wrapper > [role="tooltip"] {
  width: 15rem;
}

io-popout .close {
  position: absolute;
  top: 10px;
}

io-popout .close:focus {
  outline: none;
}

io-popout p {
  padding: 0.2rem var(--horizontal-padding);
}

io-popout [role="dialog"] p {
  padding: 1em 0;
  margin: 0;
  font-size: 0.9em;
}

io-popout [role="tooltip"] p {
  overflow-y: auto;
  /* Approximated to achieve a total tooltip height of 12.5em without
  hiding overflowing anchor pointer */
  max-height: 9em;
  line-height: 1.5rem;
}

html[dir="ltr"] io-popout button.close {
  right: 10px;
  left: auto;
}

html[dir="rtl"] io-popout button.close {
  right: auto;
  left: 10px;
}

io-popout .close + * {
  margin-top: 2em;
}

html[dir="ltr"] io-popout button.close {
  right: 10px;
  left: auto;
}

html[dir="rtl"] io-popout button.close {
  right: auto;
  left: 10px;
}

/*******************************************************************************
 * Appearance variants
 ******************************************************************************/

io-popout[appearance="error"] .icon.close::before {
  background-image: url(/skin/icons/close.svg?error#error);
}

io-popout[appearance="error"] .icon.close:hover::before {
  background-image: url(/skin/icons/close.svg?error-hover#error-hover);
}

io-popout[appearance="error"] {
  --border-color: var(--color-error);
}

io-popout[appearance="error"] ul {
  padding: 0 var(--horizontal-padding);
  margin-bottom: 1rem;
}

io-popout[appearance="error"] .error-list li {
  --border-size: 4px;
  --border: var(--border-size) solid var(--background-color-error);
  --padding: calc(var(--horizontal-padding) - var(--border-size));
  display: block;
  border-radius: 0;
  margin: 0.8rem 0;
  color: var(--color-error);
}

html:not([dir="rtl"]) io-popout[appearance="error"] .error-list li {
  border-left: var(--border);
  padding-left: var(--padding);
}

html[dir="rtl"] io-popout[appearance="error"] .error-list li {
  border-right: var(--border);
  padding-right: var(--padding);
}

io-popout[appearance="error"] .error-list li a {
  display: block;
  color: inherit;
  font-weight: 600;
  text-decoration: underline;
  cursor: pointer;
}

/*******************************************************************************
 * Animations
 ******************************************************************************/

@keyframes tap {
  0% {
    background-position: center;
    background-size: 40%;
  }

  20% {
    background-position: center 40%;
    background-size: 50%;
  }

  100% {
    background-position: center;
    background-size: 40%;
  }
}
`, "",{"version":3,"sources":["webpack://./src/components/ui/io-popout.css"],"names":[],"mappings":"AAAA;;;;;;;;;;;;;;;EAeE;;AAIF;EACE,wBAAwB;EACxB,uBAAuB;EACvB,uCAAuC;EACvC,0BAA0B;EAC1B,qBAAqB;EACrB,uBAAuB;EACvB,oEAAoE;EACpE,oBAAoB;EACpB,0DAA0D;EAC1D;;GAEC;EACD,yDAAyD;EACzD,6EAA6E;AAC/E;;AAEA;EACE,uBAAuB;AACzB;;AAEA;;;EAGE;AACF;EACE,aAAa;AACf;;AAEA,wEAAwE;AACxE;EACE,aAAa;AACf;;AAEA;;+EAE+E;;AAE/E;;;EAGE;AACF;;EAEE,wBAAwB;AAC1B;;AAEA,2EAA2E;AAC3E;;EAEE;;;;IAIE;EACF,+BAA+B;AACjC;;AAEA;;;EAGE;AACF;EACE,UAAU;AACZ;;AAEA;;+EAE+E;;AAE/E;EACE,qBAAqB;EACrB,kBAAkB;EAClB,sBAAsB;AACxB;;AAEA;EACE,6BAA6B;EAC7B,8BAA8B;EAC9B,eAAe;AACjB;;AAEA;EACE,kBAAkB;EAClB,yBAAyB;EACzB,4BAA4B;EAC5B,oBAAoB;EACpB,2BAA2B;EAC3B,yCAAyC;EACzC;;oBAEkB;AACpB;;AAEA;EACE,yBAAyB;EACzB,gBAAgB;EAChB,mBAAmB;EACnB,yBAAyB;AAC3B;;AAEA;EACE,2DAA2D;AAC7D;;AAEA;EACE,8CAA8C;AAChD;;AAEA;EACE,4CAA4C;AAC9C;;AAEA;EACE,kDAAkD;AACpD;;AAEA;;+EAE+E;;AAE/E;EACE,cAAc;EACd,kBAAkB;EAClB,0BAA0B;EAC1B,2BAA2B;EAC3B,qBAAqB;EACrB,kBAAkB;EAClB,mBAAmB;EACnB,yCAAyC;EACzC,WAAW;AACb;;AAEA;;;EAGE,kCAAkC;AACpC;;AAEA;;;EAGE,WAAW;EACX,iCAAiC;AACnC;;AAEA;;EAEE,8BAA8B;EAC9B,wBAAwB;AAC1B;;AAEA;EACE,iCAAiC;EACjC,0BAA0B;AAC5B;;AAEA;EACE,gCAAgC;EAChC,gCAAgC;EAChC,yBAAyB;AAC3B;;AAEA;EACE,WAAW;EACX,+BAA+B;EAC/B,yBAAyB;AAC3B;;AAEA;;+EAE+E;;AAE/E;EACE,kBAAkB;EAClB,sBAAsB;EACtB,qBAAqB;EACrB,mCAAmC;EACnC,yCAAyC;EACzC,yCAAyC;EACzC,eAAe;AACjB;;AAEA;EACE,aAAa;AACf;;AAEA;;;EAGE,gCAAgC;AAClC;;AAEA;;;EAGE,WAAW;EACX,+BAA+B;AACjC;;AAEA;;EAEE,gCAAgC;AAClC;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,8BAA8B;EAC9B,kCAAkC;AACpC;;AAEA;EACE,WAAW;EACX,iCAAiC;AACnC;;AAEA;EACE,YAAY;EACZ,aAAa;AACf;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,YAAY;AACd;;AAEA;EACE,kBAAkB;EAClB,SAAS;AACX;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,yCAAyC;AAC3C;;AAEA;EACE,cAAc;EACd,SAAS;EACT,gBAAgB;AAClB;;AAEA;EACE,gBAAgB;EAChB;qCACmC;EACnC,eAAe;EACf,mBAAmB;AACrB;;AAEA;EACE,WAAW;EACX,UAAU;AACZ;;AAEA;EACE,WAAW;EACX,UAAU;AACZ;;AAEA;EACE,eAAe;AACjB;;AAEA;EACE,WAAW;EACX,UAAU;AACZ;;AAEA;EACE,WAAW;EACX,UAAU;AACZ;;AAEA;;+EAE+E;;AAE/E;EACE,wDAAwD;AAC1D;;AAEA;EACE,oEAAoE;AACtE;;AAEA;EACE,kCAAkC;AACpC;;AAEA;EACE,oCAAoC;EACpC,mBAAmB;AACrB;;AAEA;EACE,kBAAkB;EAClB,gEAAgE;EAChE,+DAA+D;EAC/D,cAAc;EACd,gBAAgB;EAChB,gBAAgB;EAChB,yBAAyB;AAC3B;;AAEA;EACE,0BAA0B;EAC1B,4BAA4B;AAC9B;;AAEA;EACE,2BAA2B;EAC3B,6BAA6B;AAC/B;;AAEA;EACE,cAAc;EACd,cAAc;EACd,gBAAgB;EAChB,0BAA0B;EAC1B,eAAe;AACjB;;AAEA;;+EAE+E;;AAE/E;EACE;IACE,2BAA2B;IAC3B,oBAAoB;EACtB;;EAEA;IACE,+BAA+B;IAC/B,oBAAoB;EACtB;;EAEA;IACE,2BAA2B;IAC3B,oBAAoB;EACtB;AACF","sourcesContent":["/*\n * This file is part of Adblock Plus <https://adblockplus.org/>,\n * Copyright (C) 2006-present eyeo GmbH\n *\n * Adblock Plus is free software: you can redistribute it and/or modify\n * it under the terms of the GNU General Public License version 3 as\n * published by the Free Software Foundation.\n *\n * Adblock Plus is distributed in the hope that it will be useful,\n * but WITHOUT ANY WARRANTY; without even the implied warranty of\n * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n * GNU General Public License for more details.\n *\n * You should have received a copy of the GNU General Public License\n * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.\n */\n\n@import \"../../theme/ui/z-index.css\";\n\nio-popout {\n  --background-color: #fff;\n  --border-color: #0797e1;\n  --border: 1px solid var(--border-color);\n  --horizontal-padding: 1rem;\n  --icon-margin: 0.4rem;\n  --icon-size-inner: 1rem;\n  --icon-size-outer: calc(var(--icon-size-inner) + var(--icon-margin));\n  --pointer-size: 10px;\n  --pointer-offset-out: calc(var(--pointer-size) / -2 - 1px);\n  --pointer-offset-start: calc(\n    var(--icon-size-outer) + var(--pointer-offset-out)\n  );\n  --content-offset-out: calc(-0.5 * var(--icon-size-outer));\n  --content-offset-start: calc(var(--icon-size-outer) + 2 * var(--icon-margin));\n}\n\nio-popout[type=\"dialog\"] {\n  --icon-size-inner: 3rem;\n}\n\n/*\n * This component is not keyboard-accessible yet but we need it to be focusable\n * to detect when we can close it\n */\nio-popout:focus {\n  outline: none;\n}\n\n/* Prevent pre-rendered content to show up before component has loaded */\nio-popout > :not(.wrapper) {\n  display: none;\n}\n\n/*******************************************************************************\n * Z-Index\n ******************************************************************************/\n\n/*\n * z-index on custom elements seem to be ignored, so that\n * this extra z-index for io-popout > .wrapper is needed to avoid issues\n */\nio-popout,\nio-popout > .wrapper {\n  z-index: var(--z-popout);\n}\n\n/* Ensures that expanded popouts are always shown on top of other popouts */\nio-popout[expanded],\nio-popout[expanded] > .wrapper {\n  /*\n   * We can't use calc() for setting the z-index yet because support for it was\n   * only added in Firefox 57. Therefore we have to hardcode its value for now.\n   * https://developer.mozilla.org/en-US/docs/Mozilla/Firefox/Releases/57#Quantum_CSS_notes\n   */\n  z-index: var(--z-popout-active);\n}\n\n/*\n * We need to ensure that any content overlays the anchor pointer or otherwise\n * its inner half becomes visible when the content's background color changes\n */\nio-popout > .wrapper > [role] * {\n  z-index: 1;\n}\n\n/*******************************************************************************\n * Anchor\n ******************************************************************************/\n\nio-popout > .wrapper {\n  display: inline-block;\n  position: relative;\n  vertical-align: middle;\n}\n\nio-popout > .wrapper::before {\n  width: var(--icon-size-inner);\n  height: var(--icon-size-inner);\n  cursor: pointer;\n}\n\nio-popout[anchor-icon=\"heart\"] > .wrapper::before {\n  border-radius: 50%;\n  background-color: #0797e1;\n  background-repeat: no-repeat;\n  background-size: 40%;\n  background-position: center;\n  box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);\n  transition:\n    background-color 100ms,\n    box-shadow 100ms;\n}\n\nio-popout[anchor-icon=\"heart\"][expanded] > .wrapper::before {\n  background-color: #4a4a4a;\n  box-shadow: none;\n  animation-name: tap;\n  animation-duration: 500ms;\n}\n\nio-popout[type=\"menubar\"] > .wrapper::before {\n  background-image: url(/skin/icons/gear.svg?default#default);\n}\n\nio-popout[type=\"tooltip\"] > .wrapper::before {\n  background-image: url(/skin/icons/tooltip.svg);\n}\n\nio-popout[anchor-icon=\"heart\"] > .wrapper::before {\n  background-image: url(/skin/icons/heart.svg);\n}\n\nio-popout[anchor-icon=\"error\"] > .wrapper::before {\n  background-image: url(/skin/icons/error-round.svg);\n}\n\n/*******************************************************************************\n * Anchor pointer\n ******************************************************************************/\n\nio-popout > .wrapper > [role]::before {\n  display: block;\n  position: absolute;\n  width: var(--pointer-size);\n  height: var(--pointer-size);\n  border: var(--border);\n  border-right: none;\n  border-bottom: none;\n  background-color: var(--background-color);\n  content: \"\";\n}\n\nio-popout:not([expanded]) > .wrapper > [role]::before,\nio-popout[expanded=\"above\"] > .wrapper > [role]::before,\nio-popout[expanded=\"below\"] > .wrapper > [role]::before {\n  right: var(--pointer-offset-start);\n}\n\nhtml[dir=\"rtl\"] io-popout:not([expanded]) > .wrapper > [role]::before,\nhtml[dir=\"rtl\"] io-popout[expanded=\"above\"] > .wrapper > [role]::before,\nhtml[dir=\"rtl\"] io-popout[expanded=\"below\"] > .wrapper > [role]::before {\n  right: auto;\n  left: var(--pointer-offset-start);\n}\n\nio-popout:not([expanded]) > .wrapper > [role]::before,\nio-popout[expanded=\"below\"] > .wrapper > [role]::before {\n  top: var(--pointer-offset-out);\n  transform: rotate(45deg);\n}\n\nio-popout[expanded=\"above\"] > .wrapper > [role]::before {\n  bottom: var(--pointer-offset-out);\n  transform: rotate(-135deg);\n}\n\nio-popout[expanded=\"start\"] > .wrapper > [role]::before {\n  top: var(--pointer-offset-start);\n  right: var(--pointer-offset-out);\n  transform: rotate(135deg);\n}\n\nhtml[dir=\"rtl\"] io-popout[expanded=\"start\"] > .wrapper > [role]::before {\n  right: auto;\n  left: var(--pointer-offset-out);\n  transform: rotate(-45deg);\n}\n\n/*******************************************************************************\n * Content\n ******************************************************************************/\n\nio-popout > .wrapper > [role] {\n  position: absolute;\n  box-sizing: border-box;\n  border: var(--border);\n  border-radius: var(--border-radius);\n  background-color: var(--background-color);\n  box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);\n  cursor: default;\n}\n\nio-popout [aria-hidden=\"true\"] {\n  display: none;\n}\n\nio-popout:not([expanded]) > .wrapper > [role],\nio-popout[expanded=\"above\"] > .wrapper > [role],\nio-popout[expanded=\"below\"] > .wrapper > [role] {\n  right: var(--content-offset-out);\n}\n\nhtml[dir=\"rtl\"] io-popout:not([expanded]) > .wrapper > [role],\nhtml[dir=\"rtl\"] io-popout[expanded=\"above\"] > .wrapper > [role],\nhtml[dir=\"rtl\"] io-popout[expanded=\"below\"] > .wrapper > [role] {\n  right: auto;\n  left: var(--content-offset-out);\n}\n\nio-popout:not([expanded]) > .wrapper > [role],\nio-popout[expanded=\"below\"] > .wrapper > [role] {\n  top: var(--content-offset-start);\n}\n\nio-popout[expanded=\"above\"] > .wrapper > [role] {\n  bottom: var(--content-offset-start);\n}\n\nio-popout[expanded=\"start\"] > .wrapper > [role] {\n  top: var(--content-offset-out);\n  right: var(--content-offset-start);\n}\n\nhtml[dir=\"rtl\"] io-popout[expanded=\"start\"] > .wrapper > [role] {\n  right: auto;\n  left: var(--content-offset-start);\n}\n\nio-popout > .wrapper > [role=\"dialog\"] {\n  width: 12rem;\n  padding: 20px;\n}\n\nio-popout > .wrapper > [role=\"menubar\"] {\n  width: 12.2rem;\n}\n\nio-popout > .wrapper > [role=\"tooltip\"] {\n  width: 15rem;\n}\n\nio-popout .close {\n  position: absolute;\n  top: 10px;\n}\n\nio-popout .close:focus {\n  outline: none;\n}\n\nio-popout p {\n  padding: 0.2rem var(--horizontal-padding);\n}\n\nio-popout [role=\"dialog\"] p {\n  padding: 1em 0;\n  margin: 0;\n  font-size: 0.9em;\n}\n\nio-popout [role=\"tooltip\"] p {\n  overflow-y: auto;\n  /* Approximated to achieve a total tooltip height of 12.5em without\n  hiding overflowing anchor pointer */\n  max-height: 9em;\n  line-height: 1.5rem;\n}\n\nhtml[dir=\"ltr\"] io-popout button.close {\n  right: 10px;\n  left: auto;\n}\n\nhtml[dir=\"rtl\"] io-popout button.close {\n  right: auto;\n  left: 10px;\n}\n\nio-popout .close + * {\n  margin-top: 2em;\n}\n\nhtml[dir=\"ltr\"] io-popout button.close {\n  right: 10px;\n  left: auto;\n}\n\nhtml[dir=\"rtl\"] io-popout button.close {\n  right: auto;\n  left: 10px;\n}\n\n/*******************************************************************************\n * Appearance variants\n ******************************************************************************/\n\nio-popout[appearance=\"error\"] .icon.close::before {\n  background-image: url(/skin/icons/close.svg?error#error);\n}\n\nio-popout[appearance=\"error\"] .icon.close:hover::before {\n  background-image: url(/skin/icons/close.svg?error-hover#error-hover);\n}\n\nio-popout[appearance=\"error\"] {\n  --border-color: var(--color-error);\n}\n\nio-popout[appearance=\"error\"] ul {\n  padding: 0 var(--horizontal-padding);\n  margin-bottom: 1rem;\n}\n\nio-popout[appearance=\"error\"] .error-list li {\n  --border-size: 4px;\n  --border: var(--border-size) solid var(--background-color-error);\n  --padding: calc(var(--horizontal-padding) - var(--border-size));\n  display: block;\n  border-radius: 0;\n  margin: 0.8rem 0;\n  color: var(--color-error);\n}\n\nhtml:not([dir=\"rtl\"]) io-popout[appearance=\"error\"] .error-list li {\n  border-left: var(--border);\n  padding-left: var(--padding);\n}\n\nhtml[dir=\"rtl\"] io-popout[appearance=\"error\"] .error-list li {\n  border-right: var(--border);\n  padding-right: var(--padding);\n}\n\nio-popout[appearance=\"error\"] .error-list li a {\n  display: block;\n  color: inherit;\n  font-weight: 600;\n  text-decoration: underline;\n  cursor: pointer;\n}\n\n/*******************************************************************************\n * Animations\n ******************************************************************************/\n\n@keyframes tap {\n  0% {\n    background-position: center;\n    background-size: 40%;\n  }\n\n  20% {\n    background-position: center 40%;\n    background-size: 50%;\n  }\n\n  100% {\n    background-position: center;\n    background-size: 40%;\n  }\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ 7769
(module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2929);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1287);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/*
 * This file is part of Adblock Plus <https://adblockplus.org/>,
 * Copyright (C) 2006-present eyeo GmbH
 *
 * Adblock Plus is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * Adblock Plus is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.
 */

io-scrollbar {
  /*
    related to the container height, as in ░▓░░░░░░░░░░░
    or width, in case it's a vertical scrollbar
  */
  --size: 12px;
  overflow: hidden;
  cursor: default;
  user-select: none;
}

io-scrollbar,
io-scrollbar > .slider {
  display: block;
  box-sizing: border-box;
  padding: 0;
}

io-scrollbar > .slider {
  margin: 0;
  border: 1px solid #979797;
  background-color: #d8d8d8;
  font-size: 0;
  line-height: 0;
}

io-scrollbar[direction="horizontal"] {
  height: var(--size);
}

io-scrollbar[direction="vertical"] {
  width: var(--size);
}

io-scrollbar[direction="horizontal"] > .slider {
  width: var(--slider-size, var(--size));
  height: 100%;
  transform: translateX(var(--position, 0));
}

io-scrollbar[direction="vertical"] > .slider {
  width: 100%;
  height: var(--slider-size, var(--size));
  transform: translateY(var(--position, 0));
}
`, "",{"version":3,"sources":["webpack://./src/components/ui/io-scrollbar.css"],"names":[],"mappings":"AAAA;;;;;;;;;;;;;;;EAeE;;AAEF;EACE;;;GAGC;EACD,YAAY;EACZ,gBAAgB;EAChB,eAAe;EACf,iBAAiB;AACnB;;AAEA;;EAEE,cAAc;EACd,sBAAsB;EACtB,UAAU;AACZ;;AAEA;EACE,SAAS;EACT,yBAAyB;EACzB,yBAAyB;EACzB,YAAY;EACZ,cAAc;AAChB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,kBAAkB;AACpB;;AAEA;EACE,sCAAsC;EACtC,YAAY;EACZ,yCAAyC;AAC3C;;AAEA;EACE,WAAW;EACX,uCAAuC;EACvC,yCAAyC;AAC3C","sourcesContent":["/*\n * This file is part of Adblock Plus <https://adblockplus.org/>,\n * Copyright (C) 2006-present eyeo GmbH\n *\n * Adblock Plus is free software: you can redistribute it and/or modify\n * it under the terms of the GNU General Public License version 3 as\n * published by the Free Software Foundation.\n *\n * Adblock Plus is distributed in the hope that it will be useful,\n * but WITHOUT ANY WARRANTY; without even the implied warranty of\n * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n * GNU General Public License for more details.\n *\n * You should have received a copy of the GNU General Public License\n * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.\n */\n\nio-scrollbar {\n  /*\n    related to the container height, as in ░▓░░░░░░░░░░░\n    or width, in case it's a vertical scrollbar\n  */\n  --size: 12px;\n  overflow: hidden;\n  cursor: default;\n  user-select: none;\n}\n\nio-scrollbar,\nio-scrollbar > .slider {\n  display: block;\n  box-sizing: border-box;\n  padding: 0;\n}\n\nio-scrollbar > .slider {\n  margin: 0;\n  border: 1px solid #979797;\n  background-color: #d8d8d8;\n  font-size: 0;\n  line-height: 0;\n}\n\nio-scrollbar[direction=\"horizontal\"] {\n  height: var(--size);\n}\n\nio-scrollbar[direction=\"vertical\"] {\n  width: var(--size);\n}\n\nio-scrollbar[direction=\"horizontal\"] > .slider {\n  width: var(--slider-size, var(--size));\n  height: 100%;\n  transform: translateX(var(--position, 0));\n}\n\nio-scrollbar[direction=\"vertical\"] > .slider {\n  width: 100%;\n  height: var(--slider-size, var(--size));\n  transform: translateY(var(--position, 0));\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ 3107
(module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2929);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1287);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/*
 * This file is part of Adblock Plus <https://adblockplus.org/>,
 * Copyright (C) 2006-present eyeo GmbH
 *
 * Adblock Plus is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * Adblock Plus is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.
 */

io-toggle {
  --width: 30px;
  --height: 8px;
  --translateY: -4px;
  --translateX: 14px;
  display: inline-block;
  width: var(--width);
  height: var(--height);
  border-radius: 4px;
  background-color: #9b9b9b;
  cursor: pointer;
  transition: background 0.2s ease-out;
  transform: translateY(calc(var(--translateY) * -1));
  will-change: background;
}

html[dir="rtl"] io-toggle {
  --translateX: -14px;
}

io-toggle[checked] {
  background-color: #92d3ea;
}

io-toggle[disabled] {
  opacity: 0.5;
  cursor: default;
}

io-toggle button {
  width: calc(var(--height) * 2);
  height: calc(var(--height) * 2);
  padding: 0;
  border: 2px solid #e1e0e1;
  border-radius: var(--height);
  outline: none;
  cursor: pointer;
  transition:
    border 0.2s ease-out,
    box-shadow 0.2s ease-out,
    transform 0.2s ease-out,
    width 0.2s ease-out;
  transform: translateY(var(--translateY));
  will-change: border, box-shadow, transform, width;
}

io-toggle button[aria-checked="false"] {
  background-color: #f1f1f1;
  box-shadow: 0 1px 2px 0 #e5d1d1;
}

io-toggle button[aria-checked="false"]:hover {
  box-shadow: 0 2px 4px 0 #d3b0b0;
}

io-toggle button[aria-checked="true"] {
  border: 2px solid #0797e1;
  background-color: #0797e1;
  box-shadow: 0 1px 2px 0 #a6cede;
  transform: translateY(var(--translateY)) translateX(var(--translateX));
}

io-toggle button[aria-checked="true"]:hover {
  box-shadow: 0 2px 4px 0 #a6cede;
}

io-toggle button:focus,
io-toggle button[aria-checked="true"]:focus {
  border: 2px solid #87bffe;
}
`, "",{"version":3,"sources":["webpack://./src/components/ui/io-toggle.css"],"names":[],"mappings":"AAAA;;;;;;;;;;;;;;;EAeE;;AAEF;EACE,aAAa;EACb,aAAa;EACb,kBAAkB;EAClB,kBAAkB;EAClB,qBAAqB;EACrB,mBAAmB;EACnB,qBAAqB;EACrB,kBAAkB;EAClB,yBAAyB;EACzB,eAAe;EACf,oCAAoC;EACpC,mDAAmD;EACnD,uBAAuB;AACzB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,yBAAyB;AAC3B;;AAEA;EACE,YAAY;EACZ,eAAe;AACjB;;AAEA;EACE,8BAA8B;EAC9B,+BAA+B;EAC/B,UAAU;EACV,yBAAyB;EACzB,4BAA4B;EAC5B,aAAa;EACb,eAAe;EACf;;;;uBAIqB;EACrB,wCAAwC;EACxC,iDAAiD;AACnD;;AAEA;EACE,yBAAyB;EACzB,+BAA+B;AACjC;;AAEA;EACE,+BAA+B;AACjC;;AAEA;EACE,yBAAyB;EACzB,yBAAyB;EACzB,+BAA+B;EAC/B,sEAAsE;AACxE;;AAEA;EACE,+BAA+B;AACjC;;AAEA;;EAEE,yBAAyB;AAC3B","sourcesContent":["/*\n * This file is part of Adblock Plus <https://adblockplus.org/>,\n * Copyright (C) 2006-present eyeo GmbH\n *\n * Adblock Plus is free software: you can redistribute it and/or modify\n * it under the terms of the GNU General Public License version 3 as\n * published by the Free Software Foundation.\n *\n * Adblock Plus is distributed in the hope that it will be useful,\n * but WITHOUT ANY WARRANTY; without even the implied warranty of\n * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n * GNU General Public License for more details.\n *\n * You should have received a copy of the GNU General Public License\n * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.\n */\n\nio-toggle {\n  --width: 30px;\n  --height: 8px;\n  --translateY: -4px;\n  --translateX: 14px;\n  display: inline-block;\n  width: var(--width);\n  height: var(--height);\n  border-radius: 4px;\n  background-color: #9b9b9b;\n  cursor: pointer;\n  transition: background 0.2s ease-out;\n  transform: translateY(calc(var(--translateY) * -1));\n  will-change: background;\n}\n\nhtml[dir=\"rtl\"] io-toggle {\n  --translateX: -14px;\n}\n\nio-toggle[checked] {\n  background-color: #92d3ea;\n}\n\nio-toggle[disabled] {\n  opacity: 0.5;\n  cursor: default;\n}\n\nio-toggle button {\n  width: calc(var(--height) * 2);\n  height: calc(var(--height) * 2);\n  padding: 0;\n  border: 2px solid #e1e0e1;\n  border-radius: var(--height);\n  outline: none;\n  cursor: pointer;\n  transition:\n    border 0.2s ease-out,\n    box-shadow 0.2s ease-out,\n    transform 0.2s ease-out,\n    width 0.2s ease-out;\n  transform: translateY(var(--translateY));\n  will-change: border, box-shadow, transform, width;\n}\n\nio-toggle button[aria-checked=\"false\"] {\n  background-color: #f1f1f1;\n  box-shadow: 0 1px 2px 0 #e5d1d1;\n}\n\nio-toggle button[aria-checked=\"false\"]:hover {\n  box-shadow: 0 2px 4px 0 #d3b0b0;\n}\n\nio-toggle button[aria-checked=\"true\"] {\n  border: 2px solid #0797e1;\n  background-color: #0797e1;\n  box-shadow: 0 1px 2px 0 #a6cede;\n  transform: translateY(var(--translateY)) translateX(var(--translateX));\n}\n\nio-toggle button[aria-checked=\"true\"]:hover {\n  box-shadow: 0 2px 4px 0 #a6cede;\n}\n\nio-toggle button:focus,\nio-toggle button[aria-checked=\"true\"]:focus {\n  border: 2px solid #87bffe;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ 6350
(module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2929);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1287);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/*
 * This file is part of Adblock Plus <https://adblockplus.org/>,
 * Copyright (C) 2006-present eyeo GmbH
 *
 * Adblock Plus is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * Adblock Plus is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
  Used for translatable screen reader only content.
  e.g.: Use instead of aria-label to avoid complex attribute value translation
*/
.sr-only {
  clip: rect(0, 0, 0, 0);
  overflow: hidden;
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0px;
  border: 0px;
}
`, "",{"version":3,"sources":["webpack://./src/theme/ui/common.css"],"names":[],"mappings":"AAAA;;;;;;;;;;;;;;;EAeE;;AAEF;;;CAGC;AACD;EACE,sBAAsB;EACtB,gBAAgB;EAChB,kBAAkB;EAClB,UAAU;EACV,WAAW;EACX,YAAY;EACZ,YAAY;EACZ,WAAW;AACb","sourcesContent":["/*\n * This file is part of Adblock Plus <https://adblockplus.org/>,\n * Copyright (C) 2006-present eyeo GmbH\n *\n * Adblock Plus is free software: you can redistribute it and/or modify\n * it under the terms of the GNU General Public License version 3 as\n * published by the Free Software Foundation.\n *\n * Adblock Plus is distributed in the hope that it will be useful,\n * but WITHOUT ANY WARRANTY; without even the implied warranty of\n * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n * GNU General Public License for more details.\n *\n * You should have received a copy of the GNU General Public License\n * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.\n */\n\n/*\n  Used for translatable screen reader only content.\n  e.g.: Use instead of aria-label to avoid complex attribute value translation\n*/\n.sr-only {\n  clip: rect(0, 0, 0, 0);\n  overflow: hidden;\n  position: absolute;\n  width: 1px;\n  height: 1px;\n  margin: -1px;\n  padding: 0px;\n  border: 0px;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ 6054
(module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2929);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1287);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/*
 * This file is part of Adblock Plus <https://adblockplus.org/>,
 * Copyright (C) 2006-present eyeo GmbH
 *
 * Adblock Plus is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * Adblock Plus is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.
 */

@font-face {
  font-family: "Source Sans Pro";
  font-style: normal;
  font-weight: 300;
  src:
    local("Source Sans Pro Light"),
    local("SourceSansPro-Light"),
    url(/skin/fonts/source-sans-pro-300.woff2) format("woff2");
}

@font-face {
  font-family: "Source Sans Pro";
  font-style: normal;
  font-weight: 400;
  src:
    local("Source Sans Pro Regular"),
    local("SourceSansPro-Regular"),
    url(/skin/fonts/source-sans-pro-400.woff2) format("woff2");
}

@font-face {
  font-family: "Source Sans Pro";
  font-style: normal;
  font-weight: 700;
  src:
    local("Source Sans Pro Bold"),
    local("SourceSansPro-Bold"),
    url(/skin/fonts/source-sans-pro-700.woff2) format("woff2");
}

body {
  font-family: "Source Sans Pro", sans-serif;
  font-size: inherit;
}
`, "",{"version":3,"sources":["webpack://./src/theme/ui/font.css"],"names":[],"mappings":"AAAA;;;;;;;;;;;;;;;EAeE;;AAEF;EACE,8BAA8B;EAC9B,kBAAkB;EAClB,gBAAgB;EAChB;;;8DAG4D;AAC9D;;AAEA;EACE,8BAA8B;EAC9B,kBAAkB;EAClB,gBAAgB;EAChB;;;8DAG4D;AAC9D;;AAEA;EACE,8BAA8B;EAC9B,kBAAkB;EAClB,gBAAgB;EAChB;;;8DAG4D;AAC9D;;AAEA;EACE,0CAA0C;EAC1C,kBAAkB;AACpB","sourcesContent":["/*\n * This file is part of Adblock Plus <https://adblockplus.org/>,\n * Copyright (C) 2006-present eyeo GmbH\n *\n * Adblock Plus is free software: you can redistribute it and/or modify\n * it under the terms of the GNU General Public License version 3 as\n * published by the Free Software Foundation.\n *\n * Adblock Plus is distributed in the hope that it will be useful,\n * but WITHOUT ANY WARRANTY; without even the implied warranty of\n * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n * GNU General Public License for more details.\n *\n * You should have received a copy of the GNU General Public License\n * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.\n */\n\n@font-face {\n  font-family: \"Source Sans Pro\";\n  font-style: normal;\n  font-weight: 300;\n  src:\n    local(\"Source Sans Pro Light\"),\n    local(\"SourceSansPro-Light\"),\n    url(/skin/fonts/source-sans-pro-300.woff2) format(\"woff2\");\n}\n\n@font-face {\n  font-family: \"Source Sans Pro\";\n  font-style: normal;\n  font-weight: 400;\n  src:\n    local(\"Source Sans Pro Regular\"),\n    local(\"SourceSansPro-Regular\"),\n    url(/skin/fonts/source-sans-pro-400.woff2) format(\"woff2\");\n}\n\n@font-face {\n  font-family: \"Source Sans Pro\";\n  font-style: normal;\n  font-weight: 700;\n  src:\n    local(\"Source Sans Pro Bold\"),\n    local(\"SourceSansPro-Bold\"),\n    url(/skin/fonts/source-sans-pro-700.woff2) format(\"woff2\");\n}\n\nbody {\n  font-family: \"Source Sans Pro\", sans-serif;\n  font-size: inherit;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ 4341
(module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2929);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1287);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/*
 * This file is part of Adblock Plus <https://adblockplus.org/>,
 * Copyright (C) 2006-present eyeo GmbH
 *
 * Adblock Plus is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * Adblock Plus is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.
 */

:root {
  --background-color-cta-primary: #0797e1;
  --background-color-cta-primary-hover: #0797e1ee;
  --background-color-cta-secondary: #fff;
  --background-color-cta-secondary-hover: #0001;
  --background-color-error: #f7dde1;
  --background-color-info: #0797e1;
  --background-color-secondary: #f7f7f7;
  --background-color-primary: #fff;
  --background-color-ternary: #edf9ff;
  --border-color-cta-primary: var(--background-color-cta-primary);
  --border-color-cta-secondary: var(--color-primary);
  --border-color-secondary: #d2d2d2;
  --border-color-primary: #cdcdcd;
  --border-color-ternary: #c0e6f9;
  --border-color-outline: #acacac;
  --border-radius: 4px;
  --border-radius-primary: 6px;
  --border-style-primary: solid;
  --border-width-thick: 4px;
  --border-width-thin: 1px;
  --box-shadow-primary: 0 2px 4px 0 hsla(0, 0%, 84%, 0.5);
  --color-brand-primary: #ed1e45;
  --color-cta-primary: #fff;
  --color-cta-secondary: #666;
  --color-primary: #585858;
  --color-secondary: #000;
  --color-dimmed: #4a4a4a;
  --color-critical: var(--color-brand-primary);
  --color-default: #ff8f00;
  --color-error: var(--color-brand-primary);
  --color-link: #0797e1;
  --color-info: #0797e1;
  --color-premium: #eda51e;
  --color-premium-hover: #eb9b05;
  --font-size-heavy: 20px;
  --font-size-big: 17px;
  --font-size-medium: 16px;
  --font-size-primary: 13px;
  --font-size-small: 12px;
  --margin-primary: 16px;
  --margin-secondary: calc(var(--margin-primary) / 2);
  --padding-primary: 16px;
  --padding-secondary: calc(var(--padding-primary) / 2);
  --primary-outline: var(--border-color-outline) dotted 1px;
}
`, "",{"version":3,"sources":["webpack://./src/theme/ui/light.css"],"names":[],"mappings":"AAAA;;;;;;;;;;;;;;;EAeE;;AAEF;EACE,uCAAuC;EACvC,+CAA+C;EAC/C,sCAAsC;EACtC,6CAA6C;EAC7C,iCAAiC;EACjC,gCAAgC;EAChC,qCAAqC;EACrC,gCAAgC;EAChC,mCAAmC;EACnC,+DAA+D;EAC/D,kDAAkD;EAClD,iCAAiC;EACjC,+BAA+B;EAC/B,+BAA+B;EAC/B,+BAA+B;EAC/B,oBAAoB;EACpB,4BAA4B;EAC5B,6BAA6B;EAC7B,yBAAyB;EACzB,wBAAwB;EACxB,uDAAuD;EACvD,8BAA8B;EAC9B,yBAAyB;EACzB,2BAA2B;EAC3B,wBAAwB;EACxB,uBAAuB;EACvB,uBAAuB;EACvB,4CAA4C;EAC5C,wBAAwB;EACxB,yCAAyC;EACzC,qBAAqB;EACrB,qBAAqB;EACrB,wBAAwB;EACxB,8BAA8B;EAC9B,uBAAuB;EACvB,qBAAqB;EACrB,wBAAwB;EACxB,yBAAyB;EACzB,uBAAuB;EACvB,sBAAsB;EACtB,mDAAmD;EACnD,uBAAuB;EACvB,qDAAqD;EACrD,yDAAyD;AAC3D","sourcesContent":["/*\n * This file is part of Adblock Plus <https://adblockplus.org/>,\n * Copyright (C) 2006-present eyeo GmbH\n *\n * Adblock Plus is free software: you can redistribute it and/or modify\n * it under the terms of the GNU General Public License version 3 as\n * published by the Free Software Foundation.\n *\n * Adblock Plus is distributed in the hope that it will be useful,\n * but WITHOUT ANY WARRANTY; without even the implied warranty of\n * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n * GNU General Public License for more details.\n *\n * You should have received a copy of the GNU General Public License\n * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.\n */\n\n:root {\n  --background-color-cta-primary: #0797e1;\n  --background-color-cta-primary-hover: #0797e1ee;\n  --background-color-cta-secondary: #fff;\n  --background-color-cta-secondary-hover: #0001;\n  --background-color-error: #f7dde1;\n  --background-color-info: #0797e1;\n  --background-color-secondary: #f7f7f7;\n  --background-color-primary: #fff;\n  --background-color-ternary: #edf9ff;\n  --border-color-cta-primary: var(--background-color-cta-primary);\n  --border-color-cta-secondary: var(--color-primary);\n  --border-color-secondary: #d2d2d2;\n  --border-color-primary: #cdcdcd;\n  --border-color-ternary: #c0e6f9;\n  --border-color-outline: #acacac;\n  --border-radius: 4px;\n  --border-radius-primary: 6px;\n  --border-style-primary: solid;\n  --border-width-thick: 4px;\n  --border-width-thin: 1px;\n  --box-shadow-primary: 0 2px 4px 0 hsla(0, 0%, 84%, 0.5);\n  --color-brand-primary: #ed1e45;\n  --color-cta-primary: #fff;\n  --color-cta-secondary: #666;\n  --color-primary: #585858;\n  --color-secondary: #000;\n  --color-dimmed: #4a4a4a;\n  --color-critical: var(--color-brand-primary);\n  --color-default: #ff8f00;\n  --color-error: var(--color-brand-primary);\n  --color-link: #0797e1;\n  --color-info: #0797e1;\n  --color-premium: #eda51e;\n  --color-premium-hover: #eb9b05;\n  --font-size-heavy: 20px;\n  --font-size-big: 17px;\n  --font-size-medium: 16px;\n  --font-size-primary: 13px;\n  --font-size-small: 12px;\n  --margin-primary: 16px;\n  --margin-secondary: calc(var(--margin-primary) / 2);\n  --padding-primary: 16px;\n  --padding-secondary: calc(var(--padding-primary) / 2);\n  --primary-outline: var(--border-color-outline) dotted 1px;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ 9956
(module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2929);
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1287);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/*
 * This file is part of Adblock Plus <https://adblockplus.org/>,
 * Copyright (C) 2006-present eyeo GmbH
 *
 * Adblock Plus is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * Adblock Plus is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.
 */

:root {
  --z-popout: 10;
  --z-popout-active: 11;
  --z-dialog: 20;
}
`, "",{"version":3,"sources":["webpack://./src/theme/ui/z-index.css"],"names":[],"mappings":"AAAA;;;;;;;;;;;;;;;EAeE;;AAEF;EACE,cAAc;EACd,qBAAqB;EACrB,cAAc;AAChB","sourcesContent":["/*\n * This file is part of Adblock Plus <https://adblockplus.org/>,\n * Copyright (C) 2006-present eyeo GmbH\n *\n * Adblock Plus is free software: you can redistribute it and/or modify\n * it under the terms of the GNU General Public License version 3 as\n * published by the Free Software Foundation.\n *\n * Adblock Plus is distributed in the hope that it will be useful,\n * but WITHOUT ANY WARRANTY; without even the implied warranty of\n * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n * GNU General Public License for more details.\n *\n * You should have received a copy of the GNU General Public License\n * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.\n */\n\n:root {\n  --z-popout: 10;\n  --z-popout-active: 11;\n  --z-dialog: 20;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ 2058
(module) {

module.exports = /*#__PURE__*/JSON.parse('{"alarms":{"clear":{"minArgs":0,"maxArgs":1},"clearAll":{"minArgs":0,"maxArgs":0},"get":{"minArgs":0,"maxArgs":1},"getAll":{"minArgs":0,"maxArgs":0}},"bookmarks":{"create":{"minArgs":1,"maxArgs":1},"get":{"minArgs":1,"maxArgs":1},"getChildren":{"minArgs":1,"maxArgs":1},"getRecent":{"minArgs":1,"maxArgs":1},"getSubTree":{"minArgs":1,"maxArgs":1},"getTree":{"minArgs":0,"maxArgs":0},"move":{"minArgs":2,"maxArgs":2},"remove":{"minArgs":1,"maxArgs":1},"removeTree":{"minArgs":1,"maxArgs":1},"search":{"minArgs":1,"maxArgs":1},"update":{"minArgs":2,"maxArgs":2}},"browserAction":{"disable":{"minArgs":0,"maxArgs":1,"fallbackToNoCallback":true},"enable":{"minArgs":0,"maxArgs":1,"fallbackToNoCallback":true},"getBadgeBackgroundColor":{"minArgs":1,"maxArgs":1},"getBadgeText":{"minArgs":1,"maxArgs":1},"getPopup":{"minArgs":1,"maxArgs":1},"getTitle":{"minArgs":1,"maxArgs":1},"openPopup":{"minArgs":0,"maxArgs":0},"setBadgeBackgroundColor":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true},"setBadgeText":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true},"setIcon":{"minArgs":1,"maxArgs":1},"setPopup":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true},"setTitle":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true}},"browsingData":{"remove":{"minArgs":2,"maxArgs":2},"removeCache":{"minArgs":1,"maxArgs":1},"removeCookies":{"minArgs":1,"maxArgs":1},"removeDownloads":{"minArgs":1,"maxArgs":1},"removeFormData":{"minArgs":1,"maxArgs":1},"removeHistory":{"minArgs":1,"maxArgs":1},"removeLocalStorage":{"minArgs":1,"maxArgs":1},"removePasswords":{"minArgs":1,"maxArgs":1},"removePluginData":{"minArgs":1,"maxArgs":1},"settings":{"minArgs":0,"maxArgs":0}},"commands":{"getAll":{"minArgs":0,"maxArgs":0}},"contextMenus":{"remove":{"minArgs":1,"maxArgs":1},"removeAll":{"minArgs":0,"maxArgs":0},"update":{"minArgs":2,"maxArgs":2}},"cookies":{"get":{"minArgs":1,"maxArgs":1},"getAll":{"minArgs":1,"maxArgs":1},"getAllCookieStores":{"minArgs":0,"maxArgs":0},"remove":{"minArgs":1,"maxArgs":1},"set":{"minArgs":1,"maxArgs":1}},"devtools":{"inspectedWindow":{"eval":{"minArgs":1,"maxArgs":2,"singleCallbackArg":false}},"panels":{"create":{"minArgs":3,"maxArgs":3,"singleCallbackArg":true},"elements":{"createSidebarPane":{"minArgs":1,"maxArgs":1}}}},"downloads":{"cancel":{"minArgs":1,"maxArgs":1},"download":{"minArgs":1,"maxArgs":1},"erase":{"minArgs":1,"maxArgs":1},"getFileIcon":{"minArgs":1,"maxArgs":2},"open":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true},"pause":{"minArgs":1,"maxArgs":1},"removeFile":{"minArgs":1,"maxArgs":1},"resume":{"minArgs":1,"maxArgs":1},"search":{"minArgs":1,"maxArgs":1},"show":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true}},"extension":{"isAllowedFileSchemeAccess":{"minArgs":0,"maxArgs":0},"isAllowedIncognitoAccess":{"minArgs":0,"maxArgs":0}},"history":{"addUrl":{"minArgs":1,"maxArgs":1},"deleteAll":{"minArgs":0,"maxArgs":0},"deleteRange":{"minArgs":1,"maxArgs":1},"deleteUrl":{"minArgs":1,"maxArgs":1},"getVisits":{"minArgs":1,"maxArgs":1},"search":{"minArgs":1,"maxArgs":1}},"i18n":{"detectLanguage":{"minArgs":1,"maxArgs":1},"getAcceptLanguages":{"minArgs":0,"maxArgs":0}},"identity":{"launchWebAuthFlow":{"minArgs":1,"maxArgs":1}},"idle":{"queryState":{"minArgs":1,"maxArgs":1}},"management":{"get":{"minArgs":1,"maxArgs":1},"getAll":{"minArgs":0,"maxArgs":0},"getSelf":{"minArgs":0,"maxArgs":0},"setEnabled":{"minArgs":2,"maxArgs":2},"uninstallSelf":{"minArgs":0,"maxArgs":1}},"notifications":{"clear":{"minArgs":1,"maxArgs":1},"create":{"minArgs":1,"maxArgs":2},"getAll":{"minArgs":0,"maxArgs":0},"getPermissionLevel":{"minArgs":0,"maxArgs":0},"update":{"minArgs":2,"maxArgs":2}},"pageAction":{"getPopup":{"minArgs":1,"maxArgs":1},"getTitle":{"minArgs":1,"maxArgs":1},"hide":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true},"setIcon":{"minArgs":1,"maxArgs":1},"setPopup":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true},"setTitle":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true},"show":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true}},"permissions":{"contains":{"minArgs":1,"maxArgs":1},"getAll":{"minArgs":0,"maxArgs":0},"remove":{"minArgs":1,"maxArgs":1},"request":{"minArgs":1,"maxArgs":1}},"runtime":{"getBackgroundPage":{"minArgs":0,"maxArgs":0},"getPlatformInfo":{"minArgs":0,"maxArgs":0},"openOptionsPage":{"minArgs":0,"maxArgs":0},"requestUpdateCheck":{"minArgs":0,"maxArgs":0},"sendMessage":{"minArgs":1,"maxArgs":3},"sendNativeMessage":{"minArgs":2,"maxArgs":2},"setUninstallURL":{"minArgs":1,"maxArgs":1}},"sessions":{"getDevices":{"minArgs":0,"maxArgs":1},"getRecentlyClosed":{"minArgs":0,"maxArgs":1},"restore":{"minArgs":0,"maxArgs":1}},"storage":{"local":{"clear":{"minArgs":0,"maxArgs":0},"get":{"minArgs":0,"maxArgs":1},"getBytesInUse":{"minArgs":0,"maxArgs":1},"remove":{"minArgs":1,"maxArgs":1},"set":{"minArgs":1,"maxArgs":1}},"managed":{"get":{"minArgs":0,"maxArgs":1},"getBytesInUse":{"minArgs":0,"maxArgs":1}},"sync":{"clear":{"minArgs":0,"maxArgs":0},"get":{"minArgs":0,"maxArgs":1},"getBytesInUse":{"minArgs":0,"maxArgs":1},"remove":{"minArgs":1,"maxArgs":1},"set":{"minArgs":1,"maxArgs":1}}},"tabs":{"captureVisibleTab":{"minArgs":0,"maxArgs":2},"create":{"minArgs":1,"maxArgs":1},"detectLanguage":{"minArgs":0,"maxArgs":1},"discard":{"minArgs":0,"maxArgs":1},"duplicate":{"minArgs":1,"maxArgs":1},"executeScript":{"minArgs":1,"maxArgs":2},"get":{"minArgs":1,"maxArgs":1},"getCurrent":{"minArgs":0,"maxArgs":0},"getZoom":{"minArgs":0,"maxArgs":1},"getZoomSettings":{"minArgs":0,"maxArgs":1},"goBack":{"minArgs":0,"maxArgs":1},"goForward":{"minArgs":0,"maxArgs":1},"highlight":{"minArgs":1,"maxArgs":1},"insertCSS":{"minArgs":1,"maxArgs":2},"move":{"minArgs":2,"maxArgs":2},"query":{"minArgs":1,"maxArgs":1},"reload":{"minArgs":0,"maxArgs":2},"remove":{"minArgs":1,"maxArgs":1},"removeCSS":{"minArgs":1,"maxArgs":2},"sendMessage":{"minArgs":2,"maxArgs":3},"setZoom":{"minArgs":1,"maxArgs":2},"setZoomSettings":{"minArgs":1,"maxArgs":2},"update":{"minArgs":1,"maxArgs":2}},"topSites":{"get":{"minArgs":0,"maxArgs":0}},"webNavigation":{"getAllFrames":{"minArgs":1,"maxArgs":1},"getFrame":{"minArgs":1,"maxArgs":1}},"webRequest":{"handlerBehaviorChanged":{"minArgs":0,"maxArgs":0}},"windows":{"create":{"minArgs":0,"maxArgs":1},"get":{"minArgs":1,"maxArgs":2},"getAll":{"minArgs":0,"maxArgs":1},"getCurrent":{"minArgs":0,"maxArgs":1},"getLastFocused":{"minArgs":0,"maxArgs":1},"remove":{"minArgs":1,"maxArgs":1},"update":{"minArgs":2,"maxArgs":2}}}');

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	const __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		const cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		const module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			const getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter/value functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			if(Array.isArray(definition)) {
/******/ 				var i = 0;
/******/ 				while(i < definition.length) {
/******/ 					var key = definition[i++];
/******/ 					var binding = definition[i++];
/******/ 					if(!__webpack_require__.o(exports, key)) {
/******/ 						if(binding === 0) {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, value: definition[i++] });
/******/ 						} else {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, get: binding });
/******/ 						}
/******/ 					} else if(binding === 0) { i++; }
/******/ 				}
/******/ 			} else {
/******/ 				for(var key in definition) {
/******/ 					if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 						Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.hasOwn(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/set anonymous default export name */
/******/ 	(() => {
/******/ 		// set .name for anonymous default exports per ES spec
/******/ 		// skipped when the property is non-configurable (pre-ES2015 engines),
/******/ 		// where Object.defineProperty would throw
/******/ 		__webpack_require__.dn = (x) => {
/******/ 			var descriptor = Object.getOwnPropertyDescriptor(x, "name");
/******/ 			if (!descriptor || (!descriptor.writable && descriptor.configurable)) Object.defineProperty(x, "name", { value: "default", configurable: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/wrap commonjs module */
/******/ 	(() => {
/******/ 		// execute a CommonJS module body with real module/exports objects, returning the final exports
/******/ 		__webpack_require__.cjs = (body) => {
/******/ 			const mod = { exports: {} };
/******/ 			body.call(mod.exports, mod, mod.exports);
/******/ 			return mod.exports;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/nonce */
/******/ 	(() => {
/******/ 		__webpack_require__.nc = undefined;
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module used 'module' so it can't be inlined
/******/ 	let __webpack_exports__ = __webpack_require__(9033);
/******/ 	
/******/ })()
;
//# sourceMappingURL=desktop-options.js.map