(function() {
	// src/ui/categories.js
	/**
	* Ghostery Browser Extension
	* https://www.ghostery.com/
	*
	* Copyright 2017-present Ghostery GmbH. All rights reserved.
	*
	* This Source Code Form is subject to the terms of the Mozilla Public
	* License, v. 2.0. If a copy of the MPL was not distributed with this
	* file, You can obtain one at http://mozilla.org/MPL/2.0
	*/
	var colors = {
		advertising: "#CB55CD",
		site_analytics: "#5EBEDB",
		consent: "#556FCD",
		utilities: "#FC9734",
		hosting: "#8459A5",
		customer_interaction: "#EF671E",
		unidentified: "#79859E",
		audio_video_player: "#4ECB4E",
		extensions: "#A14ECB",
		misc: "#CB4EA1",
		pornvertising: "#CB4E4E",
		social_media: "#CBA14E",
		other: "#D5DBE5"
	};
	var backgroundColors = {
		...colors,
		site_analytics: "#87D7EF",
		unidentified: "#DBDFE7"
	};
	var order = [
		"advertising",
		"site_analytics",
		"consent",
		"utilities",
		"hosting",
		"customer_interaction",
		"audio_video_player",
		"extensions",
		"misc",
		"pornvertising",
		"social_media",
		"unidentified",
		"other"
	];
	function getCategoryKey(category) {
		return colors[category] ? category : "unidentified";
	}
	function getCategoryBgColor(category) {
		return backgroundColors[getCategoryKey(category)];
	}
	// src/ui/wheel.js
	/**
	* Ghostery Browser Extension
	* https://www.ghostery.com/
	*
	* Copyright 2017-present Ghostery GmbH. All rights reserved.
	*
	* This Source Code Form is subject to the terms of the Mozilla Public
	* License, v. 2.0. If a copy of the MPL was not distributed with this
	* file, You can obtain one at http://mozilla.org/MPL/2.0
	*/
	function degToRad(degree) {
		return degree * (Math.PI / 180);
	}
	function grayscaleColor(hexColor) {
		const r = parseInt(hexColor.substr(1, 2), 16);
		const g = parseInt(hexColor.substr(3, 2), 16);
		const b = parseInt(hexColor.substr(5, 2), 16);
		const value = .2126 * r + .7152 * g + .0722 * b;
		return `rgb(${value}, ${value}, ${value})`;
	}
	function drawWheel(ctx, size, categories, { useScale = true, grayscale = false } = {}) {
		if (useScale && typeof window !== "undefined") {
			const { canvas } = ctx;
			canvas.style.width = size + "px";
			canvas.style.height = size + "px";
			const scale = window.devicePixelRatio;
			canvas.width = Math.floor(size * scale);
			canvas.height = Math.floor(size * scale);
			ctx.scale(scale, scale);
		}
		const groupedCategories = {};
		order.forEach((c) => groupedCategories[getCategoryKey(c)] = 0);
		categories.forEach((c) => groupedCategories[getCategoryKey(c)] += 1);
		const center = size / 2;
		const increment = 360 / categories.length;
		ctx.lineWidth = Math.floor(size * .14) * .95;
		const radius = size / 2 - ctx.lineWidth;
		ctx.strokeStyle = "blue";
		ctx.beginPath();
		ctx.arc(center, center, Math.floor(radius), 0, 2 * Math.PI);
		ctx.stroke();
		ctx.lineWidth = size * .14;
		let position = -90;
		for (const [category, numTrackers] of Object.entries(groupedCategories)) if (numTrackers > 0) {
			const newPosition = position + numTrackers * increment;
			const color = getCategoryBgColor(category);
			ctx.strokeStyle = grayscale ? grayscaleColor(color) : color;
			ctx.beginPath();
			ctx.arc(center, center, radius, degToRad(position), Math.min(degToRad(newPosition + 1), 2 * Math.PI));
			ctx.stroke();
			position = newPosition;
		}
	}
	// src/utils/messaging.js
	/**
	* Ghostery Browser Extension
	* https://www.ghostery.com/
	*
	* Copyright 2017-present Ghostery GmbH. All rights reserved.
	*
	* This Source Code Form is subject to the terms of the Mozilla Public
	* License, v. 2.0. If a copy of the MPL was not distributed with this
	* file, You can obtain one at http://mozilla.org/MPL/2.0
	*/
	var EXTENSION_ORIGIN = chrome.runtime.getURL("/").toLowerCase().slice(0, -1);
	function isFromExtensionFrame(event) {
		return event.origin === EXTENSION_ORIGIN;
	}
	// src/utils/link-destinations.js
	/**
	* Ghostery Browser Extension
	* https://www.ghostery.com/
	*
	* Copyright 2017-present Ghostery GmbH. All rights reserved.
	*
	* This Source Code Form is subject to the terms of the Mozilla Public
	* License, v. 2.0. If a copy of the MPL was not distributed with this
	* file, You can obtain one at http://mozilla.org/MPL/2.0
	*/
	var RESULT_PAGE_REGEXP = /^((www\.)?google\.(com|cat|[a-z]{2}|com?\.[a-z]{2})|(www|cn)\.bing\.com)$/;
	var AD_CLICK_PATHNAME_REGEXP = /^(?:\/pagead)?\/aclk$/;
	function isResultPage(hostname = window.location.hostname) {
		return RESULT_PAGE_REGEXP.test(hostname);
	}
	function httpUrl(value) {
		try {
			const { protocol, href } = new URL(value);
			return protocol === "https:" || protocol === "http:" ? href : null;
		} catch {
			return null;
		}
	}
	function getAdDestination(el) {
		for (const clickUrl of [el.getAttribute("data-rw"), el.href]) {
			if (!clickUrl) continue;
			let landingPage;
			try {
				const url = new URL(clickUrl, window.location.href);
				if (!AD_CLICK_PATHNAME_REGEXP.test(url.pathname)) continue;
				landingPage = url.searchParams.get("adurl");
			} catch {
				continue;
			}
			const destination = landingPage && httpUrl(landingPage);
			if (destination) return destination;
		}
		return null;
	}
	function getDestination(el) {
		if (el.protocol !== "https:" && el.protocol !== "http:") return null;
		const landingPage = getAdDestination(el);
		if (landingPage) return landingPage;
		if (el.hostname !== window.location.hostname && !isResultPage(el.hostname)) return el.href;
		const { searchParams } = new URL(el.href);
		switch (el.pathname) {
			case "/url": return httpUrl(searchParams.get("url") || searchParams.get("q"));
			case "/ck/a": {
				const param = searchParams.get("u");
				if (!param) return null;
				try {
					return httpUrl(atob(param.slice(2)));
				} catch {
					return null;
				}
			}
			default: return null;
		}
	}
	// src/content_scripts/trackers-preview.js
	/**
	* Ghostery Browser Extension
	* https://www.ghostery.com/
	*
	* Copyright 2017-present Ghostery GmbH. All rights reserved.
	*
	* This Source Code Form is subject to the terms of the Mozilla Public
	* License, v. 2.0. If a copy of the MPL was not distributed with this
	* file, You can obtain one at http://mozilla.org/MPL/2.0
	*/
	var WRAPPER_CLASS = "wtm-popup-iframe-wrapper";
	var isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
	function closePopups() {
		[...document.querySelectorAll(`.${WRAPPER_CLASS}`)].forEach((popup) => {
			popup.parentElement.removeChild(popup);
		});
	}
	function resizePopup(height) {
		[...document.querySelectorAll(`.${WRAPPER_CLASS}`)].forEach((popup) => {
			popup.style.height = `${height}px`;
		});
	}
	var getTop = (el) => el.offsetTop + (el.offsetParent && getTop(el.offsetParent));
	function renderPopup(container, stats, popupUrl) {
		closePopups();
		const wrapper = document.createElement("div");
		wrapper.classList.add(WRAPPER_CLASS);
		if (isMobile) {
			wrapper.style.width = window.innerWidth - 20 + "px";
			wrapper.style.left = "10px";
		} else {
			const left = container.getBoundingClientRect().left - 175 + 12;
			wrapper.style.left = (left < 20 ? 20 : left) + "px";
		}
		wrapper.style.top = getTop(container) + 25 + "px";
		const iframe = document.createElement("iframe");
		iframe.setAttribute("src", `${popupUrl}?domain=${stats.domain}`);
		wrapper.appendChild(iframe);
		document.body.appendChild(wrapper);
	}
	function getWheelElement(stats, popupUrl) {
		const count = stats.stats.length;
		if (count === 0) return null;
		const container = document.createElement("div");
		container.classList.add("wtm-tracker-wheel-container");
		const label = document.createElement("div");
		label.innerText = count;
		const canvas = document.createElement("canvas");
		canvas.classList.add("wtm-tracker-wheel");
		drawWheel(canvas.getContext("2d"), 16, stats.stats);
		container.appendChild(canvas);
		container.appendChild(label);
		container.addEventListener("click", (ev) => {
			ev.preventDefault();
			ev.stopImmediatePropagation();
			renderPopup(container, stats, popupUrl);
		});
		return container;
	}
	var SELECTORS = [
		"[data-hveid] div.yuRUbf > div > span > a",
		"[data-hveid] div.yuRUbf > div > a",
		"[data-hveid] div.xpd a.cz3goc",
		"[data-hveid] > .xpd > div.kCrYT:first-child > a",
		"[data-hveid] div.OhZyZc > a",
		"[data-hveid] div.fqvXQb > a",
		"li[data-id] h2 > a",
		"li[data-id] div.b_algoheader > a"
	].join(", ");
	function setupTrackersPreview(popupUrl) {
		const elements = [];
		const links = [];
		for (const el of window.document.querySelectorAll(SELECTORS)) {
			if (el.dataset.wtm) continue;
			const destination = getDestination(el);
			if (!destination) continue;
			el.dataset.wtm = 1;
			elements.push(el);
			links.push(destination);
		}
		if (elements.length) chrome.runtime.sendMessage({
			action: "getWTMReport",
			links
		}, (response) => {
			if (chrome.runtime.lastError) {
				console.error("Could not retrieve WTM information on URLs", chrome.runtime.lastError);
				return;
			}
			elements.forEach((anchor, i) => {
				const stats = response.wtmStats[i];
				if (stats) try {
					const wheelEl = getWheelElement(stats, popupUrl);
					if (!wheelEl) return;
					const container = anchor.parentElement.querySelector(".B6fmyf") || anchor.parentElement.parentElement.querySelector(".B6fmyf") || anchor.querySelector("span.yIn8Od") || anchor.querySelector("div[role=\"link\"]") || anchor.querySelector("div.UPmit.AP7Wnd") || anchor.parentElement.parentElement.querySelector(".b_tpcn");
					if (!container) return;
					if (container.classList.contains("b_tpcn")) container.style.display = "flex";
					let tempEl = container.firstElementChild;
					if (tempEl && tempEl.textContent.includes(stats.domain)) container.insertBefore(wheelEl, tempEl.nextElementSibling);
					else container.appendChild(wheelEl);
				} catch (e) {
					console.warn("Unexpected error while rendering the Tracker Preview wheel", e);
				}
			});
		});
	}
	window.addEventListener("message", (message) => {
		if (!isFromExtensionFrame(message) || typeof message.data !== "string") return;
		if (message.data === "WTMReportClosePopups") closePopups();
		else if (message.data === "WTMReportDisable") {
			closePopups();
			[...document.querySelectorAll("[data-wtm]")].forEach((el) => {
				delete el.dataset.wtm;
			});
			[...document.querySelectorAll(".wtm-tracker-wheel-container")].forEach((el) => {
				el.parentElement.removeChild(el);
			});
			chrome.runtime.sendMessage({ action: "disableWTMReport" });
		} else if (message.data?.startsWith("WTMReportResize")) {
			const height = message.data.split(":")[1];
			resizePopup(height);
		}
	});
	function setup() {
		const popupUrl = chrome.runtime.getURL("pages/trackers-preview/index.html");
		let timeout = null;
		setupTrackersPreview(popupUrl);
		new MutationObserver((mutations) => {
			if (timeout) return;
			if (!mutations.some((m) => m.addedNodes.length || m.type === "attributes")) return;
			timeout = setTimeout(() => {
				timeout = null;
				setupTrackersPreview(popupUrl);
			}, 500);
		}).observe(document.body, {
			childList: true,
			subtree: true,
			attributes: true,
			attributeFilter: ["href"]
		});
	}
	if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", setup);
	else setup();
})();
