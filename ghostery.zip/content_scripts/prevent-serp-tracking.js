(function() {
	// src/utils/link-destinations.js
	/**
	* Ghostery Browser Extension
	* https://www.ghostery.com/
	*
	* Copyright 2017-present Ghostery GmbH. All rights reserved.
	*
	* This Source Code Form is subject to the terms of the Mozilla Public
	* License, v. 2.0. If a copy of the MPL was not distributed with this
	* file, You can obtain one at http://mozilla.org/MPL/2.0
	*/
	var RESULT_PAGE_REGEXP = /^((www\.)?google\.(com|cat|[a-z]{2}|com?\.[a-z]{2})|(www|cn)\.bing\.com)$/;
	var AD_CLICK_PATHNAME_REGEXP = /^(?:\/pagead)?\/aclk$/;
	function isResultPage(hostname = window.location.hostname) {
		return RESULT_PAGE_REGEXP.test(hostname);
	}
	function hash(str) {
		let h1 = 3735928559;
		let h2 = 1103547991;
		for (let i = 0; i < str.length; i++) {
			const ch = str.charCodeAt(i);
			h1 = Math.imul(h1 ^ ch, 2654435761);
			h2 = Math.imul(h2 ^ ch, 1597334677);
		}
		h1 = Math.imul(h1 ^ h1 >>> 16, 2246822507) ^ Math.imul(h2 ^ h2 >>> 13, 3266489909);
		h2 = Math.imul(h2 ^ h2 >>> 16, 2246822507) ^ Math.imul(h1 ^ h1 >>> 13, 3266489909);
		return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
	}
	function httpUrl(value) {
		try {
			const { protocol, href } = new URL(value);
			return protocol === "https:" || protocol === "http:" ? href : null;
		} catch {
			return null;
		}
	}
	function getAdDestination(el) {
		for (const clickUrl of [el.getAttribute("data-rw"), el.href]) {
			if (!clickUrl) continue;
			let landingPage;
			try {
				const url = new URL(clickUrl, window.location.href);
				if (!AD_CLICK_PATHNAME_REGEXP.test(url.pathname)) continue;
				landingPage = url.searchParams.get("adurl");
			} catch {
				continue;
			}
			const destination = landingPage && httpUrl(landingPage);
			if (destination) return destination;
		}
		return null;
	}
	function getDestination(el) {
		if (el.protocol !== "https:" && el.protocol !== "http:") return null;
		const landingPage = getAdDestination(el);
		if (landingPage) return landingPage;
		if (el.hostname !== window.location.hostname && !isResultPage(el.hostname)) return el.href;
		const { searchParams } = new URL(el.href);
		switch (el.pathname) {
			case "/url": return httpUrl(searchParams.get("url") || searchParams.get("q"));
			case "/ck/a": {
				const param = searchParams.get("u");
				if (!param) return null;
				try {
					return httpUrl(atob(param.slice(2)));
				} catch {
					return null;
				}
			}
			default: return null;
		}
	}
	// src/content_scripts/prevent-serp-tracking.js
	/**
	* Ghostery Browser Extension
	* https://www.ghostery.com/
	*
	* Copyright 2017-present Ghostery GmbH. All rights reserved.
	*
	* This Source Code Form is subject to the terms of the Mozilla Public
	* License, v. 2.0. If a copy of the MPL was not distributed with this
	* file, You can obtain one at http://mozilla.org/MPL/2.0
	*/
	var WRAPPED_LINKS = "a[ping], a[href^=\"/url?\"], a[href*=\"/ck/a?\"], a[href*=\"/aclk?\"], a[data-rw], a[data-agdh=\"arwt\"]";
	function isOpaque(el) {
		return (el.protocol === "https:" || el.protocol === "http:") && !getDestination(el);
	}
	function dropSwap(el) {
		el.removeAttribute("data-rw");
		if (el.dataset.agdh === "arwt") el.removeAttribute("data-agdh");
	}
	function normalize(text) {
		return (text || "").replace(/\s+/g, " ").trim();
	}
	var searchContext = "";
	var LAYOUT_ATTRIBUTES = [
		"id",
		"class",
		"style"
	];
	function getResultId(el) {
		const layout = LAYOUT_ATTRIBUTES.map((name) => el.getAttribute(name) || "").join("\n");
		const text = normalize(el.textContent) || normalize(el.getAttribute("aria-label"));
		return text ? hash(`${searchContext}\n${layout}\n${text}`) : null;
	}
	var recorded = /* @__PURE__ */ new Map();
	var destinations = /* @__PURE__ */ new Map();
	async function resolve() {
		const entries = {};
		for (const el of document.querySelectorAll(WRAPPED_LINKS)) {
			el.removeAttribute("ping");
			const destination = getDestination(el);
			if (!destination) continue;
			if (el.href !== destination) el.href = destination;
			dropSwap(el);
			if (isResultPage(new URL(destination).hostname)) continue;
			const id = getResultId(el);
			if (!id) continue;
			const known = recorded.get(id);
			if (known === destination || known === null) continue;
			entries[id] = known === void 0 ? destination : null;
			recorded.set(id, entries[id]);
			if (entries[id] === null) destinations.set(id, null);
		}
		if (Object.keys(entries).length) chrome.runtime.sendMessage({
			action: "serp:record-targets",
			entries
		}).catch(() => {});
		const opaque = [];
		const ids = /* @__PURE__ */ new Set();
		for (const el of document.querySelectorAll("a[href]")) {
			if (!isOpaque(el)) continue;
			const id = getResultId(el);
			if (!id) continue;
			opaque.push(el);
			if (!destinations.has(id)) ids.add(id);
		}
		if (ids.size) {
			const resolved = await chrome.runtime.sendMessage({
				action: "serp:resolve-targets",
				ids: [...ids]
			}).catch(() => null);
			if (resolved) for (const id of ids) destinations.set(id, resolved[id] || null);
		}
		for (const el of opaque) {
			const destination = destinations.get(getResultId(el));
			if (destination && el.href !== destination) {
				el.href = destination;
				dropSwap(el);
			}
		}
	}
	var running = Promise.resolve();
	var scheduled = false;
	function sync() {
		if (scheduled) return;
		scheduled = true;
		running = running.then(() => {
			scheduled = false;
			return resolve();
		}).catch(() => {});
	}
	if (isResultPage()) {
		const query = normalize(new URLSearchParams(window.location.search).get("q")).toLowerCase();
		if (query) {
			searchContext = `${window.location.hostname}\n${query}`;
			sync();
			new MutationObserver(sync).observe(document, {
				childList: true,
				subtree: true,
				attributes: true,
				attributeFilter: [
					"ping",
					"href",
					"data-rw",
					"data-agdh"
				]
			});
			document.addEventListener("click", function safeLinkClick(event) {
				let el = event.target;
				while (el && !el.href) el = el.parentElement;
				if (!el) return;
				el.removeAttribute("ping");
				const destination = getDestination(el) || destinations.get(getResultId(el));
				if (destination && el.href !== destination) {
					event.stopImmediatePropagation();
					el.href = destination;
					dropSwap(el);
				}
			}, true);
		}
	}
})();
