(function() {
	// src/content_scripts/youtube.js
	/**
	* Ghostery Browser Extension
	* https://www.ghostery.com/
	*
	* Copyright 2017-present Ghostery GmbH. All rights reserved.
	*
	* This Source Code Form is subject to the terms of the Mozilla Public
	* License, v. 2.0. If a copy of the MPL was not distributed with this
	* file, You can obtain one at http://mozilla.org/MPL/2.0
	*/
	var WALL_SELECTORS = [
		"ytd-watch-flexy:not([hidden]) ytd-enforcement-message-view-model > div.ytd-enforcement-message-view-model",
		"yt-playability-error-supported-renderers#error-screen ytd-enforcement-message-view-model",
		"tp-yt-paper-dialog .ytd-enforcement-message-view-model"
	];
	var AD_SELECTORS = [".html5-video-player.ad-showing"];
	function detectWall(cb) {
		let timeout = null;
		const observer = new MutationObserver(() => {
			if (timeout) return;
			timeout = setTimeout(() => {
				if (document.querySelector(WALL_SELECTORS)?.clientHeight > 0) try {
					cb();
				} catch {}
				else timeout = null;
			}, 1e3);
		});
		document.addEventListener("yt-navigate-start", () => {
			clearTimeout(timeout);
			timeout = null;
		});
		document.addEventListener("DOMContentLoaded", () => {
			observer.observe(document.body, {
				childList: true,
				subtree: true,
				attributeFilter: ["src", "style"]
			});
		});
	}
	function detectAd(cb) {
		let adShowing = false;
		const check = () => {
			const showing = !!document.querySelector(AD_SELECTORS);
			if (showing !== adShowing) {
				adShowing = showing;
				if (showing) setTimeout(cb, 1e3);
			}
		};
		const observer = new MutationObserver(check);
		document.addEventListener("DOMContentLoaded", () => {
			observer.observe(document.body, {
				childList: true,
				subtree: true,
				attributeFilter: ["class"]
			});
			check();
		});
	}
	if (!chrome.extension.inIncognitoContext) {
		detectAd(() => {
			chrome.runtime.sendMessage({ action: "youtube:ads" });
		});
		detectWall(() => {
			chrome.runtime.sendMessage({ action: "youtube:wall" });
			window.addEventListener("yt-navigate-start", () => {
				chrome.runtime.sendMessage({ action: "youtube:navigate" });
			}, {
				once: true,
				capture: true
			});
		});
	}
})();
