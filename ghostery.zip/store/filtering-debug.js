import store_default from "../npm/hybrids/src/store.js";
import { safeForStorage } from "../utils/storage.js";
// src/store/filtering-debug.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
var STORAGE_KEY = "filteringDebug";
var FilteringDebug = {
	network: true,
	cosmeticsCSS: true,
	cosmeticsScriptlets: true,
	cosmeticsExtendedCSS: true,
	antitracking: true,
	autoconsent: true,
	[store_default.connect]: {
		async get() {
			const { [STORAGE_KEY]: values = {} } = await chrome.storage.session.get([STORAGE_KEY]);
			return values;
		},
		async set(_, values) {
			await chrome.storage.session.set({ [STORAGE_KEY]: safeForStorage(values) });
			return values;
		}
	}
};
chrome.storage.onChanged.addListener((changes, areaName) => {
	if (areaName === "session" && changes[STORAGE_KEY]) store_default.clear(FilteringDebug, false);
});
export { FilteringDebug as default };
