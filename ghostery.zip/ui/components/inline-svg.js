import { html } from "../../npm/hybrids/src/template/index.js";
// src/ui/components/inline-svg.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
var EXTENSION_URL = chrome.runtime.getURL("/");
var cache = /* @__PURE__ */ new Map();
function fetchSVG(src) {
	let template = cache.get(src);
	if (!template) {
		template = new URL(src, document.baseURI).href.startsWith(EXTENSION_URL) ? fetch(src).then((res) => res.text()).then((markup) => html([markup])).catch(() => "") : Promise.resolve("");
		cache.set(src, template);
	}
	return template;
}
var inline_svg_default = {
	src: "",
	render: ({ src }) => html`
    <template layout="block">${src && html.resolve(fetchSVG(src))}</template>
  `.css`
    svg {
      display: block;
      width: 100%;
      height: 100%;
    }
  `
};
export { inline_svg_default as default };
