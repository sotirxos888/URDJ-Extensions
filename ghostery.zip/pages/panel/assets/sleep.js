// src/pages/panel/assets/sleep.svg
var sleep_default = "/assets/sleep-BmCTahGd.svg";
export { sleep_default as default };
