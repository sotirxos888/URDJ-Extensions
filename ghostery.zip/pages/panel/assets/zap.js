// src/pages/panel/assets/zap.svg
var zap_default = "/assets/zap-hbyqZjIZ.svg";
export { zap_default as default };
