// src/pages/panel/assets/contribution.svg
var contribution_default = "/assets/contribution-DqF7EuEI.svg";
export { contribution_default as default };
