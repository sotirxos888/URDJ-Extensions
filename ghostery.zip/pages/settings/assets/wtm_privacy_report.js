// src/pages/settings/assets/wtm_privacy_report.svg
var wtm_privacy_report_default = "/assets/wtm_privacy_report-DRHGsmiv.svg";
export { wtm_privacy_report_default as default };
