// src/pages/settings/assets/feedback.svg
var feedback_default = "/assets/feedback-vUK1L7gp.svg";
export { feedback_default as default };
