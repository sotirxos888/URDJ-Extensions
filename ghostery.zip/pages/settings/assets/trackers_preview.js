// src/pages/settings/assets/trackers_preview.svg
var trackers_preview_default = "/assets/trackers_preview-Bih2OWk2.svg";
export { trackers_preview_default as default };
