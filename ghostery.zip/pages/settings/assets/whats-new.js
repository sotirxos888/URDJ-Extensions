// src/pages/settings/assets/whats-new.svg
var whats_new_default = "/assets/whats-new-CggUfm5_.svg";
export { whats_new_default as default };
