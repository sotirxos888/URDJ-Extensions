// src/pages/settings/assets/hands.svg
var hands_default = "/assets/hands-Dy0ClsPv.svg";
export { hands_default as default };
