import store_default from "../../../npm/hybrids/src/store.js";
import router_default from "../../../npm/hybrids/src/router.js";
import { html } from "../../../npm/hybrids/src/template/index.js";
import CustomFilters from "../../../store/custom-filters.js";
import Options from "../../../store/options.js";
// src/pages/settings/views/custom-filters-remove-filter-list.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
function remove({ options, url }, event) {
	event.preventDefault();
	router_default.resolve(event, store_default.set(options, { customFilters: { filterLists: { [url]: null } } }));
}
var custom_filters_remove_filter_list_default = {
	[router_default.connect]: { dialog: true },
	url: "",
	options: store_default(Options),
	customFilters: store_default(CustomFilters),
	name: ({ customFilters, url }) => store_default.ready(customFilters) && customFilters.filterLists[url]?.name || "",
	render: ({ url, name }) => html`
    <template layout>
      <settings-dialog closable>
        <form
          action="${router_default.backUrl()}"
          onsubmit="${remove}"
          layout="column gap:2 width::0"
          data-qa="form:custom-filters:remove-filter-list"
        >
          <ui-text type="label-l" layout="block:center margin:bottom">Remove Filter List</ui-text>
          <div layout="column gap:0.5">
            <ui-text type="label-s" ellipsis>${name || url}</ui-text>
            ${name && html`<ui-text type="body-s" color="secondary" ellipsis>${url}</ui-text>`}
          </div>
          <ui-text type="body-m" color="secondary">Remove this filter list?</ui-text>
          <ui-text type="body-s" color="tertiary">
            Its rules will stop applying. You can add it again anytime with its URL.
          </ui-text>
          <div layout="grid:2 gap">
            <ui-button>
              <a href="${router_default.backUrl()}" tabindex="2">Cancel</a>
            </ui-button>
            <ui-button type="danger" data-qa="button:custom-filters:remove-filter-list:confirm">
              <button type="submit" tabindex="1">Remove</button>
            </ui-button>
          </div>
        </form>
      </settings-dialog>
    </template>
  `
};
export { custom_filters_remove_filter_list_default as default };
