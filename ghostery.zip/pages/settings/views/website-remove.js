import store_default from "../../../npm/hybrids/src/store.js";
import router_default from "../../../npm/hybrids/src/router.js";
import { html } from "../../../npm/hybrids/src/template/index.js";
import { msg } from "../../../npm/hybrids/src/localize.js";
import Options from "../../../store/options.js";
import { ACTION_PAUSE_ASSISTANT } from "../../../npm/@ghostery/config/dist/esm/actions.js";
import { dismissAction } from "../../../store/config.js";
import ElementPickerSelectors from "../../../store/element-picker-selectors.js";
// src/pages/settings/views/website-remove.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
var MAX_DOMAIN_LENGTH = 20;
var SCOPE_FULL = "full";
var SCOPE_PAUSE = "pause";
function remove({ options, domain, scope }, event) {
	event.preventDefault();
	if (scope === "pause") {
		router_default.resolve(event, store_default.set(options, { paused: { [domain]: null } }));
		return;
	}
	const exceptions = Object.entries(options.exceptions).reduce((acc, [id, exception]) => {
		if (!exception.domains.includes(domain)) return acc;
		const domains = exception.domains.filter((d) => d !== domain);
		acc[id] = exception.global || domains.length > 0 ? {
			...exception,
			domains
		} : null;
		return acc;
	}, {});
	if (options.paused[domain]?.assist) dismissAction(domain, ACTION_PAUSE_ASSISTANT);
	store_default.set(ElementPickerSelectors, { hostnames: { [domain]: null } });
	router_default.resolve(event, store_default.set(options, {
		[options.mode === "zap" ? "zapped" : "paused"]: { [domain]: null },
		exceptions
	}));
}
var website_remove_default = {
	[router_default.connect]: { dialog: true },
	domain: "",
	shortDomain: ({ domain }) => domain.length > MAX_DOMAIN_LENGTH ? `${domain.slice(0, MAX_DOMAIN_LENGTH)}...` : domain,
	scope: SCOPE_FULL,
	options: store_default(Options),
	render: ({ shortDomain, scope }) => html`
    <template layout>
      <settings-dialog closable>
        <form
          action="${router_default.backUrl()}"
          onsubmit="${remove}"
          layout="column gap:2 width::0"
          data-qa="form:website:remove"
        >
          <ui-text type="label-l" layout="block:center margin:bottom">
            ${scope === "pause" ? html`Resume Protection` : html`Remove Website`}
          </ui-text>
          ${scope === "pause" ? html`
                  <ui-text type="body-m" color="secondary">
                    ${msg.html`Resume protection on <strong>${shortDomain}</strong>?`}
                  </ui-text>
                  <ui-text type="body-s" color="tertiary">
                    Ghostery will start blocking on this site again. Its exceptions and blocked
                    elements stay as they are.
                  </ui-text>
                ` : html`
                  <ui-text type="body-m" color="secondary">
                    ${msg.html`Remove <strong>${shortDomain}</strong> from your list?`}
                  </ui-text>
                  <ui-text type="body-s" color="tertiary">
                    Its protection status, exceptions and blocked elements will be reset to default.
                  </ui-text>
                `}
          <div layout="grid:2 gap">
            <ui-button>
              <a href="${router_default.backUrl()}" tabindex="2">Cancel</a>
            </ui-button>
            <ui-button type="danger" data-qa="button:website:remove:confirm">
              <button type="submit" tabindex="1">
                ${scope === "pause" ? html`Resume` : html`Remove`}
              </button>
            </ui-button>
          </div>
        </form>
      </settings-dialog>
    </template>
  `
};
export { SCOPE_FULL, SCOPE_PAUSE, website_remove_default as default };
