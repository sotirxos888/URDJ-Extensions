// src/pages/notifications/assets/pin-extension-chrome.png
var pin_extension_chrome_default = "/assets/pin-extension-chrome-BJM0T1sG.png";
export { pin_extension_chrome_default as default };
