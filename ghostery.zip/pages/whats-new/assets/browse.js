//#region src/pages/whats-new/assets/browse.svg
var browse_default = "/assets/browse-Bk6ZCJGX.svg";
//#endregion
export { browse_default as default };
