// src/pages/whats-new/assets/zap-flow-1.svg
var zap_flow_1_default = "/assets/zap-flow-1-VfwWryYs.svg";
export { zap_flow_1_default as default };
