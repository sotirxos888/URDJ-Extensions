//#region src/pages/whats-new/assets/distractions.svg
var distractions_default = "/assets/distractions-DuZndSps.svg";
//#endregion
export { distractions_default as default };
