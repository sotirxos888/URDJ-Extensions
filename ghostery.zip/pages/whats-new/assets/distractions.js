// src/pages/whats-new/assets/distractions.svg
var distractions_default = "/assets/distractions-DuZndSps.svg";
export { distractions_default as default };
