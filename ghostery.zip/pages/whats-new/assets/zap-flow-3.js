// src/pages/whats-new/assets/zap-flow-3.svg
var zap_flow_3_default = "/assets/zap-flow-3-CsEX0uoG.svg";
export { zap_flow_3_default as default };
