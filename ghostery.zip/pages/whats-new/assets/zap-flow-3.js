//#region src/pages/whats-new/assets/zap-flow-3.svg
var zap_flow_3_default = "/assets/zap-flow-3-CsEX0uoG.svg";
//#endregion
export { zap_flow_3_default as default };
