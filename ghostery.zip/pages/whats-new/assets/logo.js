//#region src/pages/whats-new/assets/logo.svg
var logo_default = "/assets/logo-BrKJLrcT.svg";
//#endregion
export { logo_default as default };
