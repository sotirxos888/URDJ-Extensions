// src/pages/whats-new/assets/logo.svg
var logo_default = "/assets/logo-BrKJLrcT.svg";
export { logo_default as default };
