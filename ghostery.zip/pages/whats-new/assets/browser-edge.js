//#region src/pages/whats-new/assets/browser-edge.svg
var browser_edge_default = "/assets/browser-edge-DqRSpxr5.svg";
//#endregion
export { browser_edge_default as default };
