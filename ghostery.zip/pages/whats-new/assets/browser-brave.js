//#region src/pages/whats-new/assets/browser-brave.svg
var browser_brave_default = "/assets/browser-brave-JPWiocEF.svg";
//#endregion
export { browser_brave_default as default };
