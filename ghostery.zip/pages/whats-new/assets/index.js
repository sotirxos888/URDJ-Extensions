import browse_default from "./browse.js";
import browser_brave_default from "./browser-brave.js";
import browser_chrome_default from "./browser-chrome.js";
import browser_edge_default from "./browser-edge.js";
import browser_firefox_default from "./browser-firefox.js";
import browser_opera_default from "./browser-opera.js";
import browser_safari_default from "./browser-safari.js";
import distractions_default from "./distractions.js";
import footer_badge_default from "./footer-badge.js";
import logo_default from "./logo.js";
import wave_default from "./wave.js";
import zap_flow_1_default from "./zap-flow-1.js";
import zap_flow_2_default from "./zap-flow-2.js";
import zap_flow_3_default from "./zap-flow-3.js";
import zap_flow_4_default from "./zap-flow-4.js";
//#region src/pages/whats-new/assets/index.js
var assets_default = Object.fromEntries(Object.entries(/* #__PURE__ */ Object.assign({
	"./browse.svg": browse_default,
	"./browser-brave.svg": browser_brave_default,
	"./browser-chrome.svg": browser_chrome_default,
	"./browser-edge.svg": browser_edge_default,
	"./browser-firefox.svg": browser_firefox_default,
	"./browser-opera.svg": browser_opera_default,
	"./browser-safari.svg": browser_safari_default,
	"./distractions.svg": distractions_default,
	"./footer-badge.svg": footer_badge_default,
	"./logo.svg": logo_default,
	"./wave.svg": wave_default,
	"./zap-flow-1.svg": zap_flow_1_default,
	"./zap-flow-2.svg": zap_flow_2_default,
	"./zap-flow-3.svg": zap_flow_3_default,
	"./zap-flow-4.svg": zap_flow_4_default
})).map(([path, url]) => [path.replace("./", "").replace(".svg", ""), url]));
//#endregion
export { assets_default as default };
