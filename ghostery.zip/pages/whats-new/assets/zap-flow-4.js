// src/pages/whats-new/assets/zap-flow-4.svg
var zap_flow_4_default = "/assets/zap-flow-4-C5bEtkI3.svg";
export { zap_flow_4_default as default };
