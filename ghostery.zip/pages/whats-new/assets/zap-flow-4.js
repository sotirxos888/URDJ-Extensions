//#region src/pages/whats-new/assets/zap-flow-4.svg
var zap_flow_4_default = "/assets/zap-flow-4-C5bEtkI3.svg";
//#endregion
export { zap_flow_4_default as default };
