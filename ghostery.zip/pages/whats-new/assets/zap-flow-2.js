// src/pages/whats-new/assets/zap-flow-2.svg
var zap_flow_2_default = "/assets/zap-flow-2-DG0E_0BT.svg";
export { zap_flow_2_default as default };
