//#region src/pages/whats-new/assets/footer-badge.svg
var footer_badge_default = "/assets/footer-badge-BHlpivsz.svg";
//#endregion
export { footer_badge_default as default };
