//#region src/pages/whats-new/assets/browser-firefox.svg
var browser_firefox_default = "/assets/browser-firefox-fSeFeFLn.svg";
//#endregion
export { browser_firefox_default as default };
