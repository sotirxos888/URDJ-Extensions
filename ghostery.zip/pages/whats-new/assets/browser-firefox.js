// src/pages/whats-new/assets/browser-firefox.svg
var browser_firefox_default = "/assets/browser-firefox-fSeFeFLn.svg";
export { browser_firefox_default as default };
