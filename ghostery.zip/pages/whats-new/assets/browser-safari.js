//#region src/pages/whats-new/assets/browser-safari.svg
var browser_safari_default = "/assets/browser-safari-CrmYD3VY.svg";
//#endregion
export { browser_safari_default as default };
