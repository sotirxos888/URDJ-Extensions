import define_default from "../../npm/hybrids/src/define.js";
import browser_link_default from "./components/browser-link.js";
import entity_default from "./components/entity.js";
import fact_default from "./components/fact.js";
import facts_default from "./components/facts.js";
import flow_default from "./components/flow.js";
import hero_default from "./components/hero.js";
import outro_default from "./components/outro.js";
import panel_default from "./components/panel.js";
import stat_default from "./components/stat.js";
import stats_default from "./components/stats.js";
import step_default from "./components/step.js";
import wave_default from "./components/wave.js";
import main_default from "./views/main.js";
//#region src/pages/whats-new/elements.js
define_default.from(/* #__PURE__ */ Object.assign({
	"./components/browser-link.js": browser_link_default,
	"./components/entity.js": entity_default,
	"./components/fact.js": fact_default,
	"./components/facts.js": facts_default,
	"./components/flow.js": flow_default,
	"./components/hero.js": hero_default,
	"./components/outro.js": outro_default,
	"./components/panel.js": panel_default,
	"./components/stat.js": stat_default,
	"./components/stats.js": stats_default,
	"./components/step.js": step_default,
	"./components/wave.js": wave_default,
	"./views/main.js": main_default
}), {
	root: ["components", "views"],
	prefix: "whats-new"
});
//#endregion
