import { html } from "../../../npm/hybrids/src/template/index.js";
//#region src/pages/whats-new/components/flow.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
var flow_default = { render: () => html`
    <template layout="block">
      <slot></slot>
    </template>
  `.css`
    :host {
      border: 2px dashed var(--border-wtm-primary);
      border-radius: 16px;
    }
  ` };
//#endregion
export { flow_default as default };
