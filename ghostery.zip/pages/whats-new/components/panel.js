import { html } from "../../../npm/hybrids/src/template/index.js";
// src/pages/whats-new/components/panel.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
var panel_default = {
	type: {
		value: "brand",
		reflect: true
	},
	render: () => html`
    <template layout="block">
      <slot></slot>
    </template>
  `.css`
    :host {
      background: var(--background-brand-primary);
      border-radius: 24px;
    }

    :host([type="secondary"]) {
      background: var(--background-secondary);
    }
  `
};
export { panel_default as default };
