import { html } from "../../../npm/hybrids/src/template/index.js";
import assets_default from "../assets/index.js";
// src/pages/whats-new/components/wave.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
var wave_default = {
	flip: {
		value: false,
		reflect: true
	},
	render: () => html`
    <template layout="block shrink:0 height:6 margin:-1px:0:0" layout@768px="height:12"></template>
  `.css`
    :host {
      background: var(--background-primary);
      mask: url("${assets_default.wave}") no-repeat 0 bottom / 100% min(100%, 100vw);
    }

    :host([flip]) {
      transform: scaleY(-1);
    }
  `
};
export { wave_default as default };
