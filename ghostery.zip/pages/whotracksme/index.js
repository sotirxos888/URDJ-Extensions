import mount from "../../npm/hybrids/src/mount.js";
import "../../ui/index.js";
import "./elements.js";
/* empty css           */
import whotracksme_default from "./whotracksme.js";
// src/pages/whotracksme/index.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
mount(document.body, whotracksme_default);
