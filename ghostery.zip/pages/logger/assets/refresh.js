// src/pages/logger/assets/refresh.svg
var refresh_default = "/assets/refresh-B0nlARG8.svg";
export { refresh_default as default };
