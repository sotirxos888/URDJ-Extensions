// src/pages/element-picker/assets/hidden.svg
var hidden_default = "/assets/hidden-cXGyAdhW.svg";
export { hidden_default as default };
