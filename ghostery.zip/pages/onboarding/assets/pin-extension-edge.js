// src/pages/onboarding/assets/pin-extension-edge.jpg
var pin_extension_edge_default = "/assets/pin-extension-edge-0ejqs-oy.jpg";
export { pin_extension_edge_default as default };
