// src/pages/onboarding/assets/pin-extension-chrome.jpg
var pin_extension_chrome_default = "/assets/pin-extension-chrome-jv4rqzUD.jpg";
export { pin_extension_chrome_default as default };
