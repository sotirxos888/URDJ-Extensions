// src/pages/onboarding/assets/skip.svg
var skip_default = "/assets/skip-D4RDmVhk.svg";
export { skip_default as default };
