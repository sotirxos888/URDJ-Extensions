import store_default from "../../../npm/hybrids/src/store.js";
import router_default from "../../../npm/hybrids/src/router.js";
import { html } from "../../../npm/hybrids/src/template/index.js";
import { msg } from "../../../npm/hybrids/src/localize.js";
import ManagedConfig from "../../../store/managed-config.js";
import Options from "../../../store/options.js";
import { TERMS_AND_CONDITIONS_URL } from "../../../utils/urls.js";
import addon_health_default from "./addon-health.js";
import web_trackers_default from "./web-trackers.js";
import performance_default from "./performance.js";
import privacy_default from "./privacy.js";
import skip_default from "./skip.js";
import success_default from "./success.js";
import modes_default from "./modes.js";
// src/pages/onboarding/views/main.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
function acceptTerms(host, event) {
	router_default.resolve(event, store_default.set(Options, {
		terms: true,
		feedback: host.feedback,
		filtersUpdatedAt: Date.now()
	}));
}
function uninstall(host, event) {
	event.preventDefault();
	chrome.management.uninstallSelf({ showConfirmDialog: true });
}
var main_default = {
	[router_default.connect]: { stack: () => [
		addon_health_default,
		web_trackers_default,
		performance_default,
		privacy_default,
		skip_default
	] },
	managedConfig: store_default(ManagedConfig),
	feedback: true,
	modesEnabled: ({ managedConfig }) => store_default.ready(managedConfig) && !managedConfig.disableModes,
	render: ({ feedback, modesEnabled }) => html`
    <template layout="column gap:2 width:::375px">
      <ui-card layout="gap:2" layout@390px="gap:3">
        <section layout="block:center column gap" layout@390px="margin:2:0:1">
          <ui-text type="body-m">Welcome to Ghostery</ui-text>
          ${false}
          ${html`<ui-text type="display-m" layout="padding:0:4">Setup Ghostery to get started</ui-text>`}
        </section>
        <div layout="column gap:2">
          <ui-text type="display-2xs" layout="block:center">
            Your Community‑Powered Privacy Features:
          </ui-text>
          <div layout="grid:3 gap">
            <onboarding-feature icon="onboarding-adblocking">Ad-Blocking</onboarding-feature>
            <onboarding-feature icon="onboarding-anti-tracking">Anti-Tracking</onboarding-feature>
            <onboarding-feature icon="onboarding-never-consent">Never-Consent</onboarding-feature>
          </div>
        </div>
        <div layout="column gap:2">
          ${false}
          ${html`
              <ui-text type="body-s" underline data-qa="text:description">
                ${msg.html`
                Information about <a href="${router_default.url(web_trackers_default)}">web trackers</a>,
                <a href="${router_default.url(addon_health_default)}">add-on's health</a>, and
                <a href="${router_default.url(performance_default)}">performance telemetry</a>
                will be shared in accordance with our <a href="${router_default.url(privacy_default)}" target="_blank" rel="noreferrer">Privacy Policy</a>,
                advancing privacy protection for the Ghostery community.
              `}
              </ui-text>
            `}
          <ui-text type="body-s">
            Ghostery uses this information to provide its community-powered privacy features,
            ensuring that personal information—such as passwords, browsing history, and page
            content—is never collected.
          </ui-text>
        </div>
        <div layout="column gap:2">
          ${false}
          ${html`
              <ui-button type="success" layout="height:5.5" data-qa="button:enable">
                <a href="${router_default.url(modesEnabled ? modes_default : success_default)}" onclick="${acceptTerms}">
                  Continue
                </a>
              </ui-button>
              ${chrome.management?.uninstallSelf && html`
                  <ui-text type="body-xs" color="tertiary" layout="block:center" underline>
                    Changed your mind?
                    <a href="#" onclick="${uninstall}" data-qa="button:uninstall"
                      >Uninstall Ghostery</a
                    >
                  </ui-text>
                `}
            `}
        </div>
      </ui-card>
      <ui-button type="transparent" layout="self:center">
        <a href="${TERMS_AND_CONDITIONS_URL}" target="_blank">Terms & Conditions</a>
      </ui-button>
    </template>
  `
};
export { main_default as default };
