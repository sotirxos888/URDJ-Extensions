// src/utils/browsing-data.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
var SCOPE_WEBSITE = "website";
var HOUR = 36e5;
var TIME_RANGES = {
	hour: HOUR,
	day: 24 * HOUR,
	week: 168 * HOUR,
	all: 0
};
export { SCOPE_WEBSITE, TIME_RANGES };
