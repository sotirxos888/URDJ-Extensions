import store_default from "../npm/hybrids/src/store.js";
import getBrowserInfo from "./browser-info.js";
import Options from "../store/options.js";
import { withScope } from "../npm/@sentry/core/build/esm/currentScopes.js";
import { captureException, setTag as setTag$1 } from "../npm/@sentry/core/build/esm/exports.js";
import { init } from "../npm/@sentry/browser/build/npm/esm/prod/sdk.js";
import Errors from "../store/errors.js";
// src/utils/errors.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
var SAMPLE_RATE = .3;
var TAG_CRITICAL = "critical";
var { version } = chrome.runtime.getManifest();
var hostRegexp = new RegExp(new URL(chrome.runtime.getURL("/")).host, "g");
function hasStackFrames(stack) {
	return typeof stack === "string" && /(\n\s*at\s|@)/.test(stack);
}
var config = {
	tunnel: "https://crashreporting.ghostery.net/",
	dsn: "https://05c74f55666649f0b6d671b9c37f6da1@o475874.ingest.sentry.io/6447378",
	release: `ghostery-extension@${version}`,
	debug: false,
	environment: "production",
	autoSessionTracking: false,
	defaultIntegrations: false,
	sampleRate: 1,
	beforeSend(event) {
		if (!event.tags?.ua) return null;
		if (event.tags?.[TAG_CRITICAL]) return event;
		if (Math.random() > SAMPLE_RATE) return null;
		return event;
	},
	attachStacktrace: true
};
init(config);
function setTag(key, value) {
	if (value === "" || value == null || typeof value === "number" && Number.isNaN(value)) return;
	setTag$1(key, value);
}
var browserInfo = getBrowserInfo();
setTag("ua", browserInfo.token);
setTag("uaVersion", browserInfo.version);
setTag("os", browserInfo.os);
setTag("osVersion", browserInfo.osVersion);
async function captureError(error, { critical = false, once = false } = {}) {
	const fallbackStack = (/* @__PURE__ */ new Error()).stack;
	const { terms, feedback } = await store_default.resolve(Options);
	if (!terms || !feedback || !(error instanceof Error)) return;
	if (once) {
		const id = error.message;
		if (typeof id !== "string" || !id) {
			console.warn("[errors] error has no message to identify it");
			return;
		}
		const errors = await store_default.resolve(Errors);
		if (Date.now() - errors.onceIds[id] < 864e5) return;
		await store_default.set(errors, { onceIds: { [id]: Date.now() } });
	}
	const newError = new Error(error.message);
	newError.name = error.name;
	newError.cause = error.cause;
	newError.stack = (hasStackFrames(error.stack) ? error.stack : fallbackStack ?? "").replace(hostRegexp, "filtered");
	withScope((scope) => {
		if (critical) scope.setTag(TAG_CRITICAL, true);
		captureException(newError);
	});
}
(globalThis.ghostery ??= {}).errors = { captureError };
export { captureError };
