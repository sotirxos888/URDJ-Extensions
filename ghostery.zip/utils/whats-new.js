//#region src/utils/whats-new.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
var PERIOD_IN_MS = 7776e6;
function getPeriod() {
	const now = Date.now();
	return {
		dateFrom: (/* @__PURE__ */ new Date(now - PERIOD_IN_MS)).toISOString().slice(0, 10),
		dateTo: new Date(now).toISOString().slice(0, 10)
	};
}
//#endregion
export { getPeriod };
