import Bowser from "../npm/bowser/bowser.js";
// src/utils/browser-info.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
var UNKNOWN_UA = {
	browser: {
		name: "",
		version: ""
	},
	os: {
		name: "",
		version: ""
	},
	platform: {},
	engine: {}
};
var ua;
function getUA() {
	if (ua) return ua;
	try {
		ua = Bowser.parse(navigator.userAgent);
	} catch {
		ua = UNKNOWN_UA;
	}
	return ua;
}
function getBrowser() {
	{
		if (navigator.brave?.isBrave) return {
			name: "brave",
			token: "br"
		};
		if (navigator.userAgent.includes("OculusBrowser")) return {
			name: "oculus",
			token: "oc"
		};
		const browser = getUA().browser.name;
		if (browser.includes("Safari")) return {
			name: "safari",
			token: "sf"
		};
		if (browser.includes("Chrome")) return {
			name: "chrome",
			token: "ch"
		};
		if (browser.includes("Edge")) return {
			name: "edge",
			token: "ed"
		};
		if (browser.includes("Opera")) return {
			name: "opera",
			token: "op"
		};
		if (browser.includes("Yandex")) return {
			name: "yandex",
			token: "yx"
		};
		return {
			name: browser.toLowerCase().replace(/\s+/g, "_"),
			token: ""
		};
	}
}
function isBrave() {
	return getBrowser().name === "brave";
}
function isEdge() {
	return getBrowser().name === "edge";
}
function isOpera() {
	return getBrowser().name === "opera";
}
function isSafari() {
	return getBrowser().name === "safari";
}
function isWebkit() {
	if (isSafari()) return true;
	const os = getOS();
	return os === "ios" || os === "ipados";
}
function isMobile() {
	const os = getOS();
	return os === "android" || os === "ios" || os === "ipados";
}
function getOS() {
	const os = getUA().os?.name?.toLowerCase() || "";
	if (os.includes("mac")) {
		if (navigator.maxTouchPoints > 1) return "ipados";
		return "mac";
	} else if (os.includes("win")) return "win";
	else if (os.includes("android")) return "android";
	else if (os.includes("ios")) {
		if (navigator.platform?.toLocaleLowerCase() === "ipad") return "ipados";
		return "ios";
	} else if (os.includes("chrome os")) return "cros";
	else if (os.includes("linux")) return "linux";
	return "other";
}
var browserInfo = null;
function getBrowserInfo() {
	if (browserInfo) return browserInfo;
	const ua = getUA();
	const { name, token } = getBrowser();
	browserInfo = {
		name,
		token,
		version: parseInt(ua.browser.version, 10),
		os: getOS(),
		osVersion: ua.os.version || ""
	};
	return browserInfo;
}
export { getBrowserInfo as default, getBrowser, getOS, isBrave, isEdge, isMobile, isOpera, isSafari, isWebkit };
