import { __commonJSMin } from "../../virtual/_rolldown/runtime.js";
import { require_js_yaml as require_js_yaml$1 } from "./lib/js-yaml.js";
// node_modules/js-yaml/index.js
var require_js_yaml = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_js_yaml$1();
}));
export { require_js_yaml };
