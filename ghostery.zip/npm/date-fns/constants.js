// node_modules/date-fns/constants.js
/**
* @constant
* @name maxTime
* @summary Maximum allowed time.
*
* @example
* import { maxTime } from "./constants/date-fns/constants";
*
* const isValid = 8640000000000001 <= maxTime;
* //=> false
*
* new Date(8640000000000001);
* //=> Invalid Date
*/
var maxTime = Math.pow(10, 8) * 24 * 60 * 60 * 1e3;
-maxTime;
/**
* @constant
* @name millisecondsInDay
* @summary Milliseconds in 1 day.
*/
var millisecondsInDay = 864e5;
/**
* @constant
* @name millisecondsInMinute
* @summary Milliseconds in 1 minute
*/
var millisecondsInMinute = 6e4;
/**
* @constant
* @name millisecondsInHour
* @summary Milliseconds in 1 hour
*/
var millisecondsInHour = 36e5;
/**
* @constant
* @name constructFromSymbol
* @summary Symbol enabling Date extensions to inherit properties from the reference date.
*
* The symbol is used to enable the `constructFrom` function to construct a date
* using a reference date and a value. It allows to transfer extra properties
* from the reference date to the new date. It's useful for extensions like
* [`TZDate`](https://github.com/date-fns/tz) that accept a time zone as
* a constructor argument.
*/
var constructFromSymbol = Symbol.for("constructDateFrom");
export { constructFromSymbol, maxTime, millisecondsInDay, millisecondsInHour, millisecondsInMinute };
