// node_modules/hybrids/src/template/resolvers/promise.js
var promiseMap = /* @__PURE__ */ new WeakMap();
function resolvePromise(host, target, promise, lastValue, resolveValue, useLayout) {
	const pending = { lastValue };
	promiseMap.set(target, pending);
	promise.then((value) => {
		if (promiseMap.get(target) === pending) {
			resolveValue(host, target, value, lastValue, useLayout);
			pending.lastValue = value;
		}
	});
}
export { resolvePromise as default, promiseMap };
