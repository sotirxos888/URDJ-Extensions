import { __commonJSMin } from "../../virtual/_rolldown/runtime.js";
import { require_kind_of } from "../kind-of/index.js";
//#region node_modules/shallow-clone/index.js
/*!
* shallow-clone <https://github.com/jonschlinkert/shallow-clone>
*
* Copyright (c) 2015-present, Jon Schlinkert.
* Released under the MIT License.
*/
var require_shallow_clone = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var valueOf = Symbol.prototype.valueOf;
	var typeOf = require_kind_of();
	function clone(val, deep) {
		switch (typeOf(val)) {
			case "array": return val.slice();
			case "object": return Object.assign({}, val);
			case "date": return new val.constructor(Number(val));
			case "map": return new Map(val);
			case "set": return new Set(val);
			case "buffer": return cloneBuffer(val);
			case "symbol": return cloneSymbol(val);
			case "arraybuffer": return cloneArrayBuffer(val);
			case "float32array":
			case "float64array":
			case "int16array":
			case "int32array":
			case "int8array":
			case "uint16array":
			case "uint32array":
			case "uint8clampedarray":
			case "uint8array": return cloneTypedArray(val);
			case "regexp": return cloneRegExp(val);
			case "error": return Object.create(val);
			default: return val;
		}
	}
	function cloneRegExp(val) {
		const flags = val.flags !== void 0 ? val.flags : /\w+$/.exec(val) || void 0;
		const re = new val.constructor(val.source, flags);
		re.lastIndex = val.lastIndex;
		return re;
	}
	function cloneArrayBuffer(val) {
		const res = new val.constructor(val.byteLength);
		new Uint8Array(res).set(new Uint8Array(val));
		return res;
	}
	function cloneTypedArray(val, deep) {
		return new val.constructor(val.buffer, val.byteOffset, val.length);
	}
	function cloneBuffer(val) {
		const len = val.length;
		const buf = Buffer.allocUnsafe ? Buffer.allocUnsafe(len) : Buffer.from(len);
		val.copy(buf);
		return buf;
	}
	function cloneSymbol(val) {
		return valueOf ? Object(valueOf.call(val)) : {};
	}
	/**
	* Expose `clone`
	*/
	module.exports = clone;
}));
//#endregion
export { require_shallow_clone };
