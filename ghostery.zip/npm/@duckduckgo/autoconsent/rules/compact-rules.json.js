var s = [
	".c-simple-popup:has(.c-cookie-popup)",
	".c-cookie-popup [data-role=refuse-cookies]",
	".c-cookie-popup",
	"dialog.cookie-consent",
	"dialog.cookie-consent form.cookie-consent__form",
	"dialog.cookie-consent form.cookie-consent__form button[value=no]",
	"dialog.cookie-consent form.cookie-consent__form button.cookie-consent__options-toggle",
	"dialog.cookie-consent form.cookie-consent__form button[value=\"save_options\"]",
	"#abe-gdpr-banner #gdpr-banner-component",
	"#abe-gdpr-banner #gdpr-banner-component-decline-btn",
	"#gdpr-banner-component",
	"#gdpr-banner-component-decline-btn",
	"abeconsent=%221%3A1%2C2%3A0%2C3%3A0%2C4%3A0%22",
	"div[id$=\"_cookie_box\"]:has(a[onclick^=\"accept_\"][onclick*=\"_cookie_box()\"])",
	"div[id$=\"_cookie_box\"] a[onclick^=\"accept_\"][onclick*=\"_cookie_box()\"]",
	".bc-content-modal:has([class*=\"_cookieFooter_\"])",
	".bc-content-modal [class*=\"_cookieFooter_\"]",
	".bc-content-modal [class*=\"_cookieFooter_\"] button:first-child",
	"%222%22%3Afalse",
	"div.acris-cookie-consent",
	"[data-acris-cookie-consent]",
	".acris-cookie-consent.is--modal",
	"#ccAcceptOnlyFunctional",
	"#__cmp_overlay",
	"#__cmp_body",
	"#__cmp_body .cmpButtonLink",
	"#__cmp_body .cmpLayer",
	"#__cmp_body .cmpLayer .vue-js-switch",
	"#__cmp_body .vue-js-switch.toggled .v-switch-input",
	"#__cmp_body .manageLink:not(.buttonDisabled)",
	"#__cmp_body .manageLink",
	"#__cmp_body .rejectLink",
	".adn-window.adn-message",
	".adn-window.adn-message .adn-footer button[onclick*='saveAll(false)']",
	"#cookie-banner",
	"#adopt-controller-button",
	"#adopt-reject-all-button",
	"#adroll_consent_container",
	"#adroll_consent_reject",
	"__adroll_fpc",
	"adstate-settings-component",
	".c-cookie-notice button[data-qa='allow-all-cookies']",
	".c-cookie-notice",
	"button[data-qa=\"reject-non-essentials\"]",
	"serif_manage_cookies_viewed",
	"serif_allow_analytics",
	".amgdprcookie-bar-container",
	".amgdprcookie-bar-container [data-amgdprcookie-js=\"accept\"]:not([disabled])",
	".amgdprcookie-bar-container [data-amgdprcookie-js=\"decline\"]",
	".amgdprcookie-bar-container [data-amgdprcookie-js=\"decline\"]:not([disabled])",
	".amgdprcookie-bar-container [data-amgdprcookie-js=\"settings\"], .amgdprcookie-bar-container [data-amgdprcookie-js=\"custom_settings\"]",
	".amgdprcookie-settings-form",
	".amgdprcookie-settings-form input.amgdprcookie-input:checked:not([disabled])",
	".amgdprcookie-settings-form .amgdprcookie-done",
	"[data-test-id=\"consentModal\"] [data-test-id=\"consentBtn\"]",
	"[data-test-id=\"consentModal\"] button[aria-label=\"Continue without accepting cookies\"]",
	"[data-test-id=\"consentModal\"] button[aria-label=\"Close cookie consent card popup\"]",
	"[data-test-id=\"consentModal\"]",
	"#sp-cc-wrapper,[data-action=sp-cc],span[data-action=\"sp-cc\"][data-sp-cc*=\"rejectAllAction\"]",
	"#sp-cc-wrapper *,[data-action=sp-cc],span[data-action=\"sp-cc\"][data-sp-cc*=\"rejectAllAction\"]",
	"#sp-cc-rejectall-link",
	"#user-consent-management-granular-banner-overlay",
	"[data-testid=granular-banner-button-decline-all]",
	"div:has(> p > a[href='https://www.anthropic.com/legal/cookies'])",
	"div:has(> p > a[href='https://www.anthropic.com/legal/cookies']) button:nth-child(2)",
	"anthropic-consent-preferences",
	"iframe[title='Consent window']",
	"script[src*='cdn.appconsent.io/tcf2-clear/'][src*='core.bundle.js']",
	"iframe[srcdoc*='frame-root']",
	"script[src*='cdn.appconsent.io/tcf2/'][src*='core.bundle.js']",
	"#consent-tracking",
	"#consent-tracking .decline.btn",
	".modal-open bahf-cookie-disclaimer-dpl3",
	"bahf-cookie-disclaimer-dpl3",
	"bahf-cookie-disclaimer-dpl3:not([aria-hidden=true])",
	"cookie_consent=denied",
	".Dialog:has(.ConsentManager)",
	".ConsentManager[data-controller~='consent-manager']",
	".ConsentManager button[data-action*='consent-manager#denyAll']",
	"arto-consent=signature",
	"dialog[data-testid=\"cookie-message-modal\"]",
	"[data-testid=\"cookie-message-bottom-sheet\"]",
	"[data-testid=\"cookie-message-bottom-sheet-overlay\"]",
	"dialog[data-testid=\"cookie-message-modal\"] button[data-testid=\"decline-all-cookies\"], [data-testid=\"cookie-message-bottom-sheet\"] button[data-testid=\"decline-all-cookies\"]",
	"dialog[data-testid=\"cookie-message-modal\"], [data-testid=\"cookie-message-bottom-sheet\"]",
	"#gdpr_area",
	"#gdpr_area .gdpr_area_inner",
	"#gdpr_area .gdpr_btn_agree, #gdpr_area #gdpr_btn_agree",
	"is_gdpr_agree=1",
	"#divCookieInfo",
	"#divCookieInfo #ctl00_CookieInfo_btnLinkNO",
	" - OFF - ",
	"#cookie-policy-info,#cookie-policy-info-bg",
	"#cookie-policy-info button",
	"#cookie-policy-info .btn-reject",
	"#cookie-policy-info .btn-setting",
	"#cookie-policy-info .btn-ok",
	"div[data-popup-cookies][data-terms-cookies-popup-common]",
	"div[data-popup-cookies][data-terms-cookies-popup-common] button[data-cookies=\"disallow_all_cookies\"]",
	"all_marketing_cookies=denied",
	"form[class*=\"a8c-cookie-banner\"][method=\"post\"]",
	"form[class*=\"a8c-cookie-banner\"] div[class*=\"simple-options\"] a[class*=\"customize-button\"]",
	"input[type=checkbox][checked]:not([disabled])",
	"a[class*=\"accept-selection-button\"]",
	".as-oil",
	".AvacyBanner",
	".as-oil, .AvacyBanner",
	".as-oil .as-js-reject-all, .AvacyBanner .as-js-reject-all",
	".as-oil .as-js-close-banner, .AvacyBanner .as-js-close-banner",
	".Avada-CookiesBar__OuterWrapper .Avada-CookiesBar_Container",
	".Avada-CookiesBar__OuterWrapper .Avada-CookiesBar_BtnDeny",
	".Avada-CookiesBar-Preferences__PopUp .Avada-CookiesBar_BtnDeny",
	"\"analytics\":false,\"marketing\":false",
	".fusion-privacy-bar",
	".fusion-privacy-bar .fusion-privacy-bar-reject, .fusion-privacy-bar .fusion-privacy-choices input[type=\"checkbox\"]:not(:disabled)",
	".fusion-privacy-bar .fusion-privacy-bar-reject",
	".fusion-privacy-bar .fusion-privacy-choices input[type=\"checkbox\"]:checked:not(:disabled)",
	".fusion-privacy-bar .fusion-privacy-bar-acceptance",
	"#ACClayerBackground",
	"#ACClayerBackground #ACCsmallCookieLayer",
	"#ACCsmallCookieLayer, #ACCtabedCookieLayer",
	"#ACCsmallCookieLayer",
	"#ACCsmallCookieLayer .kkACCButtonLearnMore",
	"#ACCdetailsSaveButton",
	"#ACCtabedCookieLayer .kkACCSwitchLabel input:checked",
	"#ACCtabedCookieLayer .kkACCSwitchLabel:has(input:checked)",
	"=1000,",
	"#awsccc-cb-content",
	"#awsccc-cs-container",
	"#awsccc-cs-modalOverlay",
	"#awsccc-cs-container-inner",
	"button[data-id=awsccc-cb-btn-decline]",
	"button[data-id=awsccc-cb-btn-customize]",
	"input[aria-checked]",
	"input[aria-checked=true]",
	"button[data-id=awsccc-cs-btn-save]",
	".axeptio_widget,.axeptio_mount",
	".axeptio-widget--open",
	".axeptio_mount .axeptio_widget",
	"%22$$completed%22:false",
	".axeptio_mount .needsclick",
	"button#axeptio_btn_dismiss,button.ax-discardButton,button#axeptio_btn_close",
	"button#axeptio_btn_dismiss,button.ax-discardButton",
	"button#axeptio_btn_close",
	"axeptio_authorized_vendors=%2C%2C",
	"#cookie_consent_wrapper, #cookie_consent_min_wrapper, #manage_cookie_consent_modal",
	"#cookie_consent_wrapper:not(.hideConsent)",
	"#cookie_consent_wrapper #consent_accept_essential, #manage_cookie_consent_modal #modal_consent_accept_essential",
	"#cookie_consent_wrapper.non_cookie_consent_wrapper #js_cookieBannerCloseBtn",
	"#cookie_consent_wrapper #consent_accept_essential",
	"#cookie_consent_wrapper #js_cookieBannerCloseBtn",
	"#manage_cookie_consent_modal #modal_consent_accept_essential",
	"#cookie_consent_min_wrapper #close_minimized_banner",
	"cookieConsent=1",
	"cookieConsent=5",
	".b-cookie.is-open",
	".cookie-alert.t-dark",
	"#cookie-accept-necessary",
	".cookie-alert .checkbox__input:checked:not(:disabled)",
	".cookie-alert__button button",
	"#banner-privacy",
	"#banner-privacy #cb-RejectAll",
	"cookiepolicy=1-",
	"iabbb-cookies-message > section",
	"iabbb-cookies-message",
	"iabbb-cookies-message > section [name='allow-all']",
	"iabbb-cookies-message > section button.bds-button-unstyled",
	"iabbb-cookies-message dialog[open]",
	"iabbb-cookies-message dialog fieldset input[type=radio][value=false]:not(:checked)",
	"iabbb-cookies-message dialog button.bds-button",
	"iabbb-cookies-message > section button.bds-button:not([name])",
	".cookiesgdpr__base:has(.cookiesgdpr__rejectbtn)",
	".cookiesgdpr__base .cookiesgdpr__rejectbtn",
	".cookiesgdpr__base .cookiesgdpr__wrapper",
	"\"analitica\":false",
	"#overlay-policy",
	"#overlay-policy #policy_pop_close .fa-times-circle",
	"#overlay-policy #policy_pop_close",
	"showpopuppolicy=No",
	"beetle-tracking-consent-modal",
	"\"bt_marketing\":false",
	"#consent-manager",
	"#consent-manager button",
	"#consent-manager button:nth-child(2)",
	"tracking-preferences",
	"#bc-cmp-host",
	"#bc-cmp-host-auto",
	"#bigidcmp-banner-widget",
	"bigidcmp-consent-",
	"marketing=false",
	"#bnp_container",
	"#bnp_cookie_banner",
	"#bnp_btn_accept,#bnp_btn_reject",
	"#bnp_btn_reject",
	"AD=0",
	"#cconsent-modal",
	"#cconsent-modal .ccm__footer .consent-givenone",
	"#cconsent-modal.ccm--visible .ccm__footer .consent-givenone",
	"\"wanted\":false",
	".cookie-notification",
	"#blocksy-ext-cookies-consent-styles-css",
	".cookie-notification .ct-cookies-decline-button",
	"blocksy_cookies_consent_accepted=no",
	"#cookie_banner:has(#cookie_essential)",
	"#cookie_banner #cookie_buttons #cookie_essential",
	"#cookie_banner #cookie_essential",
	"#cookie_banner",
	"#CookieConsentContainer:has(#BtnCCPrefs) > .container",
	"#CookieConsentContainer #BtnCCPrefs",
	"#CookieConsentContainer #BtnCCAll",
	"#CookieConsentContainer #BtnCCNone",
	"#CookieConsentPanel #BtnCCSave",
	"#ConsentAnalytics:checked",
	"#ConsentAnalytics",
	"#ConsentThirdParty:checked",
	"#ConsentThirdParty",
	"-saved=true",
	"-analytics=true",
	"#cookie-consent-banner",
	"#ccpa-consent-banner",
	"#cookie-consent-banner [data-id=\"cookie-consent-banner-modal\"]",
	"#cookie-consent-banner .banner-gdpr, #cookie-consent-banner #gdpr-modal",
	"#ccpa-consent-banner [data-id=\"btn-close-ccpa\"]",
	"#cookie-consent-banner [data-id=\"btnGdprRejectAll\"], #cookie-consent-banner [data-id=\"btn-contd-without-accpting\"]",
	"#cookie-consent-banner [data-id=\"pre-banner-btn\"]",
	"#cookie-consent-banner [data-id=\"cookie-consent-banner-modal\"] input[type=\"checkbox\"]:checked:not(:disabled)",
	"#cookie-consent-banner [data-id=\"btn-save-preference\"]",
	"#BorlabsCookieBox",
	"._brlbs-block-content,.brlbs-cmpnt-dialog",
	"._brlbs-bar-wrap,._brlbs-box-wrap,.brlbs-cmpnt-dialog",
	".brlbs-btn-accept-only-essential,a[data-cookie-refuse],.brlbs-btn-save,#CookieBoxSaveButton,.brlbs-cmpnt-close-button[data-borlabs-cookie-actions=\"close-button\"],a[data-cookie-individual]",
	".brlbs-btn-accept-only-essential,a[data-cookie-refuse]",
	".brlbs-btn-save,#CookieBoxSaveButton",
	".brlbs-cmpnt-close-button[data-borlabs-cookie-actions=\"close-button\"]",
	"a[data-cookie-individual]",
	".cookie-preference",
	"input[data-borlabs-cookie-checkbox]:checked",
	"#CookiePrefSave",
	"dock-privacy-settings",
	"#cookie-panel-banner",
	"#cookie-panel-banner-reject-button",
	"no.bouvet.app.cookiepanel-cookie-control",
	"#cconsent-bar",
	"#cconsent-bar .consent-give",
	"#cconsent-bar:not(.ccb--hidden) .consent-give",
	"#cconsent-bar button.consent-decline",
	"#cconsent-bar .ccb__edit",
	"#ccm__footer__consent-modal-submit",
	"#cconsent-modal .ccm__switch-group[aria-checked=\"true\"]",
	"#cconsent-modal input.category-onoff:checked:not(:disabled)",
	"#bsw-consentCookie",
	"#bsw-consentCookie .accept-btn",
	"#bsw-consentCookie .manage-cookies-btn",
	"#bsw-consentCookie .config-banner_section",
	"#bsw-consentCookie input[type=checkbox]:checked:not(:disabled)",
	"x-bsw-consentCookie",
	".cookie-banner #accept_all",
	"#cookies_modal #third_party_cookies_toggle",
	"#third_party_cookies_toggle:checked",
	"#third_party_cookies_toggle",
	"#cookies_modal #save_button",
	".cookie-banner:not(.d-none) #accept_all",
	"third_party_cookies_accepted=False",
	"cookie_banner_hidden=True",
	".cookiebanner--tablist",
	"#cookiebanner[data-cookiebanner]",
	".cookiebanner [data-consent=\"acceptSelection\"]",
	".cookiebanner input[type=\"checkbox\"]:checked:not(:disabled)",
	".cookiebanner input[type=\"checkbox\"]:checked:not(:disabled) + label",
	".bpa-cookie-banner",
	".bpa-cookie-banner .bpa-module-full-hero",
	".bpa-close-button",
	"cookie-allow-tracking=0",
	".cookie-modal",
	"#notice-cookie-block",
	"#notice-cookie-block #cm-selectSpecific",
	"#html-body #notice-cookie-block",
	"#notice-cookie-block #btn-cookie-decline",
	"#notice-cookie-block button[\\@click^='rejectAll']",
	"#btn-cookie-manage",
	"#notice-cookie-block input:checked",
	"#btn-cookie-save",
	"#html-body #notice-cookie-block, #notice-cookie",
	".bwr-cookie.js-cookie",
	".bwr-cookie.js-cookie .js-cookie-trigger",
	".bwr-cookie.js-cookie .bwr-cookie__buttons",
	".bwr-cookie.js-cookie input[data-cookie-option]:checked:not(:disabled)",
	"ZnVuY3Rpb25hbCI6ZmFsc2UsInBlcnNvbmFsaXphdGlvbiI6ZmFsc2V9",
	"#cookieconsent",
	"#cookieconsent .cookiechoices .rejectcookies",
	"ANALYTICALCONSENT=0",
	"MARKETINGCONSENT=0",
	"#cookieBanner.c-banner",
	"#cookieBanner.c-banner button[data-allow-cookies=false]",
	"cookies_allow=false",
	".cassie-cookie-module",
	".cassie-pre-banner",
	"#cassie_pre_banner_text",
	".cassie-reject-all",
	".cc_banner-wrapper",
	".cc_banner",
	".cc-banner[data-cc-banner]",
	".cc-banner[data-cc-banner] button[data-cc-action=reject]",
	".cc-banner[data-cc-banner] button[data-cc-action=preferences]",
	".cc-preferences[data-cc-preferences]",
	".cc-preferences[data-cc-preferences] input[type=radio][data-cc-action=toggle-category][value=off]",
	".cc-preferences[data-cc-preferences] button[data-cc-action=reject]",
	".cc-preferences[data-cc-preferences] button[data-cc-action=save]",
	"#ccm-widget.ccm-show",
	"#ccm-widget",
	"script[src*='ccm19'][src*='/app.js?apiKey=']",
	"#ccm-widget .ccm--decline-cookies",
	"#ccm-widget [data-ccm-modal='ccm-control-panel']",
	"#ccm-control-panel .ccm--save-settings:not([data-full-consent='true'])",
	"#js_cookie-consent-banner",
	"#js_cookie-consent-banner .js_cookie-consent-necessary",
	".cfGdprCookieConsentPopup",
	".cfGdprCookieConsentPopup #cfGdprCookieConsentPopupSettings",
	".cfGdprCookieConsentPopup #cfGdprCookieConsentPopupSaveSettings",
	".cfGdprCookieConsentPopup__settings input[type=checkbox]:checked",
	"CF_GDPR_COOKIE_CONSENT_PERFORMANCE=0",
	"CF_GDPR_COOKIE_CONSENT_SOCIAL=0",
	"CF_GDPR_COOKIE_CONSENT_MARKETING=0",
	".c24-cookie-consent-wrapper",
	".c24-cookie-consent-wrapper .c24-cookie-consent-functional",
	".c24-cookie-consent-notice",
	"[data-modal-content]:has([data-toggle-target^='cookie'])",
	"[data-toggle-target^='cookie']",
	"[data-cookie-dismiss-all]",
	".chefcookie",
	".chefcookie .chefcookie__buttons",
	".chefcookie .chefcookie__box",
	".chefcookie .chefcookie__buttons a[href=\"#chefcookie__decline\"]",
	"hide_prompt=1",
	".gdpr-modal:has(img[src*=\".ciaopeople.it/\"])",
	".gdpr-modal .gdpr-modal__box-top-sx img[src*=\".ciaopeople.it/\"]",
	".gdpr-modal .gdpr-modal__box",
	".gdpr-modal__box-top-dx > button",
	"section[role=\"alert\"]:has(button[aria-label=\"close cookie message\"])",
	"section[role=\"alert\"] button[aria-label=\"close cookie message\"]",
	"#ccc-module,#ccc-overlay,#ccc",
	"#ccc-module,#ccc-notify",
	"#ccc",
	".ccc-reject-button",
	"#ccc-notify .ccc-notify-buttons .ccc-notify-button:not(.ccc-accept-button):not(.ccc-reject-button)",
	"#ccc-module",
	"#ccc-dismiss-button",
	"#ccc-close",
	".cc-individual-cookie-settings",
	".cc-individual-cookie-settings #cookie-settings-reject-all",
	"ckies_cookielaw",
	"#cksModal",
	"#cksModal #cks .cksButtons",
	"#cksModal #cks",
	"#cks .cksLink[onclick*=\"setCksPrefs('0')\"]",
	"CookiePrefs=0",
	"#cl-consent",
	"#cl-consent [data-role=\"b_options\"]",
	".cl-consent-popup.cl-consent-visible [data-role=\"alloff\"]",
	"[data-role=\"b_save\"]",
	"__lxG__consent__v2_daisybit=",
	".consent-modal[role=dialog]",
	"#consent_reject",
	"#manage_cookie_preferences",
	"#cookie_consent_preferences input:checked",
	"#consent_save",
	"ctc_rejected=1",
	"#cookie-notice:has(.cookie-notice-close[onclick^='closeCookieNotice'])",
	"#cookie-notice .cookie-notice-close[onclick^='closeCookieNotice']",
	".cf_modal_container",
	"#cm-wrapper:has(#cm-selectSpecific)",
	"#cookie-consent:has(#cm-selectSpecific)",
	"#cm-selectSpecific",
	"#cm-selectAllCheckboxes",
	"#cm-openSettings",
	".cmCat-checkboxes:checked:not(:disabled)",
	"#coki61 .cok_but1",
	"#coki61",
	"coki61=2",
	"#cu-privacy-notice",
	"#cu-privacy-notice .cu-privacy-notice-close",
	"com-consent-layer",
	"#cmplz-cookiebanner-container",
	"#cmplz-cookiebanner-container .cmplz-cookiebanner",
	".cmplz-cookiebanner .cmplz-deny",
	"cmplz_banner-status=dismissed",
	".cc-type-categories[aria-describedby=\"cookieconsent:desc\"]",
	".cc-type-categories[aria-describedby=\"cookieconsent:desc\"] .cc-dismiss",
	".cc-dismiss",
	".cc-type-categories input[type=checkbox]:not([disabled]):checked",
	".cc-save",
	".cc-type-info[aria-describedby=\"cookieconsent:desc\"]",
	".cc-type-info[aria-describedby=\"cookieconsent:desc\"] .cc-compliance .cc-btn",
	".cc-deny",
	"[aria-describedby=\"cookieconsent:desc\"]",
	".cc-blockingScreen",
	"[aria-describedby=\"cookieconsent:desc\"].cc-type-opt-out",
	"[aria-describedby=\"cookieconsent:desc\"].cc-type-opt-out:not(.cc-invisible)",
	".cmp-pref-link",
	".cmp-body [id*=rejectAll]",
	".cmp-body .cmp-save-btn",
	".cc-type-opt-in[aria-describedby=\"cookieconsent:desc\"]",
	".cc-settings",
	".cc-settings-view",
	".cc-settings-view input[type=checkbox]:not([disabled]):checked",
	".cc-settings-view .cc-btn-accept-selected",
	"#cookie-banner.cookie-banner",
	"#cookie-consent",
	"#cookie-button-settings-accept",
	"#cookie_consent_Necessary",
	"#cookie-button-settings",
	"#cookie_consent_Product:checked, #cookie_consent_Marketing:checked",
	".cookie-consent-card:has([data-cy=cookie-customize])",
	".cookie-consent-card [data-cy=cookie-customize]",
	"#cookie-preferences-dialog [data-cy=cookie-save-preferences]",
	"#cookie-preferences-dialog button[role=switch][aria-checked=true]:not([aria-disabled=true])",
	"_cookieConsent=%7B%22analytics%22%3Afalse%2C%22marketing%22%3Afalse",
	".cookiebanner:has(> #cookieform .chooseCookies)",
	".diffusion_layer:has(#cookieform)",
	".cookiebanner #cookieform .chooseCookies",
	".cookiebanner [onclick^='sendForm(0']",
	".cookiebanner .chooseCookies input[type='checkbox']:checked:not([onclick])",
	".cookiebanner [onclick^='sendForm(1']",
	"._flo-consent-root",
	"._flo-consent-root ._flo-consent-modal-contextual ._flo-consent-button--accept-selected",
	"._flo-consent-root ._flo-consent-modal:not(._flo-consent-modal-contextual)",
	"._flo-consent-modal:not(._flo-consent-modal-contextual) ._flo-consent-button--reject",
	"._flo-consent-button--settings",
	"._flo-consent-modal-contextual ._flo-consent-button--accept-selected",
	"._flo-consent-modal-contextual ._flo-consent-checkbox:checked:not(._flo-consent-checkbox--necessary)",
	"._flo-consent-root._flo-consent-hide",
	".consent-studio .cookie-banner",
	".consent-studio .consent-banner",
	".consent-studio [cs-role=consent-banner]",
	".consent-studio [cs-role=consent-banner] [data-cs-button=reject_all]",
	".consent-studio [cs-role=consent-banner] [cs-consent=reject]",
	".consent-studio [cs-role=consent-banner] .cookie-banner__switch[aria-checked=true]:not([aria-disabled=true])",
	".consent-studio [cs-role=consent-banner] [data-cs-button=save]",
	"consent-studio__storage=[%22functional%22]",
	"#consentaur-banner",
	"#consentaur-banner .consentaur-btn-reject",
	"%22marketing%22%3Afalse",
	".cs-info-bar[class*=\"cs-public-cookie-\"] .cs_action_btn[data-cs_action=\"allow_all\"]",
	".cs-info-bar .cs_action_btn[data-cs_action=\"disable_all\"]",
	".cs-info-bar .options_btn",
	".cs_settings_popup [data-cs_action=\"cs_confirm\"]",
	".cs_settings_popup input.cs_script_action:checked:not(:disabled)",
	"cs_viewed_cookie_policy=",
	"#ncmp__tool .ncmp__banner",
	"#ncmp__tool .ncmp__banner.ncmp__active",
	"ncmp=",
	"csm-cookie-consent",
	"#cookie-information-template-wrapper",
	"#CcpaWrapper",
	"CookieInformationConsent=",
	"cookie-banner-element#ckb",
	"#cookie-bar",
	"#cookie-bar .cookie-bar-frame #decline",
	"#cookie-bar .cookie-bar-frame",
	"cookies-state=decline",
	".spicy-consent-wrapper",
	".spicy-consent-bar",
	".js-decline-all-cookies",
	"#cookie-law-info-bar, #cookie-law-bg, .cli-popupbar-overlay",
	"#cookie-law-info-bar",
	"cookielawinfo-checkbox-non-necessary=yes",
	"#btn-cookie-settings",
	"#notice-cookie-block #allow-functional-cookies, #notice-cookie-block #btn-cookie-settings",
	"#allow-functional-cookies",
	".modal-body",
	".modal-body input:checked, .switch[data-switch=\"on\"]",
	"[role=\"dialog\"] .modal-footer button",
	"#cookie-notice:has(#cookie-notice-accept.cookie-notice__accept--custom)",
	"#cookie-notice #cookie-notice-accept.cookie-notice__accept--custom",
	"#cookie-notice #cookie-notice-reject",
	"#cookie-notice input[type=checkbox]:not(#cookie-checkbox-mandatory, [data-is-mandatory], :disabled):checked",
	"#cookie-notice #cookie-notice-accept",
	"#cookie-popup",
	"#cookie-popup #close-cookies",
	"#cookie-popup #view-all",
	"#cookie-popup:not([class*=\"invisible\"]) #close-cookies",
	"#cookie-popup[class*=\"invisible\"]",
	"acceptedAnalytics=granted",
	"#cookie-popup:has([onclick*=\"cookieNo()\"])",
	"#cookie-popup [onclick*=\"cookieNo()\"]",
	"#cookie-popup:has([onclick*=\"cookieOk()\"]):not(:has([onclick*=\"cookieNo()\"]))",
	"#cookie-popup:not(:has([onclick*=\"cookieNo()\"])) [onclick*=\"cookieOk()\"]",
	"#cookiescript_injected",
	".cookiescript_banner_container [role=dialog]",
	"#cookiescript_injected, .cookiescript_banner_container",
	"#cookiescript_injected, .cookiescript_banner_container [role=dialog]",
	"#cookiescript_reject",
	"#cookiescript_manage",
	".cookiescript_fsd_main, #cookiescript_save",
	".cookiescript_fsd_main",
	"#cookiescript_save",
	"#cookiescript_injected input.cookiescript_checkbox_input:checked:not(:disabled), .cookiescript_banner_container input.cokiescript_checkbox:checked:not(:disabled)",
	"#cookiescript_close, .cookiescript_close_btn",
	"#cookieAcceptBar.cookieAcceptBar",
	"#cbPopupWrap.cb-popup--open",
	"#cbPopupWrap #cbRefuseTrigger",
	"cbDataAccepted=1",
	"#cc--main",
	"html.show--consent #cm, html.show--settings #s-cnt",
	"#s-all-bn",
	"#s-rall-bn",
	"#c-s-bn",
	"#s-bl input.c-tgl:checked:not(:disabled)",
	"#s-sv-bn",
	"cc_cookie=",
	"#cc_div",
	"#cc_div #cm_btns",
	"html.show--consent #cc_div #cm, html.lb-show-cookie-consent #cc_div #cm",
	"#cm_secondary_btn",
	"html.show--settings, html.lb-show-cookie-settings",
	"#cs_blocks input.c_toggle:checked:not(:disabled)",
	"#cs_save__btn",
	"lb_csc=",
	"#cc-main",
	"#cc-main .cm-wrapper",
	".cm__btn[data-role=necessary]",
	".cm__btn[data-role=show]",
	"#cc-main .pm__btn[data-role=necessary]",
	".cc-cookies",
	".cc-cookies .cc-cookie-accept",
	".cc-cookies:not(#cookies_declinedbar) .cc-cookie-accept",
	".cc-cookies .cc-cookie-decline",
	"#cookiefirst-root,.cookiefirst-root,[aria-labelledby=cookie-preference-panel-title]",
	"#cookiefirst-root,.cookiefirst-root",
	"#cookiefirst-root button[data-cookiefirst-action],.cookiefirst-root button[data-cookiefirst-action],#btnAcceptAllCookies,#btnRejectAllCookies,#btnAdjustSettings,[aria-labelledby=cookie-preference-panel-title] button",
	"button[data-cookiefirst-action=reject]",
	"#btnRejectAllCookies",
	"button[data-cookiefirst-action=adjust]",
	"[data-cookiefirst-widget=modal]",
	"button[data-cookiefirst-action=save]",
	".ch2-container",
	".ch2-dialog",
	".ch2-open-settings-btn, .ch2-open-personal-data-btn",
	".ch2-settings",
	".ch2-deny-all-btn",
	".ch2-settings input[type=checkbox]:not([disabled]):checked",
	".ch2-save-settings-btn",
	"cookiehub=",
	".cookieinfo",
	".cookieinfo-close",
	".cookiejs-banner-wrapper",
	".cookiejs-banner-wrapper:not(.modal)",
	".cookiejs-banner-wrapper button.cookiejs-button",
	".cookiejs-banner-wrapper #reject-cookies-btn",
	"analytics_cookies=false",
	".cookiejs-banner-wrapper.modal",
	".cookiejs-banner-wrapper .cookiejs-banner-text",
	".cookiejs-banner-wrapper .cookiejs-banner-li:nth-of-type(2) button",
	"cookiejs_preferences",
	"#cookie-legit-notice-container .cookie-legit-notice",
	"#cookie-legit-notice-container.notice .cookie-legit-notice",
	"#cookie-legit-notice-container .cookie-legit-deny-btn",
	"#cookie-legit-notice-container .cookie-legit-pref-btn",
	"#cookie-legit-notice-container .cookie-legit-save-pref-btn",
	"#cookie-legit-notice-container input[name=cl_tracking]:checked",
	"#cookie-legit-notice-container input[name=cl_marketing]:checked",
	"cl_tracking=false",
	"cl_marketing=false",
	"#cookieman-modal",
	"#cookieman-modal [data-cookieman-save]",
	"#cookieman-modal [data-cookieman-accept-none]",
	"#cookieman-modal [aria-controls=\"cookieman-settings\"]",
	"#cookieman-modal [data-cookieman-form]",
	"#cookieman-modal [data-cookieman-form] input[type=\"checkbox\"]:checked:not(:disabled)",
	"#cookieman-modal [data-cookieman-save]:not([data-cookieman-accept-all]):not([data-cookieman-accept-none])",
	"CookieConsent=",
	"#cp-overlay",
	"#cp-overlay #cp-no a",
	"cookiepermission=no",
	"#eksCookiePrompt",
	"#eksCookiePrompt .cpDontAcceptBtn",
	"#eksCookieNo",
	"cookieOptOut=n",
	"#CookieReportsBanner",
	"#CookieReportsOverlay",
	"#CookieReportsPanel #CookieReportsBanner",
	"#cookiesInfo #closeCookies",
	"#cookiesInfo",
	".cookiesjsr-banner.active",
	".cookiesjsr-banner",
	".cookiesjsr-banner.active .denyAll",
	".cookiesjsr-banner.active .cookiesjsr-settings",
	".cookiesjsr-layer",
	".cookiesjsr-layer .denyAll",
	".cookiesjsr-layer .cookiesjsr-switch.active input",
	".cookiesjsr-layer .save",
	"#CookieConsent dialog.cookie-popup",
	"#CookieConsent dialog.cookie-popup #cc-b-custom",
	"#CookieConsent .actions input[type=checkbox]:checked",
	"#CookieConsent #cc-b-custom",
	".cky-overlay,.cky-consent-container",
	".cky-consent-container",
	".cky-consent-container [data-cky-tag=reject-button]",
	".cky-consent-container [data-cky-tag=donotsell-button]",
	".cky-modal [data-cky-tag=optout-option-toggle]",
	".cky-modal [data-cky-tag=optout-option-toggle]:not(:checked)",
	".cky-modal [data-cky-tag=optout-confirm-button]",
	".cky-modal [data-cky-tag=optout-success]",
	".cky-modal [data-cky-tag=optout-close]",
	".cky-consent-container [data-cky-tag=settings-button]",
	".cky-modal-open input[type=checkbox],.cky-consent-bar-expand input[type=checkbox],.cky-modal-open [data-cky-tag=detail-save-button],.cky-consent-bar-expand [data-cky-tag=detail-save-button]",
	".cky-modal-open input[type=checkbox]:checked,.cky-consent-bar-expand input[type=checkbox]:checked",
	".cky-modal [data-cky-tag=detail-save-button],.cky-consent-bar-expand [data-cky-tag=detail-save-button]",
	".cky-consent-container,.cky-overlay,.cky-consent-bar-expand",
	"advertisement:no",
	"#cky-consent.cky-consent-bar",
	"#cky-consent #cky-btn-reject",
	"#cky-consent #cky-btn-settings",
	"#cky-btn-custom-accept",
	"input[id^=cky-checkbox-category]:checked:not(:disabled)",
	"cky-action=yes",
	"cky-consent=no",
	"cookieyes-analytics=no",
	".elementor-popup-modal:has(.cookiez-footer)",
	".cookiez-footer [data-cookiez-action]",
	".cookiez-footer [data-cookiez-action=\"deny-all\"]",
	"%22analytics%22%3Afalse",
	"dialog:has(#cookie-banner-2025-form)",
	"#cookie-banner-2025-form",
	"button[form=\"cookie-banner-2025-form\"][name=\"accept_cookie\"]",
	"button[form=\"cookie-banner-2025-form\"][name=\"accept_cookie\"][value=\"selection\"]",
	".c-cookie-banner.c-custom-sheet",
	"[id^=\"monetate_selectorHTML\"] > .gdprCookieBanner",
	".c-cookie-banner.c-custom-sheet .c-cookie-banner__close-button",
	"[id^=\"monetate_selectorHTML\"] > .gdprCookieBanner .gdprCookieBannerCloseBtn",
	".c-cookie-banner.c-custom-sheet, [id^=\"monetate_selectorHTML\"] > .gdprCookieBanner",
	".cookiealert",
	".configurecookies",
	".confirmcookies",
	"#gdprMessage button.gdpr-review",
	"[id^=div-transcend-cookie]",
	"#gdprMessage",
	"#btn-transcend-cookie-confirm, #btn-transcend-save",
	"#analyticsNo:not(:checked), #functionalNo:not(:checked), #targetingNo:not(:checked)",
	"#analyticsCookieCheckbox:checked, #preferenceCookieCheckbox:checked",
	"#elc-cookie-consent",
	"#elc-cookie-consent #elc-cookie-consent-form",
	"#elc-cookie-consent:not(.elc-hidden) #elc-cookie-consent-form",
	"#elc-cookie-consent-form input[type=checkbox][name^=\"group-\"]:checked:not([disabled]):not([name$=\"-necessary\"])",
	"#elc-accept-link",
	"#elc-detail-link",
	"#elc-save-link, #elc-accept-link",
	"#elc-save-link",
	"#elc-cookie-consent.elc-hidden",
	"#ct-ultimate-gdpr-cookie-popup",
	"#ct_ultimate-gdpr-cookie-reject a,#ct-ultimate-gdpr-cookie-reject",
	"#ct-ultimate-gdpr-cookie-change-settings",
	"#ct-ultimate-gdpr-cookie-modal-slider-form input[type=radio][value=\"1\"], #ct-ultimate-gdpr-cookie-modal-slider-form input[type=radio][value=\"2\"]",
	"#ct-ultimate-gdpr-cookie-modal-body .save",
	"ct-ultimate-gdpr-cookie=",
	"#cookiebar",
	"#cookiebar .cookiebar-content",
	".cookies-consent:has(.cookies-consent-accept-needed)",
	".cookies-consent .cookies-consent-accept-needed",
	".cookies-consent .cookies-inner",
	"cookiesConsentAllowedServices=",
	"]},{\"type\":",
	".cookie-consent-banner:has(#FormCookieConsentAll)",
	".cookie-consent-banner #FormCookieConsentAll",
	".cookie-consent-banner .btn-cookie-consent-settings",
	".modal-cookie-consent .btn-cookie-consent-modal-disallow-all",
	".cookie-consent-banner",
	".cookie-notice.js-cookie-modal",
	".cookie-notice.js-cookie-modal .js-accept-minimal-cookies",
	"acceptCookiePolicy-marketing=false",
	"div[class*=\"CookiePopup__desktopContainer\"]:has(div[class*=\"CookiePopup\"])",
	"div[class*=\"CookiePopup__desktopContainer\"]",
	".cookie-banner.show .cookie-banner__content-all-btn",
	".cookie-banner__content-essential-btn",
	"[data-module=cookie-consent-banner]",
	"[data-module=cookie-consent-banner] #button-accept-necessary[data-consent-set]",
	"[data-module=cookie-consent-banner] .cookie-consent-banner",
	"[data-module=cookie-consent-banner] #button-accept-necessary",
	"dbconsent=0.1.",
	".dg-consent-banner",
	"datagrail_consent",
	"#datasign_cmp__host",
	"#cookieconsent.cookie-overlay .cookie-buttons #cookie-deny",
	"#cookieconsent.cookie-overlay[style*=\"visibility: visible\"] #cookie-deny",
	"#cookieconsent.cookie-overlay #cookie-deny",
	"CLC_GDPR=AB%3A",
	"#cookie-notice",
	"#cookie-notice :is(#cn-refuse-cookie, #cn-close-notice)",
	"#cookie-notice.cookie-notice-visible #cn-notice-buttons",
	"#cookie-notice #cn-refuse-cookie",
	"#cookie-notice #cn-close-notice",
	"cookie_notice_accepted=false",
	"#didomi-popup,.didomi-popup-container,.didomi-popup-notice,.didomi-consent-popup-preferences,#didomi-notice,.didomi-popup-backdrop,.didomi-screen-medium",
	"#didomi-host",
	"#didomi-popup, #didomi-notice, .didomi-popup-notice, .didomi-notice-banner, #didomi-host:not([aria-hidden=\"true\"]):not(:empty)",
	"#didomi-notice-disagree-button,.didomi-continue-without-agreeing",
	"dnt-cookies",
	"CONSENT=OFF",
	"#cc_modal_dialog",
	"#cc_modal_window",
	"#cc_section_quick_info #cc_accept_all_cookies",
	"#cc_reject_all_cookies",
	"#cc_manage_cookies",
	"#cc_reject_all",
	"#cc_save_preferences",
	"#cc_section_quick_info",
	"cookie_consent=",
	"[data-project=\"mol-fe-cmp\"]",
	"[data-project=\"mol-fe-cmp\"] [class*=footer]",
	"[data-project=\"mol-fe-cmp\"] button[class*=basic]",
	"[data-project=\"mol-fe-cmp\"] div[class*=\"tabContent\"]",
	"[data-project=\"mol-fe-cmp\"] div[class*=\"toggle\"][class*=\"enabled\"]",
	"#mol-ads-cmp-iframe, div.mol-ads-cmp > form > div",
	"div.mol-ads-cmp > form > div",
	"div.mol-ads-ccpa--message > u > a",
	".mol-ads-cmp--modal-dialog",
	"a.mol-ads-cmp-footer-privacy",
	"button.mol-ads-cmp--btn-secondary",
	"[data-testid=\"cookie-banner\"][class*=\"cookie-banner-styles__StyledCookieBanner\"]",
	"[data-testid=\"cookie-banner\"] button[kind=\"BUTTON/FLAT_SECONDARY\"]",
	"cookie_tracking_enabled",
	"#pg-shadow-host-dom",
	".cmp-popup_popup",
	".cmp-app_gdpr",
	".cmp-popup_popup .cmp-intro_rejectAll",
	".cmp-popup_popup .cmp-details_rejectAll",
	"lpubconsent=",
	"#rgpd-popup",
	"#rgpd-custom-popup",
	"#rgpd-popup #rgpd-continue-without-accepting",
	"#rgpd-continue-without-accepting",
	"consentLevel=none",
	"#drupalorg-crosssite-gdpr",
	".no",
	"#d-notification-bar[data-rule-type=\"notification\"]:not([data-rule])",
	"#d-notification-bar[data-rule-type=\"notification\"]:not([data-rule]) .notification-dismiss",
	".showing-message--shown > #d-notification-bar[data-rule-type=\"notification\"][data-visible]:not([data-rule])",
	".showing-message--shown > #d-notification-bar:not([data-rule]) .notification-dismiss",
	".showing-message--shown > #d-notification-bar:not([data-rule])",
	"div[data-testid=cookie-consent-modal-backdrop]",
	"div[data-testid=cookie-consent-message-contents]",
	"button[data-testid=cookie-consent-adjust-settings]",
	"button[data-testid=cookie-consent-preferences-save]",
	"cc_functional=0",
	"cc_targeting=0",
	".cookieconsent form .hidden_accept_all",
	".cookieconsent:not(.hidden) form input[type=submit]",
	"#cookie-consent-deny",
	".cookieconsent form button.button--textual, #cookie-consent-button",
	".cookieconsent .hidden_accept_all[value=no]",
	"#cookie_category_marketing:checked",
	"#cookie_category_marketing",
	".cookieconsent form input[type=submit]",
	"cookie_category_marketing=on",
	"#cookieBox .block-cookie-consent",
	"#cookieBox #consentButton.block-cookie-consent--btn",
	"#cookieBox",
	"#emCookieWrapper",
	"#emCookieWrapper #emCookieBanner",
	"#emCookieBanner",
	"#emCookieBtnConfigure",
	"#emCookieTool #emCookieBtnRejectAll",
	"#emCookieFrame",
	"EducaMadrid_LSSI_Cookies=0",
	".cookieNoticeWrapper",
	".cookieNoticeWrapper #cookieConsentFormAccept input[name^='ee:cookies_']",
	".cookieNoticeWrapper #cookieConsentFormAccept",
	".cookieNoticeWrapper #cookieConsentFormDecline button",
	".cookieNoticeWrapper #cookieConsentFormAccept button",
	"div[role='dialog'][aria-modal='true']:has([data-qa='accept-all-button'])",
	"[data-qa='accept-all-button']",
	"[data-qa='reject-non-essential-button']",
	"#ensNotifyBanner",
	".ensModal",
	"#ensNotifyBanner[style*=block]",
	"#ensModalWrapper[style*=block]",
	"#ensNotifyBanner #ensRejectAll,#ensNotifyBanner #rejectAll,#ensNotifyBanner #ensRejectBanner,#ensNotifyBanner .rejectAll,#ensNotifyBanner #bannerRejectButton,#ensNotifyBanner #ensRejectAds,#ensNotifyBanner #btn-accept-essential-cookies",
	"#ensOpenModal,#modalOpenButton,#bannerOpenModal",
	".ensCheckbox:checked:not(:disabled)",
	"#ensSave,#modalSaveButton,#bannerSave",
	"#ensCloseBanner",
	"epaas-consent-drawer-shell",
	"%22advertising%22%3A0",
	"#emgCookieConsentOverlay",
	"#emgCookieConsentInitialPopup",
	"#emgCookieConsentInitialPopup button.minimal",
	"#cookiebar[data-cookie-name=\"eset_cookie-bar\"]",
	"#cookiebar[data-cookie-name=\"eset_cookie-bar\"] #cc-accept",
	"#cookiebar #cc-decline",
	"#cookiebar #cc-manage",
	"#cookiebar #cc-accept2",
	"#cookiebar .cc-category input[type=checkbox]:checked:not(:disabled)",
	"\"marketing\":0",
	"#gdpr-single-choice-overlay",
	"#gdpr-privacy-settings",
	"button[data-gdpr-open-full-settings]",
	".gdpr-overlay-body input",
	".pea_cook_wrapper,.pea_cook_more_info_popover",
	".pea_cook_wrapper",
	"euCookie",
	"body.eu-cookie-compliance-popup-open",
	".eu-cookie-compliance-banner .decline-button, .eu-cookie-compliance-banner .accept-necessary, .eu-cookie-compliance-save-preferences-button",
	"cookie-agreed=2",
	".eupopup-container",
	".eupopup-container > .eupopup-closebutton",
	"#ez-cookie-dialog-wrapper",
	"#ez-manage-settings",
	"#ez-cookie-dialog input[type=checkbox]",
	"#ez-cookie-dialog input[type=checkbox]:checked",
	"#ez-save-settings",
	"ez-consent-tcf",
	".aspire-banner.marketing-cookies-banner",
	"[data-trk-id=\"reject-marketing-cookies\"]",
	"mktck=false",
	"#fast-cmp-root",
	"iframe#fast-cmp-iframe",
	"fastCMP-",
	"iframe.ck_if",
	"iframe.ck_if[title='Cookie center']",
	"html.ck_panel iframe.ck_if[style*='visibility: visible']",
	"html.ck_panel iframe.ck_if",
	"fedex-gdpr",
	"fedex-gdpr div",
	"fedex-gdpr .fxg-gdpr__reject-all-btn",
	"_svs=",
	".cookies-container:has(.accept-necessary-only-btn)",
	".cookies-container .cookies-banner-non-essential .accept-necessary-only-btn",
	".cookies-container",
	".cookies-container .accept-necessary-only-btn",
	".cookies-container .accept-hide-message-btn",
	".cookies-accepted-container #closeStatusPopUp",
	"_website_cookie_essentialCookies=essentialCookies",
	"_website_cookie_usageCookies=",
	"astro-island[component-url*=\"CookiesBanner\"] .cookies",
	"astro-island[component-url*=\"CookiesBanner\"] .cookies button.cookies__buttons--settings",
	"astro-island[component-url*=\"CookiesBanner\"] .cookies input[name=\"targeting\"]:checked",
	"astro-island[component-url*=\"CookiesBanner\"] .cookies input[name=\"targeting\"]",
	"astro-island[component-url*=\"CookiesBanner\"] .cookies button.cookies__buttons--accept",
	"cookiesPreferences=[%22necessary%22]",
	"#cookie-advice.fv-cookie-advice",
	"#cookie-advice .fv-cookie-advice__message a:not([href]), #cookie-advice .fv-cookie-advice__message button",
	".fv-cookies-management",
	":is(fv-cookies-management-sheet, .modal-content):has(.fv-cookies-management) button[class*=\"--primary\"]",
	"fever_cookies_configuration",
	"#fides-overlay, #fides-overlay-wrapper",
	"#fides-overlay-wrapper #fides-banner",
	"#fides-overlay-wrapper .fides-banner-hidden",
	".fides-banner-button",
	"#fides-banner .fides-reject-all-button",
	".fides-banner:not(.fides-banner-hidden) .fides-reject-all-button",
	"#fides-banner .fides-manage-preferences-button",
	".fides-modal-content .fides-reject-all-button",
	".js-cookie-consent:has(.cookie-consent__accept-essential)",
	".js-cookie-consent .cookie-consent__accept-essential",
	"[fs-consent-element=banner]",
	"[fs-consent-element=banner] [fs-consent-element=allow]",
	"[fs-consent-element=banner] [fs-consent-element=deny]",
	"[fs-consent-element=banner], [fs-consent-element=root]",
	"#first-visit.first-visit",
	"#first-visit.first-visit a.js-first",
	".fp-cookie-modal",
	".fp-cookie-modal .cookie-essentials",
	".fp-cookie-modal a.cookie-essentials",
	"cookie_consent=essentials",
	".dse-cookie-disclaimer",
	".dse-cookie-disclaimer .cta-decline-cookies",
	".dse-cookie-disclaimer.cookie-visible:not(.cookie-hidden) .cta-decline-cookies",
	".dse-cookie-disclaimer.cookie-hidden",
	"%22targeting%22%3Afalse",
	".fc-consent-root,.fc-dialog-container,.fc-dialog-overlay,.fc-dialog-content",
	".fc-consent-root",
	".fc-dialog-container",
	".fc-cta-do-not-consent,.fc-cta-manage-options",
	".fc-li-only-placeholder",
	".fc-preference-consent:checked,.fc-preference-legitimate-interest:checked",
	".fc-confirm-choices",
	"[class*=\"gcb-modal-overlay\"]",
	"[data-gcb-modal-show-prefs]",
	"[data-gcb-modal-save]",
	"gcbcl=a3|m3",
	".overlay_bc_banner",
	"a[href=\"https://gdpr-legal-cookie.myshopify.com/\"]",
	".overlay_bc_banner .banner-body",
	".overlay_bc_banner *[data-cookie-save]",
	"#cookieConsentWidgetDiv .cookie-banner",
	"#cookieConsentWidgetDiv #banner-cookie-consent-reject-all",
	"#banner-cookie-consent-reject-all",
	"g4m_cookie_consent=CONSENT_ESSENTIAL",
	"[data-test-id=\"cookie-banner-body\"]",
	"cookie-banner [data-test-id=\"cookie-banner-body\"] [data-test-id=\"reject-button\"]",
	"[data-test-id=\"cookie-banner-body\"] [data-test-id=\"reject-button\"]",
	".cdk-global-overlay-wrapper:has(pf-confirm-mat-modal a[href*='getproven.com/privacy'])",
	"pf-confirm-mat-modal a[href*='getproven.com/privacy']",
	"#cookie-container .navbar-cookies",
	"#cookie-container #accetta-cookie .cookie-container-setting",
	"#cookie-container",
	"#accetta-cookie input[type=checkbox]:checked:not(:disabled)",
	"#accetta-cookie .accept",
	"acconsenti-cookie=1",
	".cookie-banner[data-available-cookies]",
	".cookie-banner[data-available-cookies] .reject-cookies",
	"CookieConsent=[]",
	"#gtm_privacy",
	"pwinteraction=",
	"[data-aid=FOOTER_COOKIE_BANNER_RENDERED]",
	"[data-aid=FOOTER_COOKIE_BANNER_RENDERED] [data-aid=FOOTER_COOKIE_DECLINE_RENDERED]",
	"[data-aid=FOOTER_COOKIE_BANNER_RENDERED][style*=transform]",
	"a[href^=\"https://policies.google.com/technologies/cookies\"",
	"form[action^=\"https://consent.google.\"][action$=\"/save\"],form[action^=\"https://consent.youtube.\"][action$=\"/save\"]",
	"form[action^=\"https://consent.google.\"][action$=\"/save\"]:has(input[name=set_eom][value=true]) button,form[action^=\"https://consent.youtube.\"][action$=\"/save\"]:has(input[name=set_eom][value=true]) button",
	".glue-cookie-notification-bar",
	".glue-cookie-notification-bar__reject",
	".HTjtHe#xe7COe",
	".HTjtHe#xe7COe a[href^=\"https://policies.google.com/technologies/cookies\"]",
	".HTjtHe#xe7COe button#W0wltc",
	"SOCS=CAE",
	".govuk-cookie-banner__message",
	".govuk-cookie-banner__message .govuk-button",
	"#gravitoCMPRoot",
	"#gravitoCMPRoot [id^=gravito][id$=-layer1-accept-all]",
	"#gravitoCMPRoot [id^=gravito][id$=-layer1-reject-all]",
	"#gravitoCMPRoot [id^=gravito][id$=-layer1-settings]",
	"#gravitoCMPRoot [id^=gravito][id$=-layer2-reject-all]",
	"gravitoData",
	"[data-test=\"modal-cookie-bottom-bar\"], [data-test=\"section-cookieModal\"]",
	"[data-test=\"modal-cookie-bottom-bar\"]",
	"[data-test=\"button-customizeCookie\"]",
	"[data-test=\"modal-cookie-customize\"]",
	"[data-test=\"modal-cookie-customize\"] input[role=\"switch\"]:checked:not([disabled])",
	"[data-test=\"modal-cookie-customize\"] [data-test=\"button-submit\"], dialog:has([data-test=\"modal-cookie-customize\"]) [data-test=\"button-submit\"]",
	"[data-test=\"section-cookieModal\"] [data-test=\"button-customize\"]",
	"[data-test=\"section-customizeModal\"]",
	"[data-test=\"section-customizeModal\"] input[data-ischecked=\"true\"]:not([disabled])",
	"[data-test=\"section-customizeModal\"] [data-test=\"button-save\"]",
	"gpc_ad=0",
	"cp_advertisement=0",
	"#gr-consent-layer-area",
	"#gr-consent-layer",
	"#gr-btn-more-options",
	"#gr-btn-legitimate-partners",
	"#toggleLegitimateCheckbox",
	"#toggleLegitimateCheckbox:not(:checked)",
	"#gr-btn-save-exit-primary",
	".bhh-cookie-banner",
	".bhh-cookie-banner .bhh-cookie-banner__btn--close, .cookie-banner .cookie-banner__btn--close",
	".bhh-cookie-banner__btn--close, .cookie-banner__btn--close",
	"#cookiebanner.cookiebanner__restrictive",
	"#c-cookiebanner.c-cookiebanner",
	".js-banner__container .js-banner-button-confirm-selection",
	".js-banner__container input.js-banner-control__element:checked:not(:disabled)",
	"gsbbanner=closed",
	"#guesty-be-root .cookies__block",
	"#guesty-be-root",
	"#guesty-be-root .cookies__block .cookies__btn--decline",
	"cookiePolicyAccepted=0",
	"div[class^='overlay-cookie-uuid-']",
	"div[class^='overlay-cookie-uuid-'] [class^='button-container-cookie-uuid-']",
	"div[class^='overlay-cookie-uuid-'] [class^='accordion-container-cookie-uuid-']",
	"div[class^='overlay-cookie-uuid-'] button[class*='btn-default-cookie-uuid-']",
	"div[class^='overlay-cookie-uuid-'] input[class^='cookie-uuid-'][id$='-legitimate-interest']",
	"div[class^='overlay-cookie-uuid-'] input[class^='cookie-uuid-'][type='checkbox']:checked",
	".cookies-bar__close-button",
	"%22advertising%22:0",
	"allow_marketing=deny",
	"shb-cookie-consent",
	"shb-cookie-consent [data-testid=\"CookieConsent_modal\"]",
	"shb-cookie-consent [data-testid=\"cookie_consent_accept_only_necessary_btn\"]",
	"shb-cookies-consent=false",
	"#modal-host > div.no-hash > div.window-wrapper",
	"#modal-host > div.no-hash > div.window-wrapper, div[data-testid=qualtrics-container]",
	"#modal-host > div.no-hash > div.window-wrapper > div:last-child a[href=\"/privacy-settings\"]",
	"div#__next",
	"#__next div:nth-child(1) > button:first-child",
	".cookie-modal .cookie-accept-btn",
	".cookie-modal .js-cookie-reject-btn",
	"cookies_rejected=1",
	".cookieModalContent",
	"#cookie-banner-overlay",
	"#manageCookie",
	".cookieSettingsModal",
	"#AOCookieToggle",
	"#AOCookieToggle[aria-pressed=true]",
	"#TPCookieToggle",
	"#TPCookieToggle[aria-pressed=true]",
	"#updateCookieButton",
	"dialog[data-cookie-consent]:has([data-cookie-accept])",
	"dialog[data-cookie-consent] [data-cookie-accept]",
	"a[data-cookie-accept=\"functional\"]",
	"[data-test=\"cookie-consent-notification\"]",
	"[data-test=\"cookie-consent-notification\"] [data-test=\"accept-button\"]",
	"[data-test=\"cookie-consent-notification\"] [data-test=\"dismiss-button\"]",
	"[data-test=\"cookie-consent-notification\"] [data-test=\"settings-button\"]",
	"[data-test=\"cookie-consent-modal\"] [data-test=\"accept-button\"]",
	"#hu.hu-wrapper",
	"#hu.hu-visible",
	"#hu-cookies-save",
	"#hs-eu-cookie-confirmation",
	"#hs-eu-decline-button",
	"body > #idxrcookies",
	"body > #idxrcookies #idxrcookiesKO",
	"#gdpr-cookie-message",
	"#gdpr-cookie-message #gdpr-cookie-advanced",
	"#gdpr-cookie-types",
	"#gdpr-cookie-types input[type=checkbox]:checked:not(:disabled)",
	"#gdpr-cookie-message #gdpr-cookie-accept2",
	"#gdpr-cookie-message #gdpr-cookie-accept",
	"cookieControl=true",
	"#toast-container.ck-tstr #ck_set",
	"#cmp_settings .cmp__button--reject",
	"cmp_ck=3",
	"#ipc_cookie_confirmation",
	"#ipc_cookie_confirmation .cookie_confirmed_and_close",
	"ipc_cookie=confirmed",
	"cookie-consent-element",
	"\"isSelected\":false",
	".q-notifications .q-notification:has(a[href=\"/cookie-policy\"])",
	".q-notifications .q-notification a[href=\"/cookie-policy\"]",
	"module-rgpd-component",
	"cookieConsent=consent_1",
	".accept-cookie",
	".accept-cookie > .accept-cookie-inner",
	"xpath///*[contains(@class, 'accept-cookie')]//*[contains(text(), 'Decline')]",
	"cookie-pref=rejected",
	"[data-preact=\"cookie-banner/index\"] .js-cookiebar",
	"[data-preact=\"cookie-banner/index\"] .js-cookiebar .js-cookie-deny",
	"form.rodo-popup",
	"form.rodo-popup button.rodo-popup-main-settings",
	"form.rodo-popup button.rodo-popup-reject",
	".privacy-consent--backdrop",
	".privacy-consent--modal",
	".footer-config-link",
	"#confirmSelection",
	"#iubenda-cs-banner",
	".iubenda-cs-accept-btn",
	"#iubenda-cs-banner .iubenda-ccpa-opt-out",
	".iubenda-cs-reject-btn",
	".iubenda-cs-customize-btn",
	".iub-btn-reject",
	"#iubFooterBtn",
	"#iubenda-alert .iubenda-button-confirm",
	"#iubenda-cs-banner .iubenda-cs-close-btn",
	"uspString%22%3A%221YY-",
	"body.cookies-request #cookie-bar",
	"body.cookies-request #cookie-bar .disallow-cookies",
	"cookie_permission_granted=no",
	".js-jcookie",
	".js-jcookie .js-jcookie-allow",
	".js-jcookie.active",
	".widget_eu_cookie_law_widget",
	"#jix-cookie-consent-modal",
	"#jix-cookie-consent-modal input.jix-cookie-consent-selection:checked:not(:disabled)",
	"#jix-cookie-consent-accept-selected",
	"div[class^=pecr-cookie-banner-]",
	"button[data-test^=manage-cookies]",
	"label[data-test^=toggle][class*=checked]:not([class*=disabled])",
	"button[data-test=save-preferences]",
	".js-cookie-consent:has(.cookie-consent__settings-save)",
	".js-cookie-consent .cookie-consent__settings-save",
	".js-cookie-consent.cookie-consent--open .cookie-consent__button--secondary",
	".js-cookie-consent .cookie-consent__button--secondary",
	".js-cookie-consent .cookie-consent__option-checkbox:checked",
	".js-cookie-consent.cookie-consent--open",
	".consent-banner:has(.consent-close-icon-wrapper)",
	".consent-banner a.consent-close-icon-wrapper[data-pt-name=\"consent-closed\"]",
	"cbc=true",
	".cookie-bar",
	".cookie-bar .cookie-bar__message,.cookie-bar .cookie-bar__buttons",
	"cookies-state=accepted",
	".consent-banner",
	".consent-banner .consent-banner__actions",
	".consent-banner__actions button.basic-button.secondary",
	".consent-modal__footer button.basic-button.secondary",
	".consent-modal .base-modal__body a",
	"label.consent-switch input[type=checkbox]:checked",
	".consent-modal__footer button.basic-button.primary",
	".ui-dialog[aria-describedby=\"cookies\"]",
	"#cookies > #cookies-info #btnCookiesAll",
	"#cookies-info #btnCookiesReject",
	"#cookies-info #btnCookiesOptions",
	"#cookies-options #btnCookiesSelected",
	"#cookies-options input[type=\"checkbox\"]:checked",
	".gdprPopup:has(> .gdprPopupContainer > .gdprButton)",
	"script#kasp-cookie-alert-js",
	".gdprPopup > .gdprPopupContainer > .gdprButton",
	".gdprPopup",
	".kc-overlay",
	"#kconsent",
	".kc-dialog",
	"#kc-denyAndHide",
	"#lanyard_root div[role='dialog']",
	"#ketch-banner",
	"#ketch-modal",
	"#lanyard_root [class*='ketch-fixed']",
	"#lanyard_root button[aria-label^='Reject' i], #ketch-banner button[aria-label^='Reject' i]",
	"#lanyard_root [aria-describedby=preference-description], #lanyard_root [aria-describedby=modal-description], #ketch-modal, #ketch-purposes-modal, #ketch-preferences",
	"#lanyard_root button[class*=confirmButton], #lanyard_root div[class*=actions_] > button:nth-child(1), #lanyard_root button[class*=actionButton], #ketch-modal button[aria-label='Confirm'], #ketch-purposes-modal button[aria-label='Confirm'], #ketch-modal button[aria-label='Save Settings'], #ketch-purposes-modal button[aria-label='Save Settings']",
	"#ketch-banner-button-tertiary",
	"#lanyard_root [aria-describedby=banner-description]",
	"#lanyard_root div[class*=buttons] > button[class*=secondaryButton], #lanyard_root button[class*=buttons-secondary], #ketch-banner-button-secondary",
	"#lanyard_root [id^='ketch-banner-buttons-container'] > button:only-child",
	"#lanyard_root [aria-describedby=preference-description],#lanyard_root [aria-describedby=modal-description], #ketch-preferences, #ketch-purposes-modal",
	"#lanyard_root button[class*=rejectButton], #lanyard_root button[class*=rejectAllButton], #ketch-modal button[aria-label='Reject All'], #ketch-purposes-modal button[aria-label='Reject All']",
	"#lanyard_root input[type=checkbox][role=switch][aria-checked=true]:not(:disabled)",
	"_ketch_consent_v1_",
	".cc-container.cc-noselect",
	".cc-container .cc-box .cc-section-landing .cc-btn-reject",
	".cc-container.displayed .cc-section-landing",
	".cc-container .cc-section-landing .cc-btn-reject",
	"cookie_consent={\"status\":\"rejected\"",
	"#xp-cookie-banner-root dialog.xp-cookie-banner",
	"#xp-cookie-banner-root dialog.xp-cookie-banner[open]",
	".xp-cookie-banner .xp-cookie-wrapper--buttons button[data-button=\"secondary_cta\"]",
	"klp-marketing-consent=false",
	"body.kolibri [data-testid=\"cookie-widget\"]",
	"body.kolibri [data-testid=\"cookie-widget\"] button.k-button--primary + button.k-button--tertiary",
	"%22advertising%22%3Afalse%2C%22hasConsented%22%3Atrue",
	".consentForm__container",
	".consentForm__root .consentForm__acceptButton[data-accept-action=selected]",
	".consentForm__root",
	".consentForm__optOutItem input:checked",
	".consentForm__acceptButton[data-accept-action=selected] button",
	"optOutAccepted=true",
	"modal-box[data-options*=\"cookies\"] .modal-object--cookie",
	".modal-object--cookie [data-js-cookies-decline]",
	"#kit-ccm",
	".cookie-settings-message",
	".cookie-settings-background",
	".cookie-settings-message #frmCookiesBanner",
	".cookie-settings-message .cookie-settings-message-close-link",
	".cookie-settings-message .cookie-settings-manage",
	"#frmCookiesBanner",
	"#frmCookiesBanner input[type=checkbox]:checked",
	".cookie-settings-message .cookie-settings-message-save-link",
	"#_evh-ric",
	"#_evh-ric #btn_donotaccept",
	"__cpmtAccept=false",
	"#lab-consent",
	"#lab-consent .lab-consent-reject",
	"lab_analytics_consent=denied",
	".lcc-modal.js-lcc-modal-alert",
	".lcc-modal.js-lcc-modal-alert .js-lcc-settings-toggle",
	".lcc-modal.js-lcc-modal-settings",
	".lcc-modal.js-lcc-modal-settings input[type=checkbox]:checked:not(:disabled)",
	".lcc-modal.js-lcc-modal-settings .js-lcc-settings-save",
	"__cookie_consent=false",
	"#lw-widget-root #lw-banner",
	"#lw-widget-root #lw-banner.lw-banner-visible",
	"#lw-banner.lw-banner-visible .lw-consent-reject",
	"#lw-banner.lw-banner-visible",
	"\"marketing\":{\"wanted\":false}",
	"#jmdCookieConsentWrapper",
	"[data-cc-window] [data-cc-popup]",
	"[data-cc-window] [data-cc-popup] [data-cc-action=allow]",
	"[data-cc-window] [data-cc-popup] button[data-cc-action=dismiss]",
	"[data-cc-window] [data-cc-popup] [data-cc-action=close-popup]",
	"cookieconsent_status=dismiss",
	".lia-cookie-banner-alert",
	".lia-cookie-banner-alert .AjaxFeedback",
	".lia-cookie-banner-alert a.lia-cookie-banner-alert-reject",
	"#p_p_id_com_liferay_cookies_banner_web_portlet_CookiesBannerPortlet_",
	"script[src*=\"otSDKStub\"]",
	"#_com_liferay_cookies_banner_web_portlet_CookiesBannerPortlet_declineAllButton",
	"CONSENT_TYPE_PERFORMANCE=false",
	".darken-layer.open,.lightbox.lightbox--cookie-consent",
	"body.cookie-consent-is-active div.lightbox--cookie-consent > div.lightbox__content > div.cookie-consent[data-jsb]",
	".cookie-consent__footer > button[type='submit']:not([data-button='selectAll'])",
	"#lgcookieslaw_banner,#lgcookieslaw_modal,#lgcookieslaw-modal,.lgcookieslaw-overlay,.lgcookieslaw_overlay",
	".lgcookieslaw-reject-button-enabled,#lgcookieslaw-overlay,.lgcookieslaw-overlay",
	".lgcookieslaw-reject-button-enabled .lgcookieslaw-reject-button",
	".lgcookieslaw-reject-button-enabled",
	".artdeco-global-alert[type=COOKIE_CONSENT]",
	".artdeco-global-alert[type=COOKIE_CONSENT] button[action-type=DENY]",
	"#lta-cookies-banner",
	"#js-lta-cookie-modal-trigger",
	"#lta-cookies-modal",
	"#lta-cookies-form input[type=radio][id^=decline-]",
	"#js-lta-cookie-modal-set",
	"%22perf%22:false",
	"#macaron_cookie_box",
	"#macaron_cookie_box .macaronbtn",
	".macaronbtn.refuse",
	".macaronbtn.letmechoose",
	".macaronbtn.letmechoose.open",
	"#cookie_description .paragraph",
	"#cookie_description input[type=checkbox]:checked:not(:disabled)",
	".macaronbtn.confirmselection",
	"_deCookiesConsent",
	".mco-consent-pop-up",
	".mco-consent-slide-up",
	".mco-consent-slide-up__backdrop",
	".mco-overlay:has(.mco-consent)",
	"#mco-consent",
	"[class*=\"mco-consent-\"][class*=\"__button-decline\"]",
	"\"acceptedAll\":false",
	"div[aria-labelledby=pwa-consent-layer-title]",
	"div[class^=StyledConsentLayerWrapper-]",
	"div[aria-labelledby^=pwa-consent-layer-title]",
	"button[data-test^=pwa-consent-layer-deny-all]",
	"#mensajeCookies",
	"#divConfigCookies",
	"#mensajeCookies .cajaCookies #btnAcceptAll",
	"#mensajeCookies #btnAcceptNoAllCookies",
	"#divConfigCookies #btnAcceptNoCookies",
	"#mensajeCookies .cajaCookies",
	"#mensajeCookies #btnConfigCookies",
	"cmm-cookie-banner",
	"#cookies-disclaimer-modal",
	"#cookies-disclaimer-modal #cookies-disclaimer-modal-settings",
	"#cookies-disclaimer-modal #cookies-disclaimer-modal-accept",
	"#cookies-disclaimer-modal-settings",
	"#cookies-settings-modal-header",
	"#cookies-settings-modal-statistics-switch:checked",
	"#cookies-settings-modal-confirm",
	"\"googleAnalytics\":false",
	"[data-testid=\"cookie-policy-dialog\"]",
	"[data-testid=\"cookie-policy-manage-dialog\"]",
	"[data-testid=\"cookie-policy-dialog\"] [data-cookiebanner=\"accept_only_essential_button\"], [data-testid=\"cookie-policy-manage-dialog\"] [data-cookiebanner=\"accept_only_essential_button\"]",
	"[data-cookiebanner=\"accept_only_essential_button\"]",
	".cmp_gdpr .fondo-cmp",
	".cmp_gdpr #btn-gdpr-accept",
	".cmp_gdpr #btn-gdpr-configure",
	".cmp_gdpr .bt-final.footer button.bt-izq-m",
	"cmp-cl=AA",
	"#wcpConsentBannerCtrl",
	"#msCookieBanner",
	"#msCookieBanner.msCookieBanner",
	".bottom-cookie-wrap:has(.js-bottom-cookie-close)",
	".bottom-cookie-wrap .js-bottom-cookie-close",
	"#gdprCookieBar",
	"#gdprCookieBarOverlay",
	".mst-gdpr__cookie-bar-wrapper",
	".mst-gdpr__cookie-bar-overlay",
	".mst-gdpr__cookie-bar .mst-gdpr__buttons",
	".mst-gdpr__buttons [data-trigger-settings=decline],.mst-gdpr__buttons button[\\@click=handleDecline]",
	".mst-gdpr__buttons [data-trigger-settings=decline]",
	".mst-gdpr__buttons button[\\@click=handleDecline]",
	".mst-gdpr__buttons [data-trigger-settings=trigger]",
	".mst-gdpr__buttons button[\\@click=openSettings]",
	"[data-mst-gdpr-settings-apply],.mst-gdpr__cookie-settings--success-btn,[x-on\\:click=save]",
	"input.checkbox[data-group-id]:not([disabled]):checked",
	"[data-mst-gdpr-settings-apply]",
	".mst-gdpr__cookie-settings--success-btn",
	"[x-on\\:click=save]",
	"gdpr_cookie_consent=",
	"#cookies.modal:has(.aceptar-cookies)",
	"#configuracion-cookies.modal",
	"#cookies.modal button[data-bs-target=\"#configuracion-cookies\"]",
	"#cookies.modal .aceptar-cookies",
	"#configuracion-cookies .aceptar-cookies",
	"#configuracion-cookies input[value=analytics-cookies]:checked",
	"#configuracion-cookies input[value=analytics-cookies]",
	"div[role=\"dialog\"]:has(button#necessary[role=\"switch\"]):has(button#marketing[role=\"switch\"]) [role=\"tablist\"]",
	"div[role=\"dialog\"]:has(button#necessary[role=\"switch\"]):has(button#marketing[role=\"switch\"])",
	"div[role=\"dialog\"]:has(button#necessary[role=\"switch\"]) div:not([role=\"tablist\"]) > button:nth-child(3):last-child",
	"decided=true",
	"#__consent .md-consent__inner",
	"#__consent .md-consent__overlay",
	"#__consent form[name='consent'] .md-consent__settings input[type='checkbox']",
	"#__consent:not([hidden]) .md-consent__inner",
	"#__consent .md-consent__settings input[type='checkbox']:checked",
	"#__consent .md-consent__controls button.md-button--primary",
	"#cookiesdirective",
	"#cookiesdirective #explicitreject",
	"dialog[data-testid=accept-our-cookies-dialog]",
	"#banner-manage",
	"#pc-confirm",
	"#moove_gdpr_cookie_info_bar",
	"#moove_gdpr_cookie_info_bar:not(.moove-gdpr-info-bar-hidden)",
	".moove-gdpr-infobar-reject-btn",
	"#moove_gdpr_cookie_info_bar .change-settings-button",
	"#moove_gdpr_cookie_modal",
	".moove-gdpr-modal-save-settings",
	"#msg-cookie:has(#hide-msg-cookie)",
	"#msg-cookie #hide-msg-cookie",
	"#msg-cookie",
	"#cookie_consent_wrapper #cookie_consent.privacy_headsup",
	"#cookie_consent_wrapper #submit_privacy_consent1",
	"#cookie_consent #cookie_only_necessary2",
	"#nhsuk-cookie-banner",
	"#nhsuk-cookie-banner__link_accept",
	".js-ne-piwik-cookies",
	".js-ne-piwik-cookies-overlay",
	".js-ne-piwik-cookies .ne-piwik-cookies__btn-manage",
	".js-ne-piwik-cookies .ne-piwik-cookies",
	".ne-piwik-cookies__btn-manage",
	".ne-piwik-modal__btn-check-choosen",
	".ne-piwik-modal input.ne-piwik-modal__checkbox-input:checked:not(:disabled)",
	"ppms_privacy_",
	"%22analytics%22:{%22status%22:0",
	"ccm-notification",
	".disc-cp--active",
	".disc-cp-modal__modal",
	".js-disc-cp-deny-all",
	".js-occ-gdrp-modal",
	".js-occ-gdrp-modal .js-occ-gdrp-modal__btn-modal-gdpr-settings",
	".js-occ-gdrp-modal.is-visible .js-occ-gdrp-modal__btn-modal-gdpr-settings",
	".js-occ-gdrp-modal .js-occ-gdrp-modal__btn-modal-gdpr-settings:not(.settings-active)",
	".js-occ-gdrp-modal .js-occ-gdrp-modal__btn-modal-gdpr-settings.settings-active",
	".js-occ-gdrp-modal .js-cookie-category:checked",
	"occ_gdpr_settings",
	".tx-om-cookie-consent",
	".tx-om-cookie-consent .active[data-omcookie-panel]",
	"[data-omcookie-panel-save=min]",
	"input[data-omcookie-panel-grp]:checked:not(:disabled)",
	"[data-omcookie-panel-save=save]",
	".legalmonster-cleanslate",
	".legalmonster-cleanslate #lm-cookie-wall-container",
	"#lm-accept-necessary",
	"#CookieBanner.cookie-banner.drawer",
	"#CookieBanner.cookie-banner.drawer.opened",
	".osano-cm-window,.osano-cm-dialog",
	".osano-cm-window",
	".osano-cm-dialog:not(.osano-cm-dialog--hidden)",
	".osano-cm-denyAll,.osano-cm-deny",
	".osano-cm-dialog--type_bar .osano-cm-dialog__close",
	".cookieBanner--visibility",
	".cookieBanner__wrapper",
	".js_cookieBannerProhibitionButton",
	".cookie-banner:has([data-ol-cookie-banner-set-consent])",
	"[data-ol-cookie-banner-set-consent]",
	"[data-ol-cookie-banner-set-consent=essential]",
	"oa",
	".js-cookie-notice:has(#cookie_settings-form)",
	".js-cookie-notice #cookie_settings-form",
	".js-cookie-notice button[value=disable]",
	"#pandectes-banner",
	"pandectes-cmp",
	"#pandectes-banner .cc-deny",
	"#pandectes-banner .cc-settings",
	".pd-cp-ui-rejectAll",
	".pd-cp-ui-save",
	"#passle-cookie-control-container #cookie-control",
	"#passle-cookie-control-container",
	"#passle-cookie-control-container.cookie-control_state--open #cookie-control",
	"#cookie-control .cookie-control--decline",
	"passleCookieControl={%22Accepted%22:false",
	"#ccpaCookieContent_wrapper",
	"#ccpaCookieBanner",
	"#bannerDeclineButton",
	"type%3Dexplicit",
	"#gdprCookieBanner",
	"#gdprCookieContent_wrapper",
	"#overlay > .gdprBackgound",
	"#overlay > .gdprBackgound > .gdprTitle",
	"#overlay > .gdprBackgound > span[onclick]",
	"pxCookie=Y",
	"pe-cookies",
	"TC_PRIVACY=1%40",
	"#consent_block[widget=\"CookieTracker\"]",
	"#consent_block [widget-attachpoint=\"basicAgree\"]",
	".cookie-wrapper .cookie-tip",
	".cookie-wrapper .cookie-tip__container",
	".cookie-wrapper .cookie-tip__text",
	".cookie-wrapper .cookie-tip__button > .button",
	".el-dialog.cookie-dialog",
	".el-dialog.cookie-dialog .el-switch.is-checked",
	".el-dialog.cookie-dialog .el-dialog__footer button.el-button--primary",
	"allow_analysis=%22false%22",
	"allow_analysis=false",
	"#PiwikPROConsentForm-container",
	".PiwikPROConsentForm-overlay",
	"#ppms_cm_popup_overlay",
	"#PiwikPROConsentForm-container, #ppms_cm_popup_overlay #ppms_cm_reject-all, #ppms_cm_popup_overlay #ppms_cm_disagree",
	"#PiwikPROConsentForm-container, #ppms_cm_popup_wrapper",
	"#ppms_cm_reject-all, #ppms_cm_disagree",
	"#ppms_consent_form_success_note_button",
	"#PiwikPROConsentForm-reject-all",
	"#PiwikPROConsentForm-toggle-details",
	"#PiwikPROConsentForm-consents",
	"button.PiwikPROConsentForm-consent-checkbox[aria-checked=true]:not([aria-required=true]), input.PiwikPROConsentForm-consent-checkbox:checked:not(:disabled)",
	"#PiwikPROConsentForm-save",
	"%22status%22:0",
	"[data-cookie-bar]",
	"[data-cookie-bar] [data-cb=\"acceptAll\"]",
	"[data-cookie-bar] [data-cb=\"declineAll\"],[data-cookie-bar] [data-cb=\"saveNecessary\"]",
	"[data-cookie-bar] [data-cb=\"declineAll\"]",
	"[data-cookie-bar] [data-cb=\"saveNecessary\"]",
	"plenty-shop-cookie=",
	"#pmc-pp-tou--notice",
	"aside[aria-labelledby=\"pmc-privacy-banner-heading\"]",
	"aside[aria-labelledby=\"pmc-privacy-banner-heading\"] button",
	"#js-consent-banner",
	"#js-consent-banner #js-cookie-reject-button",
	"#js-consent-banner #js-cookie-dismiss-button",
	"cookie-consent=",
	"#cookie-consent.c-cookie-banner",
	"#cookie-consent.c-cookie-banner .c-cookie-banner__quickform",
	"#cookie-consent .c-cookie-banner__quickform input[name='Purpose.Statistics'][value='False'] ~ input[type='submit']",
	"%22statistics%22%3Afalse",
	"#spopupCont",
	"#spopupCont #poper #cookie-btn.spopupbtnok",
	"#spopupCont #poper",
	".cookiesBanner",
	".cookiesBanner .wrapper-cookies",
	".gdpr-wrapper",
	".gdpr-wrapper .gdpr-cookie-wrapper",
	"#cookie-bar .cb-enable,#cookie-bar .cb-disable,#cookie-bar .cb-policy",
	"#cookie-bar .cb-disable",
	"cb-enabled=accepted",
	".azpp-cookie-consent",
	"\"status\":\"reject_all\"",
	"\"status\":\"do_not_sell\"",
	".privacyArea",
	".privacyArea .privacyTrigger.acceptAll",
	"#modulePrivacy .privacyTrigger.acceptCustom",
	".privacyArea .privacyTrigger.rejectOptional",
	"#modulePrivacy input[type=checkbox]:checked",
	"privacy={\"necessary\":\"ok\"}",
	".c-cookie-banner-main.c-consent-window",
	".c-cookie-banner .c-cookie-banner-main.c-consent-window",
	".c-cookie-banner-main.c-consent-window[style*=\"visibility: visible\"]",
	".c-cookie-banner-main .c-cookie-banner-header-refuse-btn",
	"elmo_vc={\"purposes\":[\"necessary\"]",
	"#cookie-consent-banner #accept-button",
	"#cookie-consent-banner #deny-button",
	"#cookie-consent-banner #manage-settings-button",
	"#manage-cookies #save-button",
	"#pro_euclp_cookies_box",
	"#pro_euclp_cookies_box .pro_euclp_accept",
	"#euCookiesZone .european-union-cookies-agreement",
	"body[data-page-initialized=true]",
	"#euCookiesZone [data-testid=cookieBannerDismiss]",
	"EUCookieOff=t",
	"#pubtech-cmp",
	"#pubtech-cmp #pt-actions",
	"#pubtech-cmp #pt-close",
	"#pubtech-cmp a[href*=\"pubtech_action_reject_all\"]",
	"xpath///div[@id='qtip-growl-container']/div[contains(@class,'qtip-jgrowl')][.//div[contains(@class,'qtip-title')][contains(., 'ookie')]]",
	"xpath///div[@id='qtip-growl-container']/div[contains(@class,'qtip-jgrowl')][.//div[contains(@class,'qtip-title')][contains(., 'ookie')]]//a[contains(@class,'qtip-close')]",
	"#qc-cmp2-main,#qc-cmp2-container",
	"#qc-cmp2-container",
	"#qc-cmp2-ui,#qc-cmp2-usp",
	"#qc-cmp2-usp",
	"#qc-cmp2-usp .qc-cmp2-list-item-header,#qc-cmp2-usp .qc-cmp2-toggle-switch",
	"#qc-cmp2-usp .qc-cmp2-list-item:not(:has(.qc-cmp2-toggle-switch)) > .qc-cmp2-list-item-header",
	"#qc-cmp2-usp .qc-cmp2-toggle-switch",
	"#qc-cmp2-usp .qc-cmp2-toggle-switch > button[aria-checked=\"false\"]",
	"#qc-cmp2-usp .qc-usp-ui-form-content button[mode=\"primary\"]",
	"#qc-cmp2-mspa-success-modal button",
	"#disagree-btn",
	"#disagree-btn:not([disabled])",
	".qc-cmp2-summary-buttons button[mode=\"secondary\"]",
	".qc-cmp2-summary-buttons button[mode=\"secondary\"]:nth-of-type(2)",
	".qc-cmp2-summary-buttons button[mode=\"secondary\"]:nth-of-type(1)",
	"#qc-cmp2-ui .qc-cmp2-consent-info",
	".qc-cmp2-toggle-switch > button[aria-checked=\"true\"]",
	"#qc-cmp2-ui",
	".qc-cmp2-buttons-desktop > button[mode=primary]",
	".cookieconsent-popup:has(.ui-icon-wrench)",
	".cookieconsent-popup .cookieconsent-button-wrap button:has(.ui-icon-wrench)",
	".cookieconsent-edit-settings .cookieconsent-level-changer",
	".cookieconsent-level-changer > a:nth-of-type(2).activated",
	".cookieconsent-level-changer > a:first-of-type",
	".cookieconsent-edit-settings .cookieconsent-dialog-close-btn",
	".cookieconsent-edit-settings .cookieconsent-dialog-close",
	"cookie_consent_level=",
	"cookie_consent_level=tracking",
	"cookie_consent_level=targeting",
	"cookie_consent_level=functional",
	"#consent_iframe",
	"_svs=%7B%22v%22%3A1%2C%22c%22%3A%7B%221%22%3Atrue%2C%222%22%3Afalse%2C%223%22%3Afalse",
	"#r42CookieBar",
	"#r42CookieBar .cw-deny",
	"#r42CookieBar[open] .cw-deny",
	"feature-modular-cookiebanner-variant-one .cookiebanner-container",
	"#modular-cookiebanner-variant-one-consent-level-button-1",
	"feature-modular-cookiebanner-variant-one .cookiebanner-default-consent-button",
	"RABO_PSL=1",
	"[data-component=RADCookieOverlay] .CookieOverlay",
	"[data-component=RADCookieOverlay] .CookieOverlay_Buttons",
	"[data-component=RADCookieOverlay] .CookieOverlay_ButtonGroup > button:nth-child(2)",
	"cookie=False",
	"#raksha-consent-banner",
	"#raksha-consent-overlay",
	"#raksha-decline",
	"#raksha-manage",
	"#raksha-btn-reject",
	"#cookie-policy-notification.r-sdk__policy-notification",
	"#cookie-policy-notification .r-sdk__button",
	"terms-notification=true",
	"#_cpmt-iframe",
	"#concentBanner",
	"#concentPopup",
	"#concentBanner .rdc-save-preferences, #concentPopup .rdc-save-preferences",
	"#concentBanner, #concentPopup",
	"div[consent-skip-blocker=\"1\"][id][data-bg]",
	"div[consent-skip-blocker=\"1\"][id][data-bg] > dialog > div > div > div > div > div > a[role=button][id]",
	"#cookie:has(a.remove_cookie[onclick*=\"/cookie/close\"])",
	"xpath///div[@id='cookie']//a[contains(@class,'remove_cookie') and contains(@onclick,'/cookie/close') and (normalize-space(.)='OK' or normalize-space(.)='x' or normalize-space(.)='×')]",
	"#cookie a.remove_cookie[onclick*=\"/cookie/close\"]",
	"#cookie",
	"#notification-bar:has(> #close-notification[aria-label=\"Sluit de cookiebanner\"])",
	"#notification-bar > #close-notification[aria-label=\"Sluit de cookiebanner\"]",
	"#notification-bar",
	"#notification-bar > #close-notification",
	"cookie_notification_shown=true",
	".consent-banner .consent-banner-copy",
	".consent-banner .consent--manage",
	".consent-modal .consent-bucket",
	".consent-modal input[type=checkbox]:checked",
	".consent-modal .consent-save",
	"dialog[aria-labelledby='cookie-dialog-title']:has(#deny-consent-button)",
	"dialog[aria-labelledby='cookie-dialog-title'] #deny-consent-button",
	"dialog[aria-labelledby='cookie-dialog-title'][open]",
	".sv-cookie-management__banner",
	".sv-cookie-management__banner.sv--visible",
	".sv-cookie-management__banner .sv-manage-cookies",
	".sv-cookie-management__modal--visible",
	"#functional-cookies:checked",
	"label[for='functional-cookies']",
	"#tracking-cookies:checked",
	"label[for='tracking-cookies']",
	".sv-cookie-management__modal--visible .sv-save-close",
	"\"tracking\":false",
	"#scCookieBanner:has(.sc-cookie-reject)",
	"#scCookieBanner .sc-cookie-reject",
	"#scCookieBanner",
	"_consent=denied",
	"[data-module=\"ds-cookie-notification\"]",
	"[data-module=\"ds-cookie-notification\"] .js-accept-essential-cookies",
	"cookiePermissions=eyJuZWNlc3NhcnkiOnRydWUsInByZWZlcmVuY2VzIjpmYWxzZSwic3RhdGlzdGljcyI6ZmFsc2UsImNhbXBhaWducyI6ZmFsc2UsIm1hcmtldGluZyI6ZmFsc2V9",
	".f-cmp-flyout-wrapper .f-gpc-banner",
	".f-cmp-flyout-wrapper .f-gpc-banner .f-banner-close-btn",
	".cc-window",
	".f-gpc-banner .f-banner-close-btn",
	".f-gpc-banner",
	"#gdpr-cookie",
	"#gdpr-cookie .js-allow-required",
	"gdpr-cookie=eyJwcmVmZXJlbmNlIjpmYWxzZSwic3RhdGlzdGljIjpmYWxzZSwibWFya2V0aW5nIjpmYWxzZX0",
	".stpd_cmp_wrapper",
	".stpd_cmp_wrapper .stpd_cmp_form",
	".stpd_cmp_wrapper .stpd_flexed_btns button[type=\"submit\"]",
	".stpd_cmp_wrapper .stpd_flexed_btns button[type=\"button\"]:not(.withdraw_consent)",
	".stpd_cmp_wrapper .stpd_purposes_list",
	".stpd_cmp_wrapper input[type=\"checkbox\"]:checked",
	"euconsent-v2=",
	"#shopify-pc__banner",
	"#shopify-pc__banner__btn-decline",
	".cookie-permission-container[data-cookie-permission]",
	".cookie-permission-container[data-cookie-permission] .js-cookie-configuration-button",
	".cookie-permission-container .js-cookie-permission-button",
	".cookie-permission-container .js-cookie-permission-button button",
	".cookie-permission-container .js-cookie-configuration-button button",
	".js-offcanvas-cookie-submit",
	"cookie-preference=1",
	"footer.pageFooter #cookieBanner.cookieBanner",
	"footer.pageFooter #cookieBanner.cookieBanner.visible",
	".js-top-modal-window-container",
	".js-top-modal-window-container .modal-link[href*='shueisha.co.jp/privacy']",
	".js-top-modal-window-container .js-top-modal-content",
	".js-top-modal-window-container button.close-modal.js-top-modal-close-button",
	"sibbo-cmp-layout",
	"#rejectAllMain",
	"#silktide-banner",
	"#silktide-backdrop",
	"#silktide-banner .reject-all",
	"#silktide-banner .preferences",
	"#silktide-modal .preferences-reject-all",
	".contentRender_name_plugins_common_cookie_banner",
	".contentRender_name_plugins_common_gdpr_banner",
	".contentRender_name_plugins_common_cookie_banner [data-sv-close-banner], .contentRender_name_plugins_common_gdpr_banner [data-sv-close-banner]",
	".contentRender_name_plugins_common_cookie_banner > :has([data-sv-close-banner]), .contentRender_name_plugins_common_gdpr_banner > :has([data-sv-close-banner])",
	".contentRender_name_plugins_common_cookie_banner, .contentRender_name_plugins_common_gdpr_banner",
	"#sd-cmp",
	"#sd-cmp [role='button'][title='Close']",
	".sv-cookie-consent-banner",
	".sv-cookie-consent-banner form:has(input[name=\"necessary\"]):not(:has(input[name=\"analytics\"])) button[type=\"submit\"]",
	".sv-cookie-consent-banner button[type=\"button\"]",
	".sv-cookie-consent-banner button[type=\"submit\"][form]",
	".sv-cookie-consent-banner form input[type=\"checkbox\"]:checked:not(:disabled)",
	".sv-cookie-consent-modal",
	".sv-cookie-consent-modal form:has(input[name=necessary]):not(:has(input[name=analytics])) button[type=submit]",
	".sv-cookie-consent-modal .env-dialog__controls > button[type=button]",
	".sv-cookie-consent-modal button[type=submit][form]",
	".sv-cookie-consent-modal form input[type=checkbox]:checked:not(:disabled)",
	".sv-iw-cookie #cookie-banner",
	".sv-iw-cookie #cookie-banner button:nth-of-type(3)",
	".sv-iw-cookie #cookie-banner button:nth-of-type(2)",
	".sv-iw-cookie #cookie-banner button:first-of-type",
	".sv-iw-cookie #cookie-modal",
	".sv-iw-cookie #cookie-modal input[type=checkbox]:checked:not(:disabled)",
	".sv-iw-cookie #cookie-modal > div > button:first-of-type",
	".w-cookie",
	".w-cookie-modal .w-cookie-actions button[name=accept]",
	".w-cookie-modal .w-cookie-form",
	".w-cookie-modal .w-cookie-option input[type=checkbox]:checked:not([disabled])",
	"cookie_consent=REQUIRED",
	".snigel-cmp-framework",
	"#sn-b-custom",
	"#sn-b-save",
	"snconsent",
	"#cookie_modal",
	"#cookie_modal #id_cookies_necessary",
	"#cookie_modal #id_cookies_all",
	"#cookiebar-tra",
	"#cookiebar-tra #cb-RejectAll, #cookiebar #cb-RejectAll",
	"#cb-RejectAll",
	"cookieConsent=",
	".cookies-banner .cookies-banner__button-group .cookies-banner__reject",
	".cookies-banner .cookies-banner__reject",
	"_SC_analytics=reject",
	"#cookies_message",
	"#cookies-message-modal",
	"#cookies-close-deny, #cookies_frame > #cookies_close",
	"#cookies-close-deny",
	"#cookies_frame > #cookies_close",
	"cookies_message_bar_hidden=true",
	"cookies_google_targeting=false",
	"cookies_message_hidden=true",
	"body > div[id^='sp_message_container_']",
	".cookiebar:has(.cookiebar-ko)",
	".cookiebar .cookiebar-buttons .cookiebar-ko",
	".cookie-banner-mount-point",
	".cookie-banner-mount-point section[aria-label='Cookie banner'] :is(button.decline, button.manage)",
	".cookie-banner-mount-point section[aria-label='Cookie banner']",
	".cookie-banner-mount-point button.decline",
	".cookie-banner-mount-point button.manage",
	".cookie-banner-manager .manage-cookies-overlay",
	".cookie-banner-manager .manage-cookies-overlay label.sqs-toggle--on input",
	".cookie-banner-manager .manage-cookies-overlay button.save",
	".cookie-banner-mount-point section[aria-label='Cookie banner'] button.accept",
	"#cookie-consent-banner #accept-cdp-cookie",
	"#reject-cdp-cookie",
	"squiz.cdp.consent",
	".cookiepreferences_popup",
	"#rejectAllButton",
	"#_psaihm_main_div",
	"#_psaihm_overlay",
	"#_psaihm_main_div #_psaihm_id_accept_all_btn",
	"#_psaihm_refuse_all",
	"#_psaihm_continue_without_accepting",
	"_psac_gdpr_consent_given=1",
	"_psac_gdpr_consent_purposes=;",
	"#GDPRConsentManagerContainer",
	"#GDPRConsentManagerContainer [data-atx-component='cookieConsent']",
	"#GDPRConsentManagerContainer #explicit_consent",
	"#GDPRConsentManagerContainer #ccmgt_explicit_preferences",
	"#GDPRConsentManagerContainer #ccmgt_preferences_reject",
	"CONSENTMGR=c1:0%7Cc2:0%7Cc3:0",
	".js-cookie-banner.cookie-banner",
	".js-cookie-banner.cookie-banner #cookie-banner__settings .js-cookie-settings__form",
	".js-cookie-banner.cookie-banner .cookie-banner__actions .js-cookie-banner-settings-btn",
	"#cookie-banner__settings .js-cookie-settings__form",
	"#cookie-banner__settings .js-cookie-settings__checkbox:checked:not(:disabled)",
	"#cookie-banner__settings .cookie-settings__submit-btn",
	"-consent-necessary=1",
	"#controlled_banner-cookie_consent-consent_banner",
	"#controlled_banner-cookie_consent-privacy_setting_banner",
	"#controlled_banner-cookie_consent-consent_banner [data-search-key-button=reject_all_text]",
	"#controlled_submit-cookie_consent-consent_banner-privacy_setting_banner_link",
	"#controlled_banner-cookie_consent-privacy_setting_banner [data-search-key-button=reject_all_text]",
	"#controlled_banner-cookie_consent-privacy_setting_banner [role=checkbox][aria-checked=true]",
	"#controlled_banner-cookie_consent-privacy_setting_banner [data-search-key-button=save_settings_text]",
	"[data-testid=\"CookiesReminder\"]",
	"[data-testid=\"CookiesReminder\"] [data-testid=\"CookiesManage\"]",
	"body:not(.disable-transition)",
	"dialog[open] .cookies-select-modal",
	"dialog[open] .cookies-select-modal .cookies-select-modal__buttons .ds-btn-apply-2-ds",
	" c=%7B%22essential",
	"div[class*=cookieBanner].pencraft",
	"hideCookieBanner=",
	"#CookieConsentBannerPlaceholder",
	"#CookieConsentBannerPlaceholder .cookies-banner-container",
	".js-consent-modal",
	".js-consent-modal #validate_cookie_btn, .js-consent-modal #validate_cookie_foreign_btn",
	".js-consent-modal .modal-content",
	".js-consent-modal #validate_cookie_foreign_btn",
	".js-consent-modal #unfold_cookie_btn",
	".js-consent-modal .cookie-selection",
	".js-consent-modal .cookie-selection input[type=checkbox]:checked:not(:disabled)",
	".js-consent-modal #validate_cookie_btn",
	"_gtm_consent_prod=",
	".syno_cookie_element",
	".syno_cookie_element .btn_option",
	".syno_cookie_element .scb_dialog_body",
	".syno_cookie_element.scb_dialog input[type=checkbox]:checked:not(:disabled):not([readonly])",
	".syno_cookie_element.scb_dialog .scb_btn_save",
	"syno_confirm_v5_answer",
	"\"targeting\":false",
	"#consent-banner-main",
	"#consent-banner-modal",
	"#consent-banner-modal a[href=\"#reject\"]",
	"#consent-banner-modal a[href=\"#settings\"]",
	"#consent-banner-settings",
	"#consent-banner-settings a[href=\"#reject\"]",
	"#consent-banner-settings input[type=\"checkbox\"]:checked:not(:disabled)",
	"#consent-banner-settings a[href=\"#save\"]",
	"#consent-banner-modal, #consent-banner-settings",
	"div[class^=\"cookies-banner-module_\"]",
	"div[class^=\"cookies-banner-module_cookie-banner_\"]",
	"div[class^=\"cookies-banner-module_small-cookie-banner_\"]",
	"#tarteaucitronRoot",
	"#tarteaucitronAllDenied2",
	"#tarteaucitronCloseAlert",
	".dsgvoaio-checkbox",
	".dsgvoaio-checkbox > input:checked",
	"#tarteaucitronPersonalize",
	"#tarteaucitronAllDenied",
	"#tarteaucitronClosePanel",
	"#taunton-user-consent__overlay",
	"#taunton-user-consent__overlay:not([aria-hidden=true])",
	"#taunton-user-consent__toolbar input[type=checkbox]:checked",
	"#taunton-user-consent__toolbar button[type=submit]",
	"taunton_user_consent_submitted=true",
	"#tccCmpAlert",
	"xpath///span[contains(.,'Accetta solo cookie necessari')]",
	"#__tealiumGDPRecModal,#__tealiumGDPRcpPrefs,#__tealiumImplicitmodal,#consent-layer",
	"#__tealiumGDPRecModal *,#__tealiumGDPRcpPrefs *,#__tealiumImplicitmodal *",
	"#__tealiumGDPRecModal #rejectAll,#__tealiumGDPRcpPrefs #preferences_prompt_reject_all_submit",
	"#__tealiumGDPRecModal,#__tealiumGDPRcpPrefs,#__tealiumImplicitmodal",
	"#cm-acceptNone,.js-accept-essential-cookies,#continueWithoutAccepting,#no_consent,#consent_prompt_decline,#teal-decline-consent,#deny_full_submit_1",
	"#__tealiumGDPRecModal,#__tealiumGDPRcpPrefs > *",
	"div[data-cookie-consent]:has(> button[data-cookie-consent-close])",
	"div[data-cookie-consent] > button[data-cookie-consent-close]",
	"#termly-code-snippet-support",
	"#termly-code-snippet-support div",
	"[data-tid=\"banner-decline\"]",
	".t-preference-button,[data-testid=\"preferences-link\"]",
	".t-declineAllButton",
	".t-preference-modal input[type=checkbox][checked]:not([disabled])",
	".t-saveButton",
	".termsfeed-com---nb",
	".freeprivacypolicy-com---nb",
	".termsfeed-com---nb,.freeprivacypolicy-com---nb",
	".cc-nb-reject",
	".cc-nb-changep",
	"input[cookie_consent_toggler=\"true\"]",
	"input[cookie_consent_toggler=\"true\"]:checked",
	".cc-cp-foot-save",
	".cc_dialog.cc_css_reboot,.cc_overlay_lock",
	".cc_dialog.cc_css_reboot",
	".cc_dialog.cc_css_reboot .cc_b_cp",
	".cookie-consent-preferences-dialog .cc_cp_f_save button",
	"#reject-all",
	"#privacy-test-page-cmp-test",
	"#privacy-test-page-cmp-test-prehide",
	"#privacy-test-page-cmp-test-banner",
	"#tiGDPRecModal,#tiGDPRcpPrefs",
	"#tiGDPRecModal #consent_pref_center",
	"#tiGDPRecModal .privacy_prompt",
	"#consent_pref_center",
	"#tiGDPRcpPrefs .privacy_prompt",
	"#tiGDPRcpPrefs input.cookie-custom-checkbox:checked",
	"#preferences_prompt_submit",
	"c1:0%7Cc3:0%7Cc6:0%7Cc7:0",
	".consent-banner-box",
	"consent-banner[component=consent-banner]",
	"button[data-consent=disagree]",
	"#cmpBanner",
	".tna-cookie-banner",
	".tna-cookie-banner button[value=\"reject\"]",
	".tna-cookie-banner__message--prompt button[value=\"reject\"]",
	".tna-cookie-banner__message--rejected button[value=\"close\"]",
	"cookie_preferences_set=true",
	"%22usage%22%3Afalse",
	"#cookie-banner.visible",
	"#cookie-banner .cookie-banner__container [data-cookie-preferences-button]",
	"#cookie-banner.visible .cookie-banner__container",
	"#ensModalWrapper",
	"#cookie-banner.visible [data-cookie-preferences-button]",
	"#ensModalWrapper #ensSave",
	"#consentModalOverlay",
	"#ensModalWrapper[tabindex]",
	"#ensModalWrapper .ensCheckbox:checked:not(:disabled):not(#EssentialCookiesSlide)",
	"ENSIGHTEN_PRIVACY_TargetingCookies=0",
	".tp-dialog.cookie-dialog",
	".tp-cookie-banner",
	".tp-dialog.cookie-dialog, :not(.tp-cookie-banner-tpl) > .tp-cookie-banner .show-cookie-dialog",
	".tp-dialog.cookie-dialog button",
	":not(.tp-cookie-banner-tpl) > .tp-cookie-banner .show-cookie-dialog",
	".tp-dialog.cookie-dialog .tp-dialog-box",
	".tp-dialog-box .tp-cookie-opt-out",
	".tp-dialog-box .checkbox.clickable.checked",
	".tp-dialog-box .tp-cookie-save",
	"_privacy_banner=1",
	"_privacy_marketing=1",
	".my-cookie-wrapper.cc-window",
	".my-cookie-wrapper [aria-describedby=\"cookieconsent:desc\"] .cc-reject-all",
	".my-cookie-wrapper:not(.cc-invisible) [aria-describedby=\"cookieconsent:desc\"] .cc-reject-all",
	"cookieconsent_dismissed1=reject_all",
	"div.aem-page > div[class^=\"CookiesAlert_cookiesAlert__\"]",
	"#transcend-consent-manager",
	"[class^=\"app_gdpr--\"] button",
	"[class^=\"app_gdpr--\"] div > button:first-of-type:nth-last-of-type(2)",
	"[class^=\"app_gdpr--\"] div > button:nth-of-type(2):nth-last-of-type(2)",
	"tt_cons_addtl=",
	"#shopify-section-cookies-controller",
	"#shopify-section-cookies-controller #cookies-controller-main-pane",
	"#cookies-controller-main-pane a[data-tab-target=manage-cookies]",
	"#manage-cookies-pane.active",
	"#manage-cookies-pane.active input[type=checkbox][checked]:not([disabled])",
	"#manage-cookies-pane.active button[type=submit]",
	"#truendo_container .tru_cookie-dialog_wrapper",
	".tru_cookie-dialog_accept-only",
	".tru_cookie-dialog_accept-only .tru_cookie-dialog_message a[href='']",
	".tru_cookie-dialog_wrapper [data-cy=banner-options-btn], .tru_cookie-dialog_wrapper [data-cy=optionsBtn], .tru_cookie-dialog_wrapper #tru_options_btn",
	"#truendo_container [data-cy=action-button-necessary]",
	"\"adsPermitted\":false",
	".T360PurposeOverviewBanner",
	".T360PurposeOverviewBanner :is(.T360_Banner_Reject, .T360Banner_Reject)",
	"_trust360_=",
	".truste_popframe.trustarc_newcm_container",
	"cmapi_cookie_privacy=permit 1",
	"cmapi_cookie_privacy=permit 1,2",
	"#truyo-consent-module",
	"#truyo-cookieBarContent",
	"button#declineAllCookieButton",
	".react-cookie-policy",
	".react-cookie-policy #cookie-policy",
	"xpath///div[@class='react-cookie-policy']//button[contains(., 'Cookie settings')]",
	"button[role='switch']",
	"xpath///li[contains(., 'Tracking')]//button[@role='switch'][@aria-checked='true']",
	"xpath///li[contains(., 'Advertising')]//button[@role='switch'][@aria-checked='true']",
	"xpath///button[contains(., 'Save and close')]",
	"trybe_cookies_consent_tracking=false",
	"#cookie-onetrust-show-info",
	"#cookie-onetrust-only-necessary",
	"#onetrust-pc-sdk",
	"#onetrust-pc-sdk .ot-pc-refuse-all-handler",
	"#onetrust-pc-sdk input.category-switch-handler:checked",
	"#onetrust-pc-sdk .save-preference-btn-handler",
	"OptanonAlertBoxClosed",
	"iframe.tmblr-iframe--gdpr-banner",
	"[x-data^='cookieNotice('] > .fixed",
	"[x-data^='cookieNotice('][x-data*='tv2reg_cookie_consent']",
	"[x-data^='cookieNotice('] button[\\@click='acceptNecessary'], [x-data^='cookieNotice('] button[x-on\\:click='acceptNecessary']",
	"\"handle\":\"marketing\",\"value\":false",
	"#twcc__mechanism",
	"#twcc__mechanism .twcc__notice",
	"#twcc__decline-button",
	"twCookieConsent=",
	".cookie-notify:has(a[href*=\"cookies_policy\"]) > button.btn, .cookies-policy-block:has(a[href*=\"cookies_policy\"]) > button.btn, .header__cookie:has(a[href*=\"cookies_policy\"]) > button.btn",
	".u-cookie-frame, .modal:has([data-attr='btn-reject-cookies'])",
	".u-cookie-frame [data-attr='btn-reject-cookies'], .modal [data-attr='btn-reject-cookies']",
	".u12-data-protection-notice",
	".u12-data-protection-notice button",
	".u12-data-protection-notice button.js-decline",
	"dialog.cookie-policy",
	"dialog.cookie-policy header",
	"xpath///*[@id=\"modal\"]/div/header",
	"dialog header",
	"button.js-manage",
	"xpath///*[@id=\"cookie-policy-content\"]/p[4]/button[2]",
	"dialog.cookie-policy .p-switch__input:checked",
	"dialog.cookie-policy .js-save-preferences",
	"xpath///*[@id=\"modal\"]/div/button",
	"_cookies_accepted=essential",
	"#politique_confidentialite",
	"#politique_confidentialite #cookies_settings",
	"#cookie_settings a.refuse",
	"UFT_cookie_notice_accepted=%5B%5D",
	"#catapult-cookie-bar",
	".has-cookie-bar #catapult-cookie-bar",
	"catAccCookies",
	".cookie-manager > #cookiebanner",
	"#p-cookie-banner",
	".cookie-manager #cookiebanner #rejectall, #p-cookie-banner #p-cookie-banner__button--reject",
	".cookie-manager > #cookiebanner, #p-cookie-banner",
	"uk-parliament.cookie-policy=eyJhbmFseXRpY3MiOmZhbHNl",
	".cookie-notice-advanced",
	".cookie-notice-advanced .cookie-bar #cookie-save",
	".cookie-notice-advanced .cookie-bar",
	".cookie-notice-advanced input:is(#social-cookies, #advertisement-cookies):checked",
	".cookie-notice-advanced #cookie-save",
	".upcc-cookie-widget",
	".upcc-cookie-widget .upcc-cookie-reject-all",
	".upcc-cookie-widget .js-upcc-view-upcc-cookie-options",
	".upcc-cookie-modal-container .upcc-cookie-reject-all",
	".upcc-cookie-widget, .upcc-cookie-modal-container",
	"up-cookie-consent=true",
	"up-cookie-consent-options=[\"strictly_necessary\"]",
	"#usercentrics-root,#usercentrics-cmp-ui",
	"#usercentrics-cmp-ui",
	"#usercentrics-root",
	"#usercentrics-button",
	"#usercentrics-button #uc-btn-accept-banner",
	"#usercentrics-button #uc-btn-deny-banner",
	"#cookieconsent-window[aria-describedby=\"cookieconsent-desc\"]",
	"#cookieconsent-window[aria-describedby=\"cookieconsent-desc\"] #cookieconsent-dismiss",
	"#cookieconsent-window",
	"#cookie-banner[data-once~='vdg-cookies-block']",
	"#cookie-banner__config",
	"#cookie-banner__reject",
	"%22analytics%22:false",
	"#cookie_consent:has(#cookie_consent_details)",
	"#cookie_consent #cookie_consent_details :is(#functional-cookie-accept, .functional-button)",
	"#cookie_consent #cookie_consent_summary",
	"#cookie_consent_details :is(#functional-cookie-accept, .functional-button)",
	"cookieconsent_status=accept_functional",
	"[data-slot=\"dialog-content\"] a[href*=\"vivenu.com/dataprivacy\"]",
	"[data-slot=\"dialog-content\"]:has(a[href*=\"vivenu.com/dataprivacy\"]) button:nth-of-type(2)",
	".cookie.cookie__floating",
	".cookie.cookie__bar",
	".cookie__floating__buttons__button--accept, .cookie__bar__buttons__button--accept",
	".cookie.cookie__floating, .cookie.cookie__bar",
	".cookie__floating__buttons__button--decline, .cookie__bar__buttons__button--decline",
	"div[aria-labelledby=CookieAlertModalHeading]",
	"section[data-test=initial-waitrose-cookie-consent-banner]",
	"section[data-test=cookie-consent-modal]",
	"button[data-test=manage-cookies]",
	"button[data-test=submit]",
	"wtr_cookies_advertising=0",
	"wtr_cookies_analytics=0",
	".warning.warning--active:has(.warning__apply)",
	".warning:has(.warning__text) .warning__apply",
	"dialog#ltp-dialog, [id=\"id/ltp\"]",
	"dialog#ltp-dialog[open], [id=\"id/ltp/banner\"]",
	"dialog#ltp-dialog",
	"[id=\"id/ltp\"]",
	".fs-cc-components,[fs-cc=banner]",
	"script[src*=\"@finsweet/cookie-consent\"]",
	".fs-cc-components,[fs-cc=banner] [fs-cc=allow]",
	"[fs-cc=banner] [fs-cc=deny]",
	"[fs-cc=banner]",
	"fs-cc",
	".wcc-overlay,.wcc-consent-container",
	".wcc-consent-container",
	".wcc-consent-container [data-tag=reject-button]",
	".wcc-consent-container [data-tag=donotsell-button]",
	".wcc-modal-open [data-tag=optout-option-toggle]",
	".wcc-modal-open [data-tag=optout-option-toggle]:not(:checked)",
	".wcc-modal-open [data-tag=optout-confirm-button]",
	".wcc-consent-container [data-tag=settings-button]",
	".wcc-modal-open [data-tag=detail-save-button],.wcc-consent-bar-expand [data-tag=detail-save-button]",
	".wcc-modal-open [data-tag=detail-category-toggle] input:checked,.wcc-consent-bar-expand [data-tag=detail-category-toggle] input:checked",
	"action:yes",
	"[data-global-privacy-control-banner]",
	"[data-global-privacy-control-banner] > button",
	".mw-cookiewarning-container",
	"[data-gtm-consent-modal]",
	"[data-gtm-consent-modal].gtm-consent__modal--show",
	"[data-gtm-consent-modal] [data-gtm-consent-close]",
	"[data-gtm-consent-modal] [data-gtm-consent-toggle]",
	"[data-gtm-consent-modal] [data-gtm-consent-details-section]",
	"[data-gtm-consent-modal] [data-gtm-consent-types-form] input[type=checkbox]:checked:not(:disabled)",
	"[data-gtm-consent-modal] [data-gtm-consent-submit]",
	"\"analytics_storage\":false",
	"\"ad_storage\":false",
	"div[role=dialog][aria-modal=true][aria-label*='WP']",
	"[data-comp-type=cookie-banner-root-wix],[data-hook=ccsu-banner-wrapper],[data-comp-type=cookie-banner-root-uou]",
	"[data-comp-type=cookie-banner-root-uou]",
	"[data-hook=consent-banner-decline-all-button]",
	"[data-hook=consent-banner-settings-button]",
	"[data-hook=consent-banner-settings-save-button]",
	"[data-hook=consent-banner-section-toggle-input]:checked:not(:disabled)",
	"[data-hook=ccsu-banner-decline-all]",
	"[data-hook=ccsu-banner-wrapper]",
	".wccom-comp-privacy-banner .wccom-privacy-banner",
	".wccom-privacy-banner__content-buttons button.is-style-secondary:has(+ button.is-style-secondary)",
	".wccom-privacy-banner__content-buttons button.is-style-secondary:not([disabled]):has(+ button.is-style-secondary)",
	".wccom-privacy-banner__content-buttons button.is-style-secondary:not([disabled]):has(+ button.is-style-primary)",
	".wccom-modal__footer button.is-style-primary",
	".wccom-customize-privacy-checkbox input[type=checkbox]:checked:not([disabled])",
	".wccom-modal__footer button.is-style-primary:not([disabled])",
	"wccom_cookie_consent_analytics=denied",
	"[data-automation-id=\"legalNotice\"]",
	"[data-automation-id=\"legalNoticeDeclineButton\"]",
	"enablePrivacyTracking=false",
	"#cookieconsentpopup.lp__cookie_tooltip",
	"#cookieconsentpopup .accept-consent",
	"consent_cookie=1",
	"#gdpr-cookie-consent-bar",
	"#gdpr-cookie-consent-bar #cookie_action_reject",
	"wpl_viewed_cookie=no",
	".sp-dsgvo",
	".sp-dsgvo.sp-dsgvo-popup-overlay",
	".sp-dsgvo-popup-overlay .sp-dsgvo-privacy-btn-accept-nothing",
	".sp-dsgvo-popup-overlay .sp-dsgvo-popup-close",
	"integrations%22%3A%5B%5D",
	".wpcc-container",
	".wpcc-container .wpcc-message",
	"#wpconsent-root",
	"#wpconsent-container",
	"wpconsent_preferences=",
	".notice--cookieAdvanced",
	".js-notice.notice--cookieAdvanced #cookieConsentConfig",
	".js-notice.notice--cookieAdvanced",
	".notice--cookieAdvanced a[href*=\"reject=1\"]",
	".notice--cookieAdvanced [data-xf-click=\"toggle\"][data-target=\"#cookieConsentConfig\"]:not(.is-active)",
	"#cookieConsentConfig button[type=\"submit\"]",
	"#cookieConsentConfig input[name^=\"consent[\"]:checked",
	"_consent=%5B%5D",
	".cookie_warn",
	".cookie_warn .cookie_warn_inner",
	"div[class^=cookie-consent-CookieConsent]",
	"#consent-settings-button",
	".consent-banner-button-accept-overlay",
	"userConsent=%7B%22marketing%22%3Afalse",
	"#cookies-use-alert",
	".disclaimer-opened #disclaimer-reject_cookies",
	".disclaimer-opened #disclaimer-cookies",
	"#disclaimer-reject_cookies",
	"#yle-consent-sdk-container .ycd-banner",
	"#yle-consent-sdk-container button[name=accept-necessary-consents]",
	"tp-yt-iron-overlay-backdrop.opened",
	"ytd-consent-bump-v2-lightbox",
	"ytd-consent-bump-v2-lightbox tp-yt-paper-dialog",
	"ytd-consent-bump-v2-lightbox tp-yt-paper-dialog a[href^=\"https://consent.youtube.com/\"]",
	"ytd-consent-bump-v2-lightbox .eom-buttons .eom-button-row:first-child ytd-button-renderer:first-child #button,ytd-consent-bump-v2-lightbox .eom-buttons .eom-button-row:first-child ytd-button-renderer:first-child button",
	".consent-bump-v2-lightbox",
	"ytm-consent-bump-v2-renderer",
	"ytm-consent-bump-v2-renderer .privacy-terms + .one-col-dialog-buttons c3-material-button:nth-child(2) button, ytm-consent-bump-v2-renderer .privacy-terms + .one-col-dialog-buttons ytm-button-renderer:nth-child(2) button",
	"#zdf-cmp-banner-sdk",
	"#zdf-cmp-main.zdf-cmp-show",
	"#zdf-cmp-main #zdf-cmp-deny-btn",
	".cookiewarning:has(> button.cookiewarning_yes.close-button)",
	".cookiewarning > button.cookiewarning_yes.close-button",
	".cookiewarning",
	".c-cookies-notification-banner",
	".c-cookies-notification-banner .c-notification-banner__close-button button",
	".c-cookies-notification-banner .c-notification-banner--open",
	"_acceptCookies=true",
	".cookie-alert-extended",
	".cookie-alert-extended-modal",
	"a[data-controller='cookie-alert/extended/detail-link']",
	".cookie-alert-configuration-input:checked",
	"button[data-controller='cookie-alert/extended/button/configuration']",
	"#piano-cookie_banner",
	"#piano-cookie_banner [data-close-button]",
	"body > div#root > div#ccpa-iframe-theme-provider[data-testid=\"ccpa-iframe-theme-provider\"] > div#ccpa-iframe[data-testid=\"ccpa-iframe\"] > div#ccpa_consent_banner[data-testid=\"ccpa_consent_banner\"] > div:not([id]) > div:nth-child(3):not([id]) > span:not([id]) > span:not([id]) > div:nth-child(2):not([id]) > span:nth-child(1):not([id]) > button#decline_cookies_button[data-testid=\"decline_cookies_button\"]",
	"body:not([id]) > div#banner-0 > div:nth-child(1)#grouped-pageload-Banner > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div#iubenda-cs-banner > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(5):not([id]) > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body > div#ds-cookie-consent-banner > div:not([id]) > div:not([id]) > button:nth-child(4)#reject_optional_cookies",
	"body:not([id]) > div#banner-0 > div:nth-child(1)#grouped-pageload-Banner > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(3):not([id])",
	"body > div:not([id]) > div#clym-app-layout > div:nth-child(2)#clym-notice-layout > div:nth-child(1):not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > div:not([id]) > button:nth-child(1):not([id])",
	"body > div:not([id]) > div#clym-app-layout > div:nth-child(2)#clym-notice-layout > div:not([id]) > div:nth-child(1):not([id]) > div:nth-child(2):not([id]) > div:not([id]) > button:nth-child(1):not([id])",
	"body > div:not([id]) > div#clym-app-layout > div:nth-child(2)#clym-notice-layout > div:nth-child(2):not([id]) > div:nth-child(1):not([id]) > div:nth-child(2):not([id]) > div:not([id]) > button:nth-child(1)#handle-reject-all",
	"body > div#banner-0 > div:nth-child(1)#grouped-pageload-Banner > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(1)#dashboard > div:not([id]) > div:nth-child(2)#dashboard-body-container > div:nth-child(2):not([id]) > button:nth-child(4)#decline-text",
	"body > div:not([id]) > div:nth-child(4):not([id]) > button#cookie_all_reject",
	"body > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2)#cookie_all_reject",
	"body > div:not([id]) > div#clym-app-layout > div:nth-child(2)#clym-notice-layout > div:not([id]) > div:nth-child(1):not([id]) > div:nth-child(2):not([id]) > div:not([id]) > button:nth-child(1)#handle-reject-all",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(1)#dashboard > div:not([id]) > div:nth-child(1):not([id]) > button#decline-text",
	"body:not([id]) > div#root > div#ccpa-iframe-theme-provider > div#ccpa-iframe > div#ccpa_consent_banner > div:not([id]) > div:nth-child(3):not([id]) > span:not([id]) > span:not([id]) > div:nth-child(2):not([id]) > span:nth-child(1):not([id]) > button#decline_cookies_button",
	"body#moneyinvesting > div#top > div#content > div:nth-child(4):not([id]) > a:nth-child(11):not([id])",
	"body > div#banner-0 > div:nth-child(1)#grouped-pageload-Banner > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(3):not([id])",
	"body > div#app > div#app > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > div:not([id]) > button:nth-child(1):not([id]) > div:not([id])",
	"body > div:not([id]) > div:nth-child(1):not([id]) > div:nth-child(4):not([id]) > div:not([id]) > a:nth-child(1)#ipoclick-btn-cookiebar-ik_ga_niet_akkoord_var_a",
	"body > div[id] > div > div > div > div > div:nth-child(3) > span > span > div:nth-child(2) > span:nth-child(1) > button",
	"div[class^=CookieBannerContent__Container]",
	"button[class^=CookieBannerContent__Settings]",
	"div[class^=CookiePreferencesModal__CategoryContainer] input:checked",
	"div[class^=CookiePreferencesModal__ButtonContainer] > button",
	".ecoPrivacyMain .ecoPrivacyButton",
	".ecoPrivacyMain .ecoPrivacyButton:not([disabled])",
	"#app > div[role=alertdialog]",
	"#react-root div[role=alertdialog]",
	"#app > div[role=alertdialog] button .btn-text, #react-root div[role=alertdialog] button .btn-text",
	"#app > div[role=alertdialog], #react-root div[role=alertdialog]",
	"div[role=alertdialog] button:has(.btn-text) + button:has(.btn-text), div[role=alertdialog] > button:has(.btn-text)",
	"pref=%7B%22t%22%3A%22",
	"%22m%22%3Afalse%7D",
	"#overlay.cmp",
	"#overlay[role=dialog]",
	"#deny",
	"#edit-purpose-settings",
	"#save-purpose-settings",
	"ui_cid=OPTOUT",
	"#consentui #buttons .btn.amber",
	"#consentui #buttons .btn.red",
	"#consentui.screen_2 #filters",
	"#consentui #filters input[type=checkbox]:checked",
	"#consentui.screen_2 #buttons .btn.green",
	"#consentManagerButtons .entryPage .settings",
	"#consentManagerEntryPage",
	"#consentManagerButtons .entryPage .declineAll",
	"#consentManagerSettingsPage",
	"#consentManagerButtons .otherPages .declineAll",
	"#gdpr-consent-tool-wrapper",
	"iframe[src^=\"https://cmp-consent-tool.privacymanager.io\"]",
	"button#save",
	"#denyAll",
	".okButton",
	"#manageSettings",
	".purposes-overview-list",
	"button#saveAndExit",
	"span[role=checkbox][aria-checked=true]",
	"#cmp-app-container",
	"#save-all-pur",
	"#reminder",
	".wd-cookie-banner.x-cookie-open",
	".wd-cookie-banner",
	".wd-cookie-banner.x-cookie-open .wd-cookie-banner__header__close",
	"adc-cookie-banner",
	"cookie_banner=closed",
	"[data-component=CookieBanner]",
	"[data-component=CookieBanner] [data-component=CookieBanner_AcceptAll]",
	"[data-component=CookieBanner] [data-component=CookieBanner_AcceptABCRequired]",
	"trackingconsent",
	".fc-consent-root .fc-dialog-container",
	"[data-testid=\"cookies_reject\"]",
	"#__next > div:has(> p > a[href*='cookie-policy'])",
	"xpath///div[@id='__next']/div[h2[normalize-space(.)='Cookies on this website']]",
	"xpath///div[@id='__next']/div[h2[normalize-space(.)='Cookies on this website']]//button[contains(., 'do not use analytics cookies')]",
	"#cookie-consent-banner #cookie-consent-accept",
	"#cookie-consent-accept",
	"cookie-consent=1",
	"aside#cookies,.overlay-cookies",
	"#cookies .cookies-btn",
	"#cookies #submitCookies",
	"#cookies #rejectCookies",
	".fullpageCover",
	".fullpageCover a[href*='/go/page/privacy.html']",
	".fullpageCover div.rounded-full:nth-child(2)",
	"#popup_cookies",
	"#popup_cookies .boton_cookies",
	"#cookies_consent_div",
	"#popup_content.cookies_consent_div .config_cookies",
	"#popup_content #configurar_cookies",
	"#popup_content .cookie_button:not(.cookies_tecnicas) input[type=checkbox]:checked",
	"#popup_content .not_explanation.aceptar_cokies",
	"#cookie-overlay",
	"#decline-cookies",
	"[data-testid=\"main-cookies-banner-container\"]",
	"[data-testid=\"main-cookies-banner-container\"] section > div > div:nth-child(2) > div:nth-child(2) > button",
	"#aag-cookie-consent",
	"#gdpr-new-container",
	"#gdpr-new-container,#voyager-gdpr > div,#voyager-gdpr-2025 > div > div > button",
	"#voyager-gdpr > div",
	"#voyager-gdpr > div > div > button:nth-child(2)",
	"#voyager-gdpr-2025 > div > div > button",
	"#voyager-gdpr-2025 > div > div > button:nth-of-type(3)",
	"#voyager-gdpr-2025 > div > div > button:nth-of-type(2)",
	"#voyager-gdpr-2025 > div > div > button:last-of-type",
	"#voyager-gdpr-2025 > div > div > div > button:last-of-type",
	"#gdpr-new-container button:nth-of-type(3)",
	"#gdpr-new-container button:nth-of-type(2)",
	"#gdpr-new-container button:first-of-type",
	"#voyager-gdpr-2025",
	"#voyager-gdpr-2025 button:last-of-type",
	".cookie-message",
	".cookie-message .cookie-agree",
	"div:has(> div > button[allytmln=ally-cookie-consent])",
	"button[allytmln=ally-cookie-consent]",
	"#banner",
	"#banner #bannerFooter music-button",
	"#banner #bannerFooter",
	".cookie-menu.js-cookie-banner",
	".cookie-menu.js-cookie-banner .js-cookie-banner-close",
	"apaycnst-mktg=true",
	"#cookie-agreement",
	"#cookie-agreement .dismiss",
	"#a69-cookie-banner",
	"#a69-cookie-banner #a69-cookie-manage",
	"#a69-cookie-manage",
	"#a69-cookie-modal",
	"#a69-cookie-analytics:checked",
	"#a69-cookie-save",
	"a69_cookie_preferences=%7B%22analytics%22%3Afalse",
	"#arb-cookie-banner-section",
	"#arb-cookie-banner-section button",
	"#arb-cookie-banner-section button:first-of-type",
	"xpath///div[@role='dialog'][.//h2[normalize-space(.)='This website uses cookies']]",
	"xpath///div[@role='dialog'][.//h2[normalize-space(.)='This website uses cookies']]//button[normalize-space(.)='Manage Cookies']",
	"[role='dialog'] button[role='switch']#advertising",
	"[role='dialog'] button[role='switch'][aria-checked='true']",
	"xpath///div[@role='dialog'][.//button[@role='switch']]//button[normalize-space(.)='Save Preferences']",
	"\"advertising\":false",
	"#cookiePolicy",
	"#cookiePolicy #cookiebar-btn",
	"cookie policy accepted=",
	"#footer-container ~ div",
	"#footer-container > div",
	"#gpc-banner-container",
	"\"consent\":\"d\"",
	"form.test-cookie-consent",
	"form.test-cookie-consent [data-cookie-consent-target=\"screen1\"]",
	"form.test-cookie-consent [data-action=\"cookie-consent#showSettings\"]",
	"form.test-cookie-consent [data-cookie-consent-target=\"screen2\"] [data-action=\"cookie-consent#rejectAll\"]",
	"%22ad_storage%22%3Afalse",
	"body > div#shopify-section-popups > div:nth-child(1):not([id]) > modal-box#modal-popups-0 > div:nth-child(1):not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div#cookieNotice > span:not([id])",
	"body > div#cookieAreaBase > div#cookieArea > p:nth-child(1):not([id]) > a:nth-child(3):not([id])",
	"body > div#cookieAreaBase > div#cookieArea > div:nth-child(2):not([id]) > a:nth-child(2):not([id])",
	"body > div:not([id]) > div:nth-child(4):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body#customcss > div#root > div:nth-child(4):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(1):not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:not([id]) > span:nth-child(1):not([id]) > div:nth-child(5):not([id]) > button:nth-child(2):not([id])",
	"body > div#cookieConsentModal > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > div:not([id]) > button:nth-child(2):not([id])",
	"body > div#cookie-banner-deezer > div#gdpr-dir-tag > div:not([id])[data-testid=\"cookie-banner\"] > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button#gdpr-btn-refuse-all[data-testid=\"gdpr-btn-refuse-all\"]",
	"body:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body:not([id]) > div:not([id]) > div#gdpr_notification_container > div:not([id]) > div:nth-child(1):not([id]) > div:not([id]) > div:nth-child(6):not([id]) > div:not([id]) > a#gdpr_reject_button",
	"#cookiesPortletDiv",
	"#cookiesPortletDiv .cookie-buttons",
	"#cookiesPortletDiv button[aria-label='Only Mandatory']",
	"body > div#cookie-policy > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	".MuiStack-root:has(a[href='/privacy']):has(button)",
	"body > div#portal-cookie-banner > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2)#portal-cookie-banner__wrapper > aside#portal-cookie-banner__content > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div#messages > div:nth-child(1)#shopify-section-cookie-banner > section#shopify-section-cookie-banner > div:nth-child(1):not([id]) > button:nth-child(2):not([id])",
	"body > div#messages > div:nth-child(2)#shopify-section-newsletter-banner > section:nth-child(1):not([id]) > div:not([id]) > button:nth-child(1):not([id])",
	"body > form#trackingConsent > button:nth-child(2):not([id])",
	"body:not([id]) > div#cookieConsent > div:nth-child(2):not([id]) > a:nth-child(3):not([id])",
	"body > pnp-root:not([id]) > div:not([id]) > ui-storefront:not([id]) > footer:nth-child(8):not([id]) > cx-page-layout:not([id]) > cx-page-slot:not([id]) > cms-popia-component:nth-child(3):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body > div#___gatsby > div:nth-child(1)#gatsby-focus-wrapper > div:nth-child(3):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(1):not([id]) > button:not([id])",
	"body > div#layout-fea-0-bd-5-e-e-723-4027-aa-78-dbcc-846073-a-6 > div#page-62928 > div:not([id]) > div:nth-child(8)#\\31 e9783d2-3575-4c86-b6e8-bc0fd6b17307 > div#\\31 e9783d2-3575-4c86-b6e8-bc0fd6b17307-banner > div:nth-child(3):not([id]) > a:nth-child(1)#\\31 e9783d2-3575-4c86-b6e8-bc0fd6b17307-decline",
	"body > div:not([id]) > div:not([id]) > div:nth-child(1):not([id]) > div#c-cookiebanner > section:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(4):not([id]) > p:nth-child(1):not([id]) > button:not([id])",
	"body > div#wrapper > div:nth-child(4):not([id]) > button:nth-child(3):not([id])",
	"body > div#frame-modals > div:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body > div#message-banner > div:not([id]) > div:nth-child(2):not([id]) > button:not([id])",
	"body > div#cookiemodal > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > div:nth-child(5)#footer-cookie-buttons > a:nth-child(2)#footer-cookie-close",
	"body > div#notice-cookie-block > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:not([id])",
	"body > div#termsfeed-pc1-notice-banner > div:nth-child(2):not([id]) > div:not([id]) > div:nth-child(3):not([id]) > div:not([id]) > button:nth-child(2)#termsfeed_privacy_consent_banner_button_reject_all",
	"body > main:not([id]) > div:nth-child(1):not([id]) > div:not([id]) > button:nth-child(2):not([id])",
	"body:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > div:nth-child(1):not([id]) > button:nth-child(2):not([id])",
	"body > hathi-cookie-consent-banner:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div#cookies-modal > div:nth-child(2)#consent-modal > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(1):not([id]) > span#consent-modal-refuse",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div#csm-wrapper > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div#root > div:nth-child(3):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:nth-child(1):not([id]) > div:nth-child(1):not([id]) > button:not([id])",
	"body > div#body-wrapper > section:nth-child(5):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > button:nth-child(2):not([id])",
	"body > div#wrapwrap > div:nth-child(5)#website_cookies_bar > div:not([id]) > div:not([id]) > div:not([id]) > section:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > a:nth-child(1)#cookie-banner-essential",
	"body > aside:not([id]) > div:nth-child(2)#cookie-consent-modal > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body:not([id]) > div#cc--main > div#cc_div > div:nth-child(1)#cm > div#c-inr > div:nth-child(2)#c-bns > button:nth-child(2)#c-s-bn",
	"body > div#dk-cookie-message > div:not([id]) > button:nth-child(3):not([id])",
	"body > aside:not([id]) > div:nth-child(1):not([id]) > div:not([id]) > div:nth-child(3):not([id]) > div:nth-child(2):not([id]) > button:nth-child(3):not([id])",
	"body:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > a:nth-child(3):not([id])",
	"body > div:not([id]) > div:not([id]) > div#ch2-settings-dialog > div:nth-child(3):not([id]) > div:nth-child(1)#ch2-settings > button:nth-child(4):not([id])",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > a:nth-child(3):not([id])",
	"body:not([id]) > div#cookieConsentBanner > div#cookieConsentContent > button:nth-child(4)#closeConsentBanner",
	"body:not([id]) > div#cookies-modal > div:nth-child(2)#consent-modal > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(1):not([id]) > span#consent-modal-refuse",
	"body > div:not([id]) > a:nth-child(3):not([id])",
	"body > div#root > div:nth-child(2):not([id]) > div:nth-child(5):not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div#tna-cookie-prompt-banner > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2)#reject-cookie",
	"body > div#ecom2-spa-root > div:nth-child(4)#layout-grid > div:nth-child(4)#main-content-v2 > div:nth-child(2):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])[data-testid=\"cookie-btn-deny\"]",
	"body > div:not([id]) > div:not([id]) > button:nth-child(5):not([id])",
	"body > div:not([id]) > div:nth-child(3):not([id]) > div:nth-child(1):not([id]) > div:nth-child(2):not([id]) > a:not([id])",
	"body > div#gdprCookieBar > div:not([id]) > div:nth-child(1):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(3):not([id])",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body:not([id]) > div#c-footerBrandV1 > footer:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div#ez-cookie-notification > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(1)#ez-cookie-notification__decline",
	"body > div#site-wrapper > div:nth-child(1)#site-canvas > div#wrapper1 > main:nth-child(2)#mainSection1 > div:nth-child(3):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(2)#cookieadmin_reject_button",
	"body > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > div:not([id]) > button:not([id])",
	"body > div#privacy-cookie-banners-root > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id])[data-testid=\"CookieBanner\"] > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(1):not([id])",
	"body > div:not([id]) > form:nth-child(1):not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:nth-child(2):not([id]) > div#oax-dialog-main > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > aside#cmp-banner > form:not([id]) > div:nth-child(4):not([id]) > section:not([id]) > div:not([id]) > button:nth-child(1)#cmp-deny-all",
	"body > main#main > div:nth-child(6):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > div:nth-child(1):not([id]) > a:not([id])",
	"body > div:not([id]) > div:nth-child(3):not([id]) > div:nth-child(1):not([id]) > button:nth-child(2):not([id])[data-testid=\"s-r-bu\"]",
	"body > div#consent_manager-background > div:nth-child(1)#consent_manager-wrapper > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2)#consent_manager-accept-none",
	"body > div#ampsandConsentElement > div:nth-child(1):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(3):not([id])",
	"body > section#cookie-consent > div:not([id]) > form:nth-child(3):not([id]) > div:nth-child(5):not([id]) > button:nth-child(1):not([id])",
	"body > div:not([id]) > div#cookie-banner > div:nth-child(2):not([id]) > button:nth-child(2)#cookie-banner-reject",
	"body > privacy-banner:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id]) > span:not([id])",
	"body > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:not([id]) > div:nth-child(1):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > button:nth-child(1)#hw-cc-notice-deny-btn",
	"body > div#cookieconsent > div#cookieconsent-bar > div:nth-child(3):not([id]) > a:nth-child(2)#decline",
	"body > header#header > div:nth-child(1)#CookiesConsent > div:not([id]) > div:nth-child(2):not([id]) > form:nth-child(2):not([id]) > div:nth-child(5):not([id]) > button:not([id])[data-testid=\"AcceptRequiredCookies\"]",
	"body > div:not([id]) > div:nth-child(1)#ccm-widget > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body > div#cookieChoiceInfo > div:nth-child(2)#cookieButtonBar > a:nth-child(2)#cookieChoiceRefuse",
	"body > dialog:not([id]) > div:nth-child(1):not([id]) > div:nth-child(3):not([id]) > div:nth-child(2):not([id]) > button:not([id])",
	"body > div#consent-manager > div:nth-child(1)#consent-banner > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > div:not([id]) > div:nth-child(3):not([id]) > button#consent-banner-btn-close",
	"body > div#orejime > div:nth-child(1):not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > ul:nth-child(2):not([id]) > li:nth-child(2):not([id]) > button:not([id])",
	"body > section#cookie-policy > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body > div#cbgccp-cookies-banner > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > button:nth-child(2)#cbg_ccp_cookie_refuse_optional_btn",
	"body > div > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(5):not([id]) > button:nth-child(1)#fd-unCheckAll",
	"body > div:not([id]) > div#csm-wrapper > div:not([id]) > div:not([id]) > div:nth-child(1):not([id]) > div:nth-child(2):not([id]) > div:not([id]) > button:nth-child(2):not([id])",
	"body > div#__next > div:nth-child(5):not([id]) > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div#__next > div:nth-child(5):not([id]) > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(1):not([id])",
	"body > dialog:not([id]) > article:not([id]) > footer:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div#entry > div:nth-child(2)#main > div:nth-child(4):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div#__next > div:nth-child(3):not([id]) > dialog:nth-child(2):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div#cb-cookie-warning > div:nth-child(1):not([id]) > div:nth-child(2):not([id]) > button:nth-child(1)#cb-cookie-warning__button--decline",
	"body > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body > div#cookies-banner > div:not([id]) > div:nth-child(3):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:nth-child(1):not([id]) > div:nth-child(3):not([id]) > div:nth-child(2)#gdpr-popup-v3-button-mandatory",
	"body > div:not([id]) > div:nth-child(1):not([id])[data-testid=\"privacy-banner\"] > div:nth-child(2):not([id]) > div:nth-child(3):not([id]) > button:nth-child(2)#react-aria491930105-\\:r29\\:[data-testid=\"privacy-banner-decline-all-btn-desktop\"]",
	"body > div#tc-privacy-wrapper > div#footer_tc_privacy > div:not([id]) > div:nth-child(2)#footer_tc_privacy_container_button > button:nth-child(2)#footer_tc_privacy_button_2",
	"body > div#tc-privacy-wrapper > div:nth-child(2)#footer_tc_privacy > div:nth-child(2)#footer_tc_privacy_container_button > button:nth-child(3)#footer_tc_privacy_button_3",
	"body > div#app > div:nth-child(1)#__nuxt > div#__layout > div:not([id]) > div:nth-child(4):not([id]) > div:not([id]) > div:nth-child(4):not([id]) > a:nth-child(2):not([id])",
	"body > footer:not([id]) > div:nth-child(2):not([id]) > cookie-notice:nth-child(1):not([id]) > div#cookie-notice > div:not([id]) > div#cookie-notice-inner > div:nth-child(2):not([id]) > div:not([id]) > div:nth-child(1):not([id]) > button#cookie-notice-decline",
	"body > div#sell-root > div:nth-child(2)#appRoot > div:nth-child(7):not([id]) > div:not([id]) > div:nth-child(1):not([id]) > div:nth-child(3):not([id]) > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body > div:not([id]) > div:nth-child(2)#BorlabsCookieBox > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(1):not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > p:nth-child(6):not([id]) > a:not([id])",
	"body > div:not([id]) > div:nth-child(1)#consent-manager > footer:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div#app > div:nth-child(7):not([id])[data-testid=\"cookieBanner\"] > div:not([id]) > div:nth-child(3):not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])[data-testid=\"onlyNecessaryCookies\"]",
	"body > div:not([id]) > dialog:nth-child(2):not([id])[data-testid=\"modal-dialog\"] > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(4):not([id]) > button:nth-child(2):not([id])[data-testid=\"uc-button-decline\"]",
	"body > div#tc-privacy-wrapper > div#footer_tc_privacy > div:nth-child(2)#footer_tc_privacy_container_button > button:nth-child(2)#footer_tc_privacy_button_2",
	"body > div#root > div:nth-child(2):not([id]) > div:not([id]) > div:not([id])[data-testid=\"cookie-consent-banner\"] > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body > div#c-pop > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(3)#ctl07_declinebtn",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > div:nth-child(3):not([id])",
	"body > div#cookieNoticePro > div:nth-child(3):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2)#cookieReject",
	"body > div#gdrp-cookieoverlay > div:nth-child(3)#cs2gdpr-cookiebanner > div:not([id]) > div:nth-child(3):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button#btn-accept-required-banner",
	"body > div#seeGdprCookieConsent > div:not([id]) > p:nth-child(2):not([id]) > a:nth-child(2)#seeGdprReject",
	"body > div#tc-privacy-wrapper > div#popin_tc_privacy > div:nth-child(2)#popin_tc_privacy_container_button > button:nth-child(2)#popin_tc_privacy_button_2",
	"body > div#SgCookieOptin > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div#cookieman-modal > div:not([id]) > div:not([id]) > div:not([id]) > button:nth-child(6):not([id])",
	"body > div#c20343 > div:nth-child(1)#ikanos-privacy-cookielayer > div:nth-child(2):not([id]) > form:not([id]) > div:not([id]) > div:nth-child(1):not([id]) > div:nth-child(2):not([id]) > div:not([id]) > button:nth-child(2):not([id])",
	"body > div#consent-manager > div:nth-child(1)#consent-banner > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button#consent-banner-btn-close",
	"body > div#mm-2 > div:nth-child(2)#cookie-consent > div:not([id]) > form:nth-child(3):not([id]) > div:nth-child(5):not([id]) > button:nth-child(2):not([id])",
	"body > div#root > div:not([id]) > div:nth-child(2):not([id]) > main:nth-child(2):not([id]) > div:not([id]) > div:nth-child(1):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(1):not([id])",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(1):not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > div:nth-child(1):not([id]) > button:nth-child(1):not([id])",
	"body > div#application > div:nth-child(4):not([id]) > div:nth-child(2):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > a:nth-child(2):not([id])",
	"body > div:not([id]) > div:nth-child(6):not([id]) > div:nth-child(2)#BorlabsCookieBox > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(1):not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > p:nth-child(5):not([id]) > a:not([id])",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > div:not([id]) > div:nth-child(3):not([id]) > a:not([id])",
	"body > dialog#ai-hinweis > div:nth-child(1):not([id]) > div:nth-child(3):not([id]) > div:nth-child(3):not([id]) > center:not([id]) > button:nth-child(1)#policy_notwendig",
	"body > div:not([id]) > div:nth-child(1)#ccm-widget > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(3):not([id])",
	"body > div:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > a:nth-child(3):not([id])",
	"body > div#BannerRegion > div:nth-child(1)#Banner_cookie_0 > div:nth-child(2):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > button:nth-child(2)#rejectAllBtn",
	"body > comply-consent-manager:not([id]) > div#comply-consent-manager > div:nth-child(1):not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div#__next > div:nth-child(3):not([id]) > div:nth-child(3):not([id]) > div:nth-child(3):not([id])[data-testid=\"cookie_notice_reject_all_button\"]",
	"body > div#tc-privacy-wrapper > div:nth-child(2)#popin_tc_privacy > div:nth-child(2)#popin_tc_privacy_container_button > button:nth-child(2)#popin_tc_privacy_button_2",
	"body > div#__nuxt > div:nth-child(2):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > section:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(1):not([id])",
	"body > div:not([id]) > div:nth-child(2):not([id]) > div#cdk-overlay-0 > mat-dialog-container:nth-child(2)#mat-mdc-dialog-0 > div:not([id]) > div:not([id]) > hra-consent-layer-ui:not([id]) > hra-cookie-buttons:nth-child(2):not([id]) > div:not([id]) > button:nth-child(1):not([id]) > span:nth-child(2):not([id])",
	"body > div#cookie-note-main > div:nth-child(2):not([id]) > button:nth-child(2)#cookie-accept-required",
	"body > aside:not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:not([id]) > div:nth-child(5):not([id]) > button:nth-child(4):not([id])",
	"body > div#cookiebanner-body > div:nth-child(1)#cookiebanner > div:nth-child(2):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(1):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > a:not([id])",
	"body > div#app > div:nth-child(1)#header > div:nth-child(2)#cookie_banner > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body > div#__nuxt > div#__layout > div#app > div:nth-child(6):not([id]) > div:nth-child(2):not([id]) > div:not([id]) > button:nth-child(1):not([id])",
	"body > div#__nuxt > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(1):not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > section:nth-child(1):not([id]) > div:nth-child(3):not([id]) > div:nth-child(1):not([id]) > div:not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > div:nth-child(4):not([id]) > div:nth-child(1):not([id]) > div:not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body > section#shopify-pc__banner > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(3)#shopify-pc__banner__btn-decline",
	"body > div#__nuxt > div#__layout > div:not([id]) > section:not([id]) > div:nth-child(2):not([id]) > section:nth-child(2):not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div#consent-manager > div:nth-child(1)#consent-banner > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button#consent-banner-btn-close",
	"body > div:not([id]) > div:not([id]) > div:nth-child(1):not([id]) > p:nth-child(2):not([id]) > a:not([id])",
	"body > div#tc-privacy-wrapper > div:nth-child(2)#popin_tc_privacy > div:nth-child(2)#popin_tc_privacy_container_button > button:nth-child(3)#popin_tc_privacy_button_3",
	"body > div:not([id]) > div:nth-child(3):not([id]) > div:nth-child(3):not([id]) > div:nth-child(1):not([id]) > button:nth-child(1):not([id])",
	"body > div#modal-wrap > section#modal-content > div:not([id]) > div:nth-child(2)#cookie-banner > div:not([id]) > div:nth-child(1)#s1 > p:nth-child(5):not([id]) > a:nth-child(4)#button_reject",
	"body > div#cookie-consent-banner > div:nth-child(3):not([id]) > div:nth-child(2):not([id]) > button:nth-child(3)#btn-reject-all",
	"body > div#cc-button > div#cc-text > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body > div#page > main:nth-child(2)#index > div:nth-child(3)#cookie-settings-modal > div:not([id]) > div#cookie-settings > div:nth-child(4):not([id]) > button:nth-child(3):not([id])",
	"body > div#__nuxt > div:nth-child(8)#cookie-banner > div:nth-child(1):not([id]) > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body > div#consentBanner > div:not([id]) > div#gdpr-banner-container[data-testid=\"gdpr-banner-container\"] > dialog#gdpr-banner > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(3)#gdpr-banner-cmp-button[data-testid=\"gdpr-banner-decline-button\"]",
	"body > div#consentWidget > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2)#denyBtn",
	"body > div#portal-footer > div:nth-child(3):not([id]) > div:nth-child(2)#footer-analytics > div#CookieConsent > div:not([id]) > p:nth-child(2):not([id]) > span:nth-child(3):not([id]) > button:not([id])",
	"body > div#cookieman-modal > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > div:not([id]) > button:nth-child(1):not([id])",
	"#tc-privacy-wrapper",
	"[data-testid=\"consentManager\"]",
	"[data-testid=\"privacyBanner-rejectAll\"]",
	"body > div#ww_bzga_matomo_cookiebanner > div:not([id]) > p:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div#ddt-M1 > div:not([id]) > div:nth-child(1)#ddt-Seite1 > div:nth-child(2)#ddt-sectionFirst > p:nth-child(4):not([id]) > a:nth-child(2):not([id])",
	"body > div:not([id]) > div#cookies-bar > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div#csm-wrapper > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > button:nth-child(2):not([id])",
	"body > div#cookie-consent > div:not([id]) > form:nth-child(3):not([id]) > div:nth-child(5):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:nth-child(2)#cookie-consent[data-testid=\"cookie-consent-banner\"] > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div#tc-privacy-wrapper > div#popin_tc_privacy > div:nth-child(2)#popin_tc_privacy_container_button > button:nth-child(3)#popin_tc_privacy_button_3",
	"body > div#_evidon-barrier-wrapper > div:nth-child(2)#_evidon-banner > div:nth-child(1)#_evidon-banner-content > div:nth-child(5):not([id]) > button:nth-child(2)#_evidon-barrier-declinebutton",
	"div:not([id]) > div:not([id]) > div:nth-child(4):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:nth-child(2)#BorlabsCookieBox > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(1):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > p:nth-child(2):not([id]) > a:not([id])",
	"body > div#consent_modal[data-testid=\"Over18ModalVariant1Modal\"] > div:nth-child(2):not([id])[data-testid=\"Over18ModalVariant1Content\"] > div:nth-child(3):not([id]) > div:nth-child(1):not([id]) > button:nth-child(1)#reject-all-cookies-btn",
	"body > div:not([id]) > div:nth-child(1)#matomoCookieNotification > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button#disallowMatomoCookieNotification",
	"body > div:not([id]) > aside:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > div:nth-child(2):not([id]) > button:not([id])",
	"body > div#et-consent-overlay > div:nth-child(5):not([id]) > div:nth-child(1):not([id]) > button:nth-child(1):not([id])",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > span:nth-child(1):not([id]) > button:not([id])",
	"body > div#__nuxt > div:not([id]) > div:nth-child(6):not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > button:nth-child(1):not([id])",
	"body > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > a:nth-child(1):not([id])",
	"body > div:not([id]) > div:nth-child(1)#cookies-eu-banner > div:not([id]) > div:not([id]) > button:nth-child(4)#cookies-eu-reject",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > ul:not([id]) > li:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div#__nuxt > div:not([id]) > div:nth-child(8):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > button:nth-child(1):not([id])",
	"body > div#optInId > div:nth-child(4):not([id]) > button:nth-child(2)#Ablehnen",
	"body > div:not([id]) > div#cpnb > div#w357_cpnb_outer > div:not([id]) > div:nth-child(2):not([id]) > span:nth-child(2)#cpnb-decline-btn",
	"body > div:not([id]) > div:nth-child(1):not([id]) > div:nth-child(2):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body > div#a-page > div:nth-child(5)#sc-content-container > div:nth-child(1):not([id]) > div:nth-child(12):not([id]) > div:nth-child(1) > div:nth-child(2)#cookie-consent-window > div:not([id]) > div:nth-child(2) > div:nth-child(1)#cookie-consent-continue > div:not([id]) > a:not([id])",
	"body > div:not([id]) > div:nth-child(1)#ccm-widget > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div#__next > div:not([id]) > div:not([id]) > main:nth-child(2):not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(4):not([id]) > div:nth-child(1):not([id])",
	"body > div#acris--page-wrap--cookie-permission > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2)#cookie-permission--accept-only-functional-button",
	"body > div#cookieConsentBanner > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(1)#consentMinimal",
	"body > div#elGuestTerms > div:not([id]) > div:nth-child(2):not([id]) > form:not([id]) > button:nth-child(3):not([id])",
	"body > div#mm-0 > div:nth-child(2)#cookie-consent > div:not([id]) > form:nth-child(3):not([id]) > div:nth-child(5):not([id]) > button:nth-child(1):not([id])",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id])",
	"body > div#cookiebar > div:not([id]) > span:nth-child(3)#declineCookie > button:not([id])",
	"body > main#content > aside:nth-child(10):not([id]) > div:not([id]) > wm-stack:nth-child(2):not([id]) > wm-button:nth-child(1):not([id]) > button:not([id])",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(1):not([id]) > button:not([id])",
	"body > div#tc-privacy-wrapper > div#footer_tc_privacy > div:nth-child(1)#footer_tc_privacy_container_text > div#footer_tc_privacy_text > h2:nth-child(1):not([id]) > button#footer_tc_privacy_button_2",
	"body > div#bandeau_cgv > div:not([id]) > div:not([id]) > a:nth-child(1)#dismiss-cookies",
	"body > div:not([id]) > div:not([id]) > div:nth-child(1):not([id]) > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(1):not([id])",
	"body > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(1):not([id]) > div:nth-child(3):not([id]) > button:nth-child(1):not([id])",
	"body > div:not([id]) > section:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > button:nth-child(1):not([id])",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > ul:nth-child(2):not([id]) > li:nth-child(2):not([id]) > button:not([id])",
	"body > article:not([id]) > header:nth-child(2)#header > div:nth-child(1)#cookie-modal > div:not([id]) > div:not([id]) > div:nth-child(1):not([id]) > button:nth-child(2):not([id])",
	"body > div#root > div:not([id]) > div:nth-child(1):not([id]) > div:nth-child(2):not([id]) > div:nth-child(1):not([id]) > button:not([id])",
	"body > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2)#cookieRefuse",
	"body > div#cookie-banner > div:nth-child(2):not([id]) > div:nth-child(3):not([id]) > button:nth-child(3)#reject-cookies",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > div#P0-0 > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > ul:nth-child(2):not([id]) > li:nth-child(2):not([id]) > button:not([id])",
	"body > div#ppms_cm_consent_popup_7a8e4f13-52de-496c-9239-96129f02cf08 > div#ppms_cm_popup_overlay > div#ppms_cm_popup_wrapper > div:nth-child(1)#ppms_cm_popup > div:nth-child(3)#ppms_cm_popup_main_id > div:nth-child(2)#ppms-124c44a9-52c6-4136-9964-9a6be955271a > button:nth-child(2)#ppms_cm_disagree",
	"body > div#cookie > div:nth-child(1):not([id]) > div:nth-child(2):not([id]) > a:nth-child(2):not([id]) > span:not([id]) > span:not([id])",
	"body > div#orejime > div:nth-child(2):not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > ul:nth-child(2):not([id]) > li:nth-child(2):not([id]) > button:not([id])",
	"body > div#cookie-message > a:nth-child(2):not([id])",
	"body > div#tc-privacy-wrapper > div#popin_tc_privacy > div:nth-child(1)#popin_tc_privacy_container_text > div#popin_tc_privacy_text > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2)#refuse_all",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div#main > div:nth-child(11)#cookbar_overlay > div#cookbar > span:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > a:nth-child(3):not([id])",
	"body > div#tc-privacy-wrapper > div#popin_tc_privacy > div:nth-child(2)#popin_tc_privacy_container_button > button:nth-child(1)#popin_tc_privacy_button",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > main#main > dialog:nth-child(25):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(3):not([id])",
	"body > div#cookie-banner > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > div:nth-child(1):not([id]) > button:not([id])",
	"body > div:not([id]) > div:nth-child(1):not([id])[data-testid=\"privacy-banner\"] > div:nth-child(2):not([id]) > div:nth-child(3):not([id]) > button:nth-child(2)#react-aria526766221-\\:r0\\:[data-testid=\"privacy-banner-decline-all-btn-desktop\"]",
	"body > div:not([id]) > form:nth-child(4):not([id]) > div:nth-child(2):not([id]) > div:nth-child(1):not([id]) > button#cookie_consent_use_only_functional_cookies",
	"body > div#cookiesplus-modal-container > div:not([id]) > div:nth-child(1)#cookiesplus-modal > div:nth-child(3)#cookiesplus-content > div:not([id]) > form#cookiesplus-form > div:nth-child(3):not([id]) > div:nth-child(1):not([id]) > div:nth-child(1):not([id]) > div:nth-child(2):not([id]) > button:not([id])",
	"body > app-root:not([id]) > div:not([id]) > app-cookie-banner:nth-child(3):not([id]) > div:nth-child(1):not([id]) > div:nth-child(2)#reject-cookie-link > button#reject-cookie",
	"body > main:not([id]) > footer:nth-child(4)#footer > div:nth-child(3):not([id]) > div:not([id]) > div:nth-child(1):not([id]) > div:nth-child(3)#acb-banner > div:nth-child(2)#acb-action > button:nth-child(1)#acb-deny-all-button",
	"body > div#st-cmp-v2 > div:not([id]) > div:nth-child(3):not([id]) > div:not([id]) > div:nth-child(4):not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > span:not([id]) > div:not([id])",
	"body > div#cookie-consent > div:nth-child(1):not([id]) > button:nth-child(1)#cookie-deny-button",
	"body > div#advencyRgpd > button:nth-child(3)#refuseAll",
	"body > div#rgpd > div:nth-child(1):not([id]) > div:not([id]) > button:nth-child(1):not([id])",
	"body > div#consent > user-consent:nth-child(1):not([id]) > consent-dialog:not([id]) > consent-content:not([id]) > consent-message:nth-child(1):not([id]) > button:nth-child(1):not([id])",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > a:nth-child(2):not([id])",
	"body > div#bottom-banner > div:nth-child(3):not([id]) > div:nth-child(1)#cookies-win > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:not([id])[data-testid=\"cookie-consent-banner\"] > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body > div:not([id]) > div:nth-child(2)#BorlabsCookieBox > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(1):not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > p:nth-child(8):not([id]) > a:not([id])",
	"body > div#___gatsby > div:nth-child(1)#gatsby-focus-wrapper > div:nth-child(3):not([id]) > div:nth-child(3):not([id]) > button:nth-child(1):not([id])",
	"body > div#privacy-banner > div:nth-child(3):not([id]) > button:nth-child(1)#privacy-rejected",
	"body > div#cookie > div:not([id]) > div:nth-child(2)#Buttondivanalytic > button:nth-child(2):not([id])",
	"body > div:not([id]) > p:nth-child(2):not([id]) > button:nth-child(2)#seopress-user-consent-close",
	"body#top > div:not([id]) > form:nth-child(1):not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div#cookie-notice > div:not([id]) > span:nth-child(2)#cn-notice-buttons > button:nth-child(2)#cn-refuse-cookie",
	"body:not([id]) > div#BannerRegion > div:nth-child(1)#Banner_cookie_0 > div:nth-child(2):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > button:nth-child(2)#rejectAllBtn",
	"body:not([id]) > div#tc-privacy-wrapper > div#footer_tc_privacy > div:nth-child(2)#footer_tc_privacy_container_button > button:nth-child(2)#footer_tc_privacy_button_2",
	"body#html-body > div:not([id]) > div:nth-child(1):not([id]) > div:not([id]) > div:nth-child(3):not([id]) > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body:not([id]) > div#modal-root > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > div:not([id]) > div:nth-child(1):not([id]) > button:nth-child(2):not([id]) > div:not([id])",
	"body:not([id]) > div#root > div:nth-child(3):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div#cookie-banner-container > div:nth-child(1):not([id]) > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body > div#cookie-law > div:not([id]) > div:nth-child(1):not([id]) > button:nth-child(12):not([id])",
	"body:not([id]) > div#__next > div:not([id]) > div:nth-child(8):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body:not([id]) > div#root > div:nth-child(3):not([id]) > div:nth-child(3):not([id]) > button:nth-child(1):not([id])",
	"body:not([id]) > header#header > div:nth-child(1)#CookiesConsent > div:not([id]) > div:nth-child(2):not([id]) > form:nth-child(2):not([id]) > div:nth-child(5):not([id]) > button:not([id])",
	"body:not([id]) > div#__next > div:not([id]) > div:nth-child(6)#cw-footer-container > footer:nth-child(1):not([id]) > div:nth-child(3):not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > div:nth-child(1):not([id]) > button:not([id]) > span:nth-child(2):not([id]) > span:nth-child(1):not([id])",
	"body > div#cookie_alert > div:nth-child(2)#cookie_alert_container > div#cookie_alert_text > div:nth-child(2):not([id]) > div:nth-child(2)#js-cookie_alert_button_decline > a#cookie_alert_decline",
	"body > div > div:not([id]) > div:nth-child(1) > div:nth-child(2)#cookieDisclaimer > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(3):not([id]) > button:not([id])",
	"body:not([id]) > dialog:not([id]) > div:nth-child(1):not([id]) > div:nth-child(3):not([id]) > div:nth-child(2):not([id]) > button:not([id])",
	"body:not([id]) > dialog:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > div:nth-child(4):not([id]) > div:nth-child(2):not([id]) > button:not([id])",
	"body#unlogged-body > div#cookie-banner-deezer > div#gdpr-dir-tag > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button#gdpr-btn-refuse-all",
	"body:not([id]) > section:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body:not([id]) > section#cookie-policy > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body:not([id]) > div#cc--main > div#cc_div > div:nth-child(1)#cm > div#c-inr > div:nth-child(2)#c-bns > button:nth-child(1)#c-s-bn",
	"body > div#headlessui-portal-root > div:not([id]) > div:nth-child(2):not([id]) > div#headlessui-dialog-_r_0_ > div:nth-child(2):not([id]) > div#headlessui-dialog-panel-_r_6_ > div:nth-child(3):not([id]) > div:not([id]) > div:nth-child(1):not([id]) > button:nth-child(1):not([id])",
	"body > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > a:nth-child(3):not([id])",
	"body:not([id]) > div#cookie-wall > div#cwi > div:nth-child(4)#cw-controls > div:not([id]) > div:nth-child(4):not([id]) > button:nth-child(2)#cwc-reject > span:not([id])",
	"body > div:not([id]) > div#csm-wrapper > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div#sliding-popup > div#cookiepopup > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body:not([id]) > div#elGuestTerms > div:not([id]) > div:nth-child(2):not([id]) > form:not([id]) > button:nth-child(3):not([id])",
	"body:not([id]) > div#consent-box > p:not([id]) > span:not([id]) > button:nth-child(2)#decline-cookies",
	"body > div#__next > div:nth-child(3)#cookieBanner > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > form:nth-child(2):not([id]) > button:nth-child(2)#cookieConsentRejectAll",
	"body:not([id]) > section:not([id]).privacy-banner > div:not([id]).privacy-banner__wrap > div:not([id]).privacy-content > div:not([id]).privacy-banner__grid-wrap > div:not([id]).privacy-banner__grid-col.privacy-banner__inner > div:nth-child(3):not([id]).privacy-banner__actions.privacy-banner__set.privacy-banner__btn-wrapper--stacked > button:nth-child(2):not([id]).privacy-banner__btn.privacy-banner__btn--secondary.privacy-banner__reject",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button#confirmSelection",
	"body:not([id]) > div:not([id]) > div:nth-child(5):not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > button:nth-child(2):not([id])",
	"body:not([id]) > div:not([id]) > div:nth-child(1):not([id]) > div:nth-child(3):not([id]) > div:nth-child(2)#gdpr-popup-v3-button-mandatory",
	"body#hgcBody > div#cookies-banner > a:nth-child(6)#btnCookieBannerNo",
	"body:not([id]) > dialog#biccy-banner > div#biccy-prompt > div:nth-child(2):not([id]) > button:nth-child(2)#biccy-reject-button",
	"body:not([id]) > div:not([id]) > div:nth-child(4):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div > div:nth-child(1) > div:nth-child(3) > div:nth-child(2)",
	"body > div > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > button:nth-child(3)",
	"body > aside#cookies-policy > div:not([id]) > div:nth-child(1):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > form:nth-child(1):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:nth-child(3):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > aside:nth-child(2):not([id]) > div:nth-child(2):not([id]) > div:nth-child(2)#modal-content-17 > div#pr-cookie-notice > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2)#btn-cookie-decline",
	"body > div:not([id]) > div:nth-child(14):not([id]) > div#m-cookienotice > div:not([id]) > div:nth-child(3)#action-custom-css > a:nth-child(2):not([id])",
	"body > div#__nuxt > div#__layout > div:not([id]) > div:nth-child(1):not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body:not([id]) > div#dux-privacy > div:nth-child(1):not([id]) > div:nth-child(2):not([id]) > div:nth-child(1):not([id]) > button:nth-child(1):not([id])",
	"body:not([id]) > div#__nuxt > div#__layout > div:not([id]) > div:nth-child(4):not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"[data-testid='reject-button']",
	"body > div > div:nth-child(10) > div:nth-child(2) > div > div:nth-child(2) > div:nth-child(2)",
	"body > div#shopui-cookie-popup-container > div:nth-child(2):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > a:not([id])",
	"body > section:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body:not([id]) > div#__nuxt > div:not([id]) > div:nth-child(1):not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div#cookies_overlay > div#cookies_banner > div:nth-child(2)#cookies_decision > button:nth-child(2)#cookies_read_declined",
	"body:not([id]) > div#__next > div:nth-child(3):not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(4):not([id]) > div:nth-child(2):not([id]) > button:not([id])",
	"body > div#cookie-consent-popup > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2)#cookie-reject",
	"body > div#cookie-consent-banner > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(2)#btn-reject-all",
	"body > div:not([id]) > div:nth-child(78)#cookie-banner > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div#cribbon > div:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > button:nth-child(2)#select-only-necessary > span:not([id])",
	"body > div#app > div:nth-child(3):not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div#modal-cookiesettings > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:nth-child(3):not([id]) > div:not([id]) > button:nth-child(3):not([id])",
	"body > div:not([id]) > div:nth-child(1)#react-content > div:nth-child(1):not([id]) > div:not([id]) > div:nth-child(3):not([id]) > div:nth-child(1):not([id]) > button:nth-child(2):not([id]) > span:not([id])",
	"body > div:not([id]) > div#cookieconsent > div:nth-child(2):not([id]) > div:nth-child(3):not([id]) > div:not([id]) > button:nth-child(1)#cookie-deny",
	"body > div#cookie-bar-2019 > div:nth-child(4):not([id]) > a#declineLink",
	"body > div#__next > div:nth-child(2)#cookieBanner > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])[data-testid=\"refuse-all-cookies\"]",
	"body > aside#cookie-consent-banner > div:not([id]) > form:not([id]) > div:nth-child(2):not([id]) > fieldset:nth-child(3):not([id]) > ul:not([id]) > li:nth-child(1):not([id]) > button:not([id])",
	"body > dialog:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > footer:nth-child(3):not([id]) > div:nth-child(3):not([id]) > span:not([id])",
	"body > div#cookie-popup > div:nth-child(2):not([id]) > button:nth-child(2)#reject-cookies",
	"body > div:not([id]) > div:nth-child(1):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"div[data-test-consent-banner-popup] button[aria-label=\"Niet accepteren\"]",
	"body > dialog:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(1):not([id]) > p:nth-child(2):not([id]) > a:nth-child(1):not([id])",
	"body > div:not([id]) > div:nth-child(1)#react-content > div:nth-child(8):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > div:nth-child(1):not([id]) > button:nth-child(2):not([id])",
	"body > div#consent-modal > div:not([id]) > div:nth-child(1)#consent-intro > div:nth-child(2):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button#consent-deny-all",
	"body > div:not([id]) > div:nth-child(5):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body > div#cookielaw_banner > div:nth-child(2):not([id]) > a:nth-child(2)#cookielaw_reject",
	"body > div#__next > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(8):not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:nth-child(1):not([id]) > div:not([id]) > div:nth-child(3):not([id]) > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body > div#_app > div:nth-child(3):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div#radix-_r_0_ > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(3):not([id])",
	"body > div#nimbu-consent > div:not([id]) > div:not([id]) > div:not([id]) > p:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	".ind-cbar[data-testid=\"ind-cbar\"]",
	".ind-cbar[data-testid=\"ind-cbar\"] button[save-cookie][data-value=\"0\"]",
	"body > div:not([id]) > div#container > section:nth-child(1):not([id]) > div:not([id]) > div#block-mumc-info-cookiesui > div#cookiesjsr > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > web-overlay:not([id]) > web-cookie-consent:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div#wpca-lay-out-wrapper > div:nth-child(1)#wpca-bar > div:nth-child(2)#wpca-bar-meta > button:nth-child(3):not([id])",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(1)#cookiebanner-decline[data-testid=\"button-cookie-decline\"]",
	"body > div#cookiebanner > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(1):not([id]) > span:nth-child(2):not([id]) > a:nth-child(2)#cookie-niet-akkoord",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > section#cookie-consent > div:nth-child(7):not([id]) > div:nth-child(1):not([id]) > button:nth-child(1)#button-«r0»",
	"body > aside#cookies-policy > div:not([id]) > div:nth-child(1):not([id]) > div:not([id]) > div:nth-child(3):not([id]) > form:nth-child(1):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:nth-child(4):not([id]) > div:not([id]) > a:nth-child(4):not([id])",
	"body > div#cookies-eu-wrapper > div#cookies-eu-banner > div:nth-child(2)#cookies-eu-buttons > button:nth-child(1)#cookies-eu-reject",
	"body > div#wrapper > footer:nth-child(3):not([id]) > div#footer > div:not([id]) > div:nth-child(3):not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(4):not([id]) > div:nth-child(1):not([id]) > button:nth-child(2):not([id])",
	"body > div#cc-card > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > a:nth-child(2)#cc-dismiss-btn",
	"body > div#__nuxt > div:not([id]) > div:nth-child(3):not([id]) > section#modal > div:nth-child(2):not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div#cookie-bar > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:not([id])",
	"body > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id]) > span:not([id])",
	"body > div#CNID_4eb59999-7a35-450d-a08f-1661b81e5bc4 > div:not([id]) > div:nth-child(1):not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2)#refuseAll",
	"body > div:not([id]) > div:nth-child(3)#cookie-consent[data-testid=\"cookie-consent-banner\"] > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div#_rootSiteLayout > aside:nth-child(5):not([id]) > div:nth-child(3):not([id]) > aside:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(3):not([id])",
	"body > footer:not([id]) > div:nth-child(2)#cookieParent > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(1)#noCookies",
	"body > div#siteWrapper > div:nth-child(1):not([id]) > section:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(1):not([id]) > div:nth-child(4):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(1):not([id]) > div:nth-child(1):not([id]) > button:nth-child(2)#bcSubmitConsentToNone",
	"body > aside:not([id]) > div:nth-child(1):not([id]) > div:nth-child(3):not([id]) > div:nth-child(2):not([id]) > button:nth-child(3):not([id])",
	"body > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(3):not([id])",
	"body > div:not([id]) > div:not([id]) > button:nth-child(4):not([id])",
	"body > shn-dialog#firstTimeVisitorCookieDialog > dialog:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > section#cc-window-overlay > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(1):not([id]) > button:nth-child(1):not([id])",
	"body > div#cookieconsent > section:not([id]) > div:not([id]) > p:nth-child(6):not([id]) > a:not([id])",
	"body > ticketswap-portal:not([id]) > ul:not([id]) > div:not([id]) > div:not([id]) > span:nth-child(2):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:nth-child(2)#ez-cookie-notification > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2)#ez-cookie-notification__decline",
	"body > div#__nuxt > div:nth-child(2)#__layout > div:not([id]) > div:nth-child(3):not([id]) > div:nth-child(2):not([id]) > div:nth-child(2)#cookie-consent > div:not([id]) > dialog:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > div#cookie-consent-modal-description > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > div:not([id]) > button:nth-child(2):not([id]) > span:not([id])",
	"body > div:not([id]) > div:nth-child(3):not([id]) > div:not([id]) > section#chakra-modal-\\:rd\\: > div#chakra-modal--body-\\:rd\\: > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(3):not([id]) > form:not([id]) > button:nth-child(2)#cookie_settings_disallowed",
	"body > div#app > div:not([id]) > div:nth-child(10):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(1):not([id]) > div:nth-child(1)#cookie-banner > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(3)#cookie-banner-reject",
	"body > main#maincontent > div:nth-child(1):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div#svid10_17c33ae315e94c3ae6647bf > div:nth-child(1)#svid12_3f29801717d5618f8df9bf4 > div:nth-child(2):not([id]) > div:not([id]) > button:nth-child(4)#afCookieDecline",
	"body > aza-app:not([id]) > aza-shell:not([id]) > div:nth-child(2):not([id]) > aza-cookie-message:nth-child(1):not([id]) > div:not([id]) > div:not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id]) > span:not([id])",
	"body > div#app > div:not([id]) > div:not([id]) > div:nth-child(4):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div#geotargetlygeoconsent1749551372435container > div:nth-child(1):not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div#ppms_cm_consent_popup_d0973bf6-9332-4ce3-bc7c-09678b958daf > div#ppms_cm_popup_overlay > div:nth-child(2)#ppms_cm_popup_wrapper > div#ppms_cm_popup > div#ppms_cm_popup_main_id > div#ppms_cm_popup_responsive_wrapper_id > div:nth-child(2)#ppms-4ad6f5ba-7508-4caa-bd23-e8e9a4bd64b2 > div:nth-child(2)#ppms-85b001a4-b886-4f7e-82d5-bd34f50f3266 > button:nth-child(2)#ppms_cm_reject-all",
	"body > div#__nuxt > div:nth-child(2)#main-wrapper > div:nth-child(5):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div#shopify-section-sections--20055816765655__privacy-banner > cookie-bar:not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > form:not([id]) > div:nth-child(1):not([id]) > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body > div#cookie-consent-modal > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(4):not([id])",
	"body > div#__docusaurus > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(1)#rcc-decline-button",
	"body > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body > div#radix-_r_2_ > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > section#component-cookie-banner > div:nth-child(1):not([id]) > footer:nth-child(4):not([id]) > div:nth-child(1):not([id]) > button:nth-child(2)#cookie-banner-accept-essentials",
	"body > form#cookieConsentForm > div#cookie-consent-modal > div:not([id]) > div#cookie-consent-modal-content > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div#__nuxt > div:not([id]) > div:nth-child(1):not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div#cookie_banner > div:not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:not([id]) > div:nth-child(4):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(3):not([id]) > container:nth-child(2):not([id]) > div:not([id]) > div:not([id]) > div#versionized-cookie-banner > div:nth-child(2):not([id]) > ul:not([id]) > li:nth-child(2):not([id]) > button#btn-reject-cookies",
	"body:not([id]) > div#consent-banner > div:nth-child(2)#truste-consent-track > div:nth-child(3)#truste-consent-content > div:nth-child(3):not([id]) > div#truste-consent-buttons > button:nth-child(3)#truste-consent-required",
	"body > div#__next > div:not([id]) > div:nth-child(1)#cookieBanner[data-testid=\"cookie-banner\"] > div:nth-child(2):not([id]) > div:not([id]) > div:nth-child(1):not([id]) > p:not([id]) > a:nth-child(2):not([id])",
	"body > div[class] > div:nth-child(2) > div:nth-child(2) > button:nth-child(2)",
	"body > div#cmpbox > div:not([id]) > div:nth-child(1)#cmpboxcontent > div:nth-child(1):not([id]) > div:nth-child(2):not([id]) > a:not([id])",
	"body > div[id][cookie-banner-data-theme] > div > div > div > div:nth-child(2) > div:nth-child(2) > button",
	"body:not([id]) > div#seers-cmp-cookie-data-hol > div:nth-child(2)#SeersCMPBannerMainBar > div:nth-child(2):not([id]) > a:nth-child(2):not([id])",
	"body > div:not([id]) > div:nth-child(3)#gdpr_cookie_info_bar-wr > div:nth-child(1):not([id]) > div:nth-child(3):not([id]) > button:nth-child(2):not([id])",
	"body > div[id][class][data-role][data-controller][style] > div > div:nth-child(2) > form > button:nth-child(3)",
	"body > div[class][tabindex] > div > div > div:nth-child(2) > div:nth-child(2) > button:nth-child(2)",
	"body > div[class][id][tabindex][role][aria-labelledby][aria-modal][style] > div > div > div:nth-child(3) > div > div > p > button:nth-child(3)",
	"body > div[id] > div:nth-child(2) > div:nth-child(4) > div > div:nth-child(2) > button:nth-child(2)",
	"body > div#cassie-widget > div:nth-child(4)#cassie_cookie_module > div:nth-child(2)#cassie_pre_banner > div:nth-child(3)#cassie_pre_banner__footer > button:nth-child(2)#cassie_reject_all_pre_banner",
	"body > div:not([id]) > div:nth-child(17):not([id]) > div:not([id]) > a:nth-child(3):not([id])",
	"body > aside:not([id]) > div:nth-child(1):not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"body > div:not([id]) > div:not([id]) > div#ch2-dialog > div:nth-child(2):not([id]) > button:nth-child(1):not([id])",
	"body > div[class][role][aria-labelledby][aria-live][lang] > div:nth-child(1) > div:nth-child(3) > div:nth-child(2)",
	"body > div[id] > div > div:nth-child(1) > div > div > div > div:nth-child(2) > button:nth-child(2)",
	"body:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:nth-child(2):not([id]) > button:nth-child(2):not([id])",
	"#popup-cookies",
	"#popup-cookies .cancelar-popup",
	"disclaimerCookies=12=false&14=false&15=false",
	"#cookie-consent[style*=\"max-height\"] #cookie-status-reject",
	".ui-alert.bottom-fixed a[data-href*='cookie-policy']",
	".ui-alert.bottom-fixed",
	".ui-alert.bottom-fixed button.close",
	"body.enable-cookie-control",
	".cookie-dialog-initial",
	".cookie-dialog-initial button.g-button.outline",
	"cookie_preferences=%7B%22allow%22%3A%5B%5D",
	"#cookie_modal_placeholder dialog.bm-modal--cookie",
	"Analytics_consent=2",
	"Marketing_consent=2",
	".MuiDialog-root:has([data-uit=\"accept-all\"], [data-uit=\"store-changes\"])",
	"[role=\"dialog\"] #approveAllCookies[data-uit=\"accept-all\"]",
	"[role=\"dialog\"] [data-uit=\"show-details\"]",
	"[role=\"dialog\"] [data-uit=\"store-changes\"]",
	"[role=\"dialog\"] input[role=\"switch\"]:checked",
	"[role=\"dialog\"] [data-uit=\"accept-all\"], [role=\"dialog\"] [data-uit=\"store-changes\"]",
	".cookie-alert",
	".cookie-alert .inner-cookie-alert .consent-actions",
	".cookie-alert-v2",
	".cookie-alert-v2 .consent-actions button:nth-of-type(2)",
	".cookie-alert .consent-actions button.btn-outline-light",
	".cookie-alert .consent-settings",
	".cookie-alert .consent-settings input[type=\"checkbox\"]:not([disabled]):checked",
	".cookie-alert .consent-settings button[type=\"submit\"]",
	"__consent=1",
	"*[aria-labelledby=\"consent-banner-title\"]",
	"#bbccookies-prompt:has(#bbccookies-reject-button)",
	"#consent-banner-title",
	"#bbccookies-reject-button",
	"button[data-testid=\"reject-button\"]",
	"ckns_explicit=1",
	"#cookiePrompt:has(#bbccookies-continue-button)",
	"#bbccookies-continue-button",
	"#bbccookies-prompt",
	"#note .cpref",
	"#note .cpref #cPrefToggle",
	"#cPrefToggle",
	"#cPrefModal label[for=\"tab-4r\"]",
	"#cPrefSave",
	"section.cookie",
	"section.cookie .cookie__container .cookie__close",
	"section.cookie.show .cookie__container",
	"section.cookie.show .cookie__close",
	".modalwindow-container.bar .modalwindow",
	"#bibliotheek-nl-page",
	".modalwindow-container.bar .modalwindow button.button.primary.notok",
	".sygnal24-gdpr-modal-wrap",
	".sygnal24-gdpr-modal-wrap .sygnal24-gdpr-modal",
	".sygnal24-gdpr-modal-wrap .sygnal24-gdpr-options input:checked:not([disabled])",
	".sygnal24-gdpr-modal-wrap .sygnal24-gdpr-accept-choice",
	"gdpr-consent=[\"necessary\"]",
	"[role=dialog] [data-cy=allowCookiesButton]",
	"[role=dialog] [data-cy=allowCookiesButton] ~ a[href=\"/articles/cookies\"]",
	".container > h3 ~ button",
	".container > h3 > input[type=checkbox]:checked:not([disabled])",
	"BokadirektCookiePreferencesMP=Mandatory",
	".keks-privacy-layer",
	".keks-privacy-layer #cube-cmp-reject-all",
	".keks-privacy-layer[open]",
	"acceptedCategories%22%3A%5B%22REQRD%22%5D",
	".blp-necessary-cookies-banner",
	".blp-necessary-cookies-banner__button",
	"has-dismissed-necessary-cookies-banner=true",
	"#banner-terms-dismiss",
	"\"haveConsent\":true",
	"#banner-terms",
	"dismissedTermsNotice",
	".cookieHolder",
	".cookieHolder .cookie-link",
	"GeneralCookieState=cookiestate",
	"[role=\"dialog\"][aria-modal=\"false\"]:has(a[data-anchor-id=\"cookie-policy\"])",
	"[role=\"dialog\"][aria-modal=\"false\"]:has(a[data-anchor-id=\"cookie-policy\"]) button:last-child",
	"div:has(> h3):has(> p a[data-anchor-id=\"cookie-policy\"]) + div > button:last-child",
	"div:has(> h3):has(> p a[data-anchor-id=\"cookie-policy\"]) ~ div:last-child > button:only-child",
	"CTC=",
	"div.modal.cookiesModal.is-open",
	"div.cookiesModal__buttonWrapper > button[data-closecause=\"close-by-manage-cookies\"]",
	"button#js-manage-data-privacy-save-button",
	"#privacy-banner-lh .lh-close-button",
	"lh-warning-test=manual-no",
	".cc-cookies .main",
	".cc-cookies .main .btn-cookies-config button",
	".cc-cookies .main[style*='display: block'] .btn-cookies-config button",
	"#modalConfigCookies #acceptAdditionalCookies",
	"#modalConfigCookies #acceptAdditionalCookies:checked",
	"#btnConfigCookies button",
	"cookie-agreed=false",
	"#cookie-notification",
	"#cookie-notification .cookie_pref_wrapper .pref-opt.refuse",
	"#cookie_banner #myModal",
	"#cookie_banner #myModal #popupCross",
	"#myModal #popupCross",
	".incentive-banner",
	".cookie-banner",
	".cookie-banner .all4-cc-primary-button",
	".cookie-banner button[aria-label=\"Reject non-essential cookies and continue.\"]",
	"C4_CC=eyJ2ZXJzaW9uIjoxLCJjb25zZW50ZWQiOnRydWUs",
	"dialog[data-cookie-consent]:not([aria-modal]):has(form[data-privacy-consent-form])",
	"dialog[data-cookie-consent] form[data-privacy-consent-form] button[name=\"action\"][value=\"reject\"]",
	"dialog[data-cookie-consent]:has(form[data-privacy-consent-form])",
	"dialog[data-cookie-consent]",
	".cookiesInfo .closeCookiesInfo",
	".cookiesInfo",
	".js-cookie-banner",
	"#js-cookie-banner__button-reject",
	"#js-cookie-banner__button-hide",
	"#csr-cookie-message",
	"#csr-cookie-message #accept_essential_cookies_button",
	"cookies_accepted=essential",
	".cookie-bar-backdrop",
	"#js-cookie-notification .js-reject-cookie",
	"#js-cookie-notification.opened",
	"#js-cookie-notification.opened .js-reject-cookie",
	"cookie-notification=REJECTED",
	"#consent-banner",
	"#consent-banner #truste-consent-track",
	"#truste-consent-required",
	"cmapi_cookie_privacy=permit_1_required",
	".cookieconsent[data-init=cookieConsent]",
	".cookieconsent.cookieconsent--active",
	".cookieconsent [data-cookieconsent=button]",
	"acceptCookies=true",
	".cookie-prompt-container",
	".cookie-prompt-container #custom-cookie-banner-container",
	".cookie-prompt-container #analytic-cookie:checked",
	".cookie-prompt-container #analytic-cookie",
	".cookie-prompt-container .confirm-cookies",
	"cookie_policy=false",
	"[data-consent-button][data-value=accept_partial]",
	"div.fixed.z-50.rounded-xl:has(> p > a[href*=\"privac\"]):has(> button.button-primary)",
	"[data-testid='cookie-banner-reject-button']",
	"CMCCP=AD%3D0",
	"#costco-consent-manager [data-testid=\"Popup\"]",
	"#costco-consent-manager [data-testid=\"Popup\"], script[src*=\"/consent-ui/costco-consent-manager\"]",
	"#costco-consent-manager",
	"#cookie-disclaimer",
	"#cookiesel",
	".box-cookie",
	".box-cookie .box-cookie__inner",
	".box-cookie .btn-normal.is-small",
	"disney_cc=ok",
	"#cuvva-app-injection-site button[data-testid=\"accept-cookies\"]",
	"cuvva.app.website.cookie-policy.consent.v2=",
	"#cuvva-app-injection-site button[aria-label=\"Reject all\"]",
	"cuvva.app.website.cookie-policy.consent.v2={%22preferences%22:{%22functional%22:true%2C%22analytics%22:false%2C%22marketing%22:false",
	"div[class*=\"Overlay__container\"]:has(div[class*=\"TCF2Popup\"])",
	"div[class*=\"TCF2Popup\"]",
	"[class*=\"TCF2Popup\"] a[href^=\"https://www.dailymotion.com/legal/cookiemanagement\"]",
	"button[class*=\"TCF2ContinueWithoutAcceptingButton\"]",
	"dm-euconsent-v2",
	"[class*=\"PrivacyBar_gdprAgreement\"] [class*=\"PrivacyBar_managePrefsBtn\"]",
	"[class*=\"PrivacyBar_gdprAgreement\"]",
	"[class*=\"CookieManagementModal_confirmBtn\"]",
	"[class*=\"CookieManagementModal_dropdownHeader\"] [class*=\"SwitchButton_toggleSwitch\"] input:checked",
	"%22targeting%22:false",
	"gdpr-consent-popup",
	"div[role=\"dialog\"][class*=\"CustomCookieBanner\"]",
	"#onetrust-consent-sdk .ot-pc-refuse-all-handler",
	"ngc-cookie-banner",
	"div.cookie-footer-container",
	"#cookies-modal",
	"dialog.js-cookie-bar",
	"dialog.js-cookie-bar .js-reject-all",
	"CookieLevel=Functional",
	".MuiDialog-root [role=dialog] button[aria-label^=\"Odrzuć wszystkie i zamknij popup\"]",
	".cc-window.cc-visible",
	".cc-window .cc-dialog",
	".cc-window.cc-visible .cc-consent-require-only",
	"dji_consentmanager",
	"[id^=cookie-consent-banner]",
	"#cookie-consent-denied",
	"cookie-consent=denied",
	".cc-type-info[aria-describedby=\"cookieconsent:desc\"] .cc-dismiss",
	"#cookiePopup [data-trigger=launchCookieDetails]",
	"#cookiesModal [data-trigger=saveCookiePrefs]",
	"cookiePrefs=",
	"#cookiePopup",
	"#cookiesModal",
	"#cookiesModal #functionalCookies:checked",
	"#cookiesModal #functionalCookies",
	"#cookiesModal #advertisingCookies:checked",
	"#cookiesModal #advertisingCookies",
	"#gdpr-banner",
	"#gdpr-banner-decline",
	".cookie-wrapper",
	".cookie-wrapper > .cookie-notice",
	"[data-test-id=cookie-notice-reject]",
	"#edp-cookies-banner",
	"#edp-cookies-banner .edp-cookies-refuse",
	"edp_cookie_agree=0",
	"#ef-ccpa",
	"#ef-button-ccpa-decline",
	".cookie-bar__wrapper:has(.cookie-bar__message--top)",
	".cookie-bar__wrapper .cookie-bar__message--top",
	".cookie-bar__wrapper .cookie-bar__container",
	"[data-testid=\"cookie-banner\"]",
	"[data-testid=\"accept-all-cookies-button\"] ~ [data-testid=\"cookie-settings-button\"]",
	"[data-testid=\"reject-all-cookies-button\"]",
	"[data-testid=\"cookie-settings-button\"]",
	"[data-testid=\"accept-all-cookies-button\"]",
	".modal:has(> .modal-content > .cookie-consent)",
	".cookie-consent #cookieDisagree",
	"#consent-cookie-modal",
	"#consent-cookie-modal #cookie-selection-button",
	"#consent-cookie-modal input[type=checkbox]:checked:not(:disabled)",
	"EMR-CookieConsent-Advertising=0",
	"#gdprBanner",
	"#gdprBanner .js-close-btn",
	"#app > div:has(a[href*=\"business.safety.google\"])",
	"#app > div:has(a[href*=\"business.safety.google\"]) p + div > button",
	"#app > div:has(a[href*=\"business.safety.google\"]) p + div > button:last-child",
	"[role=dialog] form input#MARKETING",
	"[role=dialog] form input[type=checkbox]:checked",
	"[role=dialog] form button[type=submit]",
	"cconsent=1000",
	".cookie-banner-container",
	".cookie-banner-container button.preferences",
	"#ccc-optional-categories .checkbox-toggle-input:checked",
	"\"analytics\":\"revoked\"",
	".global-cookie.js-cookie-banner",
	".global-cookie.js-cookie-banner .global-cookie__button",
	".global-cookie.js-cookie-banner:not(.global-cookie__hidden)",
	"_consent_banner_read=true",
	"#clb.clb-container",
	"#clb.clb-container #moreSettings",
	"#clb #moreSettings",
	"#clb #clb-panel-2",
	"#clb #switch2[data-active=true]",
	"#clb #saveSettings",
	"dws01-level=1",
	"#es-cookie-banner",
	"#es-cookie-banner #es-consent-settings-btn",
	"#es-consent-settings-btn",
	"#onetrust-consent-sdk input.category-switch-handler:checked",
	".cookies-line",
	".cookies-line a[href=\"/cookies-policy\"]",
	".cookies-line.show",
	"[data-cookie-hint]",
	"[data-cookie-hint] [data-cookie-hint-save-settings]",
	"[data-cookie-hint] [data-cookie-first]",
	"[data-cookie-hint] [data-cookie-hint-settings]",
	"[data-cookie-settings] #cookie-setting-1",
	"cookieHint=1",
	"cookieAllowed=1",
	"div#klaro",
	"xpath///div[contains(@class,'pointer-events-none')]//button[normalize-space()='Accept all' or normalize-space()='Tout accepter']",
	"xpath///button[normalize-space()='Customize' or normalize-space()='Personnaliser']",
	"xpath///button[normalize-space()='Decline' or normalize-space()='Refuser']",
	"escaparium_cookie_consent_decided=1",
	"[data-cy=\"cookies-dialog\"]",
	"[data-cy=\"cookies-dialog\"] [data-cy=\"personalize-cookies-button\"]",
	"#personalize-menu [data-cy=\"accept-essentials-button\"]",
	".cdk-overlay-container",
	".cdk-overlay-container app-esaa-cookie-component",
	".btn-cookie-refuser",
	"#cookie-consent-banner .wt-cck--container",
	".wt-cck--actions-button[href=\"#refuse\"]",
	"%22cm%22%3Atrue%2C%22all1st%22%3Afalse",
	"#tf-modal-container:has(.cookie-modal__footer)",
	"#tf-modal-container .cookie-modal__footer .js-nl-modal-decline",
	"#tf-modal-container .cookie-modal__footer",
	"efrg_v1_tracking_full=0",
	"common-tracking-optin",
	"common-tracking-optin p.opt-in__text-item:nth-of-type(2) > a:last-of-type",
	".privacy-bar",
	".privacy-bar #close-rgpd-notice",
	"#close-rgpd-notice",
	"body > div:not([id]) > div:nth-child(1):not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:not([id]) > div:nth-child(2):not([id]) > div:not([id]) > div:nth-child(1):not([id]) > div:nth-child(2):not([id])",
	"[data-testid=\"cookie-policy-manage-dialog-decline-button\"]",
	"#cookie-bar #cookieBarClose",
	"#cookie-bar[aria-hidden=\"false\"]",
	"#cookie-bar #cookieBarClose .cookie-bar-close",
	"FSE-COOKIEBAR=hide",
	".fancybox-wrap:has(#cookiemanager-popup)",
	"#cookiemanager-popup #cookie-modal-close",
	"cookieConsent={\"cookie\":\"rejected\",\"cookieThird\":\"rejected\"}",
	"#gdrp",
	".dx-cookie-banner:has(.dx-cookie-banner-close)",
	".dx-cookie-banner .dx-cookie-banner-close",
	"CookiePolicy=OK",
	"#cookie-mask",
	"#cookie-mask #cookieContainer",
	"#cookieContainer #btn-cookie-accept-edit",
	"#cookier-page-2 #btn-cookie-accept-nothing",
	"cookie_accepted={\"nothing\": 1}",
	"gf-notifications .notification:has(a[href^=\"https://policies.google.com/technologies/cookies\"])",
	"gf-notifications .notification a[href^=\"https://policies.google.com/technologies/cookies\"]",
	"gf-notifications .notification:has(a[href^=\"https://policies.google.com/technologies/cookies\"]) button.notification__close",
	".fk-cookie-warning",
	".fk-cookie-warning .cookie-warning-content",
	".fk-cookie-warning .cookie-warning-content button:nth-of-type(2)",
	"fk_hide_cookie_warning=true",
	"#privacy_modal",
	"#modalCookies",
	"#modalCookies #ck_marketing",
	"#modalCookies a[data-action=\"preferencias\"]",
	"#modalCookies .preferencias",
	"#modalCookies .preferencias input[type=checkbox]:checked:not([disabled])",
	"#modalCookies a[data-action=\"aceptar\"]",
	"gc-cookie=%7B%22estadisticas%22%3A0%2C%22marketing%22%3A0%7D",
	".cookie-consent",
	".modal-cookie",
	".push-banner-consent",
	".push-banner-consent button.close",
	"#editconsent",
	"#gu-cookie-control",
	"#gu_analytics_switch_off",
	"#gu_ads_switch_off",
	"#gu-consent-confirm",
	"gu_consent_set=true",
	"gu_analytics=false",
	"gu_remarketing=false",
	".cookies-modal",
	".show-cookies-modal .cookies-modal #cookies-accept",
	".show-cookies-modal .cookies-modal #cookies-reject",
	"#cookieBanner",
	"#cookieBanner a[href*='cookies_agreed=']",
	"#cookieBanner span[onclick*='cookieBanner']",
	".cookie-consent-modal.active",
	".cookie-consent-modal #checkbox_analiticas",
	".cookie-consent-modal button.config",
	".cookie-consent-modal #checkbox_analiticas:checked",
	".cookie-consent-modal .btn.accept",
	"cookies_allowed=true",
	"#cookies-info",
	"#cookies-info > .main-container > button",
	"#cookies-info.active",
	".fixed [data-testid=closeCookieBanner]",
	"#perfModal",
	"#perfModal #refuseCookies",
	"#perfModal #refuseCookies:not(.perfModal__btn__frozen)",
	"OptanonAlertBoxClosed=",
	"div.fixed.inset-0.drop-shadow-2xl",
	"div.fixed.inset-0.drop-shadow-2xl button[aria-haspopup=\"dialog\"]",
	"div[role=\"dialog\"] button[type=\"submit\"]",
	"cookieConsent=true",
	"[data-testid=consent-banner]",
	"[data-testid=manage-preferences]",
	"[data-testid=consent-mgr-dialog] [data-ga-button=save-preferences]",
	".notices--bottom_fixer .js-notice[data-notice-id=\"1\"]",
	".notices--bottom_fixer .js-notice[data-notice-id=\"1\"] .js-noticeDismiss",
	"div[role=\"dialog\"][aria-label^=\"Privacy Disclosure\"]",
	"#CookieConsent",
	"#CookieConsentDeclined",
	".notification-banner:has(a[href*=\"/cookie-policy/\"])",
	".notification-banner a[href*=\"/cookie-policy/\"]",
	".notification-banner:has(a[href*=\"/cookie-policy/\"]) button.close-notification-banner",
	"#consent-container",
	"#consent-container #consent",
	"#consent button[data-bs-target='#cookieSettings']",
	"#cookieSettings .modal-footer",
	"#grantAdStorageCookies:checked",
	"#cookieSettings button[onclick*='saveCookieSettings(false)']",
	"#consent-container #consent,#cookieSettings",
	"#header-gdpr",
	"#header-gdpr #header-gdpr-in-btn button",
	"#header-gdpr.is-active",
	"gdprCookieData=ok",
	"#modal-cookies",
	"#modal-cookies-options",
	"#modal-cookies .cookies-settings-link",
	"#cookieMarketingSwitch:checked",
	"#cookieMarketingSwitch",
	"#modal-cookies-options a[href*='confermaImpostazioni']",
	"\"marketing\":false",
	"#capa_galleta",
	"#capa_galleta #acepto_galleta",
	"#notifica-cookies",
	"#notifica-cookies .btn-chiudi",
	"[data-testid=consent-banner] [data-testid=reject-button]",
	"COOKIE_PREF=ANL_0|PSN_0|PRTN_0",
	"xpath///div[contains(., \"Vill du tillåta användningen av cookies från Instagram i den här webbläsaren?\") or contains(., \"Allow the use of cookies from Instagram on this browser?\") or contains(., \"Povolit v prohlížeči použití souborů cookie z Instagramu?\") or contains(., \"Dopustiti upotrebu kolačića s Instagrama na ovom pregledniku?\") or contains(., \"Разрешить использование файлов cookie от Instagram в этом браузере?\") or contains(., \"Vuoi consentire l'uso dei cookie di Instagram su questo browser?\") or contains(., \"Povoliť používanie cookies zo služby Instagram v tomto prehliadači?\") or contains(., \"Die Verwendung von Cookies durch Instagram in diesem Browser erlauben?\") or contains(., \"Sallitaanko Instagramin evästeiden käyttö tällä selaimella?\") or contains(., \"Engedélyezed az Instagram cookie-jainak használatát ebben a böngészőben?\") or contains(., \"Het gebruik van cookies van Instagram toestaan in deze browser?\") or contains(., \"Bu tarayıcıda Instagram'dan çerez kullanımına izin verilsin mi?\") or contains(., \"Permitir o uso de cookies do Instagram neste navegador?\") or contains(., \"Permiţi folosirea modulelor cookie de la Instagram în acest browser?\") or contains(., \"Autoriser l’utilisation des cookies d’Instagram sur ce navigateur ?\") or contains(., \"¿Permitir el uso de cookies de Instagram en este navegador?\") or contains(., \"Zezwolić na użycie plików cookie z Instagramu w tej przeglądarce?\") or contains(., \"Να επιτρέπεται η χρήση cookies από τo Instagram σε αυτό το πρόγραμμα περιήγησης;\") or contains(., \"Разрешавате ли използването на бисквитки от Instagram на този браузър?\") or contains(., \"Vil du tillade brugen af cookies fra Instagram i denne browser?\") or contains(., \"Vil du tillate bruk av informasjonskapsler fra Instagram i denne nettleseren?\")]",
	"xpath///button[contains(., 'Отклонить необязательные файлы cookie') or contains(., 'Decline optional cookies') or contains(., 'Refuser les cookies optionnels') or contains(., 'Hylkää valinnaiset evästeet') or contains(., 'Afvis valgfrie cookies') or contains(., 'Odmietnuť nepovinné cookies') or contains(., 'Απόρριψη προαιρετικών cookies') or contains(., 'Neka valfria cookies') or contains(., 'Optionale Cookies ablehnen') or contains(., 'Rifiuta cookie facoltativi') or contains(., 'Odbij neobavezne kolačiće') or contains(., 'Avvis valgfrie informasjonskapsler') or contains(., 'İsteğe bağlı çerezleri reddet') or contains(., 'Recusar cookies opcionais') or contains(., 'Optionele cookies afwijzen') or contains(., 'Rechazar cookies opcionales') or contains(., 'Odrzuć opcjonalne pliki cookie') or contains(., 'Отхвърляне на бисквитките по избор') or contains(., 'Odmítnout volitelné soubory cookie') or contains(., 'Refuză modulele cookie opţionale') or contains(., 'A nem kötelező cookie-k elutasítása')]",
	".js-cookie-message",
	".js-cookie-message #cookie-chiudi",
	"ISP_Cookie=1.1",
	"IntesaSanpaoloTracciatura=1",
	"#cookiebox",
	"#cookiebox a.close",
	".header-slideout-overlay-cookie",
	".pop-cookie",
	"#rti-privacy-open-modal-btn-id",
	"#rti-privacy-close-btn-id",
	"#iworks_cookie_notice",
	"iWorks_Footer_Notice_close=hide",
	"body.loaded",
	"#iworks-footer-notice-button-close",
	"#cookiebanner-popup",
	"#jg-chrome-header",
	"#cookiebanner-popup #accept-essential-Cookies",
	"necessary:true%2Cpreferences:false",
	".s_box_avvisocookie",
	".s_box_avvisocookie a[onclick*=juzaphoto_refuse_all_cookies]",
	"juzaphoto_refuse_all_cookies=ok",
	"#root > .chakra-stack:has(> div > p > a[href=\"/cookies\"])",
	"button[aria-label^=\"Tilpass informasjonskap\"]",
	"xpath///button[contains(., \"Lagre val\")]",
	".kvib-switch__root[data-state=\"checked\"]",
	"#react-consent-modal",
	"#react-consent-modal .flex.flex-column",
	"#react-consent-modal .flex.flex-row.justify-between button:first-child",
	".cookie:has(.cookie__inner .cookie__button)",
	".cookie > .cookie__inner > .cookie__button > a",
	"#loader.is--show",
	".cookie",
	"cookiesubmit=1",
	"#ccpa-request-consent",
	"#ccpa-request-consent .settings button",
	"#ccpa-request-consent.ccpa-banner--visible .settings button",
	".ReactModal__Content:has(.toggle-grid) .modal__footer button.button--vibrant--filled",
	".ReactModal__Content:has(.toggle-grid)",
	"#ccpa-request-consent button.close",
	"#gdpr-banner-container",
	"#gdpr-banner-container #gdpr-banner [data-testid=gdpr-banner-decline-button]",
	".cookieconsent .cc_banner-wrapper",
	".cookieconsent .cc_banner-wrapper [onclick*='refuseAllCookiesPreferences']",
	".cookieconsent .cc_banner",
	".cc_banner [onclick*='refuseAllCookiesPreferences']",
	"_cprefs=%7B%22stats%22%3A1%2C%22fct%22%3A1%2C%22mkt%22%3A1%7D",
	"#qc-cmp2-ui, #qc-cmp2-usp",
	"#qc-cmp2-usp .qc-usp-ui-content button[mode=\"primary\"]",
	"#qc-cmp2-mspa-success-modal-button-footer-container button",
	"#qc-cmp2-container button.qc-cmp2-link-inline",
	"#reject-all-btn",
	"#save-and-exit",
	"#js-cookie-section",
	"#js-cookie-section #js-cookie-consent-deny",
	"#js-cookie-section.show",
	"cookieConsent=false",
	"#gdpr",
	"#gdpr #gdpr-button",
	"div:has(> div > a[href*='/privacy-policy'])",
	".cookie-preferences-banner",
	".cookie-preferences-banner .reject-all-cookies",
	".cookie-preferences-banner .dismiss-banner",
	"analytics%22%3Afalse",
	"[class*=\"ConsentModal_consent-modal__modal-overlay\"]",
	"[data-test=\"cookie-necessary-button\"]",
	"AGE_GATE=",
	"[data-test=\"age-gate-overlay\"]",
	"%22key%22%3A%22analytics%22%2C%22value%22%3Afalse",
	"[class*=\"CookiesBanner_cookies-banner\"]",
	"[class*=\"CookiesBanner_cookies-banner\"] [class*=\"CookiesBanner_buttons\"] button",
	"[class*=\"CookiesBanner_buttons\"] button:first-child",
	"[role=\"dialog\"] [class*=\"_actions_\"] button:first-child",
	"#cookieNotice",
	"#cookieNotice > a.btncookieNoticesettings",
	"section.consent-banner",
	"section.consent-banner button.hide-consent",
	"#cookie-consent-popup",
	"#cookie-consent-popup #cookie-consent-accept-selected",
	"#cookie-consent-popup input[type=checkbox]:checked:not(:disabled)",
	"analytics_cookies=false!personalizationAndMarketing_cookies=false",
	".consent-categories-modal-wrapper",
	"#consent-categories-modal [data-modal-consent-open-settings]",
	"#edit-consent-app input[name=consent-category][value=nc]:checked",
	"#edit-consent-app input[name=consent-category]:checked:not(:disabled)",
	"#consent-categories-settings [data-modal-submit]",
	"#consent-categories-modal",
	"#cookie-banner #cookie-consent-settings",
	"#cookie-banner #cookie-consent-view",
	"#cookie-banner #cookie-settings-view",
	"#cookie-form input[type=checkbox]:checked:not(:disabled)",
	"#cookie-banner #cookie-settings-save",
	"analytic%3A0",
	".cookie-overlay",
	"#cookiePopup .reject-cookie",
	"_site_acceptance=0",
	"div:has(> #notice-cookie-block)",
	"[data-dialog-ref-name=\"cookie-text-popup\"]",
	"#notice-cookie-block #btn-manage-cookie",
	"#btn-manage-cookie-save-preferences",
	"#cookie-text-popup input[type=\"checkbox\"]:checked",
	"%22marketing%22%3Afalse%2C%22analytic%22%3Afalse",
	"app-cookie-modal .top-info-cookie",
	"app-cookie-modal .top-info-cookie .close-x",
	"PatientPortalCookieMonit=1",
	".js-gdpr-banner-top-hide",
	".js-gdpr-banner .js-gdpr-banner-top-hide",
	".js-gdpr-banner-top-hide .js-gdpr-banner-disagree",
	"cookie_banner=false",
	".popuppanel4 a[href*=\"/info/cookie/\"]",
	".popuppanel4 .js-popupclose",
	".popuppanel4",
	".makita-footer-warning",
	".makita-footer-warning .js-makita-modal[data-src*='privacysettings']",
	".about-cookies a[data-post*='allowcookie=false']",
	".cookies-notification-wrapper .cookie-accept-all-cta",
	".cookies-notification-wrapper .customise-cookies-cta button",
	".cookies-notification-wrapper .cookie-details-section",
	".cookies-notification-wrapper .cookie-details-section input[type=checkbox]:checked:not(:disabled)",
	".cookies-notification-wrapper .cookies-notification-bottom div:not(.hideCookiesPreferenceBtn) > button",
	"#cookies-banner",
	"#cookies-banner [class*=\"CookiesFooter-module\"]",
	"#cookies-banner [class*=\"CookiesFooter-module\"] > button:nth-child(2):not([id])",
	"#cookies-banner [class*=\"CookiesFooter-module\"] > button:first-child:not([id])",
	"#cookies-banner [class*=\"CookiesSettings-module\"][class*=\"buttonsWrapper\"] > button:nth-child(2)",
	"\"targeting\":\"DENIED\"",
	".navbar-privacy",
	"nav.navbar-privacy .privacy-continue",
	"#generic-modal .privacy-accept",
	"nav.navbar-privacy",
	".cookie-banner[data-block-name=\"cookie-banner\"]",
	".cookie-banner[data-block-name=\"cookie-banner\"] .alert-close",
	".cookie_info",
	".cookie_info > span.cookie_ok",
	"section[aria-label=\"Cookie preferences\"]",
	"xpath///section[@aria-label=\"Cookie preferences\"]//button[normalize-space()=\"Cookie Settings\"]",
	"div[role=\"dialog\"][aria-labelledby=\"consent-settings-title\"]",
	"xpath///label[contains(., \"Necessary and functional cookies\")]//input[@name=\"cookie-tier\"]",
	"div[role=\"dialog\"][aria-labelledby=\"consent-settings-title\"] button:not([aria-label])",
	"div:has(> div > div > div[role=alert] > a[href^=\"https://policy.medium.com/medium-privacy-policy-\"])",
	"dialog.cookie-banner",
	"dialog.cookie-banner .customise-cookie",
	"dialog.cookie-banner button.reject",
	"dialog.cookie-dialog button.save",
	"dialog.cookie-dialog .toggle-control.on:not(.disabled)",
	"dialog.consent-dialog .consent-settings .consent-category input[data-category]",
	"dialog.consent-dialog",
	"dialog.consent-dialog .consent-wrapper > .consent-buttons > .consent-button-secondary",
	"dialog.consent-dialog .consent-settings.active",
	"dialog.consent-dialog .consent-category input[type=checkbox]:checked:not([disabled])",
	"dialog.consent-dialog .consent-settings .consent-buttons > .consent-button:not(.consent-button-secondary)",
	"%22ad_storage%22%3A%22denied%22",
	"div[aria-label=\"Cookie Policy Banner\"]",
	"dialog.cookieconsent__dialog",
	".cookieconsent__base[data-component=\"cookieconsent\"]",
	".cookieconsent__buttonAcceptNecessary",
	"consent_choice=",
	".cookie-modal.open",
	".cookie-modal.open .cookie-box",
	".cookie-modal.open .btn-box .simple-btn.cancel",
	"#consent-tracking .btn-necessary",
	"\"marketingCookie\":false",
	"#mde-consent-modal-container",
	"#mde-consent-modal-dialog",
	"#mde-consent-modal-dialog .mde-consent-decline-btn",
	"mdeConsentData=",
	"[role='region'][aria-label='Cookie consent']",
	"xpath///div[@role='region'][@aria-label='Cookie consent']//button[normalize-space(.)='Reject']",
	"[role='dialog'][data-diagnostic-boundary='modal-shell'] button[aria-label='Close']",
	"mq-alert-cookies",
	"#cmp-banner-sdk",
	".cmp-sdk-container",
	"#cmp-reject-all-handler",
	"#onetrust-banner-sdk",
	".privacy-confirmation",
	".privacy-confirmation .pc-buttons",
	".privacy-confirmation [data-cy=accept-core-button], .privacy-confirmation .pc-buttons > button.ui-parts-button-fill:not([data-cy])",
	"dialog[data-test=\"common-consent\"]",
	"#nlportal-cookie-consent .modal",
	"dialog[data-test=\"common-consent\"] [data-test=\"consent-reject-all\"], #nlportal-cookie-consent .cookie-consent-modal-static-buttons > button",
	"dialog[data-test=\"common-consent\"] [data-test=\"consent-reject-all\"], #nlportal-cookie-consent .cookie-consent-modal-static-buttons > button:nth-child(2)",
	"dialog[data-test=\"common-consent\"], #nlportal-cookie-consent .cookie-consent-modal-static-buttons",
	".cookie-policy-wrapper .cookie-policy-content",
	".cookie-policy-wrapper #declineCookies",
	"cookies_policy=analyticsCookies%3Doff%26functionalityCookies%3Doff",
	"div#cookieWarning",
	"a#btnCookiesDenyAll",
	"button[aria-label='Close cookie banner']",
	"[data-show-cookie-banner=\"true\"]",
	"[data-show-cookie-banner-overlay=\"true\"]",
	"[data-show-cookie-banner=\"true\"], [data-show-cookie-banner-overlay=\"true\"]",
	"[class*=ConsentManager]",
	"[class*=ConsentManager_cookieBar]",
	"xpath///button[contains(@class, \"ConsentManager_cookieBarButton\") and contains(., \"weigeren\")]",
	"#cookie-banner #reject-cookies",
	"#cookie-banner.nhsuk-cookie-banner",
	"#cookie-banner [data-qa=\"cookie-banner-close\"]",
	"#cookie-banner [data-qa=\"cookie-banner\"]",
	"[data-testid=cookie-dialog-root]",
	"input[type=radio][id$=-declineLabel]",
	"[data-testid=confirm-choice-button]",
	"#CookieReportsPanel #CookieReportsBanner .wscrOk2",
	"#CookieReportsBanner .wscrSwitch input[type=checkbox]:checked:not([disabled]) + label",
	"#CookieReportsBanner .wscrOk2",
	"wscrCookieConsentShared=1=true&2=false&3=false&4=false&5=false",
	"[role=dialog] #cookie-accept-all-secondary",
	"[role=dialog] #cookie-accept-all-secondary + button",
	"consent_cookie=necessary",
	"gdpr-banner",
	"xpath///button[contains(., 'Imposta le tue preferenze')]",
	"input[data-part='checkbox-input'][name='analytics']",
	"input[data-part='checkbox-input'][name='analytics']:checked",
	"input[data-part='checkbox-input'][name='marketing']:checked",
	"input[data-part='checkbox-input'][name='marketing']",
	"xpath///button[contains(., 'Salva le mie impostazioni')]",
	"cookie_consent=a%3D0%26m%3D0",
	".cookies-agreement-notification,.modal-new:has([data-module=SetupCookies])",
	".cookies-agreement-notification",
	".cookies-agreement-notification .cb_setup",
	"[data-module=SetupCookies]",
	"[data-module=SetupCookies] input[type=checkbox]:checked:not(:disabled)",
	"[name=button_save_choice]",
	"#gdpr-selection-screen",
	"#gdpr-selection-screen #gdpr-permissionlevel-1",
	"#gdpr-selection-screen #gdpr-screen-content",
	"#gdpr-selection-screen .button-container button",
	"MascGdrpPermission=1",
	"#alert_cookies",
	"#alert_cookies #alert_cookies_close",
	"div.b-cookies-informer",
	"div.b-cookies-informer__nav > button:nth-child(1)",
	"div.b-cookies-informer__switchers",
	"div.b-cookies-informer__switchers input:not([disabled])",
	"div.b-cookies-informer__nav > button",
	".cookie-popup",
	".cookie-popup .cookie-popup__button",
	"[aria-labelledby=cookieConsentTitle]",
	"[aria-labelledby=cookieConsentTitle] button[aria-haspopup=dialog] + button",
	"consent=rejected",
	"#cookie-consent .cookie-all__btn",
	"#cookie-consent .cookie-consent__switch.active:not(.always_on)",
	"#cookie-consent .cookie-selection__btn",
	"cookie_consent_essential=true",
	"cookie_consent_marketing=true",
	"#id01.w3-modal",
	"#id01.w3-modal button[onclick*=\"setCookie('polityka'\"]",
	"#orbys-cookies",
	"#orbys-cookies .occ-btn",
	"osf-cookie-consent-banner",
	"osf-cookie-consent-banner p-message",
	".cookie-manager",
	".cookie-manager .cookie-notice.open",
	".cookie-notice button.owid-btn--outline-dark-blue.cookie-notice__button",
	"#cookie-consent ~ .banner-shadow",
	"#cookie-consent .cc-window[aria-describedby=\"cookieconsent:desc\"]",
	"#cookie-consent, #cookie-consent ~ .banner-shadow",
	"footer .ccpabanner",
	"#bandeaucookie",
	"#bandeaucookie #cookieOk",
	"pekao-cookies",
	"pekao-cookies .cookies-wrapper",
	"pekao-cookies .cookies-button button",
	"np24Cookies=",
	"[data-ui-test=pm-cookie-banner]",
	"[data-ui-test=pm-cookie-banner-decline-button]",
	"pm_cookie_consent_level=1",
	".cookie-consent-popup",
	".cookie-consent-popup .cookie-consent-accept",
	".cookie-consent-popup .cookie-consent-accept .elementor-button",
	"cookie_consent=accepted",
	".BusinessCookieConsent",
	".BusinessCookieConsent [data-id=cookie-consent-banner-buttons]",
	"[data-id=cookie-consent-banner-buttons] > div:nth-child(2) button",
	"#cookieMessage[data-cookie-boundary]",
	".cookie-bg",
	".cookie-bg .cookie-inner .cookie-btn--accept",
	".cookie-bg .cookie-inner",
	".cookie-bg .personalise-btn",
	".cookie-bg form .cookie-list",
	".cookie-bg form .cookie-item input[type=checkbox]:checked:not([disabled])",
	".cookie-bg form button[type=submit]",
	"gdpr-ga=false",
	"gdpr-fbp=false",
	"#cookie-consent button",
	"#cookie-consent input[type=checkbox]:checked:not(:disabled)",
	"plosCookieConsentStatus=false",
	"[data-testid=cookie-consent-bar-desktop], [data-testid=cookie-consent-bar-mobile]",
	"[data-testid=manage-cookies-button-desktop]",
	"[data-testid=manage-cookies-button-mobile]",
	"[data-testid=cookie-consent-modal]",
	"[data-testid=cookie-consent-modal] input[type=checkbox]:checked",
	"[data-testid=cookie-consent-save-button]",
	"pmo_c_acc=true",
	"pmo_c_mark=true",
	"#notification-stack > div:has(> header > [style*='ui-icons-lock.svg'] ~ button)",
	"#notification-stack header:has([style*='ui-icons-lock.svg']) button",
	"#notification-stack header:has([style*='ui-icons-lock.svg'])",
	"#cookieBanner.cbShort",
	"#cookieBanner.cbShort .cbCloseButton",
	"#cookieBanner #cookieBannerContent",
	"#cookieBanner #cookieBannerContent, #globalCookieBanner",
	"#globalCookieBanner .js-customizeGlobalCookies",
	"#cookieBanner [data-label=accept_essential]",
	"#cookieBanner button.cbSecondaryCTA",
	"#cookie-form",
	"#cookie-form .reject",
	"_cookieNoticeSettings=%7B%22performance%22%3Afalse%2C%22targeting%22%3Afalse%2C%22analytic%22%3Afalse%7D",
	"xpath///li[contains(@class, 'ToastRoot')][contains(., 'cookie banner')]",
	"xpath///li[contains(@class, 'ToastRoot')][contains(., 'cookie banner')]//button[@data-radix-toast-announce-alt='Close']",
	"pnl-cookie-wall-widget",
	"CookiePermissionInfo",
	".alert .accept-cookies,form.js-cookies",
	".alert:has(.accept-cookies)",
	"form.js-cookies button",
	"form.js-cookies input[type=checkbox]",
	"form.js-cookies input[type=checkbox]:checked:not(:disabled)",
	"form.js-cookies button[type=submit]",
	".alert:has(.accept-cookies) a[href='/account/cookies']",
	"#cookiesPopup",
	"#cookiesPopup button.MuiButton-outlined",
	"#cookiesPopup .MuiSwitch-root",
	"#cookiesPopup button",
	"#tc-banner",
	"#tc-consent #tc-banner",
	"#tc-banner .tc-accept-btn",
	".tc-checkbox:checked:not([disabled])",
	"UserConsentedToTastyCookies=[\"nodvandiga\"]",
	".c-modal.is-active",
	".c-modal.is-active .is-dismiss",
	"div.cookie:has(a.cookie-okay-button)",
	"div.cookie a.cookie-okay-button",
	"[data-testid=\"cookie-consent-sticky-footer\"]",
	"[data-testid=\"cookie-consent-sticky-footer\"][aria-hidden=\"false\"]",
	"[data-testid=\"cookie-consent-sticky-footer\"] button[aria-label]:first-child",
	"[data-testid=\"_cookie_modal_test\"]",
	"[data-testid=\"_cookie_modal_test\"] label:has(input[type=\"checkbox\"]:checked)",
	"[data-testid=\"_cookie_modal_test\"] button[aria-label=\"button-pmui\"]",
	"\"analytics_storage\":\"denied\"",
	".cookies .cookies__container",
	".cookies .cookies__close button.cookies__button",
	"cookieAgreements=true",
	".gdpr[data-gdprservice]",
	".gdpr[data-gdprservice]:not(.hide)",
	"#__rptl-cookiebanner #__rptl-cookiebanner-reject",
	".DialogHandlerContainer.visible:has(.cookie-dialog)",
	"#cookiesStrip:has([data-testid='accept-cookies'])",
	".DialogHandlerContainer.visible:has(.cookie-dialog), #cookiesStrip:has([data-testid='accept-cookies'])",
	"#cookiesStrip [data-testid='skip-cookies']",
	"span.cookie-option-large>div>span.link-no-decoration.gui-text",
	".cookie-dialog form .CookieConsentOption input[type='checkbox']:not([name='permanent']):checked",
	".cookie-dialog button[type='submit']",
	"[bundlename=reddit_cookie_banner]",
	"#data-protection-consent-dialog rpl-modal-card > button.button-primary",
	"#data-protection-consent-dialog rpl-modal-card > button.button-secondary",
	"eu_cookie={%22opted%22:true%2C%22nonessential%22:false}",
	"#cookiebanner",
	"#cookiebanner #acceptNecessaryCookiesBtn",
	"refbConsent={%22categories%22:[%22necessary%22]%2C",
	"%22consent_date%22:1",
	"#footer > .container > .d-flex > button.btn-outline-primary",
	"div:has(> button#cookieBar-button)",
	"#cookieBar-button",
	"#cookie_container",
	"#cookie_container #accept_cookies_btn",
	".cookie-banner-wrapper",
	".cookie-banner-wrapper .cookie-banner",
	".cookie-banner-wrapper button.btn-secondary-lg",
	"RBXcb",
	"#cookie-policy-info",
	"div.cookie-btn-box > div[aria-label=\"Reject\"]",
	".cookie-policy-lightbox-bottom > div[aria-label=\"Save Settings\"]",
	"[role=dialog] form #cookie_consent_accept_all_button",
	"[role=dialog] form:has(#cookie_consent_accept_all_button) button[type=button]",
	"[role=dialog] form input#analytical",
	"[role=dialog] form input#analytical:checked",
	"[role=dialog] form:has(input#analytical) button[type=submit]:not(#cookie_consent_accept_all_button)",
	"#m-cookienotice",
	"#manage-cookies",
	"#accept-selected",
	".cookie-consent .cookie-close",
	".cookie-consent.is-show .cookie-close",
	"cookie=true",
	"rspb-cookie-banner",
	"rspb-cookie-banner .buttons button.btn-light",
	"rspb-cookie-banner [data-testid=\"options\"]",
	"rspb-cookie-banner button[label=\"Save settings\"]",
	"RSPB.AllowMarketingCookies=No",
	".cookies-banner-shown",
	"#ConsentBar",
	"#ConsentBar [data-js--cookie=\"cookies-accept-functional\"]",
	"#gdprconsent.gdprcontainer",
	"#gdprconsent .gdprbutton a",
	"gdpr-consent=0",
	"script[src*='consent.cookiebot.com/uc.js']",
	"#cookiebanner #DeclineAll",
	"statistics:false%2Cmarketing:false",
	"#cookie-popup-with-overlay",
	"#cookie-popup-with-overlay [data-ref='cookie.no-thanks']",
	"RY_COOKIE_CONSENT",
	"div.cookie-bar",
	"#popup-notice",
	"#popup-notice .popup__close",
	"saturdaysnyc-notice=1",
	"#kakrutan",
	"#kakrutan scb-button[value='inget']",
	".cc-window[aria-describedby=\"cookieconsent:desc\"]",
	".cc-window.cc-type-info[aria-describedby=\"cookieconsent:desc\"] .cc-dismiss",
	"body.cookie-overlay",
	".cc-window[aria-describedby=\"cookieconsent:desc\"] .cc-dismiss",
	"body > div#__next > div#app > div:nth-child(7):not([id])",
	"xpath///div[contains(@class, 'MuiBackdrop-root')][.//h1[contains(., 'Your Privacy Matters to Us')]]",
	"xpath///div[contains(@class, 'MuiBackdrop-root')][.//h1[contains(., 'Your Privacy Matters to Us')]]//button[normalize-space(.)='Reject Optional']",
	"xpath///div[contains(@class, 'MuiBackdrop-root')][.//h1[contains(., 'Your Privacy Matters to Us')]]//button[contains(normalize-space(.), 'MANAGE PREFERENCES')]",
	"xpath///div[contains(@class, 'MuiBackdrop-root')][.//h1[contains(., 'Manage Preferences')]]//button[normalize-space(.)='Save Preferences']",
	"\"functional\":false",
	"\"performance\":false",
	"\"personalization\":false",
	"[data-qa=\"GDPRBanner-Container\"]",
	"[data-qa=\"GDPRBanner-Container\"] [data-qa=\"GDPRBanner-Button\"]",
	"#cookieContainer #cookies",
	"#cookieContainer #cookies .cookies_inner button[onclick*='Rechazar']",
	"%7E%7Cparcial",
	"#cookie-info",
	"#cookie-info .button-row button.btn-secondary",
	"#cookie-info #no-ad-cookies",
	"#cookie-info form button.save-button",
	".sw-cookie=1",
	".cookie-consent[data-cookieconsent], .gdpr-tab",
	".cookie-consent[data-cookieconsent], .gdpr-tab #gdpr_tab_content",
	"__hs_opt_out=",
	"__hs_opt_out=yes",
	"[class*=\"cookie-consent-required\"]",
	"html[data-cookie-consent-required] [data-testid=\"accept-all-cookie-button\"]",
	"[data-testid=\"accept-all-cookie-button\"]",
	"body[data-scroll-locked]",
	"[data-testid=\"customize-cookie-button\"]",
	"[data-testid=\"confirm-settings-cookie-button\"]",
	"[data-testid=\"cookie-banner\"] button:has(+ button)",
	"dialog[open]:has(input[name^=\"cookiesetting.\"])",
	"dialog[open] input[name^=\"cookiesetting.\"]:checked:not([disabled])",
	"dialog[open]:has(input[name^=\"cookiesetting.\"]) > div > div.p-4 > button",
	"body > div[class*=_shein_privacy]",
	"body > div[class*=_shein_privacy] > div:nth-of-type(2) > div:nth-of-type(4) > div:nth-of-type(3)",
	"#cookie-bar .cb-enable,[class^=\"app_gdpr--\"] button",
	"aside[x-data=\"cookieConsent\"]",
	"#shopify-pc__banner, aside[x-data=\"cookieConsent\"] > div.opacity-100",
	"custom-cookie-consent#cookieBubble.banner-show",
	"custom-cookie-consent#cookieBubble #configureBtn",
	"custom-cookie-consent#cookieBubble.banner-show #configureBtn",
	".custom-cookie-modal #acceptNecessaryBtn",
	"[data-testid=\"cookie-wall\"]",
	"[data-testid=\"cookie-wall\"] .cookie-bar__footer button[data-id=\"0\"]",
	"acceptCookies=0",
	"skv-cookie-banner",
	"SKVCookieAllow=strictlyNecessary",
	"#cookieBannerContent",
	"[data-tracking-element-id=cookie_banner_essential_only]",
	"[data-test-id=cookie-consent-banner]",
	"[data-test-id=cookie-consent-banner] #accept-necessary-cookies-button",
	"cookie-accept-necessary=accepted",
	"#app > div:has(> div:last-child > button:first-child + button:last-child)",
	"#app > div:not(:has(input[role=switch])) > div:last-child > button:last-child:not(:first-child)",
	"#app > div:has(input[role=switch]) > div:last-child > button:first-child",
	"#app > div:has(input[role=switch]) input[role=switch][aria-checked=true]:not([disabled])",
	"_s.cookie_consent=marketing=0:analytics=0",
	".sm-alert[data-cookie^='cookie.disclaimer']",
	".sm-alert.is-visible[data-cookie^='cookie.disclaimer'] .sm-alert__button",
	"disclaimer=closed",
	".m-gdpr-banner",
	".o-overlay--gdpr",
	".m-gdpr-banner .js-m-gdpr-banner__button-manage",
	".m-gdpr-banner.state-m-gdpr-banner--visible",
	".m-gdpr-settings .js-m-gdpr-settings__button-custom",
	".m-gdpr-settings input:checked:not(:disabled)",
	"#cookiesModal #cookiesModalCloseBtn",
	"#cookiesModalCloseBtn",
	"app-cookie-consent",
	"app-cookie-consent button.underline",
	"app-cookie-consent ui-switch button.switch",
	"app-cookie-consent ui-switch button.switch.checked:not(.disabled)",
	"app-cookie-consent app-btn button",
	"#cookie-consent-message",
	"#cookie-consent-message #cookie-consent-reject",
	"#cookie-consent-reject",
	"cookieconsent_status=0",
	".plug-gdpr-wrapper.js-gdpr-wrapper",
	".plug-gdpr-wrapper.js-gdpr-wrapper .js-gdpr-button",
	".plug-gdpr-wrapper--show.js-gdpr-wrapper",
	"[aria-describedby=\"cookieconsent:desc\"], .cc_overlay_bg",
	"#js-cookie-notification",
	"div.fixed.inset-0:has(.lucide-cookie)",
	"xpath///div[contains(@class, 'inset-0')]//button[contains(., 'Refuser tous')]",
	".consent__wrapper",
	".consent",
	"button.consentSettings",
	"button#consentSubmit",
	"dialog[class*=\"CookieModal-module\"]",
	"dialog[class*=\"CookieModal-module\"] button[class*=\"__secondaryButton\"]",
	"[role=\"dialog\"] [class*=\"SettingsModal-module\"]",
	"[role=\"dialog\"] [class*=\"SettingsModal-module\"] input[type=\"checkbox\"]:checked",
	"[role=\"dialog\"]:has([class*=\"SettingsModal-module\"]) [class*=\"__footer\"] button",
	"targTK=false",
	"#banniere_cookies",
	"#banniere_cookies span[onclick]",
	".CookieConsent__root",
	".CookieConsent__root .CookieConsent__modal",
	".CookieConsent__root button[data-consent-action=reject-all], #CookieConsent_reject_all",
	"\"improved_experience\":false,\"partners\":false",
	"#cookieChoiceInfo",
	"#cookieChoiceInfo #cookieChoiceLearnMore",
	"[id$='_ManageCookiesContent'] input[name$='BtnConfirmChoices']",
	"[id$='_ManageCookiesContent'] input[type=checkbox]:checked",
	"analyticsCookieConsent=n",
	"#myModal.showmodal",
	"#myModal.showmodal .showmodal-close",
	"div:has([href=\"cookiePrivacyLink\"]) + div:has(> [role=button][aria-label])",
	"div:has([href=\"cookiePrivacyLink\"]) + div:has(> [role=button][aria-label]) > [role=button][aria-label]:nth-child(2)",
	"privacy_setting_detail=%7B%22adsChoice%22%3A%220",
	"[aria-label=consent-banner]",
	"xpath///button[contains(., 'Reject all')]",
	"interactionCount=1",
	"#tsla-reject-cookie",
	"tsla-cookie-consent=rejected",
	".cookie-popups__container",
	".cookie-popups__first-consent-popup",
	"[data-test-id=\"cookie-manage-settings-button\"]",
	".cookie-popups__preferences-popup",
	".cookie-popups__advertising-toggle:checked",
	"[data-test-id=\"cookie-advertising-slider\"]",
	"[data-test-id=\"cookie-save-preferences-button\"]",
	"lts-cookie-consent=1",
	"#user-consent",
	"#user-consent .page.main button.manage",
	"#user-consent .page.main",
	"#user-consent .page.secondary",
	"#user-consent .page.secondary input[type=checkbox]:checked:not([disabled])",
	"#user-consent .page.secondary button.save",
	"\"marketing\":\"denied\"",
	"#consent-banner button[data-testid='close-button']",
	"[data-callback=\"accounts/hide-banner/CookiesBanner\"]",
	"[data-callback=\"accounts/hide-banner/CookiesBanner\"] button[class*=\"ManageLink\"]",
	"[data-testid=\"modal-body-content\"] [class*=\"IndividualBox\"] input[type=\"checkbox\"]",
	"[data-testid=\"modal-body-content\"] [class*=\"IndividualBox\"] input[type=\"checkbox\"][aria-disabled=\"false\"]:checked",
	"[data-testid=\"modal-body-content\"] [class*=\"Footer\"] button",
	"%22advertising%22%3Afalse",
	".optanon-alert-box-wrapper",
	".optanon-alert-box-wrapper .optanon-toggle-display",
	"#optanon-popup-wrapper",
	"#optanon-menu li.menu-item-on:is(.menu-item-performance,.menu-item-functional,.menu-item-advertising,.menu-item-social) button",
	"#optanon-popup-more-info-bar .optanon-status-editable .optanon-status-on label",
	"#optanon-popup-bottom .optanon-save-settings-button button",
	"%2C2%3A0%2C3%3A0%2C4%3A0",
	"[role=dialog][aria-labelledby=cookie-banner-title]",
	"xpath///div[@role='dialog'][@aria-labelledby='cookie-banner-title']//button[normalize-space()='Manage preferences']",
	"xpath///div[@role='dialog'][.//input[@id='consent-toggle-analytics']]//button[normalize-space()='Reject all']",
	"#consent-toggle-analytics:not(:checked)",
	"xpath///div[@role='dialog'][.//input[@id='consent-toggle-analytics']]//button[normalize-space()='Save preferences']",
	"#cookie-notification #accept-cookie",
	"#cookie-notification:not(.hide)",
	"cookies-accepted=true",
	"div[role=alertdialog][data-nosnippet][aria-describedby]",
	"div[role=alertdialog][data-nosnippet][aria-describedby] > div > div:last-child > div:last-child > button",
	"div[role=dialog][data-nosnippet][aria-labelledby] > div > div:last-of-type > div > div:nth-child(2) > button",
	"[data-test=\"cookie-banner\"]",
	"[data-test-id=cookies_section]",
	"#tkConsentmanager",
	"#tkConsentmanager .g-consentmanager__confirm-selection",
	"tkConsentWirtschaftlicherWerbeeinsatz=0",
	"#cookie-consent #cookie-consent-btn-customise",
	"#cookie-consent #cookie-consent-btn-accept-some",
	"#cookie-consent-btn-customise",
	"#consent-marketing:checked",
	"#consent-marketing",
	"#consent-analytics:checked",
	"#consent-analytics",
	"#cookie-consent-btn-accept-some",
	"%22analytics%22%3Afalse%2C%22marketing%22%3Afalse",
	"#cookie-compliant",
	"#cookie-compliant #saveAndAcceptCookies",
	"#cookie-compliant #cookies-config",
	"#cookie-compliant #cookie_b:checked",
	"#cookie-compliant #cookie_b",
	"#cookie-compliant #cookie_c:checked",
	"#cookie-compliant #cookie_c",
	"ALLOW_COOKIES=a",
	"ALLOW_COOKIES=a-",
	"xpath///div[contains(@class, 'fixed') and contains(., 'Cookieをブロック') and .//button[normalize-space()='Cookieの設定']]",
	"xpath///div[contains(@class, 'fixed') and contains(., 'Cookieをブロック')]//button[normalize-space()='Cookieの設定']",
	"xpath///button[normalize-space()='設定を保存する']",
	".optIn",
	".optIn .js-optin-cookie-settings",
	"label[for=\"TAB-02\"]",
	"label[for=\"TAB-02\"] + .tab-content .toggleSwitch__circle",
	"label[for=\"TAB-03\"]",
	"label[for=\"TAB-03\"] + .tab-content .toggleSwitch__circle",
	".js-modal-save-settings",
	"__performanceCookieFlag__=0",
	"__targetingCookieFlag__=0",
	"div:has(> button#accept-button):has(> button#decline-button)",
	"button#accept-button,button#decline-button",
	"button#decline-button",
	"#consent-modal",
	"#privacy-settings-content",
	"button[type=\"submit\"]",
	"div.one-modal__action-footer-column--secondary > a",
	".fixed.bottom-0:has([data-test=cookieBannerButton])",
	".fixed.bottom-0 [data-test=cookieBannerButton]",
	"[class*=\"cookie-warning-wrapper\"]",
	"[class*=\"cookie-warning-wrapper\"] #notAllowCookiesButton",
	"#notAllowCookiesButton",
	"COOKIE_WARNING_REJECTED=true",
	".tvp-cookie-overlay",
	".tvp-cookie-overlay .tvp-covl",
	".tvp-covl .tvp-covl__sb",
	".tvp-covl .tvp-covl__save",
	".tvp-covl input.iabd:not(:checked)",
	".tvp-covl input.iabd",
	"TVPtcs22=",
	"[data-a-target=\"consent-banner\"],.ReactModalPortal:has([data-a-target=consent-modal-save])",
	"[data-a-target=\"consent-banner\"]",
	"[data-a-target=\"consent-banner-accept\"]",
	"[data-a-target=\"consent-banner\"] button:not([data-a-target])",
	"button[data-a-target=\"consent-banner-manage-preferences\"]",
	"input[type=checkbox][data-a-target=tw-checkbox]:not([disabled])",
	"input[type=checkbox][data-a-target=tw-checkbox]:not(:checked):not([disabled])",
	"[data-a-target=consent-modal-save]",
	".ReactModalPortal:has([data-a-target=consent-modal-save])",
	"#footer_tc_privacy",
	"#privacy__modal__close, #footer_tc_privacy #privacy__links__center",
	"#privacy__modal__close, #footer_tc_privacy",
	"#privacy__modal__close",
	"#footer_tc_privacy #privacy__links__center",
	"#privacy_options #options_tc_privacy_button",
	"UBI_PRIVACY_POLICY_VIEWED=true",
	"UBI_PRIVACY_ADS_OPTOUT=true",
	"#__tealiumGDPRcpPrefs #consent-container",
	"#__tealiumGDPRcpPrefs #consent-container #consent-modal-settings",
	"#no-consent-popup-close-modal",
	"#cookieModal",
	"#cookieModal [onclick*=\"cookiesPolicy.selDefAndloadScript\"]",
	"unive.it=1",
	"noiframe=checked",
	"socialpix=checked",
	"app-cookie-consent > .cookie-banner",
	"app-cookie-consent .cookie-banner",
	"app-cookie-consent .cookie-banner > div > button:nth-of-type(2)",
	"#modal-consent-banner",
	"#modal-consent-banner #btn-edit-cookie-consent",
	"#cookie-consent-banner #btn-edit-cookie-consent",
	"#cookie-consent-dialog #btn-accept-some",
	"#consent-ad:checked",
	"#consent-ad",
	"#cookie-consent-dialog",
	".ucb",
	".ucb-banner",
	".ucb-banner .ucb-btn-save",
	"#js-pw-consent-wrapper bgl-modal[test-id='cookie-modal']",
	"#js-pw-consent-wrapper [data-ta-id='pw-consent-rejectAllButton']",
	".alert-cookie #dismiss-cookie-banner-button",
	"vd_cookie_warning=1",
	".gdpr_container",
	".gdpr_modal_container",
	".gdpr .gdpr_manage_cookies_button",
	".gdpr .gdpr_container",
	".gdpr_modal .gdpr_modal_button_reject",
	"vg_consent={\"functionality\":false,\"performance\":false,\"targeting\":false}",
	".cookie-policy-modal",
	".manage-cookies-modal",
	".cookie-policy-modal .cookie-policy-details button.manage",
	".manage-cookies-modal .manage-cookies-footer button.btn-outline-primary",
	".dip-consent,.dip-consent-container",
	".dip-consent-container",
	".dip-consent-content",
	".dip-consent-btn[tabindex=\"2\"]",
	"cookie-banner#cookie-banner-host",
	"C3%3A0",
	"C4%3A0",
	".footer-signup:has(consent-scheduler > .cookie-consent-js:not(.hidden))",
	"consent-scheduler > .cookie-consent-js",
	".footer-signup.active consent-scheduler > .cookie-consent-js:not(.hidden)",
	"a[href=\"https://www.walmartcanada.ca/cookie-notice\"]",
	"button[data-dca-intent=\"open\"][role=\"link\"]",
	"xpath///button[contains(., 'Save settings') or contains(., 'Enregistrer les paramètres')]",
	".MuiDialog-root [role=dialog] img[src*=\"portalCKM-cookie-dialog\"]",
	".MuiDialog-root [role=dialog] button.MuiButton-outlined",
	".MuiDialog-root [role=dialog] .MuiFormGroup-root button.MuiButton-outlined",
	".MuiDialog-root [role=dialog] .MuiFormGroup-root input[type=checkbox]:checked:not(:disabled)",
	".MuiDialog-root [role=dialog]",
	".cookie-banner .btn-accept-selected",
	".cookie-banner .toggle-switch[aria-pressed='true']",
	"[role=dialog] [data-testid=view-preferences], .CookieNotice-Dialog [data-testid=Preferences]",
	"[role=dialog] [data-testid=view-preferences]",
	"[role=dialog] [data-testid=save-preferences]",
	".CookieNotice-Dialog [data-testid=Preferences]",
	".CookieNotice-Dialog [data-testid=UpdateAndClose]",
	"%22analytics%22:false%2C%22marketing%22:false",
	"[class^=cookie_wrapper]",
	".shopify-section.cookies:has(.accept-cookies)",
	".shopify-section.cookies .accept-cookies",
	"#cookiePolicy:has(#cookiePolicyClose)",
	"#cookiePolicy #cookiePolicyWrap #cookiePolicyClose",
	"dialog[aria-labelledby=\"consent-title\"]",
	"div.animate-slideFromLeft.fixed.bottom-0.z-50",
	"dialog[aria-labelledby=\"consent-title\"], div.animate-slideFromLeft.fixed.bottom-0.z-50",
	"dialog[aria-labelledby=\"consent-title\"] button.border-xe-primary-500, div.animate-slideFromLeft button.border-xe-primary-500",
	"[data-testid=\"performance-toggle\"]",
	"dialog[aria-labelledby=\"consent-title\"] button.bg-xe-primary-500, div.animate-slideFromLeft button.bg-xe-primary-500",
	"xeConsentState={%22performance%22:false%2C%22marketing%22:false",
	"[data-role=\"cookies-modal\"]",
	"[data-role=\"cookies-modal\"] [data-opt-hydration=\"cookies-dialog-eu\"]",
	"[data-role=\"cookies-modal\"] [class*=experimentalButtons] button:nth-of-type(2)",
	"[data-role=\"cookies-modal\"] [class*=container]",
	"[class*=cookiesAnnounce]",
	"[class*=cookiesAnnounce] [class*=announceText]",
	"form#consent-dialog button[data-testid=give-consent-button]",
	"form#consent-dialog",
	"form#consent-dialog button[name=read-more]",
	"form#consent-dialog fieldset",
	"form#consent-dialog fieldset input[type=checkbox]:checked:not([disabled])",
	"cookies_marketing_ok=false",
	"#cookieBar",
	"#cookieBar .js-cookies-btn",
	"#cookieBar [data-event=cookies-show-settings]",
	"#cookiesPopup .js-save-settings",
	"#cookiesPopup .js-switch.active:not(.is-required)",
	"\"ad_storage\":\"denied\"",
	"div.cookie.flex.flex-wrap",
	"xpath///div[contains(@class,'cookie')]//button[normalize-space()='Deny']",
	"#consent-page",
	"#consent-page button[value=reject]",
	".cookies-box",
	".cookies-box .cookies-btn-customize",
	".manage-consent-preferences-dialog, .el-dialog[aria-label='Manage Consent Preferences']",
	".manage-consent-preferences-dialog .van-checkbox__icon--checked, .el-dialog[aria-label='Manage Consent Preferences'] .el-checkbox.is-checked",
	".manage-consent-preferences-dialog .van-dialog__confirm, .el-dialog[aria-label='Manage Consent Preferences'] .el-dialog__footer button",
	"yuntrackAccept=agree",
	"#cookie_modal_wrapper",
	"#cookie_modal_wrapper #cookie_modal_button_choose",
	"#consent-init",
	"#consent-init #consent-configure",
	"#consent-update #consent-configuration-save",
	"zinio-cookie-consent",
	".cookies.main-class .customize-btn",
	".cookies.main-class .cookies-container .customize-btn",
	".cookies.main-class .cookies-hidden .el-switch",
	".cookies-hidden .el-switch.is-checked:not(.is-disabled)",
	".cookies.main-class .cookies-hidden .accept-btn",
	"validCookies=general--"
];
var r = [
	[
		1,
		"123inkt",
		2,
		"",
		22,
		[0],
		[{ "e": 1 }],
		[{
			"check": "any",
			"v": 2
		}],
		[{ "c": 1 }],
		[],
		{}
	],
	[
		1,
		"abconcerts.be",
		2,
		"",
		22,
		[3],
		[{ "e": 4 }],
		[{ "v": 4 }],
		[{
			"if": { "e": 5 },
			"then": [{ "k": 5 }],
			"else": [{ "k": 6 }, { "c": 7 }]
		}],
		[],
		{ "intermediate": false }
	],
	[
		1,
		"abebooks",
		2,
		"",
		22,
		[8],
		[{ "e": 9 }],
		[{ "v": 10 }],
		[{ "c": 11 }, {
			"check": "none",
			"timeout": 2e3,
			"optional": true,
			"wv": 10
		}],
		[{ "cc": 12 }],
		{}
	],
	[
		1,
		"accept-cookie-box",
		1,
		"",
		22,
		[13],
		[{ "e": 14 }],
		[{ "v": 13 }],
		[{ "h": 13 }],
		[],
		{}
	],
	[
		1,
		"acos-cms",
		2,
		"",
		22,
		[15],
		[{ "e": 16 }],
		[{ "v": 16 }],
		[{ "c": 17 }, {
			"check": "none",
			"wv": 16
		}],
		[{ "cc": 18 }],
		{ "intermediate": false }
	],
	[
		1,
		"acris",
		2,
		"",
		22,
		[19],
		[{ "e": 20 }],
		[{ "v": 21 }],
		[
			{
				"check": "any",
				"wv": 22
			},
			{ "wait": 500 },
			{ "c": 22 }
		],
		[],
		{}
	],
	[
		1,
		"admetricspro",
		0,
		"",
		22,
		[23, 24],
		[{ "e": 25 }],
		[{ "v": 26 }],
		[{
			"if": { "e": 27 },
			"then": [{
				"all": true,
				"optional": true,
				"k": 28
			}, { "c": 29 }],
			"else": [{ "c": 30 }, { "c": 31 }]
		}],
		[{
			"check": "none",
			"timeout": 3e3,
			"wv": 26
		}],
		{}
	],
	[
		1,
		"adnuntius",
		2,
		"",
		22,
		[32],
		[{ "e": 33 }],
		[{ "v": 32 }],
		[{ "c": 33 }],
		[{
			"check": "none",
			"v": 32
		}],
		{}
	],
	[
		1,
		"adopt",
		2,
		"",
		22,
		[34],
		[{ "e": 35 }],
		[{ "v": 34 }],
		[{ "c": 36 }],
		[{ "eval": "EVAL_ADOPT_TEST" }],
		{}
	],
	[
		1,
		"Adroll",
		2,
		"",
		22,
		[37],
		[{ "e": 37 }],
		[{ "v": 37 }],
		[{ "c": 38 }],
		[{
			"negated": true,
			"cc": 39
		}],
		{}
	],
	[
		1,
		"adstate",
		2,
		"",
		22,
		[40],
		[{ "exists": ["adstate-settings-component app-wrapper", "#cookie-pop-up-only-necessary"] }],
		[{ "visible": ["adstate-settings-component app-wrapper", "app-cookie-pop-up"] }],
		[{ "waitForThenClick": ["adstate-settings-component app-wrapper", "#cookie-pop-up-only-necessary"] }],
		[{
			"waitForVisible": ["adstate-settings-component app-wrapper", "app-cookie-pop-up"],
			"check": "none",
			"timeout": 2e3
		}],
		{}
	],
	[
		1,
		"affinity.serif.com",
		2,
		"",
		22,
		[],
		[{ "e": 41 }],
		[{ "v": 42 }],
		[{ "k": 43 }],
		[
			{ "wait": 500 },
			{ "cc": 44 },
			{
				"negated": true,
				"cc": 45
			}
		],
		{}
	],
	[
		1,
		"amasty-gdpr",
		0,
		"",
		22,
		[],
		[{ "e": 46 }],
		[{ "v": 46 }],
		[{
			"timeout": 1e4,
			"w": 47
		}, {
			"if": { "v": 48 },
			"then": [{ "c": 49 }],
			"else": [
				{ "k": 50 },
				{ "wv": 51 },
				{
					"all": true,
					"optional": true,
					"k": 52
				},
				{
					"retry": 3,
					"retryInterval": 500,
					"c": 53
				}
			]
		}],
		[{
			"check": "none",
			"timeout": 5e3,
			"wv": 46
		}],
		{}
	],
	[
		1,
		"amazon-hiring",
		2,
		"",
		22,
		[],
		[{ "e": 54 }],
		[{ "v": 54 }],
		[
			{ "k": 55 },
			{
				"check": "none",
				"timeout": 2e3,
				"wv": 54
			},
			{
				"if": { "e": 56 },
				"then": [{ "k": 56 }]
			},
			{
				"check": "none",
				"timeout": 2e3,
				"wv": 57
			}
		],
		[],
		{}
	],
	[
		1,
		"amazon.com",
		2,
		"",
		22,
		[58],
		[{ "e": 58 }],
		[{
			"check": "any",
			"v": 59
		}],
		[
			{ "wv": 60 },
			{ "wait": 5e3 },
			{ "k": 60 }
		],
		[],
		{}
	],
	[
		1,
		"amex",
		0,
		"",
		22,
		[61],
		[{ "e": 61 }],
		[{ "v": 61 }],
		[{ "c": 62 }],
		[],
		{}
	],
	[
		1,
		"anthropic",
		2,
		"",
		22,
		[],
		[{ "e": 63 }],
		[{ "v": 63 }],
		[{ "c": 64 }],
		[{ "cc": 65 }],
		{}
	],
	[
		1,
		"AppConsent",
		2,
		"",
		22,
		[66],
		[{ "e": 67 }],
		[{ "v": 66 }],
		[{ "waitFor": ["iframe[title='Consent window']", ".button__refuseAll, .button__skip"] }, {
			"if": { "exists": ["iframe[title='Consent window']", ".button__refuseAll"] },
			"then": [{ "click": ["iframe[title='Consent window']", ".button__refuseAll"] }],
			"else": [{ "click": ["iframe[title='Consent window']", ".button__skip"] }]
		}],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 66
		}],
		{}
	],
	[
		1,
		"AppConsent legacy",
		2,
		"",
		22,
		[68],
		[{ "e": 69 }],
		[{ "v": 68 }],
		[{ "waitFor": ["iframe[srcdoc*='frame-root']", ".button__skip, .button__openPrivacyCenter"] }, {
			"if": { "exists": ["iframe[srcdoc*='frame-root']", ".button__skip"] },
			"then": [{ "click": ["iframe[srcdoc*='frame-root']", ".button__skip"] }],
			"else": [
				{ "click": ["iframe[srcdoc*='frame-root']", ".button__openPrivacyCenter"] },
				{ "waitForThenClick": ["iframe[srcdoc*='frame-root']", ".button__refuseAll"] },
				{ "waitForThenClick": ["iframe[srcdoc*='frame-root']", ".button__save"] }
			]
		}],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 68
		}],
		{}
	],
	[
		1,
		"aquasana.com",
		2,
		"",
		22,
		[70],
		[{ "v": 70 }],
		[{ "v": 70 }],
		[{
			"if": { "e": 71 },
			"then": [{ "k": 71 }],
			"else": [{ "h": 70 }]
		}],
		[],
		{}
	],
	[
		1,
		"arbeitsagentur",
		2,
		"",
		22,
		[72],
		[{ "e": 73 }],
		[{ "e": 74 }],
		[{ "waitForThenClick": ["bahf-cookie-disclaimer-dpl3", "#bahf-cookie-disclaimer-modal .ba-btn-contrast"] }],
		[{ "cc": 75 }],
		{}
	],
	[
		1,
		"arto",
		0,
		"",
		22,
		[76],
		[{ "e": 77 }],
		[{ "v": 78 }],
		[{ "c": 78 }],
		[{ "cc": 79 }],
		{}
	],
	[
		1,
		"as-adventure",
		2,
		"",
		22,
		[
			80,
			81,
			82
		],
		[{ "e": 83 }],
		[{
			"check": "any",
			"v": 84
		}],
		[{
			"all": true,
			"retry": 10,
			"retryInterval": 500,
			"c": 83
		}],
		[{
			"timeout": 2e3,
			"check": "none",
			"wv": 84
		}],
		{}
	],
	[
		1,
		"asahi-interactive",
		2,
		"",
		22,
		[85],
		[{ "e": 86 }],
		[{ "v": 85 }],
		[{ "c": 87 }],
		[{ "cc": 88 }],
		{}
	],
	[
		1,
		"aspnet-cookieinfo",
		0,
		"",
		22,
		[89],
		[{ "e": 90 }],
		[{ "v": 89 }],
		[{ "c": 90 }],
		[{ "cc": 91 }],
		{}
	],
	[
		1,
		"asus",
		2,
		"",
		22,
		[92],
		[{ "e": 93 }],
		[{ "v": 93 }],
		[{
			"if": { "e": 94 },
			"then": [{ "k": 94 }],
			"else": [{ "c": 95 }, { "c": 96 }]
		}],
		[],
		{}
	],
	[
		1,
		"autodoc",
		2,
		"",
		22,
		[97],
		[{ "e": 98 }],
		[{ "v": 98 }],
		[{ "c": 98 }],
		[{ "wait": 2e3 }, { "cc": 99 }],
		{}
	],
	[
		1,
		"automattic-cmp-optout",
		2,
		"",
		22,
		[100],
		[{ "e": 100 }],
		[{ "v": 100 }],
		[
			{ "k": 101 },
			{
				"all": true,
				"c": 102
			},
			{ "k": 103 }
		],
		[],
		{}
	],
	[
		1,
		"avacy",
		2,
		"",
		22,
		[104, 105],
		[{ "e": 106 }],
		[{
			"check": "any",
			"v": 106
		}],
		[{
			"if": {
				"check": "any",
				"v": 107
			},
			"then": [{ "c": 107 }],
			"else": [{ "c": 108 }]
		}],
		[],
		{}
	],
	[
		1,
		"avada-cookie-consent",
		2,
		"",
		22,
		[109],
		[{ "e": 110 }],
		[{
			"check": "any",
			"v": 110
		}],
		[{ "c": 110 }, { "any": [{
			"check": "none",
			"timeout": 1e3,
			"wv": 109
		}, { "c": 111 }] }],
		[{ "cc": 112 }],
		{}
	],
	[
		1,
		"avada-privacy-bar",
		2,
		"",
		22,
		[113],
		[{ "e": 114 }],
		[{
			"check": "any",
			"v": 113
		}],
		[{
			"if": { "e": 115 },
			"then": [{
				"all": true,
				"k": 115
			}],
			"else": [{
				"all": true,
				"optional": true,
				"k": 116
			}, {
				"all": true,
				"k": 117
			}]
		}],
		[{
			"check": "none",
			"timeout": 1e3,
			"wv": 113
		}],
		{}
	],
	[
		1,
		"avada-privacy-bar-cosmetic",
		1,
		"",
		22,
		[113],
		[{ "e": 117 }],
		[{
			"check": "any",
			"v": 113
		}],
		[{ "h": 113 }],
		[],
		{}
	],
	[
		1,
		"avvio",
		2,
		"",
		22,
		[118],
		[{ "e": 119 }],
		[{
			"check": "any",
			"v": 120
		}],
		[
			{
				"if": { "v": 121 },
				"then": [{ "c": 122 }]
			},
			{ "wv": 123 },
			{
				"if": { "e": 124 },
				"then": [{
					"all": true,
					"k": 125
				}]
			},
			{ "k": 123 },
			{
				"check": "none",
				"wv": 118
			}
		],
		[{ "cc": 126 }],
		{}
	],
	[
		1,
		"aws.amazon.com",
		2,
		"",
		22,
		[
			127,
			128,
			129,
			130
		],
		[{ "e": 127 }],
		[{ "v": 127 }],
		[{
			"if": { "e": 131 },
			"then": [{ "k": 131 }],
			"else": [
				{ "k": 132 },
				{ "w": 133 },
				{
					"all": true,
					"optional": true,
					"k": 134
				},
				{ "k": 135 }
			]
		}],
		[],
		{}
	],
	[
		1,
		"axeptio",
		2,
		"",
		22,
		[136],
		[{ "e": 136 }],
		[{ "any": [
			{ "e": 137 },
			{ "v": 138 },
			{ "visible": [".axeptio_mount .needsclick", ".axeptio_widget"] },
			{ "cc": 139 }
		] }],
		[{
			"if": { "e": 140 },
			"then": [
				{ "waitForVisible": [".axeptio_mount .needsclick", "button#axeptio_btn_dismiss,button.ax-discardButton,button#axeptio_btn_close"] },
				{ "wait": 300 },
				{
					"if": { "exists": [".axeptio_mount .needsclick", "button#axeptio_btn_dismiss,button.ax-discardButton"] },
					"then": [{ "click": [".axeptio_mount .needsclick", "button#axeptio_btn_dismiss,button.ax-discardButton"] }],
					"else": [{ "click": [".axeptio_mount .needsclick", "button#axeptio_btn_close"] }]
				}
			],
			"else": [
				{ "wv": 141 },
				{ "wait": 300 },
				{
					"if": { "e": 142 },
					"then": [{ "k": 142 }],
					"else": [{ "k": 143 }]
				}
			]
		}],
		[{ "cc": 144 }],
		{}
	],
	[
		1,
		"aylo-cookie-banner",
		2,
		"",
		22,
		[145],
		[{ "e": 146 }, { "e": 147 }],
		[{ "v": 146 }, { "any": [{ "v": 148 }, { "eval": "EVAL_AYLO_COOKIE_MANAGER_READY" }] }],
		[{
			"if": { "v": 149 },
			"then": [{ "c": 149 }],
			"else": [{
				"if": { "v": 150 },
				"then": [{ "wait": 8e3 }, { "c": 150 }],
				"else": [{ "c": 151 }]
			}]
		}, {
			"optional": true,
			"c": 152
		}],
		[{ "any": [{ "cc": 153 }, { "cc": 154 }] }],
		{}
	],
	[
		1,
		"b-cookie",
		1,
		"",
		22,
		[155],
		[{ "e": 155 }],
		[{ "v": 155 }],
		[{ "h": 155 }],
		[],
		{}
	],
	[
		1,
		"baden-wuerttemberg.de",
		2,
		"",
		22,
		[156],
		[{ "e": 156 }],
		[{ "v": 156 }],
		[{
			"if": { "e": 157 },
			"then": [{ "k": 157 }],
			"else": [{
				"all": true,
				"optional": true,
				"k": 158
			}, { "k": 159 }]
		}],
		[],
		{}
	],
	[
		1,
		"bancaditalia",
		2,
		"",
		22,
		[160],
		[{ "e": 161 }],
		[{ "v": 160 }],
		[{ "c": 161 }],
		[{ "cc": 162 }],
		{}
	],
	[
		1,
		"bbb.org",
		0,
		"",
		22,
		[163],
		[{ "e": 164 }],
		[{ "v": 165 }],
		[
			{ "wv": 166 },
			{ "wait": 500 },
			{ "k": 166 },
			{ "w": 167 },
			{
				"all": true,
				"optional": true,
				"k": 168
			},
			{ "k": 169 },
			{ "c": 170 }
		],
		[],
		{}
	],
	[
		1,
		"bbva",
		2,
		"",
		22,
		[171],
		[{ "e": 172 }],
		[{ "v": 172 }],
		[{ "c": 172 }, {
			"check": "none",
			"wv": 173
		}],
		[{ "cc": 174 }],
		{}
	],
	[
		1,
		"bdirect-booking-engine",
		2,
		"",
		22,
		[175],
		[{ "e": 176 }],
		[{ "v": 176 }],
		[{
			"retry": 2,
			"c": 177
		}],
		[{ "cc": 178 }],
		{ "intermediate": false }
	],
	[
		1,
		"beetle-tracking",
		2,
		"",
		22,
		[179],
		[{ "exists": ["beetle-tracking-consent-modal", ".consent"] }],
		[{ "visible": ["beetle-tracking-consent-modal", ".consent__dialog-wrapper"] }],
		[{
			"waitForThenClick": ["beetle-tracking-consent-modal", ".consent__button-decline-all"],
			"retry": 10,
			"retryInterval": 500
		}],
		[{ "cc": 180 }],
		{}
	],
	[
		1,
		"bigcommerce-consent-manager",
		0,
		"",
		22,
		[181],
		[{ "e": 181 }, { "eval": "EVAL_BIGCOMMERCE_CONSENT_MANAGER_DETECT" }],
		[{ "v": 182 }],
		[{ "c": 183 }],
		[{ "cc": 184 }],
		{}
	],
	[
		1,
		"bigcrunch",
		2,
		"",
		10,
		[185, 186],
		[{ "exists": ["#bc-cmp-host, #bc-cmp-host-auto", "#bc-cmp-banner"] }],
		[{ "visible": ["#bc-cmp-host, #bc-cmp-host-auto", "#bc-cmp-banner-container:not([style*=\"display: none\"]) #bc-cmp-banner"] }],
		[{ "waitForThenClick": ["#bc-cmp-host, #bc-cmp-host-auto", "#bc-cmp-banner [data-action=reject-all]"] }],
		[{
			"waitForVisible": ["#bc-cmp-host, #bc-cmp-host-auto", "#bc-cmp-banner-container:not([style*=\"display: none\"]) #bc-cmp-banner"],
			"timeout": 2e3,
			"check": "none"
		}],
		{}
	],
	[
		1,
		"bigid",
		2,
		"",
		22,
		[187],
		[{ "e": 187 }],
		[{ "visible": ["#bigidcmp-banner-widget", "#cmp-accept-all"] }],
		[{
			"if": { "exists": ["#bigidcmp-banner-widget", "#cmp-reject-all"] },
			"then": [{ "waitForThenClick": ["#bigidcmp-banner-widget", "#cmp-reject-all"] }],
			"else": [{
				"if": { "exists": ["#bigidcmp-banner-widget", "#cmp-custom-permissions"] },
				"then": [
					{ "waitForThenClick": ["#bigidcmp-banner-widget", "#cmp-custom-permissions"] },
					{ "waitForVisible": ["#bigidcmp-banner-widget", "#cmp-submit"] },
					{
						"click": ["#bigidcmp-banner-widget", "button[role=\"switch\"]:not([disabled]) > span[class*=\"translate-x-[1.1rem]\"]"],
						"all": true,
						"optional": true
					},
					{ "waitForThenClick": ["#bigidcmp-banner-widget", "#cmp-submit"] }
				],
				"else": [{ "waitForThenClick": ["#bigidcmp-banner-widget", "div[tabindex=\"0\"]:has(> svg #times-solid)"] }]
			}]
		}],
		[{ "cc": 188 }, { "cc": 189 }],
		{}
	],
	[
		1,
		"bing.com",
		2,
		"",
		22,
		[190],
		[{ "e": 191 }],
		[{ "v": 191 }, { "v": 192 }],
		[{ "wait": 500 }, { "c": 193 }],
		[{ "cc": 194 }],
		{}
	],
	[
		1,
		"bleau-cookiecontrol",
		2,
		"",
		22,
		[195],
		[{ "e": 196 }],
		[{ "v": 197 }],
		[{ "c": 196 }],
		[{
			"check": "none",
			"wv": 195
		}, { "cc": 198 }],
		{}
	],
	[
		1,
		"blocksy",
		0,
		"",
		10,
		[199],
		[{ "e": 200 }],
		[{ "v": 199 }],
		[{ "c": 201 }],
		[{ "cc": 202 }],
		{ "intermediate": false }
	],
	[
		1,
		"bluepark",
		2,
		"",
		22,
		[203],
		[{ "e": 204 }],
		[{ "v": 205 }],
		[{ "c": 205 }],
		[{
			"check": "none",
			"timeout": 3e3,
			"wv": 206
		}],
		{}
	],
	[
		1,
		"bnes-cc",
		2,
		"",
		22,
		[207],
		[{ "e": 208 }],
		[{ "v": 209 }],
		[{
			"if": { "e": 210 },
			"then": [{ "c": 210 }],
			"else": [
				{ "c": 208 },
				{ "wv": 211 },
				{
					"if": { "e": 212 },
					"then": [{ "k": 213 }]
				},
				{
					"if": { "e": 214 },
					"then": [{ "k": 215 }]
				},
				{ "k": 211 }
			]
		}],
		[{ "cc": 216 }, {
			"negated": true,
			"cc": 217
		}],
		{}
	],
	[
		1,
		"bold-cookie-consent",
		0,
		"",
		22,
		[218, 219],
		[{ "e": 220 }],
		[{
			"if": { "v": 219 },
			"then": [{ "v": 219 }],
			"else": [{ "v": 218 }, {
				"check": "any",
				"v": 221
			}]
		}],
		[{
			"if": { "v": 219 },
			"then": [{ "k": 222 }, {
				"check": "none",
				"timeout": 3e3,
				"optional": true,
				"wv": 219
			}],
			"else": [{
				"if": {
					"check": "any",
					"v": 223
				},
				"then": [{ "k": 223 }],
				"else": [
					{ "k": 224 },
					{ "wv": 220 },
					{
						"all": true,
						"optional": true,
						"k": 225
					},
					{ "k": 226 }
				]
			}, {
				"check": "none",
				"timeout": 3e3,
				"optional": true,
				"wv": 218
			}]
		}],
		[{
			"if": { "e": 219 },
			"then": [{
				"check": "none",
				"v": 219
			}],
			"else": [{
				"check": "none",
				"v": 218
			}]
		}],
		{}
	],
	[
		1,
		"borlabs",
		2,
		"",
		22,
		[227],
		[{ "e": 228 }],
		[{ "v": 229 }],
		[{
			"timeout": 3e3,
			"optional": true,
			"w": 230
		}, {
			"if": { "e": 231 },
			"then": [{ "k": 231 }],
			"else": [{
				"if": { "e": 232 },
				"then": [{ "k": 232 }],
				"else": [{
					"if": { "e": 233 },
					"then": [{ "k": 233 }],
					"else": [{
						"if": { "e": 234 },
						"then": [
							{ "k": 234 },
							{ "wv": 235 },
							{
								"all": true,
								"optional": true,
								"k": 236
							},
							{ "k": 237 },
							{ "wait": 500 }
						]
					}]
				}]
			}]
		}],
		[{ "eval": "EVAL_BORLABS_0" }],
		{}
	],
	[
		1,
		"bosch-dock-privacy-settings",
		2,
		"",
		22,
		[238],
		[{ "e": 238 }],
		[{ "visible": ["dock-privacy-settings", "#decline-all-modal-dialog button"] }],
		[{ "waitForThenClick": ["dock-privacy-settings", "#decline-all-modal-dialog button"] }],
		[{
			"waitForVisible": ["dock-privacy-settings", "#decline-all-modal-dialog button"],
			"timeout": 1e3,
			"check": "none"
		}],
		{}
	],
	[
		1,
		"bouvet-cookiepanel",
		2,
		"",
		22,
		[239],
		[{ "e": 239 }],
		[{ "v": 239 }],
		[{ "c": 240 }],
		[{ "cc": 241 }],
		{}
	],
	[
		1,
		"brainsum-cookieconsent",
		2,
		"",
		22,
		[242],
		[{ "e": 243 }],
		[{ "v": 244 }],
		[{
			"if": { "v": 245 },
			"then": [{ "k": 245 }],
			"else": [
				{ "k": 246 },
				{ "wv": 247 },
				{
					"all": true,
					"optional": true,
					"k": 248
				},
				{
					"all": true,
					"optional": true,
					"k": 249
				},
				{ "k": 247 }
			]
		}],
		[{
			"check": "none",
			"wv": 244
		}, { "cc": 198 }],
		{}
	],
	[
		1,
		"bswhealth",
		0,
		"",
		22,
		[250],
		[{ "e": 250 }],
		[{ "v": 251 }],
		[
			{ "c": 252 },
			{ "wv": 253 },
			{
				"all": true,
				"optional": true,
				"c": 254
			},
			{ "c": 251 }
		],
		[{ "cc": 255 }],
		{}
	],
	[
		1,
		"bullionbypost",
		2,
		"",
		22,
		[],
		[{ "e": 256 }, { "e": 257 }],
		[{ "v": 256 }],
		[
			{
				"if": { "e": 258 },
				"then": [{ "k": 259 }]
			},
			{ "c": 260 },
			{
				"if": { "e": 261 },
				"then": [{ "wait": 1e3 }, { "k": 260 }]
			},
			{
				"if": { "e": 261 },
				"then": [{ "wait": 1e3 }, { "k": 260 }]
			},
			{
				"if": { "e": 261 },
				"then": [{ "wait": 1e3 }, { "k": 260 }]
			},
			{
				"if": { "e": 261 },
				"then": [{ "wait": 1e3 }, { "k": 260 }]
			},
			{
				"if": { "e": 261 },
				"then": [{ "wait": 1e3 }, { "k": 260 }]
			}
		],
		[{ "cc": 262 }, { "cc": 263 }],
		{}
	],
	[
		1,
		"bundesarchiv-cookiebanner",
		2,
		"",
		22,
		[264, 265],
		[{ "e": 266 }],
		[{ "v": 266 }],
		[{
			"if": { "e": 267 },
			"then": [{
				"all": true,
				"k": 268
			}]
		}, { "c": 266 }],
		[{
			"timeout": 2e3,
			"check": "none",
			"wv": 266
		}],
		{}
	],
	[
		1,
		"bundesregierung.de",
		2,
		"",
		22,
		[269],
		[{ "e": 269 }],
		[{ "v": 270 }],
		[{ "wait": 500 }, { "c": 271 }],
		[{ "cc": 272 }],
		{}
	],
	[
		2,
		"burpee.com",
		2,
		"",
		22,
		[273, 274],
		[{ "e": 274 }, {
			"negated": true,
			"e": 275
		}],
		[{ "v": 276 }],
		[{
			"if": { "e": 277 },
			"then": [{ "c": 277 }],
			"else": [{
				"if": { "e": 278 },
				"then": [{ "c": 278 }],
				"else": [{
					"if": { "e": 279 },
					"then": [
						{ "c": 279 },
						{
							"all": true,
							"k": 280
						},
						{ "k": 281 }
					],
					"else": [{ "h": 282 }, {
						"removeClass": "cookie-notification-active",
						"selector": "body",
						"optional": true
					}]
				}]
			}]
		}],
		[],
		{}
	],
	[
		1,
		"bwr-cookie",
		2,
		"",
		22,
		[283],
		[{ "e": 284 }],
		[{ "v": 285 }],
		[
			{
				"all": true,
				"optional": true,
				"k": 286
			},
			{ "c": 284 },
			{
				"check": "none",
				"timeout": 2e3,
				"optional": true,
				"wv": 283
			}
		],
		[{ "cc": 287 }],
		{}
	],
	[
		1,
		"bynder",
		2,
		"",
		22,
		[288],
		[{ "e": 289 }],
		[{ "v": 289 }],
		[{ "c": 289 }],
		[{ "cc": 290 }, { "cc": 291 }],
		{}
	],
	[
		1,
		"c-banner-allow-cookies",
		0,
		"",
		10,
		[292],
		[{ "e": 293 }],
		[{ "v": 292 }],
		[{ "c": 293 }, {
			"check": "none",
			"wv": 292
		}],
		[{ "cc": 294 }],
		{}
	],
	[
		1,
		"cassie",
		0,
		"",
		10,
		[295],
		[{ "e": 296 }],
		[{ "v": 297 }],
		[{ "c": 298 }],
		[],
		{}
	],
	[
		1,
		"cc_banner",
		1,
		"",
		22,
		[299],
		[{ "e": 299 }],
		[{ "v": 300 }],
		[{ "h": 299 }],
		[],
		{}
	],
	[
		1,
		"cc-banner-springer",
		2,
		"",
		22,
		[301],
		[{ "e": 301 }],
		[{ "v": 301 }],
		[{
			"if": { "e": 302 },
			"then": [{ "k": 302 }],
			"else": [
				{ "c": 303 },
				{ "w": 304 },
				{
					"all": true,
					"optional": true,
					"k": 305
				},
				{
					"if": { "e": 306 },
					"then": [{ "k": 306 }],
					"else": [{ "k": 307 }]
				}
			]
		}],
		[{ "eval": "EVAL_CC_BANNER2_0" }],
		{}
	],
	[
		1,
		"ccm19",
		2,
		"",
		22,
		[308],
		[{ "any": [{ "e": 309 }, { "e": 310 }] }],
		[{ "v": 308 }],
		[{
			"if": { "e": 311 },
			"then": [{ "c": 311 }],
			"else": [{ "c": 312 }, { "c": 313 }]
		}],
		[{
			"timeout": 2e3,
			"check": "none",
			"wv": 308
		}],
		{}
	],
	[
		1,
		"ceneo",
		2,
		"",
		22,
		[314],
		[{ "e": 315 }],
		[{ "v": 315 }],
		[{ "c": 315 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 314
		}],
		{}
	],
	[
		1,
		"cf-gdpr-cookie-consent",
		2,
		"",
		22,
		[316],
		[{ "e": 317 }],
		[{ "v": 317 }],
		[
			{ "c": 317 },
			{ "wv": 318 },
			{
				"if": { "e": 319 },
				"then": [{
					"all": true,
					"k": 319
				}]
			},
			{ "k": 318 },
			{
				"check": "none",
				"wv": 316
			}
		],
		[
			{ "cc": 320 },
			{ "cc": 321 },
			{ "cc": 322 }
		],
		{}
	],
	[
		1,
		"check24",
		2,
		"",
		22,
		[323],
		[{ "e": 324 }],
		[{ "v": 325 }],
		[{ "c": 324 }],
		[{
			"check": "none",
			"v": 323
		}],
		{}
	],
	[
		1,
		"check24-partnerprogramm-de",
		2,
		"",
		22,
		[326],
		[{ "e": 327 }],
		[{
			"check": "any",
			"v": 327
		}],
		[{ "c": 328 }],
		[],
		{}
	],
	[
		1,
		"chefcookie",
		2,
		"",
		22,
		[329],
		[{ "e": 330 }],
		[{ "v": 331 }],
		[{ "c": 332 }],
		[{ "cc": 333 }],
		{}
	],
	[
		1,
		"ciaopeople.it",
		2,
		"",
		22,
		[334],
		[{ "e": 335 }],
		[{ "v": 336 }],
		[{ "c": 337 }],
		[{
			"check": "none",
			"timeout": 5e3,
			"wv": 336
		}],
		{}
	],
	[
		1,
		"cinemaplus",
		2,
		"",
		22,
		[338],
		[{ "e": 339 }],
		[{ "v": 339 }],
		[{ "c": 339 }],
		[{
			"check": "none",
			"v": 339
		}],
		{}
	],
	[
		1,
		"civic-cookie-control",
		2,
		"",
		22,
		[340],
		[{ "e": 341 }],
		[{ "v": 342 }, { "v": 341 }],
		[{
			"if": { "v": 343 },
			"then": [{ "c": 343 }],
			"else": [{
				"if": { "e": 344 },
				"then": [{ "c": 344 }, { "wv": 345 }]
			}, {
				"if": { "v": 343 },
				"then": [{ "c": 343 }],
				"else": [{
					"if": { "e": 346 },
					"then": [{ "c": 346 }],
					"else": [{ "c": 347 }]
				}]
			}]
		}],
		[],
		{}
	],
	[
		1,
		"ckies",
		2,
		"",
		22,
		[348],
		[{ "e": 349 }],
		[{ "v": 348 }],
		[{ "c": 349 }],
		[{ "cc": 350 }],
		{}
	],
	[
		1,
		"cksmodal",
		2,
		"",
		22,
		[351],
		[{ "e": 352 }],
		[{ "v": 353 }],
		[{ "c": 354 }, {
			"check": "none",
			"wv": 351
		}],
		[{ "cc": 355 }],
		{}
	],
	[
		1,
		"click.io",
		2,
		"",
		22,
		[356],
		[{ "e": 356 }],
		[{ "v": 356 }],
		[
			{ "w": 357 },
			{ "wait": 500 },
			{ "k": 357 },
			{ "w": 358 },
			{
				"all": true,
				"k": 358
			},
			{ "k": 359 }
		],
		[{ "cc": 360 }],
		{}
	],
	[
		1,
		"clinch",
		2,
		"",
		10,
		[361],
		[{ "e": 361 }],
		[{ "v": 361 }],
		[{
			"if": { "e": 362 },
			"then": [{ "k": 362 }],
			"else": [
				{ "k": 363 },
				{
					"all": true,
					"optional": true,
					"k": 364
				},
				{ "k": 365 }
			]
		}],
		[{ "cc": 366 }],
		{ "intermediate": false }
	],
	[
		1,
		"close-cookie-notice-snippet",
		1,
		"",
		22,
		[367],
		[{ "e": 368 }],
		[{ "v": 367 }],
		[{ "h": 367 }],
		[],
		{}
	],
	[
		1,
		"cloudflare-zaraz",
		2,
		"",
		22,
		[369],
		[{ "exists": [".cf_modal_container", ".cf_consent-buttons"] }],
		[{ "visible": [".cf_modal_container", ".cf_consent-buttons"] }],
		[{ "waitForThenClick": [".cf_modal_container", ".cf_consent-buttons #cf_consent-buttons__reject-all"] }],
		[],
		{}
	],
	[
		1,
		"cm-cookie-manager",
		2,
		"",
		22,
		[370, 371],
		[{ "e": 372 }, { "e": 373 }],
		[{ "v": 373 }],
		[
			{
				"if": { "v": 374 },
				"then": [{ "k": 374 }]
			},
			{ "wv": 372 },
			{
				"if": { "e": 375 },
				"then": [{
					"all": true,
					"k": 375
				}]
			},
			{ "k": 372 }
		],
		[{
			"check": "none",
			"v": 373
		}],
		{}
	],
	[
		1,
		"coki61",
		2,
		"",
		22,
		[],
		[{ "e": 376 }],
		[{ "v": 377 }],
		[{ "c": 376 }],
		[{ "cc": 378 }],
		{}
	],
	[
		1,
		"columbia-privacy-notice",
		1,
		"",
		22,
		[379],
		[{ "e": 380 }],
		[{ "v": 379 }],
		[{ "h": 379 }],
		[{
			"check": "none",
			"v": 379
		}],
		{}
	],
	[
		1,
		"com-consent-layer",
		2,
		"",
		22,
		[381],
		[{ "exists": ["com-consent-layer", "dialog"] }],
		[{ "visible": ["com-consent-layer", "dialog[open]"] }],
		[{ "waitForThenClick": ["com-consent-layer", "#cmpDenyAll"] }],
		[{
			"waitForVisible": ["com-consent-layer", "dialog[open]"],
			"timeout": 1e3,
			"check": "none"
		}],
		{}
	],
	[
		1,
		"Complianz banner",
		2,
		"",
		22,
		[382],
		[{ "e": 383 }],
		[{
			"check": "any",
			"v": 383
		}],
		[{ "c": 384 }],
		[{ "cc": 385 }],
		{}
	],
	[
		1,
		"Complianz categories",
		2,
		"",
		22,
		[386],
		[{ "e": 386 }],
		[{ "v": 386 }],
		[{
			"if": { "e": 387 },
			"then": [{ "k": 388 }],
			"else": [{
				"all": true,
				"optional": true,
				"k": 389
			}, { "k": 390 }]
		}],
		[],
		{}
	],
	[
		1,
		"Complianz notice",
		1,
		"",
		22,
		[391],
		[{ "e": 392 }],
		[{ "v": 392 }],
		[{
			"if": { "e": 393 },
			"then": [{ "k": 393 }],
			"else": [{ "h": 394 }, {
				"optional": true,
				"h": 395
			}]
		}],
		[],
		{}
	],
	[
		1,
		"Complianz opt-out",
		2,
		"",
		22,
		[396],
		[{ "e": 396 }],
		[{ "v": 396 }],
		[{
			"timeout": 2e3,
			"optional": true,
			"w": 397
		}, {
			"if": { "e": 393 },
			"then": [{ "k": 393 }],
			"else": [{
				"if": { "e": 398 },
				"then": [
					{ "k": 398 },
					{ "c": 399 },
					{ "c": 400 }
				]
			}]
		}],
		[],
		{}
	],
	[
		1,
		"Complianz optin",
		2,
		"",
		22,
		[401],
		[{ "e": 401 }],
		[{ "v": 401 }],
		[{
			"if": { "v": 393 },
			"then": [{ "k": 393 }],
			"else": [{
				"if": { "v": 402 },
				"then": [
					{ "c": 402 },
					{ "wv": 403 },
					{
						"all": true,
						"optional": true,
						"k": 404
					},
					{ "k": 405 }
				],
				"else": [{
					"if": { "e": 388 },
					"then": [{ "k": 388 }],
					"else": [
						{ "k": 398 },
						{ "c": 399 },
						{ "c": 400 }
					]
				}]
			}]
		}],
		[],
		{}
	],
	[
		1,
		"compricer",
		2,
		"",
		22,
		[406, 407],
		[{ "e": 408 }, { "e": 409 }],
		[{ "v": 410 }],
		[
			{ "c": 410 },
			{ "wv": 408 },
			{
				"all": true,
				"optional": true,
				"k": 411
			},
			{ "k": 408 },
			{
				"check": "none",
				"optional": true,
				"wv": 408
			}
		],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 410
		}, {
			"negated": true,
			"e": 411
		}],
		{}
	],
	[
		1,
		"concept3d",
		2,
		"",
		22,
		[412],
		[{ "e": 413 }],
		[{ "v": 413 }],
		[
			{ "c": 413 },
			{ "wv": 414 },
			{
				"all": true,
				"optional": true,
				"k": 415
			},
			{ "c": 414 }
		],
		[{ "cc": 416 }],
		{}
	],
	[
		1,
		"conextra",
		2,
		"",
		22,
		[417, 418],
		[{ "e": 419 }],
		[{ "v": 419 }],
		[{
			"if": { "e": 420 },
			"then": [{ "c": 420 }],
			"else": [{
				"all": true,
				"optional": true,
				"k": 421
			}, { "c": 422 }]
		}],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 419
		}],
		{}
	],
	[
		1,
		"consent-flo",
		2,
		"",
		22,
		[423],
		[{ "e": 424 }],
		[{ "v": 425 }],
		[{
			"if": { "e": 426 },
			"then": [{ "c": 426 }],
			"else": [
				{ "c": 427 },
				{ "wv": 428 },
				{
					"all": true,
					"optional": true,
					"k": 429
				},
				{ "c": 428 }
			]
		}],
		[{ "e": 430 }],
		{}
	],
	[
		1,
		"consent-studio",
		0,
		"",
		10,
		[431, 432],
		[{ "e": 433 }],
		[{ "v": 433 }],
		[{
			"if": { "v": 434 },
			"then": [{ "k": 434 }],
			"else": [{
				"if": {
					"check": "any",
					"v": 435
				},
				"then": [{ "k": 435 }],
				"else": [{
					"if": { "e": 436 },
					"then": [{
						"all": true,
						"k": 436
					}]
				}, { "c": 437 }]
			}]
		}, {
			"check": "none",
			"wv": 433
		}],
		[{ "wait": 500 }, { "cc": 438 }],
		{}
	],
	[
		1,
		"consentaur",
		2,
		"",
		22,
		[439],
		[{ "e": 439 }],
		[{ "v": 440 }],
		[{ "c": 440 }],
		[{ "cc": 441 }],
		{}
	],
	[
		1,
		"consentmagic",
		0,
		"",
		10,
		[],
		[{ "v": 442 }],
		[{ "v": 442 }],
		[{
			"if": { "e": 443 },
			"then": [{
				"retry": 5,
				"retryInterval": 500,
				"c": 443
			}],
			"else": [
				{ "c": 444 },
				{ "wv": 445 },
				{
					"all": true,
					"optional": true,
					"k": 446
				},
				{ "c": 445 }
			]
		}],
		[{ "cc": 447 }],
		{}
	],
	[
		1,
		"consentmanager-ncmp",
		2,
		"",
		22,
		[448],
		[{ "e": 449 }],
		[{
			"check": "any",
			"v": 449
		}],
		[{ "wait": 500 }, { "eval": "EVAL_CONSENTMANAGER_NCMP_REJECT" }],
		[{ "cc": 450 }],
		{}
	],
	[
		1,
		"consentmo",
		2,
		"",
		22,
		[451],
		[{ "exists": ["csm-cookie-consent", ".csm-wrapper"] }],
		[{ "visible": ["csm-cookie-consent", ".csm-wrapper button"] }],
		[{
			"if": { "exists": ["csm-cookie-consent", ".csm-wrapper .cc-deny, .csm-wrapper [data-csm-button-type='reject']"] },
			"then": [{ "waitForThenClick": ["csm-cookie-consent", ".csm-wrapper .cc-deny, .csm-wrapper [data-csm-button-type='reject']"] }],
			"else": [{
				"if": { "exists": ["csm-cookie-consent", ".csm-wrapper [data-csm-button-type='do_not_sell']"] },
				"then": [{ "waitForThenClick": ["csm-cookie-consent", ".csm-wrapper [data-csm-button-type='do_not_sell']"] }, {
					"waitForThenClick": ["csm-cookie-consent", ".csm-wrapper [data-csm-button-type='dismiss']"],
					"timeout": 2e3,
					"optional": true
				}],
				"else": [
					{ "waitForThenClick": ["csm-cookie-consent", ".csm-wrapper .cc-settings, .csm-wrapper [data-csm-button-type='preferences']"] },
					{ "waitForVisible": ["csm-cookie-consent", ".csm-wrapper .cc-deny, .csm-wrapper [data-csm-button-type='accept_selected']"] },
					{
						"if": { "exists": ["csm-cookie-consent", ".csm-wrapper .cc-deny"] },
						"then": [{ "click": ["csm-cookie-consent", ".csm-wrapper .cc-deny"] }],
						"else": [{ "click": ["csm-cookie-consent", ".csm-wrapper [data-csm-button-type='accept_selected']"] }]
					}
				]
			}]
		}],
		[{
			"waitForVisible": ["csm-cookie-consent", ".csm-wrapper button"],
			"timeout": 1e3,
			"check": "none"
		}],
		{}
	],
	[
		1,
		"Cookie Information Banner",
		2,
		"",
		22,
		[452],
		[{ "e": 452 }],
		[{ "v": 452 }],
		[
			{ "eval": "EVAL_COOKIEINFORMATION_0" },
			{ "wait": 1e3 },
			{
				"if": { "v": 453 },
				"then": [{ "h": 452 }]
			}
		],
		[{ "cc": 454 }],
		{}
	],
	[
		1,
		"cookie-banner-element",
		2,
		"",
		22,
		[455],
		[{ "e": 455 }],
		[{ "visible": ["cookie-banner-element#ckb", "#ckb[role=\"dialog\"]"] }],
		[{ "waitForThenClick": ["cookie-banner-element#ckb", "#ckn"] }],
		[],
		{}
	],
	[
		1,
		"cookie-bar-frame",
		2,
		"",
		22,
		[456],
		[{ "e": 457 }],
		[{ "v": 458 }],
		[{ "c": 457 }],
		[{ "cc": 459 }],
		{}
	],
	[
		1,
		"cookie-consent-spice",
		0,
		"",
		10,
		[460, 461],
		[{ "e": 461 }],
		[{ "v": 461 }],
		[{ "c": 462 }],
		[],
		{}
	],
	[
		1,
		"cookie-law-info",
		2,
		"",
		22,
		[463],
		[{ "e": 464 }, { "eval": "EVAL_COOKIE_LAW_INFO_DETECT" }],
		[{ "v": 464 }],
		[{ "h": 463 }, { "eval": "EVAL_COOKIE_LAW_INFO_0" }],
		[{
			"negated": true,
			"cc": 465
		}],
		{}
	],
	[
		1,
		"cookie-manager-popup",
		0,
		"",
		10,
		[466],
		[{ "e": 467 }],
		[{ "v": 274 }],
		[{
			"if": { "e": 468 },
			"then": [{ "k": 468 }],
			"else": [
				{ "c": 466 },
				{ "wv": 469 },
				{
					"all": true,
					"optional": true,
					"k": 470
				},
				{ "k": 471 }
			]
		}],
		[{ "eval": "EVAL_COOKIE_MANAGER_POPUP_0" }],
		{ "intermediate": false }
	],
	[
		1,
		"cookie-notice-checkboxes",
		2,
		"",
		22,
		[472],
		[{ "e": 473 }],
		[{ "v": 473 }],
		[{
			"if": { "e": 474 },
			"then": [{ "c": 474 }],
			"else": [{
				"if": { "e": 475 },
				"then": [{
					"all": true,
					"k": 475
				}]
			}, { "c": 476 }]
		}],
		[{
			"check": "none",
			"v": 476
		}],
		{}
	],
	[
		1,
		"cookie-popup-close-cookies",
		2,
		"",
		22,
		[477],
		[{ "e": 478 }, { "e": 479 }],
		[{ "e": 480 }],
		[{ "eval": "EVAL_COOKIE_POPUP_CLOSE" }, {
			"timeout": 2e3,
			"w": 481
		}],
		[{
			"negated": true,
			"cc": 482
		}],
		{}
	],
	[
		1,
		"cookie-popup-cookieno",
		2,
		"",
		22,
		[483],
		[{ "e": 484 }],
		[{ "v": 477 }],
		[{ "c": 484 }, {
			"check": "none",
			"timeout": 3e3,
			"wv": 477
		}],
		[],
		{}
	],
	[
		1,
		"cookie-popup-cookieok",
		1,
		"",
		22,
		[485],
		[{ "e": 486 }],
		[{ "v": 477 }],
		[{ "h": 477 }],
		[],
		{}
	],
	[
		1,
		"cookie-script",
		2,
		"",
		22,
		[487, 488],
		[{ "e": 489 }],
		[{ "v": 490 }],
		[{
			"if": { "e": 491 },
			"then": [{ "wait": 100 }, { "k": 491 }],
			"else": [
				{ "k": 492 },
				{
					"timeout": 3e3,
					"optional": true,
					"wv": 493
				},
				{
					"if": { "e": 494 },
					"then": [{ "c": 491 }],
					"else": [{
						"if": { "v": 495 },
						"then": [{
							"if": { "e": 496 },
							"then": [{
								"all": true,
								"k": 496
							}]
						}, {
							"retry": 6,
							"retryInterval": 1e3,
							"c": 495
						}],
						"else": [{ "k": 497 }]
					}]
				}
			]
		}],
		[],
		{}
	],
	[
		1,
		"cookieacceptbar",
		1,
		"",
		22,
		[498],
		[{ "e": 498 }],
		[{ "v": 498 }],
		[{ "h": 498 }],
		[],
		{}
	],
	[
		1,
		"cookiebot.be",
		2,
		"",
		22,
		[499],
		[{ "e": 500 }],
		[{ "v": 499 }],
		[{ "c": 500 }],
		[{ "cc": 501 }],
		{}
	],
	[
		1,
		"cookieconsent2",
		2,
		"",
		22,
		[502],
		[{ "e": 502 }],
		[{ "e": 503 }, { "e": 504 }],
		[{
			"if": { "e": 505 },
			"then": [{ "c": 505 }],
			"else": [
				{ "c": 506 },
				{ "wait": 500 },
				{
					"all": true,
					"optional": true,
					"k": 507
				},
				{ "c": 508 }
			]
		}],
		[{ "cc": 509 }],
		{}
	],
	[
		1,
		"cookieconsent2-legacy",
		2,
		"",
		22,
		[510],
		[{ "e": 511 }],
		[{ "e": 512 }],
		[
			{ "c": 513 },
			{
				"timeout": 1e3,
				"optional": true,
				"w": 514
			},
			{
				"if": { "e": 514 },
				"then": [{
					"all": true,
					"optional": true,
					"k": 515
				}, { "c": 516 }]
			}
		],
		[{ "any": [{ "cc": 509 }, { "cc": 517 }] }],
		{}
	],
	[
		1,
		"cookieconsent3",
		2,
		"",
		22,
		[518],
		[{ "e": 518 }],
		[{ "v": 519 }],
		[{
			"if": { "e": 520 },
			"then": [{ "c": 520 }],
			"else": [{ "c": 521 }, { "c": 522 }]
		}],
		[{ "cc": 509 }],
		{}
	],
	[
		1,
		"cookiecuttr",
		0,
		"",
		10,
		[523],
		[{ "e": 524 }],
		[{
			"check": "any",
			"v": 525
		}],
		[{
			"if": { "e": 526 },
			"then": [{ "k": 526 }],
			"else": [{ "h": 523 }]
		}],
		[],
		{}
	],
	[
		1,
		"cookiefirst.com",
		2,
		"",
		22,
		[527],
		[{ "e": 528 }],
		[{
			"check": "any",
			"v": 529
		}],
		[{
			"if": { "e": 530 },
			"then": [{ "k": 530 }],
			"else": [{
				"if": { "e": 531 },
				"then": [
					{
						"timeout": 5e3,
						"wv": 531
					},
					{ "k": 531 },
					{ "wait": 1500 }
				],
				"else": [{
					"if": { "e": 532 },
					"then": [
						{ "k": 532 },
						{
							"timeout": 1e3,
							"wv": 533
						},
						{ "eval": "EVAL_COOKIEFIRST_1" },
						{ "wait": 1e3 },
						{ "k": 534 }
					],
					"else": [{ "k": 530 }]
				}]
			}]
		}],
		[{ "eval": "EVAL_COOKIEFIRST_0" }],
		{}
	],
	[
		1,
		"cookiehub",
		2,
		"",
		22,
		[535],
		[{ "e": 536 }],
		[{ "v": 536 }],
		[{
			"if": { "e": 537 },
			"then": [
				{ "k": 537 },
				{ "wv": 538 },
				{
					"if": { "e": 539 },
					"then": [{ "k": 539 }],
					"else": [{
						"all": true,
						"optional": true,
						"k": 540
					}, { "k": 541 }]
				}
			],
			"else": [{ "h": 535 }]
		}],
		[{ "cc": 542 }],
		{}
	],
	[
		1,
		"cookieinfo",
		1,
		"",
		22,
		[543],
		[{ "e": 543 }],
		[{ "v": 543 }],
		[{ "c": 544 }],
		[],
		{}
	],
	[
		1,
		"cookiejs-banner",
		2,
		"",
		22,
		[545],
		[{ "e": 546 }],
		[{ "v": 547 }],
		[{ "c": 548 }],
		[{ "cc": 549 }],
		{}
	],
	[
		1,
		"cookiejs-modal",
		2,
		"",
		22,
		[545],
		[{ "e": 550 }],
		[{ "v": 551 }],
		[{ "c": 552 }],
		[{ "cc": 553 }],
		{}
	],
	[
		1,
		"cookielegit",
		2,
		"",
		22,
		[554],
		[{ "e": 554 }],
		[{ "v": 555 }],
		[{
			"if": { "e": 556 },
			"then": [{ "c": 556 }],
			"else": [
				{ "c": 557 },
				{ "wv": 558 },
				{
					"optional": true,
					"k": 559
				},
				{
					"optional": true,
					"k": 560
				},
				{ "k": 558 }
			]
		}],
		[{ "cc": 561 }, { "cc": 562 }],
		{}
	],
	[
		1,
		"cookieman",
		2,
		"",
		10,
		[563],
		[{ "e": 564 }],
		[{
			"check": "any",
			"v": 564
		}],
		[{
			"if": { "e": 565 },
			"then": [{
				"retry": 3,
				"retryInterval": 500,
				"c": 565
			}],
			"else": [
				{ "c": 566 },
				{
					"timeout": 2e3,
					"optional": true,
					"wv": 567
				},
				{
					"all": true,
					"optional": true,
					"k": 568
				},
				{
					"retry": 3,
					"retryInterval": 500,
					"c": 569
				}
			]
		}],
		[{ "cc": 570 }, {
			"timeout": 2e3,
			"check": "none",
			"wv": 564
		}],
		{}
	],
	[
		1,
		"cookiepermission-cp-overlay",
		0,
		"",
		10,
		[571],
		[{ "e": 572 }],
		[{ "v": 571 }],
		[{ "c": 572 }, {
			"check": "none",
			"wv": 571
		}],
		[{ "cc": 573 }],
		{}
	],
	[
		1,
		"cookieprompter",
		0,
		"",
		10,
		[574],
		[{ "e": 574 }],
		[{ "v": 574 }],
		[{
			"if": { "e": 575 },
			"then": [{ "k": 575 }],
			"else": [{ "c": 576 }]
		}, {
			"check": "none",
			"wv": 574
		}],
		[{ "cc": 577 }],
		{}
	],
	[
		1,
		"cookiereports",
		2,
		"",
		22,
		[578, 579],
		[{ "e": 580 }],
		[{ "v": 578 }],
		[{ "eval": "EVAL_COOKIEREPORTS_OPT_OUT" }],
		[{ "eval": "EVAL_COOKIEREPORTS_TEST" }],
		{}
	],
	[
		1,
		"cookiesinfo-closecookies",
		2,
		"",
		22,
		[],
		[{ "e": 581 }],
		[{ "v": 581 }],
		[{ "c": 581 }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 582
		}],
		{}
	],
	[
		1,
		"cookiesjsr",
		2,
		"",
		22,
		[583],
		[{ "e": 584 }],
		[{ "v": 583 }],
		[{
			"if": { "v": 585 },
			"then": [{ "k": 585 }],
			"else": [
				{ "c": 586 },
				{ "wv": 587 },
				{
					"if": { "v": 588 },
					"then": [{ "k": 588 }],
					"else": [{
						"all": true,
						"optional": true,
						"k": 589
					}, { "c": 590 }]
				}
			]
		}, {
			"timeout": 2e3,
			"check": "none",
			"wv": 583
		}],
		[],
		{}
	],
	[
		1,
		"cookietractor",
		2,
		"",
		22,
		[591],
		[{ "e": 592 }],
		[{ "v": 592 }],
		[{
			"all": true,
			"optional": true,
			"k": 593
		}, { "c": 594 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 592
		}],
		{}
	],
	[
		1,
		"cookieyes",
		2,
		"",
		22,
		[595],
		[{ "e": 596 }],
		[{ "v": 596 }],
		[{
			"if": { "e": 597 },
			"then": [{ "c": 597 }],
			"else": [{
				"if": { "e": 598 },
				"then": [
					{ "c": 598 },
					{ "w": 599 },
					{
						"all": true,
						"optional": true,
						"k": 600
					},
					{ "c": 601 },
					{
						"optional": true,
						"wv": 602
					},
					{
						"optional": true,
						"c": 603
					}
				],
				"else": [{
					"if": { "e": 604 },
					"then": [
						{ "k": 604 },
						{ "w": 605 },
						{
							"all": true,
							"optional": true,
							"k": 606
						},
						{ "c": 607 }
					],
					"else": [{ "h": 608 }]
				}]
			}]
		}],
		[{ "cc": 609 }],
		{}
	],
	[
		1,
		"cookieyes-legacy",
		2,
		"",
		22,
		[610],
		[{ "e": 610 }],
		[{ "v": 610 }],
		[{
			"if": { "v": 611 },
			"then": [{ "c": 611 }],
			"else": [
				{ "c": 612 },
				{ "wv": 613 },
				{
					"all": true,
					"optional": true,
					"k": 614
				},
				{ "k": 613 }
			]
		}],
		[{ "cc": 615 }, { "any": [{ "cc": 616 }, { "cc": 617 }] }],
		{}
	],
	[
		1,
		"cookiez",
		2,
		"",
		22,
		[618],
		[{ "e": 619 }],
		[{ "v": 620 }],
		[{ "c": 620 }],
		[{ "wait": 1e3 }, { "cc": 621 }],
		{}
	],
	[
		1,
		"coolblue",
		0,
		"",
		10,
		[622],
		[{ "e": 623 }],
		[{ "v": 624 }],
		[{ "c": 625 }],
		[],
		{}
	],
	[
		1,
		"cornerstone-brands",
		2,
		"",
		22,
		[626, 627],
		[{ "any": [{ "e": 628 }, { "e": 629 }] }],
		[{ "any": [{ "v": 626 }, { "v": 627 }] }],
		[{
			"timeout": 5e3,
			"optional": true,
			"c": 628
		}, {
			"timeout": 6e3,
			"optional": true,
			"c": 629
		}],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 630
		}],
		{}
	],
	[
		1,
		"corona-in-zahlen.de",
		2,
		"",
		22,
		[631],
		[{ "e": 631 }],
		[{ "v": 631 }],
		[{ "k": 632 }, { "k": 633 }],
		[],
		{}
	],
	[
		1,
		"costco-travel",
		2,
		"",
		22,
		[],
		[{ "e": 634 }, { "e": 635 }],
		[{ "v": 636 }],
		[
			{ "c": 634 },
			{ "wv": 637 },
			{
				"all": true,
				"optional": true,
				"k": 638
			},
			{
				"all": true,
				"optional": true,
				"k": 639
			},
			{ "k": 637 }
		],
		[],
		{}
	],
	[
		1,
		"craft-cookie-consent",
		2,
		"",
		22,
		[640],
		[{ "e": 641 }],
		[{ "v": 642 }],
		[{
			"all": true,
			"optional": true,
			"k": 643
		}, {
			"if": { "v": 644 },
			"then": [{ "k": 644 }],
			"else": [
				{ "k": 645 },
				{ "wv": 646 },
				{
					"if": { "v": 647 },
					"then": [{ "k": 647 }],
					"else": [{ "k": 644 }]
				}
			]
		}],
		[{ "w": 648 }],
		{}
	],
	[
		1,
		"ct-ultimate-gdpr",
		2,
		"",
		22,
		[649],
		[{ "e": 649 }],
		[{
			"timeout": 3e4,
			"wv": 649
		}],
		[{
			"if": { "v": 650 },
			"then": [{ "k": 650 }],
			"else": [{
				"if": { "v": 651 },
				"then": [
					{ "k": 651 },
					{ "c": 652 },
					{ "k": 653 }
				],
				"else": [{ "h": 649 }]
			}]
		}],
		[{ "wait": 500 }, { "cc": 654 }],
		{}
	],
	[
		1,
		"curseforge",
		1,
		"",
		22,
		[655],
		[{ "e": 656 }],
		[{ "v": 656 }],
		[{ "h": 655 }],
		[],
		{}
	],
	[
		1,
		"cz-eshop-cookies-consent",
		2,
		"",
		22,
		[657],
		[{ "e": 658 }],
		[{ "v": 659 }],
		[{
			"retry": 10,
			"retryInterval": 500,
			"c": 658
		}],
		[{ "cc": 660 }, {
			"negated": true,
			"cc": 661
		}],
		{}
	],
	[
		1,
		"dack365",
		2,
		"",
		22,
		[662],
		[{ "e": 663 }],
		[{ "v": 664 }],
		[{ "c": 664 }, { "c": 665 }],
		[{
			"check": "none",
			"timeout": 5e3,
			"wv": 666
		}],
		{}
	],
	[
		1,
		"daikin",
		2,
		"",
		22,
		[667],
		[{ "e": 668 }],
		[{ "v": 667 }],
		[{ "c": 668 }],
		[{ "cc": 669 }],
		{}
	],
	[
		1,
		"dailymotion-us",
		1,
		"",
		22,
		[670],
		[{ "e": 671 }],
		[{ "v": 671 }],
		[{ "h": 671 }],
		[],
		{}
	],
	[
		1,
		"dan-com",
		2,
		"",
		10,
		[],
		[{ "e": 672 }],
		[{ "v": 672 }],
		[{ "c": 673 }],
		[],
		{}
	],
	[
		1,
		"danskebank",
		0,
		"",
		10,
		[674],
		[{ "e": 675 }],
		[{ "v": 676 }],
		[{ "c": 677 }, {
			"check": "none",
			"wv": 676
		}],
		[{ "cc": 678 }],
		{}
	],
	[
		1,
		"datagrail",
		2,
		"",
		22,
		[679],
		[{ "e": 679 }, { "exists": [".dg-consent-banner", ".dg-app"] }],
		[{ "v": 679 }],
		[{
			"if": { "exists": [".dg-consent-banner", "button.dg-button.reject_all, button.dg-button.accept_some"] },
			"then": [{ "waitForThenClick": [".dg-consent-banner", "button.dg-button.reject_all, button.dg-button.accept_some"] }],
			"else": [{
				"if": { "exists": [".dg-consent-banner", ".dg-browser-signal-notice"] },
				"then": [{
					"if": { "exists": [".dg-consent-banner", "button.dg-button.open_layer"] },
					"then": [{ "waitForThenClick": [".dg-consent-banner", "button.dg-button.open_layer"] }, { "waitForThenClick": [".dg-consent-banner", "button.dg-button.reject_all, button.dg-button.accept_some, button.dg-button.essential_only, button.dg-button.custom"] }],
					"else": [{ "waitForThenClick": [".dg-consent-banner", "button.dg-header-close"] }]
				}],
				"else": [{ "waitForThenClick": [".dg-consent-banner", "button.dg-button.open_layer"] }, { "waitForThenClick": [".dg-consent-banner", "button.dg-button.reject_all, button.dg-button.accept_some, button.dg-button.essential_only"] }]
			}]
		}],
		[{ "any": [{ "cc": 680 }, { "exists": [".dg-consent-banner", ".dg-browser-signal-notice"] }] }],
		{}
	],
	[
		1,
		"datasign",
		0,
		"",
		22,
		[],
		[{ "e": 681 }],
		[{ "visible": ["#datasign_cmp__host", "#datasign_cmp__cmp_summary"] }],
		[{
			"if": { "exists": ["#datasign_cmp__host", "#datasign_cmp__cmp_content input[type=checkbox]:not([disabled])"] },
			"then": [
				{ "waitForThenClick": ["#datasign_cmp__host", "#datasign_cmp__config-button, #datasign_cmp__cmp_summary [aria-controls=datasign_cmp__cmp_content]"] },
				{ "waitForVisible": ["#datasign_cmp__host", "#datasign_cmp__cmp_content_apply-button"] },
				{
					"click": ["#datasign_cmp__host", "#datasign_cmp__cmp_content input[type=checkbox]:checked:not([disabled])"],
					"all": true,
					"optional": true
				},
				{ "click": ["#datasign_cmp__host", "#datasign_cmp__cmp_content_apply-button"] }
			],
			"else": [{ "click": ["#datasign_cmp__host", "#datasign_cmp__cmp_summary .datasign__dialogCloseButton--index-module"] }]
		}],
		[{
			"waitForVisible": ["#datasign_cmp__host", "#datasign_cmp__cmp_summary"],
			"check": "none",
			"timeout": 3e3
		}],
		{}
	],
	[
		1,
		"de-volksbank",
		2,
		"",
		22,
		[],
		[{ "e": 682 }],
		[{ "e": 683 }],
		[{ "c": 684 }],
		[{ "cc": 685 }],
		{}
	],
	[
		1,
		"dfactory-cookie-notice",
		2,
		"",
		22,
		[686],
		[{ "e": 687 }],
		[{ "v": 688 }],
		[{
			"if": { "e": 689 },
			"then": [{ "c": 689 }],
			"else": [{ "c": 690 }]
		}],
		[{ "cc": 691 }],
		{}
	],
	[
		1,
		"didomi",
		2,
		"",
		22,
		[692],
		[{ "e": 693 }],
		[{
			"check": "any",
			"v": 694
		}],
		[{
			"if": { "e": 695 },
			"then": [{ "c": 695 }],
			"else": [{ "eval": "EVAL_DIDOMI_OPT_OUT" }]
		}],
		[{ "eval": "EVAL_DIDOMI_TEST" }],
		{}
	],
	[
		1,
		"dintel",
		2,
		"",
		22,
		[696],
		[{ "exists": ["dnt-cookies", ".dnt-cookies__footer"] }],
		[{ "visible": ["dnt-cookies", ".dnt-cookies--is-open"] }],
		[{ "waitForThenClick": ["dnt-cookies", ".dnt-cookies__footer dnt-button[type^=secondary]"] }, {
			"waitForVisible": ["dnt-cookies", ".dnt-cookies--is-open"],
			"check": "none",
			"timeout": 2e3,
			"optional": true
		}],
		[{ "cc": 697 }],
		{}
	],
	[
		1,
		"django-gdpr-cookie-consent",
		2,
		"",
		22,
		[698, 699],
		[{ "e": 700 }],
		[{ "v": 700 }],
		[{
			"if": { "e": 701 },
			"then": [{ "c": 701 }],
			"else": [
				{ "c": 702 },
				{ "c": 703 },
				{ "k": 704 }
			]
		}, {
			"check": "none",
			"timeout": 1e4,
			"wv": 705
		}],
		[{ "cc": 706 }],
		{}
	],
	[
		1,
		"dmgmedia",
		2,
		"",
		22,
		[707],
		[{ "e": 708 }],
		[{ "v": 708 }],
		[
			{ "c": 709 },
			{ "wv": 710 },
			{
				"all": true,
				"c": 711
			},
			{ "waitForThenClick": ["[data-project=\"mol-fe-cmp\"] [class*=footer]", "xpath///button[contains(., 'Save & Exit')]"] }
		],
		[],
		{}
	],
	[
		1,
		"dmgmedia-us",
		2,
		"",
		22,
		[712],
		[{ "e": 713 }],
		[{ "wv": 713 }],
		[
			{ "c": 714 },
			{ "wv": 715 },
			{ "c": 716 },
			{ "c": 717 }
		],
		[],
		{}
	],
	[
		1,
		"doordash-storefront",
		2,
		"",
		22,
		[718],
		[{ "e": 718 }],
		[{ "v": 718 }],
		[{
			"retry": 15,
			"retryInterval": 300,
			"c": 719
		}],
		[{ "cc": 720 }],
		{}
	],
	[
		1,
		"dpgmedia-nl",
		2,
		"",
		22,
		[721],
		[{ "e": 721 }],
		[{ "visible": ["#pg-shadow-host-dom", "#pg-modal"] }],
		[{
			"if": { "visible": ["#pg-shadow-host-dom", "#pg-reject-btn"] },
			"then": [{ "click": ["#pg-shadow-host-dom", "#pg-reject-btn"] }],
			"else": [{ "waitForThenClick": ["#pg-shadow-host-dom", "#pg-configure-btn"] }, { "waitForThenClick": ["#pg-shadow-host-dom", "#pg-reject-btn"] }]
		}],
		[],
		{}
	],
	[
		1,
		"dreamlab-cmp",
		2,
		"",
		22,
		[722],
		[{ "e": 723 }],
		[{ "v": 722 }],
		[{ "c": 724 }, { "c": 725 }],
		[{ "cc": 726 }],
		{}
	],
	[
		1,
		"drouot-rgpd",
		2,
		"",
		22,
		[727, 728],
		[{ "e": 729 }],
		[{ "v": 727 }],
		[{ "c": 730 }],
		[{ "cc": 731 }],
		{}
	],
	[
		1,
		"Drupal",
		2,
		"",
		22,
		[],
		[{ "e": 732 }],
		[{ "v": 732 }],
		[{ "k": 733 }],
		[],
		{}
	],
	[
		1,
		"duda-cookie-notification",
		0,
		"",
		10,
		[734],
		[{ "e": 735 }],
		[{ "v": 736 }],
		[{
			"retry": 3,
			"retryInterval": 500,
			"c": 737
		}],
		[{
			"check": "none",
			"v": 738
		}],
		{ "intermediate": false }
	],
	[
		1,
		"dunelm.com",
		2,
		"",
		22,
		[739],
		[{ "e": 740 }],
		[{ "v": 740 }],
		[{ "k": 741 }, { "k": 742 }],
		[{ "cc": 743 }, { "cc": 744 }],
		{}
	],
	[
		1,
		"e-grip",
		2,
		"",
		22,
		[],
		[{ "e": 745 }],
		[{ "v": 746 }],
		[{
			"if": { "e": 747 },
			"then": [{ "c": 747 }],
			"else": [
				{ "c": 748 },
				{
					"timeout": 2e3,
					"w": 749
				},
				{
					"if": { "e": 750 },
					"then": [{ "k": 751 }]
				},
				{ "k": 752 }
			]
		}],
		[{ "cc": 706 }, {
			"negated": true,
			"cc": 753
		}],
		{}
	],
	[
		1,
		"ecbeing",
		1,
		"",
		22,
		[754],
		[{ "e": 755 }],
		[{ "v": 756 }],
		[{ "h": 756 }],
		[],
		{}
	],
	[
		1,
		"eccmm",
		2,
		"",
		22,
		[],
		[{ "exists": ["#eccm-shadow-host", ".eccmm"] }],
		[{ "visible": ["#eccm-shadow-host", ".eccmm-dialog.eccmm-visible"] }],
		[{ "waitForThenClick": ["#eccm-shadow-host", ".eccmm-dialog .eccmm-deny-all-btn--footer"] }],
		[{
			"waitForVisible": ["#eccm-shadow-host", ".eccmm-dialog"],
			"check": "none",
			"timeout": 2e3
		}],
		{}
	],
	[
		1,
		"educamadrid",
		2,
		"",
		22,
		[757],
		[{ "e": 758 }],
		[{ "v": 759 }],
		[{ "c": 760 }, { "c": 761 }],
		[{
			"timeout": 3e3,
			"w": 762
		}, { "cc": 763 }],
		{}
	],
	[
		1,
		"ee-consent-notice",
		2,
		"",
		22,
		[764],
		[{ "e": 765 }],
		[{ "v": 766 }],
		[{
			"if": { "e": 767 },
			"then": [{ "c": 767 }],
			"else": [{ "eval": "EVAL_EE_CONSENT_DECLINE_0" }, { "c": 768 }]
		}],
		[],
		{}
	],
	[
		1,
		"elsevier-pure",
		2,
		"",
		22,
		[769],
		[{ "e": 770 }],
		[{ "v": 770 }],
		[{ "c": 771 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 770
		}],
		{}
	],
	[
		1,
		"Ensighten",
		2,
		"",
		22,
		[772, 773],
		[{ "any": [{ "v": 774 }, { "v": 775 }] }],
		[{ "any": [{ "v": 774 }, { "v": 775 }] }],
		[{ "wait": 500 }, {
			"if": { "v": 774 },
			"then": [{
				"if": {
					"check": "any",
					"v": 776
				},
				"then": [{ "c": 776 }],
				"else": [{
					"if": {
						"check": "any",
						"v": 777
					},
					"then": [
						{ "c": 777 },
						{
							"timeout": 1e3,
							"w": 775
						},
						{
							"all": true,
							"optional": true,
							"k": 778
						},
						{ "c": 779 }
					],
					"else": [{ "c": 780 }]
				}]
			}],
			"else": [{
				"all": true,
				"optional": true,
				"k": 778
			}, { "c": 779 }]
		}],
		[],
		{}
	],
	[
		1,
		"epaas",
		2,
		"",
		22,
		[781],
		[{ "e": 781 }],
		[{ "visible": ["epaas-consent-drawer-shell", "section.consentDrawer"] }],
		[{
			"if": { "exists": ["epaas-consent-drawer-shell", "button.reject-button"] },
			"then": [{ "waitForThenClick": ["epaas-consent-drawer-shell", "button.reject-button"] }],
			"else": [
				{ "waitForThenClick": ["epaas-consent-drawer-shell", "button.personalize-button"] },
				{ "waitFor": ["epaas-consent-drawer-shell", "epaas-policy-page-shell"] },
				{ "waitForThenClick": ["epaas-consent-drawer-shell", "button.save-button"] }
			]
		}],
		[{ "cc": 782 }],
		{}
	],
	[
		1,
		"erdee-media",
		2,
		"",
		22,
		[783],
		[{ "e": 783 }],
		[{ "v": 784 }],
		[{ "c": 785 }],
		[],
		{}
	],
	[
		1,
		"eset",
		0,
		"",
		22,
		[786],
		[{ "e": 787 }],
		[{ "v": 787 }],
		[{
			"if": { "v": 788 },
			"then": [{ "k": 788 }],
			"else": [
				{ "k": 789 },
				{ "wv": 790 },
				{
					"all": true,
					"optional": true,
					"k": 791
				},
				{ "k": 790 }
			]
		}],
		[{ "wait": 2e3 }, { "cc": 792 }],
		{}
	],
	[
		1,
		"etsy",
		2,
		"",
		22,
		[793, 794],
		[{ "e": 793 }],
		[{ "v": 793 }],
		[
			{ "k": 795 },
			{
				"timeout": 3e3,
				"wv": 796
			},
			{ "wait": 1e3 },
			{ "eval": "EVAL_ETSY_0" },
			{ "eval": "EVAL_ETSY_1" }
		],
		[],
		{}
	],
	[
		1,
		"EU Cookie Law",
		1,
		"",
		22,
		[797],
		[{ "e": 798 }],
		[{ "wait": 500 }, { "v": 798 }],
		[{ "h": 798 }],
		[{
			"negated": true,
			"cc": 799
		}],
		{}
	],
	[
		1,
		"eu-cookie-compliance-banner",
		2,
		"",
		22,
		[],
		[{ "e": 800 }],
		[{ "e": 800 }],
		[{ "k": 801 }],
		[{
			"negated": true,
			"cc": 802
		}],
		{}
	],
	[
		1,
		"eu-cookie-law-popup",
		2,
		"",
		22,
		[803],
		[{ "e": 804 }],
		[{
			"check": "any",
			"v": 804
		}],
		[{ "c": 804 }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 804
		}],
		{}
	],
	[
		1,
		"EZoic",
		2,
		"",
		22,
		[805],
		[{ "e": 805 }],
		[{ "v": 805 }],
		[
			{ "wait": 500 },
			{ "k": 806 },
			{ "w": 807 },
			{
				"all": true,
				"optional": true,
				"k": 808
			},
			{ "c": 809 }
		],
		[{ "cc": 810 }],
		{}
	],
	[
		1,
		"fanatics",
		2,
		"",
		22,
		[811],
		[{ "e": 811 }],
		[{ "v": 811 }],
		[{ "c": 812 }],
		[{ "cc": 813 }],
		{}
	],
	[
		1,
		"fastcmp",
		0,
		"",
		22,
		[814],
		[{ "e": 815 }],
		[{ "v": 815 }],
		[{ "waitForThenClick": ["iframe#fast-cmp-iframe", ".fast-cmp-home-refuse button"] }],
		[{ "cc": 816 }],
		{}
	],
	[
		1,
		"fastweb-cookie-center",
		2,
		"",
		22,
		[817],
		[{ "e": 818 }],
		[{ "v": 819 }],
		[{ "waitForThenClick": ["iframe.ck_if", "#Main > .close img"] }, {
			"check": "none",
			"timeout": 5e3,
			"wv": 817
		}],
		[{
			"check": "none",
			"v": 820
		}],
		{}
	],
	[
		1,
		"fedex",
		0,
		"",
		22,
		[821],
		[{ "e": 821 }],
		[{ "v": 822 }],
		[{ "c": 823 }],
		[{ "cc": 824 }],
		{}
	],
	[
		1,
		"fera-cookies",
		2,
		"",
		22,
		[825],
		[{ "e": 826 }],
		[{ "v": 827 }],
		[{
			"if": { "v": 828 },
			"then": [{ "k": 828 }],
			"else": [{ "c": 829 }]
		}, {
			"timeout": 2e3,
			"optional": true,
			"c": 830
		}],
		[{ "cc": 831 }, {
			"negated": true,
			"cc": 832
		}],
		{}
	],
	[
		1,
		"fever",
		2,
		"",
		22,
		[833],
		[{ "e": 834 }],
		[{ "v": 833 }],
		[
			{ "c": 834 },
			{
				"if": { "e": 835 },
				"then": [{ "k": 836 }]
			},
			{ "c": 837 }
		],
		[{ "cc": 838 }],
		{}
	],
	[
		1,
		"fever-cookie-advice",
		2,
		"",
		22,
		[839],
		[{ "e": 839 }],
		[{ "v": 839 }],
		[
			{ "c": 840 },
			{ "wv": 841 },
			{ "c": 842 }
		],
		[{ "wait": 500 }, { "cc": 843 }],
		{}
	],
	[
		1,
		"fides",
		2,
		"",
		22,
		[844],
		[{ "e": 845 }],
		[
			{ "v": 845 },
			{
				"check": "none",
				"v": 846
			},
			{ "eval": "EVAL_FIDES_DETECT_POPUP" }
		],
		[{ "w": 847 }, {
			"if": { "v": 848 },
			"then": [{
				"retry": 5,
				"retryInterval": 500,
				"c": 849
			}],
			"else": [{ "k": 850 }, {
				"retry": 5,
				"retryInterval": 500,
				"c": 851
			}]
		}],
		[],
		{}
	],
	[
		1,
		"finna",
		2,
		"",
		22,
		[852],
		[{ "e": 853 }],
		[{ "v": 853 }],
		[{
			"retry": 10,
			"retryInterval": 500,
			"c": 853
		}],
		[],
		{}
	],
	[
		1,
		"finsweet",
		0,
		"",
		22,
		[854],
		[{ "any": [{ "e": 854 }, { "exists": ["[fs-consent-element=root]", "[fs-consent-element=banner]"] }] }],
		[{ "any": [{ "v": 855 }, { "visible": ["[fs-consent-element=root]", "[fs-consent-element=banner] [fs-consent-element=allow]"] }] }],
		[{ "wait": 500 }, {
			"if": { "e": 856 },
			"then": [{ "k": 856 }],
			"else": [{
				"if": { "exists": ["[fs-consent-element=root]", "[fs-consent-element=banner] [fs-consent-element=deny]"] },
				"then": [{ "click": ["[fs-consent-element=root]", "[fs-consent-element=banner] [fs-consent-element=deny]"] }],
				"else": [{ "h": 857 }]
			}]
		}],
		[],
		{}
	],
	[
		1,
		"first-visit-notice",
		1,
		"",
		22,
		[858],
		[{ "e": 859 }],
		[{ "v": 858 }],
		[{ "h": 858 }],
		[],
		{}
	],
	[
		1,
		"fixpart",
		2,
		"",
		22,
		[860],
		[{ "e": 861 }],
		[{ "v": 860 }],
		[{ "c": 862 }],
		[{ "cc": 863 }],
		{}
	],
	[
		1,
		"ford-dse",
		2,
		"",
		22,
		[864],
		[{ "e": 865 }],
		[{ "v": 866 }],
		[{ "c": 865 }, { "w": 867 }],
		[{ "cc": 868 }],
		{}
	],
	[
		1,
		"fullertonhotels.com",
		0,
		"",
		10,
		[],
		[{ "exists": ["#ifrmCookieBanner", "#sp-decline"] }],
		[{ "visible": ["#ifrmCookieBanner", "#sp-decline"] }],
		[{ "wait": 500 }, { "waitForThenClick": ["#ifrmCookieBanner", "#sp-decline"] }],
		[],
		{}
	],
	[
		1,
		"funding-choices",
		2,
		"",
		22,
		[869],
		[{ "e": 870 }],
		[{ "e": 871 }],
		[
			{
				"if": { "e": 872 },
				"then": [{ "k": 872 }],
				"else": [{ "e": 873 }]
			},
			{
				"all": true,
				"optional": true,
				"k": 874
			},
			{
				"optional": true,
				"k": 875
			}
		],
		[],
		{}
	],
	[
		1,
		"gallup",
		2,
		"",
		22,
		[876],
		[{ "e": 877 }],
		[{ "v": 877 }],
		[
			{ "c": 877 },
			{ "wait": 500 },
			{ "c": 878 }
		],
		[{ "cc": 879 }],
		{}
	],
	[
		1,
		"gdpr-legal-cookie",
		2,
		"",
		22,
		[880],
		[{ "any": [{ "eval": "EVAL_GDPR_LEGAL_COOKIE_DETECT_CMP" }, { "e": 881 }] }],
		[{
			"check": "any",
			"v": 882
		}],
		[{ "c": 883 }],
		[{ "eval": "EVAL_GDPR_LEGAL_COOKIE_TEST" }],
		{}
	],
	[
		1,
		"gear4music",
		2,
		"",
		10,
		[884],
		[{ "e": 885 }],
		[{ "v": 884 }],
		[{ "c": 886 }, {
			"check": "none",
			"timeout": 2e3,
			"wv": 884
		}],
		[{ "wait": 1e3 }, { "cc": 887 }],
		{}
	],
	[
		1,
		"gemini.google.com",
		2,
		"",
		22,
		[888],
		[{ "e": 889 }],
		[{ "v": 888 }],
		[{ "c": 890 }],
		[],
		{}
	],
	[
		2,
		"getproven",
		1,
		"",
		22,
		[891],
		[{ "e": 892 }],
		[{ "v": 892 }],
		[{ "h": 891 }, {
			"removeClass": "cdk-global-scrollblock",
			"selector": "html",
			"optional": true
		}],
		[],
		{}
	],
	[
		1,
		"giustizia-it",
		2,
		"",
		22,
		[893],
		[{ "e": 894 }],
		[{ "v": 895 }],
		[{
			"all": true,
			"optional": true,
			"k": 896
		}, { "c": 897 }],
		[{ "cc": 898 }],
		{}
	],
	[
		1,
		"gobasic",
		2,
		"",
		22,
		[899],
		[{ "e": 900 }],
		[{ "v": 900 }],
		[{ "c": 900 }],
		[{ "cc": 901 }],
		{}
	],
	[
		1,
		"godaddy-privacy-widget",
		2,
		"",
		22,
		[902],
		[{ "exists": ["#gtm_privacy", "#privacy_widget"] }],
		[{ "visible": ["#gtm_privacy", "#privacy_widget"] }],
		[{ "waitForThenClick": ["#gtm_privacy", "#pw_decline"] }],
		[{ "cc": 903 }],
		{}
	],
	[
		1,
		"godaddy-website-builder",
		2,
		"",
		22,
		[904],
		[{ "e": 905 }],
		[{ "v": 906 }],
		[{ "c": 905 }],
		[],
		{}
	],
	[
		1,
		"godaddy-website-builder-cosmetic",
		1,
		"",
		22,
		[904],
		[{ "e": 904 }, {
			"negated": true,
			"e": 905
		}],
		[{ "v": 906 }],
		[{ "h": 904 }],
		[],
		{}
	],
	[
		1,
		"google-consent-standalone",
		2,
		"",
		22,
		[],
		[{ "e": 907 }, { "e": 908 }],
		[{ "v": 907 }],
		[{ "c": 909 }],
		[],
		{}
	],
	[
		1,
		"google-cookiebar",
		0,
		"",
		22,
		[910],
		[{ "e": 910 }],
		[{ "v": 910 }],
		[{
			"if": { "e": 911 },
			"then": [{ "k": 911 }],
			"else": [{ "h": 910 }]
		}],
		[],
		{}
	],
	[
		1,
		"google.com",
		2,
		"",
		22,
		[912],
		[{ "e": 912 }, { "e": 913 }],
		[{ "v": 914 }],
		[{ "c": 914 }],
		[{ "cc": 915 }],
		{}
	],
	[
		1,
		"gov.uk",
		2,
		"",
		22,
		[],
		[{ "e": 916 }],
		[{ "e": 917 }],
		[
			{ "wait": 300 },
			{
				"if": { "visible": [".govuk-cookie-banner__message", "xpath///button[contains(., 'Reject')] | //a[contains(., 'Reject')] | //input[contains(@value, 'Reject')] | //button[contains(., 'do not use analytics cookies')]"] },
				"then": [{ "click": [".govuk-cookie-banner__message", "xpath///button[contains(., 'Reject')] | //a[contains(., 'Reject')] | //input[contains(@value, 'Reject')] | //button[contains(., 'do not use analytics cookies')]"] }]
			},
			{ "waitForVisible": [".govuk-cookie-banner__message", "xpath///button[contains(., 'Hide')] | //a[contains(., 'Hide')] | //input[contains(@value, 'Hide')]"] },
			{ "click": [".govuk-cookie-banner__message", "xpath///button[contains(., 'Hide')] | //a[contains(., 'Hide')] | //input[contains(@value, 'Hide')]"] }
		],
		[],
		{}
	],
	[
		1,
		"gravito",
		2,
		"",
		22,
		[918],
		[{ "e": 919 }],
		[{ "v": 919 }],
		[{
			"if": { "v": 920 },
			"then": [{ "k": 920 }],
			"else": [{ "c": 921 }, { "c": 922 }]
		}, {
			"check": "none",
			"timeout": 2e3,
			"optional": true,
			"wv": 919
		}],
		[{ "cc": 923 }],
		{}
	],
	[
		1,
		"grupa-pracuj",
		0,
		"",
		22,
		[],
		[{ "e": 924 }],
		[{
			"check": "any",
			"v": 924
		}],
		[{
			"if": { "e": 925 },
			"then": [
				{ "c": 926 },
				{ "wv": 927 },
				{
					"all": true,
					"optional": true,
					"k": 928
				},
				{ "c": 929 }
			],
			"else": [
				{ "c": 930 },
				{ "wv": 931 },
				{
					"all": true,
					"optional": true,
					"k": 932
				},
				{ "c": 933 }
			]
		}],
		[{ "any": [{ "cc": 934 }, { "cc": 935 }] }],
		{}
	],
	[
		1,
		"grupa-rmf",
		2,
		"",
		22,
		[936],
		[{ "e": 937 }],
		[{ "v": 936 }],
		[
			{ "wv": 938 },
			{ "k": 938 },
			{ "wv": 939 },
			{ "k": 939 },
			{ "wv": 940 },
			{
				"if": { "e": 941 },
				"then": [{ "k": 940 }]
			},
			{ "wv": 942 },
			{ "k": 942 },
			{
				"check": "none",
				"wv": 936
			}
		],
		[],
		{}
	],
	[
		1,
		"gsb-cookie-banner",
		2,
		"",
		22,
		[943],
		[{ "e": 944 }],
		[{
			"check": "any",
			"v": 945
		}],
		[{ "c": 945 }],
		[{ "cc": 272 }],
		{}
	],
	[
		1,
		"gsb-cookiebanner-selection",
		2,
		"",
		22,
		[946, 947],
		[{ "e": 948 }],
		[{ "v": 948 }],
		[{
			"all": true,
			"optional": true,
			"k": 949
		}, { "c": 948 }],
		[{ "cc": 950 }],
		{}
	],
	[
		1,
		"guesty",
		0,
		"",
		22,
		[951],
		[{ "e": 952 }],
		[{ "v": 951 }],
		[{ "c": 953 }],
		[{ "cc": 954 }],
		{}
	],
	[
		1,
		"gwo",
		2,
		"",
		22,
		[955],
		[{ "e": 955 }],
		[{ "v": 956 }],
		[
			{
				"if": { "e": 957 },
				"then": [],
				"else": [{ "c": 958 }]
			},
			{ "w": 959 },
			{
				"all": true,
				"optional": true,
				"k": 960
			},
			{
				"optional": true,
				"k": 961
			},
			{ "k": 958 }
		],
		[{ "cc": 962 }],
		{}
	],
	[
		1,
		"hacon-next-gen",
		2,
		"",
		22,
		[],
		[{ "exists": ["next-gen-map-based-route", "next-gen-cookie-dialog"] }],
		[{ "visible": ["next-gen-map-based-route", "next-gen-cookie-dialog next-gen-page.cookie-dialog"] }],
		[{
			"if": { "exists": ["next-gen-map-based-route", "next-gen-cookie-dialog input[type=checkbox]:checked"] },
			"then": [{
				"click": ["next-gen-map-based-route", "next-gen-cookie-dialog input[type=checkbox]:checked"],
				"all": true
			}]
		}, { "waitForThenClick": ["next-gen-map-based-route", "next-gen-cookie-dialog next-gen-page-footer button[variant=secondary]"] }],
		[{ "cc": 963 }],
		{}
	],
	[
		1,
		"handelsbanken",
		2,
		"",
		22,
		[964],
		[{ "e": 965 }],
		[{ "v": 965 }],
		[{ "c": 966 }],
		[{ "cc": 967 }],
		{}
	],
	[
		1,
		"healthline-media",
		2,
		"",
		22,
		[968],
		[{ "e": 969 }],
		[{ "e": 969 }],
		[{
			"if": { "e": 970 },
			"then": [{ "k": 970 }],
			"else": [{ "wv": 971 }, { "k": 972 }]
		}],
		[],
		{}
	],
	[
		1,
		"hema",
		2,
		"",
		22,
		[273],
		[{ "v": 973 }],
		[{ "v": 973 }],
		[{ "c": 974 }],
		[{ "cc": 975 }],
		{}
	],
	[
		1,
		"hl.co.uk",
		2,
		"",
		22,
		[976, 977],
		[{ "e": 977 }],
		[{ "e": 977 }],
		[
			{ "k": 978 },
			{ "h": 979 },
			{ "w": 980 },
			{
				"optional": true,
				"k": 981
			},
			{ "w": 982 },
			{
				"optional": true,
				"k": 983
			},
			{ "k": 984 }
		],
		[],
		{}
	],
	[
		1,
		"holidaymedia",
		2,
		"",
		22,
		[985],
		[{ "e": 986 }],
		[{ "v": 985 }],
		[{
			"timeout": 2e3,
			"c": 987
		}],
		[],
		{}
	],
	[
		1,
		"hometogo",
		2,
		"",
		22,
		[988],
		[{ "e": 989 }],
		[{ "v": 988 }],
		[{
			"if": { "e": 990 },
			"then": [{ "c": 990 }],
			"else": [{ "c": 991 }, { "c": 992 }]
		}],
		[{ "cc": 706 }],
		{}
	],
	[
		1,
		"hu-manity",
		2,
		"",
		22,
		[993],
		[{ "e": 994 }],
		[{ "v": 994 }],
		[{ "c": 995 }],
		[],
		{}
	],
	[
		1,
		"hubspot",
		2,
		"",
		22,
		[],
		[{ "e": 996 }],
		[{ "v": 996 }],
		[{ "k": 997 }],
		[],
		{}
	],
	[
		1,
		"idxrcookies",
		2,
		"",
		22,
		[998],
		[{ "e": 999 }],
		[{ "v": 999 }],
		[{ "c": 999 }],
		[],
		{}
	],
	[
		1,
		"ihavecookies",
		2,
		"",
		22,
		[1e3],
		[{ "e": 1001 }],
		[{ "v": 1e3 }],
		[
			{ "c": 1001 },
			{ "wv": 1002 },
			{
				"all": true,
				"optional": true,
				"k": 1003
			},
			{
				"if": { "v": 1004 },
				"then": [{ "k": 1004 }],
				"else": [{ "k": 1005 }]
			},
			{
				"check": "none",
				"timeout": 2e3,
				"optional": true,
				"wv": 1e3
			}
		],
		[{ "cc": 1006 }],
		{}
	],
	[
		1,
		"ilovepdf",
		2,
		"",
		22,
		[],
		[{ "e": 1007 }],
		[{ "v": 1007 }],
		[{ "c": 1007 }, { "c": 1008 }],
		[{ "cc": 1009 }],
		{}
	],
	[
		1,
		"impress-co-jp",
		2,
		"",
		22,
		[1010],
		[{ "e": 1011 }],
		[{ "v": 1011 }],
		[{ "c": 1011 }],
		[{ "cc": 1012 }],
		{}
	],
	[
		1,
		"incomit",
		2,
		"",
		22,
		[1013],
		[{ "exists": ["cookie-consent-element", ".incom-cookie-module"] }],
		[{ "visible": ["cookie-consent-element", ".incom-cookie-module #main-cookie-view"] }],
		[{ "waitForThenClick": ["cookie-consent-element", "#main-cookie-view nav button.btn:not(#cookie-accept-all)"] }],
		[{ "cc": 1014 }],
		{}
	],
	[
		1,
		"indy-systems",
		1,
		"",
		22,
		[1015],
		[{ "e": 1016 }],
		[{ "v": 1015 }],
		[{ "h": 1015 }],
		[],
		{}
	],
	[
		1,
		"infomaniak-rgpd",
		2,
		"",
		22,
		[1017],
		[{ "e": 1017 }],
		[{ "visible": ["module-rgpd-component", ".modal"] }],
		[{
			"waitForThenClick": ["module-rgpd-component", ".buttons > button:nth-of-type(2)"],
			"retry": 3
		}],
		[{ "cc": 1018 }],
		{}
	],
	[
		1,
		"inmobi",
		2,
		"",
		22,
		[1019],
		[{ "e": 1020 }],
		[{ "v": 1020 }],
		[{ "c": 1021 }],
		[{ "cc": 1022 }],
		{}
	],
	[
		1,
		"insided",
		0,
		"",
		10,
		[1023],
		[{ "e": 1024 }],
		[{ "v": 1024 }],
		[{ "c": 1024 }],
		[{
			"check": "none",
			"v": 1024
		}],
		{}
	],
	[
		1,
		"interia",
		2,
		"",
		22,
		[1025],
		[{ "e": 1026 }],
		[{ "v": 1025 }],
		[{ "c": 1026 }, { "c": 1027 }],
		[{
			"check": "none",
			"timeout": 3e3,
			"wv": 1025
		}],
		{}
	],
	[
		1,
		"ionos.de",
		2,
		"",
		22,
		[1028, 1029],
		[{ "e": 1029 }],
		[{ "v": 1029 }],
		[{ "k": 1030 }, { "k": 1031 }],
		[],
		{}
	],
	[
		1,
		"iubenda",
		2,
		"",
		22,
		[1032],
		[{ "e": 1032 }],
		[{ "any": [{ "v": 1033 }, { "v": 1034 }] }],
		[{
			"if": { "e": 1035 },
			"then": [{ "k": 1035 }],
			"else": [{
				"if": { "e": 1036 },
				"then": [
					{ "c": 1036 },
					{ "c": 1037 },
					{ "c": 1038 }
				],
				"else": [{
					"if": { "e": 1034 },
					"then": [
						{ "k": 1034 },
						{ "c": 1039 },
						{
							"timeout": 2e3,
							"optional": true,
							"c": 1040
						}
					],
					"else": [{ "h": 1032 }]
				}]
			}]
		}],
		[{ "any": [{ "eval": "EVAL_IUBENDA_1" }, { "cc": 1041 }] }],
		{}
	],
	[
		1,
		"iWink",
		2,
		"",
		22,
		[1042],
		[{ "e": 1042 }],
		[{ "v": 1042 }],
		[{ "c": 1043 }],
		[{ "cc": 1044 }],
		{}
	],
	[
		1,
		"jcookie",
		1,
		"",
		22,
		[1045],
		[{ "e": 1046 }],
		[{ "v": 1047 }],
		[{ "h": 1045 }],
		[],
		{}
	],
	[
		1,
		"jetpack-eu-cookie-law",
		1,
		"",
		22,
		[1048],
		[{ "e": 1048 }],
		[{ "v": 1048 }],
		[{ "h": 1048 }],
		[],
		{}
	],
	[
		1,
		"jobindex",
		2,
		"",
		22,
		[1049],
		[{ "e": 1049 }],
		[{ "v": 1049 }],
		[{
			"if": { "e": 1050 },
			"then": [{
				"all": true,
				"k": 1050
			}]
		}, { "c": 1051 }],
		[{ "cc": 441 }],
		{}
	],
	[
		1,
		"johnlewis.com",
		2,
		"",
		22,
		[1052],
		[{ "e": 1052 }],
		[{ "e": 1052 }],
		[
			{ "k": 1053 },
			{ "wait": 500 },
			{
				"all": true,
				"optional": true,
				"k": 1054
			},
			{ "k": 1055 }
		],
		[],
		{}
	],
	[
		1,
		"jollyroom",
		2,
		"",
		22,
		[1056],
		[{ "e": 1057 }],
		[{ "v": 1058 }],
		[
			{ "c": 1059 },
			{
				"if": { "e": 1060 },
				"then": [{
					"all": true,
					"k": 1060
				}]
			},
			{
				"retry": 5,
				"retryInterval": 500,
				"c": 1057
			}
		],
		[{
			"check": "none",
			"v": 1061
		}],
		{}
	],
	[
		1,
		"jpmorgan-chase",
		2,
		"",
		22,
		[1062],
		[{ "e": 1063 }],
		[{ "v": 1063 }],
		[{ "c": 1063 }],
		[{ "cc": 1064 }],
		{}
	],
	[
		1,
		"jquery.cookieBar",
		1,
		"",
		22,
		[1065],
		[{ "e": 1066 }],
		[{
			"check": "any",
			"v": 1066
		}],
		[{ "h": 1065 }],
		[{
			"check": "none",
			"v": 1066
		}, {
			"negated": true,
			"cc": 1067
		}],
		{}
	],
	[
		1,
		"justwatch.com",
		2,
		"",
		22,
		[1068],
		[{ "e": 1069 }],
		[{ "v": 1069 }],
		[
			{ "k": 1070 },
			{ "c": 1071 },
			{
				"all": true,
				"c": 1072
			},
			{
				"all": true,
				"optional": true,
				"k": 1073
			},
			{ "wv": 1074 },
			{ "k": 1074 }
		],
		[],
		{}
	],
	[
		1,
		"kamsoft-cookiesmanager",
		2,
		"",
		22,
		[1075],
		[{ "e": 1076 }],
		[{ "v": 1076 }],
		[{
			"if": { "e": 1077 },
			"then": [{ "c": 1077 }],
			"else": [
				{ "c": 1078 },
				{ "wv": 1079 },
				{
					"all": true,
					"optional": true,
					"k": 1080
				},
				{ "k": 1079 }
			]
		}],
		[],
		{}
	],
	[
		1,
		"kaspersky-cookies-notification",
		1,
		"",
		22,
		[1081],
		[{ "e": 1082 }, { "e": 1083 }],
		[{ "v": 1083 }],
		[{ "h": 1084 }],
		[],
		{}
	],
	[
		1,
		"kconsent",
		0,
		"",
		10,
		[1085],
		[{ "e": 1086 }],
		[{ "v": 1087 }],
		[{ "c": 1088 }],
		[],
		{}
	],
	[
		1,
		"ketch",
		2,
		"",
		10,
		[
			1089,
			1090,
			1091
		],
		[{ "any": [
			{ "e": 1089 },
			{ "e": 1090 },
			{ "e": 1091 },
			{ "e": 1092 }
		] }],
		[{ "any": [
			{ "v": 1089 },
			{ "v": 1090 },
			{ "v": 1091 }
		] }],
		[
			{
				"if": { "e": 1093 },
				"then": [{ "c": 1093 }, {
					"if": { "v": 1094 },
					"then": [{ "k": 1095 }]
				}],
				"else": [{
					"if": { "e": 1096 },
					"then": [{ "c": 1096 }],
					"else": [{
						"if": { "e": 1097 },
						"then": [{
							"if": { "e": 1098 },
							"then": [{ "c": 1098 }],
							"else": [{
								"if": { "e": 1099 },
								"then": [{ "k": 1099 }]
							}]
						}]
					}]
				}]
			},
			{
				"timeout": 1e3,
				"optional": true,
				"w": 1100
			},
			{
				"if": { "e": 1100 },
				"then": [{
					"if": { "e": 1101 },
					"then": [{ "c": 1101 }],
					"else": [{
						"all": true,
						"optional": true,
						"k": 1102
					}]
				}, { "k": 1095 }]
			}
		],
		[{ "cc": 1103 }],
		{ "intermediate": false }
	],
	[
		1,
		"klaxit-cookie-consent",
		2,
		"",
		22,
		[1104],
		[{ "e": 1105 }],
		[{ "v": 1106 }],
		[{ "c": 1107 }],
		[{ "cc": 1108 }],
		{}
	],
	[
		1,
		"klp-cookie-banner",
		2,
		"",
		22,
		[1109],
		[{ "e": 1109 }],
		[{ "v": 1110 }],
		[{ "c": 1111 }],
		[{ "wait": 500 }, { "cc": 1112 }],
		{}
	],
	[
		1,
		"kolibri-cookie-widget",
		2,
		"",
		22,
		[1113],
		[{ "e": 1113 }],
		[{ "v": 1113 }],
		[{ "c": 1114 }, {
			"check": "none",
			"timeout": 5e3,
			"wv": 1113
		}],
		[{ "cc": 1115 }],
		{}
	],
	[
		1,
		"krieger-consent-form",
		2,
		"",
		22,
		[1116],
		[{ "e": 1117 }],
		[{ "v": 1118 }],
		[{
			"all": true,
			"optional": true,
			"k": 1119
		}, { "c": 1120 }],
		[{ "cc": 1121 }],
		{}
	],
	[
		1,
		"krown-cookie-banner",
		0,
		"",
		22,
		[1122],
		[{ "e": 1123 }],
		[{ "v": 1123 }],
		[{ "c": 1123 }],
		[{ "wait": 500 }, { "eval": "EVAL_KROWN_COOKIE_BANNER_TEST" }],
		{}
	],
	[
		1,
		"kulturit-ccm",
		0,
		"",
		22,
		[1124],
		[{ "exists": ["#kit-ccm", ".ccm-container dialog"] }],
		[{ "visible": ["#kit-ccm", ".ccm-container dialog[open] .action-buttons"] }],
		[{ "waitForThenClick": ["#kit-ccm", "dialog[open] .action-buttons button:not(.accept-selected):last-of-type"] }],
		[{
			"waitForVisible": ["#kit-ccm", ".ccm-container dialog .action-buttons"],
			"check": "none",
			"timeout": 2e3
		}],
		{}
	],
	[
		1,
		"kwik-fit",
		0,
		"",
		22,
		[1125, 1126],
		[{ "e": 1127 }],
		[{ "v": 1128 }],
		[
			{ "c": 1129 },
			{ "wv": 1130 },
			{
				"all": true,
				"optional": true,
				"k": 1131
			},
			{ "c": 1132 },
			{
				"check": "none",
				"wv": 1125
			}
		],
		[],
		{}
	],
	[
		1,
		"la7-cmp",
		2,
		"",
		22,
		[1133],
		[{ "e": 1134 }],
		[{ "v": 1134 }],
		[{ "c": 1134 }],
		[{ "cc": 1135 }],
		{}
	],
	[
		1,
		"lab-network-consent",
		2,
		"",
		22,
		[1136],
		[{ "e": 1137 }],
		[{ "v": 1136 }],
		[{ "c": 1137 }],
		[{ "cc": 1138 }],
		{}
	],
	[
		1,
		"laravel-cookie-consent",
		2,
		"",
		22,
		[1139],
		[{ "e": 1139 }],
		[{ "v": 1139 }],
		[
			{ "c": 1140 },
			{ "wv": 1141 },
			{
				"all": true,
				"optional": true,
				"k": 1142
			},
			{ "c": 1143 },
			{
				"check": "none",
				"wv": 1139
			}
		],
		[{ "cc": 1144 }],
		{}
	],
	[
		1,
		"lawwwing",
		2,
		"",
		22,
		[1145],
		[{ "e": 1145 }],
		[{ "v": 1146 }],
		[{ "c": 1147 }, {
			"check": "none",
			"timeout": 2e3,
			"wv": 1148
		}],
		[{ "cc": 1149 }],
		{}
	],
	[
		1,
		"legally-ok",
		2,
		"",
		22,
		[1150],
		[{ "exists": ["#jmdCookieConsentWrapper", "#cookieConsent"] }],
		[{ "visible": ["#jmdCookieConsentWrapper", "#cookieConsent"] }],
		[{ "waitForThenClick": ["#jmdCookieConsentWrapper", "#cookieConsent .js-select-none"] }],
		[{ "cc": 112 }],
		{}
	],
	[
		1,
		"lg-cookiecontrol",
		2,
		"",
		22,
		[1151],
		[{ "e": 1152 }],
		[{ "v": 1151 }],
		[{
			"if": { "e": 1153 },
			"then": [{ "k": 1153 }],
			"else": [{ "c": 1154 }]
		}],
		[{ "cc": 1155 }],
		{}
	],
	[
		1,
		"lia",
		2,
		"",
		22,
		[1156],
		[{ "e": 1156 }],
		[{ "e": 1157 }, { "v": 1156 }],
		[{ "c": 1158 }],
		[],
		{}
	],
	[
		1,
		"liferay-cookies-banner",
		2,
		"",
		22,
		[1159],
		[{ "e": 1159 }, {
			"negated": true,
			"e": 1160
		}],
		[{ "v": 1159 }],
		[{ "c": 1161 }],
		[{ "cc": 1162 }],
		{}
	],
	[
		1,
		"lightbox",
		2,
		"",
		22,
		[1163],
		[{ "e": 1164 }],
		[{ "v": 1164 }],
		[{ "k": 1165 }],
		[],
		{}
	],
	[
		1,
		"lineagrafica",
		1,
		"",
		22,
		[1166],
		[{ "e": 1166 }],
		[{ "e": 1166 }],
		[{ "h": 1166 }],
		[],
		{}
	],
	[
		1,
		"lineagrafica-reject",
		2,
		"",
		22,
		[1167],
		[{ "e": 1168 }],
		[{ "v": 1168 }],
		[{ "c": 1168 }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 1169
		}],
		{}
	],
	[
		1,
		"linkedin.com",
		2,
		"",
		22,
		[1170],
		[{ "e": 1170 }],
		[{ "v": 1170 }],
		[
			{ "wv": 1171 },
			{ "wait": 500 },
			{ "c": 1171 }
		],
		[{
			"check": "none",
			"wv": 1170
		}],
		{}
	],
	[
		1,
		"lta",
		0,
		"",
		10,
		[1172],
		[{ "e": 1172 }],
		[{ "v": 1172 }],
		[
			{ "c": 1173 },
			{ "wv": 1174 },
			{
				"all": true,
				"optional": true,
				"k": 1175
			},
			{ "k": 1176 }
		],
		[{ "cc": 1177 }],
		{}
	],
	[
		1,
		"macaron",
		2,
		"",
		22,
		[1178],
		[{ "e": 1178 }],
		[{ "v": 1179 }],
		[{
			"if": { "e": 1180 },
			"then": [{ "k": 1180 }],
			"else": [
				{ "c": 1181 },
				{ "w": 1182 },
				{ "wv": 1183 },
				{
					"all": true,
					"optional": true,
					"c": 1184
				},
				{ "c": 1185 }
			]
		}],
		[{ "cc": 1186 }],
		{}
	],
	[
		1,
		"mco-consent",
		2,
		"",
		22,
		[
			1187,
			1188,
			1189,
			1190
		],
		[{ "e": 1191 }],
		[{ "v": 1192 }],
		[{ "c": 1192 }],
		[{ "cc": 1193 }],
		{}
	],
	[
		1,
		"mediamarkt.de",
		2,
		"",
		22,
		[1194, 1195],
		[{ "e": 1196 }],
		[{ "e": 1196 }],
		[{ "k": 1197 }],
		[],
		{}
	],
	[
		1,
		"mensaje-cookies",
		2,
		"",
		22,
		[1198, 1199],
		[{ "e": 1200 }, { "any": [{ "e": 1201 }, { "e": 1202 }] }],
		[{ "v": 1203 }],
		[{
			"if": { "e": 1201 },
			"then": [{ "c": 1201 }],
			"else": [{ "c": 1204 }, { "c": 1202 }]
		}, {
			"check": "none",
			"timeout": 3e3,
			"wv": 1203
		}],
		[{
			"check": "none",
			"v": 1203
		}],
		{}
	],
	[
		1,
		"mercedes-benz-cmm",
		2,
		"",
		22,
		[1205],
		[{ "exists": ["cmm-cookie-banner", ".cmm-cookie-banner__wrapper"] }],
		[{ "visible": ["cmm-cookie-banner", ".cmm-cookie-banner__wrapper.visible"] }],
		[{
			"if": { "exists": ["cmm-cookie-banner", "wb7-button[data-test=handle-deny-button]"] },
			"then": [{ "waitForThenClick": ["cmm-cookie-banner", "wb7-button[data-test=handle-deny-button]"] }],
			"else": [
				{ "waitForThenClick": ["cmm-cookie-banner", "wb7-button[data-test=toggle-cookie-details]"] },
				{ "waitForVisible": ["cmm-cookie-banner", "wb7-button[data-test=handle-confirm-selection-button]"] },
				{
					"click": ["cmm-cookie-banner", "input[data-test=handle-category-change]:checked:not([disabled])"],
					"all": true,
					"optional": true
				},
				{ "waitForThenClick": ["cmm-cookie-banner", "wb7-button[data-test=handle-confirm-selection-button]"] }
			]
		}],
		[{
			"waitForVisible": ["cmm-cookie-banner", ".cmm-cookie-banner__wrapper.visible"],
			"timeout": 2e3,
			"check": "none"
		}],
		{}
	],
	[
		1,
		"meridiancu",
		2,
		"",
		22,
		[1206],
		[{ "e": 1207 }],
		[{ "v": 1208 }],
		[
			{ "c": 1209 },
			{ "wv": 1210 },
			{
				"optional": true,
				"k": 1211
			},
			{ "c": 1212 }
		],
		[{ "cc": 1213 }],
		{}
	],
	[
		1,
		"meta-cookie-dialog",
		2,
		"",
		22,
		[1214, 1215],
		[{ "e": 1216 }],
		[{ "v": 1216 }],
		[{
			"retry": 3,
			"retryInterval": 500,
			"c": 1217
		}, {
			"check": "none",
			"wv": 1217
		}],
		[],
		{}
	],
	[
		1,
		"meteored",
		2,
		"",
		22,
		[1218],
		[{ "e": 1219 }],
		[{ "v": 1219 }],
		[{ "c": 1220 }, {
			"retry": 5,
			"retryInterval": 500,
			"c": 1221
		}],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 1218
		}, { "cc": 1222 }],
		{}
	],
	[
		1,
		"microsoft.com",
		2,
		"",
		22,
		[1223],
		[{ "e": 1223 }],
		[{ "e": 1223 }],
		[{ "eval": "EVAL_MICROSOFT_0" }],
		[{ "eval": "EVAL_MICROSOFT_2" }],
		{}
	],
	[
		2,
		"milestone-internet",
		1,
		"",
		22,
		[1224],
		[{ "e": 1225 }],
		[{ "v": 1225 }],
		[{ "h": 1224 }, {
			"removeClass": "pushItDown",
			"selector": ".pushItDown",
			"optional": true
		}],
		[],
		{}
	],
	[
		1,
		"minitool",
		1,
		"",
		22,
		[1226],
		[{ "e": 1227 }],
		[{ "v": 1226 }],
		[{ "h": 1226 }],
		[{
			"check": "none",
			"v": 1226
		}],
		{}
	],
	[
		1,
		"mirasvit-gdpr",
		2,
		"",
		22,
		[
			1228,
			1229,
			1230,
			1231
		],
		[{ "e": 1232 }],
		[{
			"check": "any",
			"v": 1232
		}],
		[{
			"if": {
				"check": "any",
				"v": 1233
			},
			"then": [{ "any": [{ "k": 1234 }, { "k": 1235 }] }],
			"else": [
				{ "any": [{ "k": 1236 }, { "k": 1237 }] },
				{
					"check": "any",
					"timeout": 5e3,
					"wv": 1238
				},
				{
					"all": true,
					"timeout": 2e3,
					"optional": true,
					"c": 1239
				},
				{ "any": [
					{ "k": 1240 },
					{ "k": 1241 },
					{ "k": 1242 }
				] }
			]
		}, {
			"check": "none",
			"timeout": 1e4,
			"wv": 1232
		}],
		[{ "cc": 1243 }, {
			"check": "none",
			"v": 1232
		}],
		{}
	],
	[
		1,
		"miteco",
		2,
		"",
		22,
		[1244, 1245],
		[{ "e": 1246 }],
		[{ "v": 1247 }],
		[
			{ "c": 1246 },
			{ "wv": 1248 },
			{
				"if": { "e": 1249 },
				"then": [{ "k": 1250 }]
			},
			{ "k": 1248 }
		],
		[],
		{}
	],
	[
		1,
		"mittanbud",
		0,
		"",
		22,
		[],
		[{ "e": 1251 }],
		[{ "v": 1252 }],
		[{ "c": 1253 }],
		[{ "cc": 1254 }, { "cc": 189 }],
		{}
	],
	[
		1,
		"mkdocs-material",
		2,
		"",
		22,
		[1255, 1256],
		[{ "e": 1257 }],
		[{ "v": 1258 }],
		[{
			"all": true,
			"optional": true,
			"k": 1259
		}, { "c": 1260 }],
		[],
		{}
	],
	[
		1,
		"mobirise-cookies-alert",
		2,
		"",
		22,
		[1261],
		[{ "e": 1262 }],
		[{ "v": 1261 }],
		[{
			"retry": 3,
			"retryInterval": 1500,
			"c": 1262
		}],
		[{
			"check": "none",
			"timeout": 4e3,
			"wv": 1261
		}],
		{}
	],
	[
		1,
		"mobirise-cookies-alert-cosmetic",
		1,
		"",
		22,
		[1261],
		[{ "e": 1261 }, {
			"negated": true,
			"e": 1262
		}],
		[{ "v": 1261 }],
		[{ "h": 1261 }],
		[],
		{}
	],
	[
		1,
		"moneysavingexpert.com",
		2,
		"",
		22,
		[],
		[{ "e": 1263 }],
		[{ "v": 1263 }],
		[{ "k": 1264 }, { "k": 1265 }],
		[],
		{}
	],
	[
		1,
		"Moove",
		2,
		"",
		22,
		[1266],
		[{ "e": 1266 }],
		[{ "v": 1267 }],
		[{
			"if": { "e": 1268 },
			"then": [{ "k": 1268 }],
			"else": [{
				"if": { "e": 1269 },
				"then": [
					{ "k": 1269 },
					{ "wv": 1270 },
					{ "eval": "EVAL_MOOVE_0" },
					{ "k": 1271 }
				],
				"else": [{ "h": 1266 }]
			}]
		}],
		[{
			"check": "none",
			"v": 1266
		}],
		{}
	],
	[
		1,
		"msg-cookie",
		1,
		"",
		22,
		[1272],
		[{ "e": 1273 }],
		[{ "v": 1273 }],
		[{ "h": 1274 }],
		[],
		{}
	],
	[
		1,
		"musti",
		2,
		"",
		22,
		[1275],
		[{ "e": 1276 }],
		[{ "v": 1275 }],
		[{ "c": 1277 }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 1275
		}],
		{}
	],
	[
		1,
		"nhs.uk",
		2,
		"",
		22,
		[1278],
		[{ "e": 1278 }],
		[{ "e": 1278 }],
		[{ "k": 1279 }],
		[],
		{}
	],
	[
		1,
		"nowaera",
		2,
		"",
		22,
		[1280, 1281],
		[{ "e": 1282 }],
		[{ "v": 1283 }],
		[
			{ "c": 1284 },
			{ "wv": 1285 },
			{
				"all": true,
				"optional": true,
				"k": 1286
			},
			{ "k": 1285 }
		],
		[{ "cc": 1287 }, { "cc": 1288 }],
		{}
	],
	[
		1,
		"npo-ccm",
		2,
		"",
		22,
		[1289],
		[{ "exists": ["ccm-notification", "#ccm_notification .ccm_btn--save"] }],
		[{ "visible": ["ccm-notification", "#ccm_notification"] }],
		[{
			"if": { "exists": ["ccm-notification", "#ccm_notification .ccm_btn--deny-all"] },
			"then": [{ "click": ["ccm-notification", "#ccm_notification .ccm_btn--deny-all"] }],
			"else": [{
				"click": ["ccm-notification", "#ccm_notification input[type='radio'][value='false']"],
				"all": true,
				"optional": true
			}, { "waitForThenClick": ["ccm-notification", "#ccm_notification .ccm_btn--save:not(.ccm_btn_disabled)"] }]
		}],
		[],
		{}
	],
	[
		1,
		"obi.de",
		2,
		"",
		22,
		[1290],
		[{ "e": 1291 }],
		[{ "v": 1291 }],
		[{ "k": 1292 }],
		[],
		{}
	],
	[
		1,
		"occ-gdpr",
		2,
		"",
		22,
		[1293],
		[{ "e": 1294 }],
		[{ "v": 1295 }],
		[
			{ "c": 1296 },
			{ "wv": 1297 },
			{
				"if": { "e": 1298 },
				"then": [{
					"all": true,
					"k": 1298
				}]
			},
			{ "k": 1297 }
		],
		[{ "cc": 1299 }],
		{}
	],
	[
		1,
		"om",
		2,
		"",
		22,
		[1300],
		[{ "e": 1301 }],
		[{ "e": 1301 }],
		[{
			"if": { "e": 1302 },
			"then": [{ "c": 1302 }],
			"else": [{
				"all": true,
				"optional": true,
				"k": 1303
			}, { "c": 1304 }]
		}],
		[],
		{}
	],
	[
		1,
		"opencmp",
		2,
		"",
		22,
		[],
		[{ "exists": [".cmp-root-container", "#cmp_consentDialog .cmp_ui .cmp_mainButtons"] }],
		[{ "visible": [".cmp-root-container", "#cmp_consentDialog .cmp_ui"] }],
		[{
			"if": { "exists": [".cmp-root-container", ".cmp_ui .cmp_mainButtons .cmp_button:not(.cmp-button-accept-all)"] },
			"then": [{ "click": [".cmp-root-container", ".cmp_ui .cmp_mainButtons .cmp_button:not(.cmp-button-accept-all)"] }],
			"else": [
				{ "click": [".cmp-root-container", ".cmp_ui .cmp_mainButtons .cmp_saveLink a"] },
				{
					"waitFor": [".cmp-root-container", ".cmp_ui .cmp_level1Container"],
					"timeout": 3e3
				},
				{
					"click": [".cmp-root-container", ".cmp_ui .cmp_activateAll button:nth-child(2)"],
					"all": true,
					"optional": true
				},
				{
					"click": [".cmp-root-container", ".cmp_ui .cmp_level1Container .cmp_levelItem:nth-child(2) > div"],
					"optional": true
				},
				{
					"waitFor": [".cmp-root-container", ".cmp_ui .cmp_level1Container .cmp_levelItem.cmp_active:nth-child(2)"],
					"timeout": 2e3,
					"optional": true
				},
				{
					"click": [".cmp-root-container", ".cmp_ui .cmp_activateAll button:nth-child(2)"],
					"all": true,
					"optional": true
				},
				{ "click": [".cmp-root-container", ".cmp_ui .cmp_mainButtons .cmp_saveLink a"] }
			]
		}],
		[{
			"waitForVisible": [".cmp-root-container", "#cmp_consentDialog .cmp_ui"],
			"timeout": 2e3,
			"check": "none"
		}],
		{}
	],
	[
		1,
		"openli",
		2,
		"",
		22,
		[1305],
		[{ "e": 1305 }],
		[{
			"check": "any",
			"v": 1306
		}],
		[{ "c": 1307 }],
		[],
		{}
	],
	[
		2,
		"orw-cookie-banner",
		1,
		"",
		22,
		[1308],
		[{ "e": 1308 }],
		[{ "v": 1309 }],
		[
			{ "h": 1308 },
			{
				"removeClass": "cookie-not-accepted",
				"selector": "body",
				"optional": true
			},
			{
				"removeClass": "drawer-opt",
				"selector": "body",
				"optional": true
			},
			{
				"removeClass": "show-overlay",
				"selector": "body",
				"optional": true
			}
		],
		[],
		{}
	],
	[
		1,
		"osano",
		2,
		"",
		22,
		[1310],
		[{ "e": 1311 }],
		[{ "eval": "EVAL_OSANO_DETECT" }, { "v": 1312 }],
		[{
			"if": { "e": 1313 },
			"then": [{ "k": 1313 }],
			"else": [{
				"if": { "v": 1314 },
				"then": [{ "k": 1314 }],
				"else": [{ "h": 1310 }]
			}]
		}],
		[],
		{}
	],
	[
		1,
		"otto.de",
		2,
		"",
		22,
		[1315],
		[{ "e": 1315 }],
		[{ "v": 1316 }],
		[{ "k": 1317 }],
		[],
		{}
	],
	[
		1,
		"overleaf",
		2,
		"",
		22,
		[1318],
		[{ "e": 1319 }],
		[{ "v": 1319 }],
		[{ "c": 1320 }],
		[{ "cc": 1321 }],
		{}
	],
	[
		1,
		"pabcogypsum",
		2,
		"",
		22,
		[1322],
		[{ "e": 1323 }],
		[{ "v": 1323 }],
		[{ "c": 1324 }],
		[],
		{}
	],
	[
		1,
		"pandectes",
		2,
		"",
		22,
		[1325, 1326],
		[{ "any": [{ "e": 1325 }, { "exists": ["pandectes-cmp", "dialog.notice"] }] }],
		[{ "any": [{ "v": 1325 }, { "visible": ["pandectes-cmp", "dialog.notice"] }] }],
		[{
			"if": { "e": 1325 },
			"then": [{
				"if": { "v": 1327 },
				"then": [{ "c": 1327 }],
				"else": [
					{ "c": 1328 },
					{ "wv": 1329 },
					{ "k": 1329 },
					{ "wv": 1330 },
					{ "k": 1330 }
				]
			}, {
				"optional": true,
				"h": 1325
			}],
			"else": [{
				"if": { "visible": ["pandectes-cmp", "dialog.notice button.deny"] },
				"then": [{ "waitForThenClick": ["pandectes-cmp", "dialog.notice button.deny"] }],
				"else": [
					{ "waitForThenClick": ["pandectes-cmp", "dialog.notice button.preferences"] },
					{ "waitForVisible": ["pandectes-cmp", "dialog.preferences"] },
					{
						"if": { "exists": ["pandectes-cmp", "dialog.preferences button.deny"] },
						"then": [{ "click": ["pandectes-cmp", "dialog.preferences button.deny"] }],
						"else": [{
							"click": ["pandectes-cmp", "dialog.preferences button[role=switch][aria-checked=true]:not([disabled])"],
							"all": true,
							"optional": true
						}, { "click": ["pandectes-cmp", "dialog.preferences button.custom"] }]
					}
				]
			}]
		}],
		[{ "wait": 500 }, { "eval": "EVAL_PANDECTES_TEST" }],
		{}
	],
	[
		1,
		"passle",
		2,
		"",
		22,
		[1331],
		[{ "e": 1332 }],
		[{ "v": 1333 }],
		[{ "c": 1334 }],
		[{ "wait": 1e3 }, { "cc": 1335 }],
		{}
	],
	[
		1,
		"paypal-us",
		2,
		"",
		22,
		[1336],
		[{ "e": 1337 }],
		[{ "v": 1337 }],
		[{
			"if": { "e": 1338 },
			"then": [{
				"retry": 10,
				"retryInterval": 500,
				"c": 1338
			}],
			"else": [{ "h": 1337 }]
		}],
		[{ "wait": 1e3 }, { "cc": 1339 }],
		{}
	],
	[
		1,
		"paypal.com",
		2,
		"",
		22,
		[1340],
		[{ "e": 1340 }],
		[{ "v": 1341 }],
		[{
			"retry": 10,
			"retryInterval": 500,
			"c": 1338
		}],
		[{ "wait": 500 }, { "cc": 1339 }],
		{}
	],
	[
		1,
		"paytronix",
		2,
		"",
		22,
		[1342],
		[{ "e": 1343 }],
		[{ "v": 1342 }],
		[{ "c": 1344 }],
		[{ "cc": 1345 }],
		{}
	],
	[
		1,
		"pe-cookies",
		2,
		"",
		22,
		[1346],
		[{ "exists": ["pe-cookies", "#pecookies-continue-btn"] }],
		[{ "visible": ["pe-cookies", ".pecookies__modal"] }],
		[{ "waitForThenClick": ["pe-cookies", "#pecookies-continue-btn"] }],
		[{ "cc": 1347 }],
		{}
	],
	[
		1,
		"pigu",
		2,
		"",
		22,
		[],
		[{ "e": 1348 }],
		[{ "v": 1349 }],
		[{
			"retry": 10,
			"retryInterval": 500,
			"c": 1349
		}],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 1349
		}],
		{}
	],
	[
		1,
		"pikpak",
		2,
		"",
		22,
		[1350],
		[{ "e": 1351 }],
		[{ "v": 1352 }],
		[
			{ "c": 1353 },
			{ "wv": 1354 },
			{
				"all": true,
				"optional": true,
				"k": 1355
			},
			{ "c": 1356 }
		],
		[{ "any": [{ "cc": 1357 }, { "cc": 1358 }] }],
		{}
	],
	[
		1,
		"piwik-pro",
		2,
		"",
		22,
		[
			1359,
			1360,
			1361
		],
		[{ "e": 1362 }],
		[{
			"check": "any",
			"v": 1363
		}],
		[{
			"if": { "e": 1364 },
			"then": [{ "c": 1364 }, {
				"timeout": 1e3,
				"optional": true,
				"c": 1365
			}],
			"else": [{
				"if": { "v": 1366 },
				"then": [{ "k": 1366 }],
				"else": [
					{ "c": 1367 },
					{
						"timeout": 2e3,
						"wv": 1368
					},
					{
						"if": { "v": 1366 },
						"then": [{ "k": 1366 }],
						"else": [{
							"all": true,
							"optional": true,
							"k": 1369
						}, {
							"if": { "v": 1370 },
							"then": [{ "k": 1370 }],
							"else": [{ "k": 1367 }]
						}]
					}
				]
			}]
		}],
		[{ "cc": 1287 }, { "cc": 1371 }],
		{}
	],
	[
		1,
		"plentyshop",
		2,
		"",
		22,
		[1372],
		[{ "e": 1373 }],
		[{
			"check": "any",
			"v": 1374
		}],
		[{
			"if": { "e": 1375 },
			"then": [{ "c": 1375 }],
			"else": [{ "c": 1376 }]
		}],
		[{
			"check": "none",
			"v": 1374
		}, { "cc": 1377 }],
		{}
	],
	[
		1,
		"pmc",
		1,
		"",
		22,
		[1378],
		[{ "e": 1378 }],
		[{ "v": 1378 }],
		[{ "h": 1378 }],
		[],
		{}
	],
	[
		1,
		"pmc-privacy-banner",
		2,
		"",
		22,
		[1379],
		[{ "e": 1379 }],
		[{ "v": 1379 }],
		[{ "c": 1380 }],
		[{
			"check": "none",
			"v": 1379
		}],
		{}
	],
	[
		1,
		"police-uk",
		2,
		"",
		22,
		[1381],
		[{ "e": 1382 }],
		[{ "v": 1382 }],
		[
			{ "c": 1382 },
			{
				"timeout": 5e3,
				"optional": true,
				"wv": 1383
			},
			{
				"optional": true,
				"k": 1383
			}
		],
		[{ "cc": 1384 }],
		{}
	],
	[
		1,
		"polisen-se",
		0,
		"",
		10,
		[1385],
		[{ "e": 1386 }],
		[{ "v": 1385 }],
		[{ "c": 1387 }],
		[{
			"check": "none",
			"timeout": 3e3,
			"optional": true,
			"wv": 1385
		}, { "cc": 1388 }],
		{}
	],
	[
		1,
		"popupsmart-cookie-notice",
		1,
		"",
		22,
		[1389],
		[{ "e": 1390 }],
		[{ "v": 1391 }],
		[{ "h": 1389 }],
		[],
		{}
	],
	[
		1,
		"pornhat",
		1,
		"",
		22,
		[1392],
		[{ "v": 1393 }],
		[{ "v": 1393 }],
		[{ "h": 1392 }],
		[],
		{}
	],
	[
		1,
		"pride.com",
		1,
		"",
		22,
		[1394],
		[{ "e": 1395 }],
		[{ "v": 1395 }],
		[{ "h": 1394 }],
		[],
		{}
	],
	[
		1,
		"PrimeBox CookieBar",
		2,
		"",
		22,
		[456],
		[{ "e": 1396 }],
		[{
			"check": "any",
			"v": 1396
		}],
		[{
			"optional": true,
			"k": 1397
		}, { "h": 456 }],
		[{
			"negated": true,
			"cc": 1398
		}],
		{}
	],
	[
		1,
		"primeconsent",
		2,
		"",
		22,
		[1399],
		[{ "exists": [".azpp-cookie-consent", ".banner-main"] }],
		[{ "visible": [".azpp-cookie-consent", ".banner-main .button-group > button"] }],
		[{ "waitForThenClick": [".azpp-cookie-consent", ".banner-main .button-group > button:nth-of-type(2):nth-last-of-type(2)"] }],
		[{ "any": [{ "cc": 1400 }, { "cc": 1401 }] }],
		{}
	],
	[
		1,
		"privacy-area",
		0,
		"",
		22,
		[1402],
		[{ "e": 1403 }, { "e": 1404 }],
		[{ "v": 1402 }],
		[{
			"if": { "e": 1405 },
			"then": [{ "k": 1405 }],
			"else": [{
				"all": true,
				"optional": true,
				"k": 1406
			}, { "k": 1404 }]
		}, {
			"check": "none",
			"timeout": 3e3,
			"wv": 1402
		}],
		[{ "cc": 1407 }],
		{}
	],
	[
		1,
		"privacylab-elmo",
		2,
		"",
		22,
		[1408],
		[{ "e": 1409 }],
		[{ "v": 1410 }],
		[{ "c": 1411 }],
		[{ "wait": 500 }, { "cc": 1412 }],
		{}
	],
	[
		1,
		"privado",
		0,
		"",
		10,
		[218],
		[{ "e": 1413 }],
		[{ "v": 1413 }],
		[{
			"if": { "e": 1414 },
			"then": [{ "c": 1414 }],
			"else": [
				{ "c": 1415 },
				{ "wv": 1416 },
				{ "c": 1416 }
			]
		}],
		[],
		{}
	],
	[
		1,
		"pro-euclp-cookies-box",
		1,
		"",
		22,
		[1417],
		[{ "e": 1418 }],
		[{ "v": 1417 }],
		[{ "h": 1417 }],
		[{
			"check": "none",
			"v": 1417
		}],
		{}
	],
	[
		1,
		"pubfactory",
		0,
		"",
		22,
		[1419],
		[{ "e": 1419 }],
		[{ "v": 1419 }],
		[
			{
				"timeout": 2e4,
				"optional": true,
				"w": 1420
			},
			{ "c": 1421 },
			{
				"check": "none",
				"wv": 1419
			}
		],
		[{ "cc": 1422 }],
		{}
	],
	[
		1,
		"pubtech",
		2,
		"",
		22,
		[1423],
		[{ "e": 1423 }],
		[{ "v": 1424 }],
		[{
			"if": { "e": 1425 },
			"then": [{ "k": 1425 }],
			"else": [{ "k": 1426 }]
		}],
		[{ "eval": "EVAL_PUBTECH_0" }],
		{}
	],
	[
		1,
		"qtip-jgrowl-cookies",
		2,
		"",
		22,
		[],
		[{ "e": 1427 }],
		[{ "v": 1427 }],
		[{ "c": 1428 }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 1427
		}],
		{}
	],
	[
		1,
		"quantcast",
		2,
		"",
		22,
		[1429],
		[{ "e": 1430 }],
		[{ "v": 1431 }],
		[{
			"if": { "e": 1432 },
			"then": [
				{
					"timeout": 2e3,
					"optional": true,
					"w": 1433
				},
				{
					"all": true,
					"optional": true,
					"k": 1434
				},
				{
					"timeout": 2e3,
					"optional": true,
					"w": 1435
				},
				{
					"all": true,
					"optional": true,
					"k": 1436
				},
				{
					"timeout": 2e3,
					"c": 1437
				},
				{
					"timeout": 2e3,
					"optional": true,
					"c": 1438
				}
			],
			"else": [{
				"if": { "e": 1439 },
				"then": [{
					"timeout": 5e3,
					"c": 1440
				}],
				"else": [{
					"timeout": 2e3,
					"w": 1441
				}, {
					"if": { "e": 1442 },
					"then": [{ "k": 1442 }],
					"else": [
						{ "k": 1443 },
						{ "wv": 1444 },
						{
							"all": true,
							"optional": true,
							"k": 1445
						},
						{
							"click": [".qc-cmp2-main", "xpath///button[contains(., 'REJECT ALL') or contains(., 'ALLE VERWERPEN') or contains(., 'ΑΠΟΡΡΙΠΤΩ ΤΑ ΠΑΝΤΑ') or contains(., 'RESPINGERE TOTALĂ') or contains(., 'ALLE ABLEHNEN') or contains(., 'ODRZUCENIE') or contains(., 'BLOQUEAR TODO') or contains(., 'REJEITAR TODOS') or contains(., 'RIFIUTA TUTTO') or contains(., 'TOUT REFUSER') or contains(., 'ОТКЛОНИТЬ ВСЕХ')]"],
							"optional": true
						},
						{
							"check": "none",
							"timeout": 1e3,
							"optional": true,
							"wv": 1446
						},
						{
							"if": { "v": 1446 },
							"then": [{
								"if": { "e": 1447 },
								"then": [{ "k": 1447 }],
								"else": [{
									"waitForThenClick": [".qc-cmp2-main", "xpath///button[contains(.,'SAVE & EXIT') or contains(.,'SALVA ED ESCI') or contains(.,'GUARDAR Y SALIR') or contains(.,'SPEICHERN & VERLASSEN')"],
									"timeout": 5e3
								}]
							}]
						}
					]
				}]
			}]
		}],
		[],
		{}
	],
	[
		1,
		"quick-cookie-consent",
		2,
		"",
		22,
		[1448],
		[{ "e": 1449 }],
		[{ "v": 1449 }],
		[
			{ "c": 1449 },
			{ "wv": 1450 },
			{
				"if": { "e": 1451 },
				"then": [{ "k": 1452 }]
			},
			{
				"if": { "e": 1453 },
				"then": [{ "k": 1453 }],
				"else": [{ "k": 1454 }]
			}
		],
		[
			{ "cc": 1455 },
			{
				"negated": true,
				"cc": 1456
			},
			{
				"negated": true,
				"cc": 1457
			},
			{
				"negated": true,
				"cc": 1458
			}
		],
		{}
	],
	[
		1,
		"r42-consent-iframe",
		0,
		"",
		10,
		[],
		[{ "exists": ["#consent_iframe", ".stsp__cookie-container #declineButton"] }],
		[{ "v": 1459 }, { "visible": ["#consent_iframe", ".stsp__cookie-container #declineButton"] }],
		[{ "waitForThenClick": ["#consent_iframe", ".stsp__cookie-container #declineButton"] }],
		[{ "cc": 1460 }],
		{}
	],
	[
		1,
		"r42-cookiebar",
		0,
		"",
		10,
		[1461],
		[{ "e": 1462 }],
		[{ "v": 1463 }],
		[{ "c": 1462 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 1462
		}],
		{}
	],
	[
		1,
		"rabobank",
		2,
		"",
		22,
		[1464],
		[{ "e": 1464 }],
		[{ "v": 1464 }],
		[{
			"if": { "e": 1465 },
			"then": [{
				"retry": 10,
				"retryInterval": 500,
				"c": 1465
			}],
			"else": [{
				"retry": 10,
				"retryInterval": 500,
				"c": 1466
			}]
		}],
		[{ "cc": 1467 }],
		{}
	],
	[
		1,
		"radboud-cookie-overlay",
		2,
		"",
		22,
		[],
		[{ "e": 1468 }],
		[{ "v": 1469 }],
		[{ "c": 1470 }],
		[{ "cc": 1471 }],
		{}
	],
	[
		2,
		"rakshaos",
		0,
		"",
		22,
		[1472, 1473],
		[{ "e": 1472 }],
		[{ "v": 1472 }],
		[{
			"if": { "e": 1474 },
			"then": [{ "c": 1474 }],
			"else": [
				{ "c": 1475 },
				{ "c": 1476 },
				{
					"addStyle": "display: none !important",
					"selector": "#raksha-consent-banner"
				}
			]
		}],
		[],
		{}
	],
	[
		1,
		"rambler",
		2,
		"",
		22,
		[1477],
		[{ "e": 1477 }],
		[{ "v": 1477 }],
		[{ "c": 1478 }],
		[{ "cc": 1479 }],
		{}
	],
	[
		1,
		"rcs-cpmt",
		2,
		"",
		22,
		[1480],
		[{ "exists": ["#_cpmt-iframe", "#_cpmt"] }],
		[{ "v": 1480 }, { "visible": ["#_cpmt-iframe", "#_cpmt"] }],
		[{ "waitForThenClick": ["#_cpmt-iframe", "#_cpmt-reject"] }],
		[],
		{}
	],
	[
		1,
		"rdc-concents",
		2,
		"",
		22,
		[1481, 1482],
		[{ "e": 1483 }],
		[{ "v": 1483 }],
		[{ "c": 1483 }],
		[{
			"negated": true,
			"e": 1484
		}],
		{}
	],
	[
		1,
		"real-cookie-banner",
		0,
		"",
		10,
		[1485],
		[{ "e": 1486 }],
		[{ "v": 1486 }],
		[{ "waitForThenClick": ["div[consent-skip-blocker=\"1\"][id][data-bg] > dialog > div > div > div > div > div > a[role=button]:not([id])", "xpath///span[contains(., ' ohne ') or contains(., 'without') or contains(., 'Ablehnen')]"] }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 1486
		}],
		{}
	],
	[
		1,
		"remove-cookie-notice",
		2,
		"",
		22,
		[1487],
		[{ "e": 1488 }],
		[{ "v": 1489 }],
		[{ "c": 1488 }, {
			"check": "none",
			"timeout": 2e3,
			"wv": 1490
		}],
		[{
			"check": "none",
			"v": 1490
		}],
		{}
	],
	[
		1,
		"rijksoverheid-notification-bar",
		0,
		"",
		10,
		[1491],
		[{ "e": 1492 }],
		[{ "v": 1493 }],
		[{ "c": 1494 }],
		[{ "cc": 1495 }],
		{}
	],
	[
		1,
		"ring",
		2,
		"",
		22,
		[],
		[{ "e": 1496 }],
		[{ "v": 1496 }],
		[
			{ "c": 1497 },
			{ "wv": 1498 },
			{
				"all": true,
				"optional": true,
				"k": 1499
			},
			{ "c": 1500 }
		],
		[],
		{}
	],
	[
		1,
		"sas",
		2,
		"",
		22,
		[1501],
		[{ "e": 1502 }],
		[{ "v": 1503 }],
		[{ "c": 1502 }],
		[{ "cc": 441 }],
		{}
	],
	[
		1,
		"savills",
		2,
		"",
		22,
		[1504],
		[{ "e": 1504 }],
		[{ "v": 1505 }],
		[
			{ "c": 1506 },
			{ "wv": 1507 },
			{
				"if": { "e": 1508 },
				"then": [{ "k": 1509 }]
			},
			{
				"if": { "e": 1510 },
				"then": [{ "k": 1511 }]
			},
			{ "k": 1512 }
		],
		[{ "cc": 1513 }],
		{}
	],
	[
		1,
		"sc-cookie-banner",
		2,
		"",
		22,
		[1514],
		[{ "e": 1515 }],
		[{ "v": 1516 }],
		[{ "c": 1515 }],
		[{ "cc": 1517 }],
		{}
	],
	[
		1,
		"scottish-government-design-system",
		2,
		"",
		22,
		[1518],
		[{ "e": 1519 }],
		[{ "v": 1519 }],
		[{ "c": 1519 }],
		[{ "cc": 1520 }],
		{}
	],
	[
		1,
		"securiti-gpc-flyout",
		2,
		"",
		22,
		[1521],
		[{ "e": 1522 }],
		[{ "v": 1521 }, {
			"negated": true,
			"e": 1523
		}],
		[{
			"retry": 2,
			"c": 1524
		}],
		[{
			"check": "none",
			"v": 1525
		}],
		{}
	],
	[
		1,
		"sedlak-gdpr-cookie",
		2,
		"",
		22,
		[1526],
		[{ "e": 1527 }],
		[{ "v": 1527 }],
		[{ "c": 1527 }],
		[{ "cc": 1528 }],
		{}
	],
	[
		1,
		"setupad",
		2,
		"",
		22,
		[1529],
		[{ "e": 1530 }],
		[{ "v": 1530 }],
		[{
			"if": { "e": 1531 },
			"then": [{ "c": 1531 }],
			"else": [
				{ "c": 1532 },
				{ "wv": 1533 },
				{
					"all": true,
					"optional": true,
					"k": 1534
				},
				{ "c": 1531 }
			]
		}, {
			"check": "none",
			"wv": 1529
		}],
		[{ "cc": 1535 }],
		{}
	],
	[
		1,
		"shopify",
		0,
		"",
		22,
		[1536],
		[{ "e": 1536 }],
		[{ "v": 1536 }],
		[{ "c": 1537 }],
		[{ "eval": "EVAL_SHOPIFY_TEST" }],
		{}
	],
	[
		1,
		"shopware",
		2,
		"",
		22,
		[1538],
		[{ "e": 1539 }],
		[{ "v": 1538 }],
		[{
			"if": { "e": 1540 },
			"then": [{ "c": 1541 }],
			"else": [{ "c": 1542 }, { "c": 1543 }]
		}],
		[
			{
				"timeout": 2e3,
				"check": "none",
				"wv": 1538
			},
			{ "wait": 500 },
			{ "cc": 1544 }
		],
		{}
	],
	[
		1,
		"shouldianswer",
		1,
		"",
		10,
		[1545],
		[{ "e": 1545 }],
		[{ "v": 1546 }],
		[{ "h": 1545 }],
		[],
		{}
	],
	[
		1,
		"shueisha-gigaviewer",
		2,
		"",
		22,
		[1547],
		[{ "e": 1548 }],
		[{ "v": 1549 }],
		[{ "c": 1550 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 1547
		}],
		{}
	],
	[
		1,
		"sibbo",
		2,
		"",
		22,
		[1551],
		[{ "e": 1551 }],
		[{ "v": 1552 }],
		[{ "k": 1552 }],
		[],
		{}
	],
	[
		1,
		"silktide",
		2,
		"",
		22,
		[1553, 1554],
		[{ "e": 1553 }],
		[{ "v": 1553 }],
		[{
			"if": { "e": 1555 },
			"then": [{ "k": 1555 }],
			"else": [{ "k": 1556 }, { "c": 1557 }]
		}],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 1553
		}],
		{}
	],
	[
		1,
		"simpleview-cookie-banner",
		1,
		"",
		22,
		[1558, 1559],
		[{ "e": 1560 }],
		[{
			"check": "any",
			"v": 1561
		}],
		[{ "h": 1562 }],
		[],
		{}
	],
	[
		1,
		"Sirdata",
		0,
		"",
		22,
		[1563],
		[{ "e": 1563 }],
		[{ "v": 1563 }],
		[{
			"if": { "exists": ["#sd-cmp", "xpath///button[contains(., 'Do not accept') or contains(., 'Acceptera inte') or contains(., 'No aceptar') or contains(., 'Ikke acceptere') or contains(., 'Nicht akzeptieren') or contains(., 'Не приемам') or contains(., 'Να μην γίνει αποδοχή') or contains(., 'Niet accepteren') or contains(., 'Nepřijímat') or contains(., 'Nie akceptuj') or contains(., 'Nu acceptați') or contains(., 'Não aceitar') or contains(., 'Continuer sans accepter') or contains(., 'Non accettare') or contains(., 'Nem fogad el')]"] },
			"then": [{ "waitForThenClick": ["#sd-cmp", "xpath///button[contains(., 'Do not accept') or contains(., 'Acceptera inte') or contains(., 'No aceptar') or contains(., 'Ikke acceptere') or contains(., 'Nicht akzeptieren') or contains(., 'Не приемам') or contains(., 'Να μην γίνει αποδοχή') or contains(., 'Niet accepteren') or contains(., 'Nepřijímat') or contains(., 'Nie akceptuj') or contains(., 'Nu acceptați') or contains(., 'Não aceitar') or contains(., 'Continuer sans accepter') or contains(., 'Non accettare') or contains(., 'Nem fogad el')]"] }],
			"else": [{
				"if": { "exists": ["#sd-cmp", "xpath///span[contains(., 'Задайте вашите избори') or contains(., 'Nastavit vaše volby') or contains(., 'Angiv dine valg') or contains(., 'Ihre Auswahl treffen') or contains(., 'Ορίστε τις επιλογές σας') or contains(., 'Set your choices') or contains(., 'Establecer preferencias') or contains(., 'Paramétrer vos choix') or contains(., 'Válassza ki a beállításokat') or contains(., 'Imposta le tue scelte') or contains(., 'Stel uw keuzes in') or contains(., 'Ustaw swoje wybory') or contains(., 'Definir suas escolhas') or contains(., 'Setați-vă opțiunile') or contains(., 'Ställ in dina val')]"] },
				"then": [{ "waitForThenClick": ["#sd-cmp", "xpath///span[contains(., 'Задайте вашите избори') or contains(., 'Nastavit vaše volby') or contains(., 'Angiv dine valg') or contains(., 'Ihre Auswahl treffen') or contains(., 'Ορίστε τις επιλογές σας') or contains(., 'Set your choices') or contains(., 'Establecer preferencias') or contains(., 'Paramétrer vos choix') or contains(., 'Válassza ki a beállításokat') or contains(., 'Imposta le tue scelte') or contains(., 'Stel uw keuzes in') or contains(., 'Ustaw swoje wybory') or contains(., 'Definir suas escolhas') or contains(., 'Setați-vă opțiunile') or contains(., 'Ställ in dina val')]"] }, { "waitForThenClick": ["#sd-cmp", "xpath///span[contains(., 'Отхвърлям всичко') or contains(., 'Odmítnout vše') or contains(., 'Afvis alt') or contains(., 'Alle ablehnen') or contains(., 'Απόρριψη όλων') or contains(., 'Reject all') or contains(., 'Rechazar todo') or contains(., 'Tout refuser') or contains(., 'Mind elutasítása') or contains(., 'Rifiuta tutto') or contains(., 'Alles weigeren') or contains(., 'Odrzuć wszystkie') or contains(., 'Rejeitar todos') or contains(., 'Respingeți toate') or contains(., 'Avvisa allt')]"] }],
				"else": [{ "c": 1564 }]
			}]
		}],
		[],
		{}
	],
	[
		1,
		"sitevision",
		2,
		"",
		22,
		[1565],
		[{ "e": 1565 }],
		[{ "v": 1565 }],
		[{
			"if": { "e": 1566 },
			"then": [{ "k": 1566 }],
			"else": [
				{ "k": 1567 },
				{ "wv": 1568 },
				{
					"all": true,
					"optional": true,
					"k": 1569
				},
				{ "k": 1568 }
			]
		}],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 1565
		}],
		{}
	],
	[
		1,
		"sitevision-cookie-consent",
		2,
		"",
		22,
		[1570],
		[{ "e": 1570 }],
		[{ "v": 1570 }],
		[{
			"if": { "e": 1571 },
			"then": [{ "k": 1571 }],
			"else": [
				{ "k": 1572 },
				{ "wv": 1573 },
				{
					"all": true,
					"optional": true,
					"k": 1574
				},
				{ "k": 1573 }
			]
		}],
		[],
		{}
	],
	[
		1,
		"sitevision-iw-cookie",
		2,
		"",
		22,
		[1575],
		[{ "e": 1575 }],
		[{ "v": 1575 }],
		[{
			"if": { "e": 1576 },
			"then": [{ "k": 1577 }],
			"else": [
				{ "k": 1578 },
				{ "wv": 1579 },
				{
					"all": true,
					"optional": true,
					"k": 1580
				},
				{ "k": 1581 }
			]
		}],
		[],
		{}
	],
	[
		1,
		"smartweb",
		0,
		"",
		10,
		[1582],
		[{ "e": 1583 }],
		[{ "v": 1584 }],
		[{
			"all": true,
			"optional": true,
			"k": 1585
		}, { "c": 1583 }],
		[{ "cc": 1586 }],
		{}
	],
	[
		1,
		"snigel",
		2,
		"",
		22,
		[],
		[{ "e": 1587 }],
		[{ "v": 1587 }],
		[{ "k": 1588 }, { "k": 1589 }],
		[{ "cc": 1590 }],
		{}
	],
	[
		1,
		"socialfunders",
		2,
		"",
		22,
		[1591],
		[{ "e": 1592 }, { "e": 1593 }],
		[{ "v": 1591 }],
		[{ "c": 1592 }],
		[],
		{}
	],
	[
		1,
		"sogei-cookiebar",
		0,
		"",
		22,
		[1594],
		[{ "e": 1595 }],
		[{ "v": 1595 }],
		[{ "c": 1596 }],
		[{ "cc": 1597 }],
		{}
	],
	[
		1,
		"somerset-council",
		0,
		"",
		10,
		[],
		[{ "e": 1598 }],
		[{ "v": 1599 }],
		[{ "c": 1599 }],
		[{ "cc": 1600 }],
		{}
	],
	[
		1,
		"soteshop",
		2,
		"",
		22,
		[1601, 1602],
		[{ "e": 1603 }],
		[{
			"check": "any",
			"v": 1603
		}],
		[{
			"if": { "e": 1604 },
			"then": [{ "c": 1604 }],
			"else": [{ "k": 1605 }]
		}, {
			"check": "none",
			"wv": 1603
		}],
		[{
			"if": { "e": 1604 },
			"then": [{ "cc": 1606 }, { "cc": 1607 }],
			"else": [{ "cc": 1608 }]
		}],
		{}
	],
	[
		3,
		"sourcepoint-top",
		2,
		"",
		10,
		[1609],
		[{ "e": 1609 }],
		[{ "v": 1609 }],
		[
			{
				"stylesheet": "body > div[id^='sp_message_container_'] { visibility: hidden !important; z-index: -1 !important; pointer-events: none !important; }",
				"stylesheetId": "sourcepoint-top-hide"
			},
			{
				"stylesheet": "html.sp-message-open { height: auto !important; width: auto !important; } html.sp-message-open body { position: relative !important; overflow: auto !important; margin-top: 0 !important; top: auto !important; left: auto !important; right: auto !important; }",
				"stylesheetId": "sourcepoint-top-scroll-unlock"
			},
			{
				"removeClass": "sp-message-open",
				"selector": "html",
				"optional": true
			},
			{
				"eval": "EVAL_SOURCEPOINT_RESTORE_SCROLL",
				"optional": true
			}
		],
		[],
		{}
	],
	[
		1,
		"spaggiari-pvw",
		0,
		"",
		10,
		[1610],
		[{ "e": 1611 }],
		[{ "v": 1611 }],
		[{ "c": 1611 }],
		[],
		{}
	],
	[
		1,
		"squarespace-cookie-banner",
		2,
		"",
		22,
		[1612],
		[{ "e": 1613 }],
		[{ "v": 1614 }],
		[{
			"if": { "e": 1615 },
			"then": [{ "c": 1615 }],
			"else": [
				{ "c": 1616 },
				{ "wv": 1617 },
				{
					"all": true,
					"optional": true,
					"k": 1618
				},
				{ "c": 1619 }
			]
		}],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 1614
		}],
		{}
	],
	[
		1,
		"squarespace-cookie-notice",
		1,
		"",
		22,
		[1612],
		[{ "e": 1620 }, {
			"negated": true,
			"e": 1613
		}],
		[{ "v": 1614 }],
		[{ "h": 1612 }],
		[],
		{}
	],
	[
		1,
		"squiz",
		0,
		"",
		10,
		[218],
		[{ "e": 1621 }],
		[{ "v": 1621 }],
		[{ "c": 1622 }],
		[{ "wait": 500 }, { "cc": 1623 }],
		{}
	],
	[
		1,
		"steampowered.com",
		2,
		"",
		22,
		[],
		[{ "e": 1624 }, { "v": 1624 }],
		[{ "v": 1624 }],
		[{ "k": 1625 }],
		[{ "wait": 1e3 }, { "eval": "EVAL_STEAMPOWERED_0" }],
		{}
	],
	[
		1,
		"stellantis-psa",
		2,
		"",
		22,
		[1626, 1627],
		[{ "e": 1628 }],
		[{ "v": 1628 }],
		[{
			"if": { "e": 1629 },
			"then": [{ "c": 1629 }],
			"else": [{ "c": 1630 }]
		}, {
			"check": "none",
			"timeout": 3e3,
			"wv": 1626
		}],
		[{ "cc": 1631 }, { "cc": 1632 }],
		{}
	],
	[
		1,
		"stepstone-ccm",
		2,
		"",
		22,
		[1633],
		[{ "e": 1634 }],
		[{ "v": 1635 }],
		[{ "c": 1636 }, {
			"timeout": 2e3,
			"optional": true,
			"c": 1637
		}],
		[{ "cc": 1638 }],
		{}
	],
	[
		1,
		"stockholm-stad",
		2,
		"",
		22,
		[1639],
		[{ "e": 1640 }],
		[{ "v": 1639 }],
		[
			{ "c": 1641 },
			{
				"timeout": 2e3,
				"wv": 1642
			},
			{
				"all": true,
				"optional": true,
				"k": 1643
			},
			{ "k": 1644 }
		],
		[{ "cc": 1645 }],
		{}
	],
	[
		1,
		"stright",
		2,
		"",
		22,
		[1646, 1647],
		[{ "e": 1646 }],
		[{ "v": 1646 }],
		[{
			"if": { "v": 1648 },
			"then": [{ "c": 1648 }],
			"else": [
				{ "c": 1649 },
				{ "wv": 1647 },
				{
					"if": { "e": 1650 },
					"then": [{ "c": 1650 }],
					"else": [{
						"all": true,
						"optional": true,
						"k": 1651
					}, { "c": 1652 }]
				}
			]
		}, {
			"check": "none",
			"wv": 1646
		}],
		[{
			"check": "none",
			"v": 1646
		}],
		{}
	],
	[
		1,
		"stripchat.com",
		0,
		"",
		22,
		[1653],
		[{ "v": 1654 }],
		[{ "v": 1653 }],
		[
			{
				"timeout": 5e3,
				"optional": true,
				"w": 1655
			},
			{ "c": 1654 },
			{
				"timeout": 1500,
				"optional": true,
				"wv": 1656
			},
			{
				"if": {
					"check": "none",
					"v": 1656
				},
				"then": [{ "k": 1654 }]
			},
			{ "c": 1657 }
		],
		[{ "wait": 500 }, { "cc": 1658 }],
		{}
	],
	[
		1,
		"substack",
		0,
		"",
		12,
		[],
		[{ "e": 1659 }],
		[{ "v": 1659 }],
		[{ "waitForThenClick": [".pencraft", "xpath///button[contains(., 'Only Necessary') or contains(., 'Reject')]"] }],
		[{ "cc": 1660 }],
		{}
	],
	[
		1,
		"summitracing",
		1,
		"",
		10,
		[1661],
		[{ "e": 1662 }],
		[{ "v": 1662 }],
		[{ "h": 1661 }],
		[],
		{}
	],
	[
		1,
		"swisscom-ecare",
		2,
		"",
		22,
		[1663],
		[{ "e": 1664 }],
		[{ "v": 1665 }],
		[{
			"if": { "v": 1666 },
			"then": [{
				"retry": 3,
				"retryInterval": 500,
				"c": 1666
			}],
			"else": [
				{ "k": 1667 },
				{ "wv": 1668 },
				{
					"all": true,
					"optional": true,
					"k": 1669
				},
				{
					"retry": 3,
					"retryInterval": 500,
					"c": 1670
				}
			]
		}, {
			"check": "none",
			"wv": 1665
		}],
		[{ "cc": 1671 }],
		{}
	],
	[
		1,
		"synology",
		0,
		"",
		22,
		[1672],
		[{ "e": 1672 }],
		[{ "v": 1672 }],
		[
			{ "c": 1673 },
			{ "wv": 1674 },
			{
				"all": true,
				"optional": true,
				"k": 1675
			},
			{ "c": 1676 }
		],
		[{ "cc": 1677 }, { "cc": 1678 }],
		{}
	],
	[
		1,
		"tagconcierge",
		2,
		"",
		22,
		[1679],
		[{ "e": 1679 }],
		[{ "v": 1680 }],
		[{
			"if": { "v": 1681 },
			"then": [{ "k": 1681 }],
			"else": [
				{ "c": 1682 },
				{ "wv": 1683 },
				{
					"if": { "e": 1684 },
					"then": [{ "k": 1684 }],
					"else": [{
						"all": true,
						"optional": true,
						"k": 1685
					}, { "c": 1686 }]
				}
			]
		}],
		[{ "any": [{
			"check": "none",
			"v": 1679
		}, {
			"check": "none",
			"v": 1687
		}] }],
		{}
	],
	[
		1,
		"takealot.com",
		1,
		"",
		22,
		[1688],
		[{ "e": 1689 }],
		[{ "e": 1689 }],
		[{ "h": 1688 }, {
			"if": { "e": 1690 },
			"then": [{ "eval": "EVAL_TAKEALOT_0" }],
			"else": []
		}],
		[],
		{}
	],
	[
		1,
		"tarteaucitron deny",
		2,
		"",
		22,
		[1691],
		[{ "e": 1691 }],
		[{ "v": 1692 }],
		[{ "wait": 500 }, { "k": 1692 }],
		[{ "eval": "EVAL_TARTEAUCITRON_2" }],
		{}
	],
	[
		1,
		"tarteaucitron.js",
		2,
		"",
		22,
		[1691],
		[{ "e": 1691 }],
		[{ "v": 1693 }, {
			"negated": true,
			"e": 1692
		}],
		[{
			"if": { "e": 1694 },
			"then": [{
				"all": true,
				"optional": true,
				"k": 1695
			}, { "k": 1693 }],
			"else": [
				{ "k": 1696 },
				{ "c": 1697 },
				{ "k": 1698 }
			]
		}],
		[{ "eval": "EVAL_TARTEAUCITRON_2" }],
		{}
	],
	[
		1,
		"taunton",
		2,
		"",
		22,
		[1699],
		[{ "e": 1699 }],
		[{ "e": 1700 }],
		[{
			"optional": true,
			"all": true,
			"k": 1701
		}, { "k": 1702 }],
		[{ "cc": 1703 }],
		{}
	],
	[
		1,
		"tccCmpAlert",
		2,
		"",
		22,
		[1704],
		[{ "e": 1704 }],
		[{ "v": 1704 }],
		[{ "c": 1705 }],
		[],
		{}
	],
	[
		1,
		"Tealium",
		2,
		"",
		22,
		[1706],
		[{ "e": 1707 }, { "eval": "EVAL_TEALIUM_0" }],
		[{
			"check": "any",
			"v": 1707
		}],
		[
			{ "eval": "EVAL_TEALIUM_1" },
			{ "eval": "EVAL_TEALIUM_DONOTSELL" },
			{
				"if": { "e": 1708 },
				"then": [{ "c": 1708 }],
				"else": [{ "h": 1709 }, {
					"timeout": 1e3,
					"optional": true,
					"c": 1710
				}]
			}
		],
		[
			{ "eval": "EVAL_TEALIUM_3" },
			{ "eval": "EVAL_TEALIUM_DONOTSELL_CHECK" },
			{
				"check": "none",
				"v": 1711
			}
		],
		{}
	],
	[
		1,
		"tempest-cookie-notice",
		1,
		"",
		22,
		[1712],
		[{ "e": 1713 }],
		[{ "v": 1712 }],
		[{ "h": 1712 }],
		[],
		{}
	],
	[
		1,
		"Termly",
		2,
		"",
		22,
		[1714],
		[{ "e": 1714 }],
		[{ "v": 1715 }],
		[{
			"if": { "e": 1716 },
			"then": [{ "k": 1716 }],
			"else": [
				{ "c": 1717 },
				{
					"timeout": 700,
					"w": 1718
				},
				{
					"if": { "e": 1718 },
					"then": [{ "k": 1718 }],
					"else": [{
						"all": true,
						"c": 1719
					}, { "c": 1720 }]
				}
			]
		}],
		[],
		{}
	],
	[
		1,
		"termsfeed",
		2,
		"",
		22,
		[1721, 1722],
		[{ "e": 1723 }],
		[{ "v": 1723 }],
		[{
			"if": { "e": 1724 },
			"then": [{ "c": 1724 }],
			"else": [
				{ "c": 1725 },
				{ "w": 1726 },
				{
					"all": true,
					"optional": true,
					"k": 1727
				},
				{ "k": 1728 }
			]
		}],
		[],
		{}
	],
	[
		1,
		"termsfeed3",
		2,
		"",
		22,
		[1729],
		[{ "e": 1730 }],
		[{ "v": 1730 }],
		[{
			"if": { "e": 1731 },
			"then": [
				{ "k": 1731 },
				{ "wv": 1732 },
				{ "c": 1732 }
			],
			"else": [{ "h": 1729 }]
		}],
		[],
		{}
	],
	[
		1,
		"Test page CMP",
		2,
		"",
		22,
		[1733],
		[{ "e": 1734 }],
		[{ "v": 1734 }],
		[
			{ "w": 1733 },
			{ "eval": "EVAL_TESTCMP_STEP" },
			{ "k": 1733 }
		],
		[{ "eval": "EVAL_TESTCMP_0" }],
		{}
	],
	[
		1,
		"Test page cosmetic CMP",
		1,
		"",
		22,
		[1735],
		[{ "e": 1736 }],
		[{ "v": 1736 }],
		[{ "h": 1736 }],
		[{ "wait": 500 }, { "eval": "EVAL_TESTCMP_COSMETIC_0" }],
		{}
	],
	[
		1,
		"texas-instruments",
		2,
		"",
		22,
		[1737],
		[{ "e": 1738 }],
		[{ "v": 1739 }],
		[
			{ "k": 1740 },
			{ "wv": 1741 },
			{
				"if": { "e": 1742 },
				"then": [{
					"all": true,
					"k": 1742
				}]
			},
			{ "c": 1743 }
		],
		[{ "cc": 1744 }],
		{}
	],
	[
		1,
		"thalia.de",
		2,
		"",
		22,
		[1745],
		[{ "e": 1746 }],
		[{ "v": 1745 }],
		[{ "k": 1747 }],
		[],
		{}
	],
	[
		1,
		"thefreedictionary.com",
		2,
		"",
		22,
		[1748],
		[{ "e": 1748 }],
		[{ "v": 1748 }],
		[{ "eval": "EVAL_THEFREEDICTIONARY_0" }],
		[],
		{}
	],
	[
		1,
		"tna-cookie-banner",
		2,
		"",
		22,
		[1749],
		[{ "e": 1750 }],
		[{ "v": 1751 }],
		[{ "c": 1751 }, {
			"timeout": 1e3,
			"optional": true,
			"c": 1752
		}],
		[{ "cc": 1753 }, { "cc": 1754 }],
		{}
	],
	[
		1,
		"toyota",
		0,
		"",
		10,
		[1755],
		[{ "e": 1756 }],
		[{ "v": 1757 }],
		[
			{
				"timeout": 5e3,
				"w": 1758
			},
			{ "c": 1759 },
			{ "wv": 1760 },
			{
				"if": { "e": 1761 },
				"then": [{
					"timeout": 2e3,
					"optional": true,
					"w": 1762
				}]
			},
			{
				"all": true,
				"optional": true,
				"k": 1763
			},
			{ "c": 1760 }
		],
		[{ "cc": 1764 }],
		{}
	],
	[
		1,
		"tplink",
		0,
		"",
		22,
		[1765, 1766],
		[{ "e": 1767 }],
		[{ "any": [{ "v": 1768 }, { "v": 1769 }] }],
		[
			{
				"if": { "v": 1769 },
				"then": [{ "k": 1769 }]
			},
			{ "wv": 1770 },
			{
				"if": { "e": 1771 },
				"then": [{ "c": 1771 }],
				"else": [{
					"all": true,
					"optional": true,
					"k": 1772
				}, { "c": 1773 }]
			}
		],
		[{ "cc": 1774 }, {
			"negated": true,
			"cc": 1775
		}],
		{}
	],
	[
		1,
		"tracsis-delay-repay",
		0,
		"",
		22,
		[1776],
		[{ "e": 1777 }],
		[{ "v": 1777 }],
		[{
			"retry": 2,
			"c": 1778
		}],
		[{ "cc": 1779 }],
		{}
	],
	[
		1,
		"trader-joes-com",
		1,
		"",
		22,
		[1780],
		[{ "e": 1780 }],
		[{ "v": 1780 }],
		[{ "h": 1780 }],
		[],
		{}
	],
	[
		2,
		"transcend",
		1,
		"",
		22,
		[1781],
		[{ "e": 1781 }],
		[{ "v": 1781 }],
		[{
			"setStyle": "display: none !important; z-index: -1 !important; pointer-events: none !important;",
			"selector": "#transcend-consent-manager"
		}],
		[],
		{}
	],
	[
		1,
		"tri-table",
		2,
		"",
		22,
		[],
		[{ "e": 1782 }],
		[{ "v": 1782 }],
		[
			{
				"retry": 2,
				"retryInterval": 500,
				"c": 1783
			},
			{ "c": 1784 },
			{
				"check": "none",
				"wv": 1782
			}
		],
		[{ "cc": 1785 }],
		{}
	],
	[
		1,
		"tropicfeel-com",
		2,
		"",
		22,
		[1786],
		[{ "e": 1786 }],
		[{
			"check": "any",
			"v": 1787
		}],
		[
			{ "k": 1788 },
			{ "w": 1789 },
			{
				"all": true,
				"k": 1790
			},
			{ "k": 1791 }
		],
		[],
		{}
	],
	[
		1,
		"truendo",
		2,
		"",
		22,
		[1792],
		[{ "e": 1792 }],
		[{ "v": 1792 }],
		[
			{
				"if": { "e": 1793 },
				"then": [{ "k": 1794 }],
				"else": [{ "k": 1795 }]
			},
			{
				"timeout": 2e3,
				"optional": true,
				"wv": 1796
			},
			{
				"if": { "v": 1796 },
				"then": [{ "k": 1796 }]
			}
		],
		[{ "cc": 441 }],
		{}
	],
	[
		1,
		"truevault-polaris",
		0,
		"",
		22,
		[],
		[{ "exists": ["#polaris-css-lockdown-container", "#polaris-consent-widgets .polaris-consent-widget"] }],
		[{ "visible": ["#polaris-css-lockdown-container", "#polaris-consent-widgets .polaris-consent-widget"] }],
		[{
			"if": { "exists": ["#polaris-css-lockdown-container", ".polaris-consent-widget__actions button:nth-child(2):not(:last-child)"] },
			"then": [{ "click": ["#polaris-css-lockdown-container", ".polaris-consent-widget__actions button:nth-child(2):not(:last-child)"] }],
			"else": [
				{ "click": ["#polaris-css-lockdown-container", ".polaris-consent-widget__actions button:first-child"] },
				{
					"waitFor": ["#polaris-css-lockdown-container", ".polaris-preferences-widget__save_button"],
					"timeout": 2e3
				},
				{
					"click": ["#polaris-css-lockdown-container", ".polaris-preferences-widget input[type=checkbox]:checked:not([disabled])"],
					"all": true,
					"optional": true
				},
				{
					"click": ["#polaris-css-lockdown-container", ".polaris-preferences-widget input[type=checkbox]:checked:not([disabled])"],
					"all": true,
					"optional": true
				},
				{ "click": ["#polaris-css-lockdown-container", ".polaris-preferences-widget__save_button"] }
			]
		}],
		[{
			"waitForVisible": ["#polaris-css-lockdown-container", "#polaris-consent-widgets .polaris-consent-widget"],
			"check": "none",
			"timeout": 2e3
		}, { "cc": 1797 }],
		{}
	],
	[
		1,
		"trust360",
		2,
		"",
		22,
		[1798],
		[{ "e": 1798 }],
		[{ "v": 1798 }],
		[{ "c": 1799 }],
		[{ "cc": 1800 }],
		{}
	],
	[
		1,
		"TrustArc-newcm",
		2,
		"",
		22,
		[1801],
		[{ "exists": [".truste_popframe.trustarc_newcm_container", "a.required, a.call, button.required, button.call"] }],
		[{
			"visible": [".truste_popframe.trustarc_newcm_container", "a.required, a.call, button.required, button.call"],
			"check": "any"
		}],
		[{ "waitForThenClick": [".truste_popframe.trustarc_newcm_container", "a.required, button.required"] }],
		[{ "cc": 1802 }, {
			"negated": true,
			"cc": 1803
		}],
		{}
	],
	[
		1,
		"truyo",
		2,
		"",
		22,
		[1804],
		[{ "e": 1805 }],
		[{ "v": 1804 }],
		[{ "k": 1806 }],
		[],
		{}
	],
	[
		1,
		"trybe",
		0,
		"",
		22,
		[1807],
		[{ "e": 1807 }],
		[{ "v": 1808 }],
		[
			{ "c": 1809 },
			{ "w": 1810 },
			{
				"optional": true,
				"k": 1811
			},
			{
				"optional": true,
				"k": 1812
			},
			{ "c": 1813 }
		],
		[{ "wait": 500 }, { "cc": 1814 }],
		{}
	],
	[
		1,
		"tti-cookie-popup",
		2,
		"",
		22,
		[],
		[{ "e": 1815 }],
		[{ "v": 1815 }],
		[{
			"if": { "v": 1816 },
			"then": [{ "k": 1816 }],
			"else": [
				{ "k": 1815 },
				{
					"timeout": 1e4,
					"wv": 1817
				},
				{
					"if": { "v": 1818 },
					"then": [{ "k": 1818 }],
					"else": [{
						"all": true,
						"optional": true,
						"k": 1819
					}, { "c": 1820 }]
				}
			]
		}, {
			"timeout": 1e4,
			"check": "none",
			"wv": 1815
		}],
		[{ "cc": 1821 }],
		{}
	],
	[
		1,
		"tumblr-custom-domain-gdpr-banner",
		1,
		"",
		22,
		[1822],
		[{ "e": 1822 }],
		[{ "v": 1822 }],
		[{ "h": 1822 }],
		[{
			"check": "none",
			"v": 1822
		}],
		{}
	],
	[
		1,
		"tv2reg-cookie-notice",
		2,
		"",
		22,
		[1823],
		[{ "e": 1824 }, { "e": 1825 }],
		[{
			"check": "any",
			"v": 1825
		}],
		[{ "c": 1825 }, {
			"check": "none",
			"timeout": 2e3,
			"optional": true,
			"wv": 1825
		}],
		[{ "cc": 1826 }],
		{}
	],
	[
		1,
		"twcc",
		0,
		"",
		10,
		[1827],
		[{ "e": 1828 }],
		[{ "v": 1828 }],
		[{ "c": 1829 }],
		[{ "cc": 1830 }],
		{}
	],
	[
		1,
		"txxx-network",
		0,
		"",
		22,
		[],
		[{ "e": 1831 }],
		[{ "v": 1831 }],
		[{ "c": 1831 }],
		[{
			"check": "none",
			"v": 1831
		}],
		{}
	],
	[
		1,
		"u-cookie-consent",
		2,
		"",
		22,
		[1832],
		[{ "e": 1833 }],
		[{ "v": 1833 }],
		[{ "c": 1833 }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 1833
		}],
		{}
	],
	[
		1,
		"u12-data-protection-notice",
		2,
		"",
		22,
		[1834],
		[{ "e": 1834 }],
		[{ "v": 1835 }],
		[{ "c": 1836 }],
		[],
		{}
	],
	[
		1,
		"ubuntu.com",
		2,
		"",
		22,
		[1837],
		[{ "any": [{ "e": 1838 }, { "e": 1839 }] }],
		[{ "any": [{ "v": 1840 }, { "v": 1839 }] }],
		[
			{ "any": [{ "c": 1841 }, { "c": 1842 }] },
			{
				"optional": true,
				"all": true,
				"timeout": 500,
				"c": 1843
			},
			{ "any": [{ "c": 1844 }, { "c": 1845 }] }
		],
		[{ "cc": 1846 }],
		{}
	],
	[
		1,
		"uft-cookie-notice",
		2,
		"",
		22,
		[1847],
		[{ "e": 1848 }],
		[{ "v": 1847 }],
		[
			{ "k": 1848 },
			{ "c": 1849 },
			{
				"check": "none",
				"wv": 1847
			}
		],
		[{ "wait": 1e3 }, { "cc": 1850 }],
		{ "intermediate": false }
	],
	[
		1,
		"UK Cookie Consent",
		1,
		"",
		22,
		[1851],
		[{ "e": 1851 }],
		[{ "e": 1852 }],
		[{ "h": 1851 }],
		[{
			"negated": true,
			"cc": 1853
		}],
		{}
	],
	[
		1,
		"uk-parliament",
		2,
		"",
		22,
		[1854, 1855],
		[{ "e": 1856 }],
		[{ "v": 1857 }],
		[{ "c": 1856 }, {
			"optional": true,
			"h": 1855
		}],
		[{ "cc": 1858 }],
		{}
	],
	[
		1,
		"umcg",
		2,
		"",
		22,
		[1859],
		[{ "e": 1860 }],
		[{ "v": 1861 }],
		[{
			"all": true,
			"optional": true,
			"k": 1862
		}, { "c": 1863 }],
		[],
		{}
	],
	[
		1,
		"up-cookie-consent",
		2,
		"",
		22,
		[1864],
		[{ "e": 1864 }],
		[{ "v": 1864 }],
		[{
			"if": { "e": 1865 },
			"then": [{ "c": 1865 }],
			"else": [{ "c": 1866 }, { "c": 1867 }]
		}, {
			"check": "none",
			"timeout": 1e4,
			"wv": 1868
		}],
		[{ "cc": 1869 }, { "cc": 1870 }],
		{}
	],
	[
		1,
		"usercentrics-api",
		2,
		"",
		22,
		[],
		[{ "e": 1871 }],
		[{ "eval": "EVAL_USERCENTRICS_API_0" }, {
			"if": { "e": 1872 },
			"then": [{
				"timeout": 2e3,
				"wv": 1872
			}],
			"else": [{ "exists": ["#usercentrics-root", "[data-testid=uc-container]"] }, {
				"timeout": 2e3,
				"wv": 1873
			}]
		}],
		[{
			"if": { "exists": ["#usercentrics-root", "[data-testid=uc-deny-all-button]"] },
			"then": [{ "click": ["#usercentrics-root", "[data-testid=uc-deny-all-button]"] }],
			"else": [{
				"if": { "exists": ["#usercentrics-cmp-ui", "[data-action-type=deny]"] },
				"then": [{ "click": ["#usercentrics-cmp-ui", "[data-action-type=deny]"] }],
				"else": [{ "eval": "EVAL_USERCENTRICS_API_1" }, { "eval": "EVAL_USERCENTRICS_API_2" }]
			}]
		}, {
			"removeClass": "overflowHidden",
			"selector": "body",
			"optional": true
		}],
		[{ "eval": "EVAL_USERCENTRICS_API_6" }],
		{}
	],
	[
		1,
		"usercentrics-button",
		2,
		"",
		22,
		[],
		[{ "e": 1874 }],
		[{ "v": 1875 }],
		[{ "k": 1876 }],
		[{ "eval": "EVAL_USERCENTRICS_BUTTON_0" }],
		{}
	],
	[
		1,
		"uw-madison-cookieconsent",
		1,
		"",
		22,
		[1877],
		[{ "e": 1878 }],
		[{ "v": 1877 }],
		[{ "h": 1879 }],
		[],
		{}
	],
	[
		1,
		"vdg-cookies",
		2,
		"",
		22,
		[1880],
		[{ "e": 1880 }],
		[{ "v": 1880 }],
		[
			{ "c": 1881 },
			{ "c": 1882 },
			{
				"check": "none",
				"wv": 1880
			}
		],
		[{ "cc": 1883 }],
		{}
	],
	[
		1,
		"vergelijkgroep",
		0,
		"",
		10,
		[1884],
		[{ "e": 1885 }],
		[{ "v": 1886 }],
		[{ "c": 1887 }],
		[{ "cc": 1888 }],
		{}
	],
	[
		1,
		"vivenu",
		2,
		"",
		22,
		[],
		[{ "e": 1889 }],
		[{ "v": 1889 }],
		[{ "c": 1890 }],
		[{
			"check": "none",
			"v": 1889
		}],
		{}
	],
	[
		1,
		"vue-cookie-accept-decline",
		0,
		"",
		10,
		[1891, 1892],
		[{ "e": 1893 }],
		[{ "v": 1894 }],
		[{
			"if": { "e": 1895 },
			"then": [{ "c": 1895 }],
			"else": [{ "h": 1894 }]
		}],
		[],
		{}
	],
	[
		1,
		"waitrose.com",
		2,
		"",
		22,
		[
			1896,
			1897,
			1898
		],
		[{ "e": 1897 }],
		[{ "v": 1897 }],
		[
			{ "k": 1899 },
			{ "wait": 200 },
			{ "eval": "EVAL_WAITROSE_0" },
			{ "k": 1900 }
		],
		[{ "cc": 1901 }, { "cc": 1902 }],
		{}
	],
	[
		1,
		"warning-cookie-notice",
		1,
		"",
		22,
		[1903],
		[{ "e": 1904 }],
		[{ "v": 1903 }],
		[{ "h": 1903 }],
		[],
		{}
	],
	[
		2,
		"wbd-legal-terms",
		1,
		"",
		22,
		[],
		[{ "e": 1905 }],
		[{
			"check": "any",
			"v": 1906
		}],
		[{
			"if": { "e": 1907 },
			"then": [{ "eval": "EVAL_WBD_LTP_CLOSE" }, {
				"removeClass": "is-NoScroll",
				"selector": "body",
				"optional": true
			}],
			"else": [{ "h": 1908 }, {
				"addStyle": "overflow: auto !important",
				"selector": "body",
				"optional": true
			}]
		}],
		[],
		{}
	],
	[
		1,
		"webflow",
		2,
		"",
		22,
		[1909],
		[{ "any": [{ "v": 1909 }, { "e": 1910 }] }],
		[{ "v": 1909 }, { "v": 1911 }],
		[{
			"if": { "e": 1912 },
			"then": [{ "wait": 500 }, { "c": 1912 }],
			"else": [{ "h": 1913 }]
		}],
		[{ "cc": 1914 }],
		{}
	],
	[
		1,
		"webtoffee-cookie-consent",
		2,
		"",
		22,
		[1915],
		[{ "e": 1916 }],
		[{ "v": 1916 }],
		[{
			"if": { "e": 1917 },
			"then": [{ "c": 1917 }],
			"else": [{
				"if": { "e": 1918 },
				"then": [
					{ "c": 1918 },
					{ "wv": 1919 },
					{
						"optional": true,
						"k": 1920
					},
					{ "c": 1921 }
				],
				"else": [
					{ "c": 1922 },
					{ "wv": 1923 },
					{
						"all": true,
						"optional": true,
						"k": 1924
					},
					{ "c": 1923 }
				]
			}]
		}],
		[{ "cc": 1925 }],
		{}
	],
	[
		1,
		"whitepages-gpc-banner",
		2,
		"",
		22,
		[1926],
		[{ "e": 1927 }],
		[{ "v": 1926 }],
		[{ "c": 1927 }],
		[{
			"check": "none",
			"v": 1926
		}],
		{}
	],
	[
		1,
		"wiki.gg",
		1,
		"",
		22,
		[1928],
		[{ "e": 1928 }],
		[{ "v": 1928 }],
		[{ "h": 1928 }],
		[],
		{}
	],
	[
		1,
		"wimc-gtm-consent",
		2,
		"",
		22,
		[1929],
		[{ "e": 1929 }],
		[{ "v": 1930 }],
		[{
			"if": { "e": 1931 },
			"then": [{ "c": 1931 }],
			"else": [
				{ "c": 1932 },
				{
					"timeout": 2e3,
					"wv": 1933
				},
				{
					"all": true,
					"optional": true,
					"k": 1934
				},
				{ "c": 1935 }
			]
		}, {
			"check": "none",
			"timeout": 2e3,
			"wv": 1930
		}],
		[{ "cc": 1936 }, { "cc": 1937 }],
		{}
	],
	[
		1,
		"wirtualna-polska",
		2,
		"",
		22,
		[1938],
		[{ "exists": ["div[role=dialog][aria-modal=true][aria-label*='WP']", "xpath/.//button[normalize-space(.)='Ustawienia zaawansowane' or normalize-space(.)='Advanced settings' or normalize-space(.)='Erweiterte einstellungen' or normalize-space(.)='Pokročilá nastavení' or normalize-space(.)='Rozšírené nastavenia' or normalize-space(.)='Išplėstiniai nustatymai']"] }],
		[{ "v": 1938 }],
		[
			{ "waitForThenClick": ["div[role=dialog][aria-modal=true][aria-label*='WP']", "xpath/.//button[normalize-space(.)='Ustawienia zaawansowane' or normalize-space(.)='Advanced settings' or normalize-space(.)='Erweiterte einstellungen' or normalize-space(.)='Pokročilá nastavení' or normalize-space(.)='Rozšírené nastavenia' or normalize-space(.)='Išplėstiniai nustatymai']"] },
			{ "waitForThenClick": ["div[role=dialog][aria-modal=true][aria-label*='WP']", "xpath/.//button[normalize-space(.)='Zapisz' or normalize-space(.)='Save' or normalize-space(.)='Speichern' or normalize-space(.)='Uložit' or normalize-space(.)='Uložiť' or normalize-space(.)='Išsaugoti']"] },
			{
				"check": "none",
				"timeout": 5e3,
				"optional": true,
				"wv": 1938
			}
		],
		[],
		{}
	],
	[
		1,
		"wix",
		0,
		"",
		22,
		[],
		[{ "e": 1939 }],
		[{ "v": 1939 }],
		[{
			"if": { "e": 1940 },
			"then": [
				{ "wait": 1e3 },
				{
					"if": { "e": 1941 },
					"then": [{ "k": 1941 }],
					"else": [
						{ "k": 1942 },
						{ "wv": 1943 },
						{
							"all": true,
							"optional": true,
							"k": 1944
						},
						{ "k": 1943 }
					]
				},
				{ "any": [{
					"check": "none",
					"timeout": 2e3,
					"wv": 1940
				}, { "h": 1940 }] }
			],
			"else": [{
				"if": { "e": 1945 },
				"then": [{ "k": 1945 }],
				"else": [{ "h": 1946 }]
			}]
		}],
		[],
		{}
	],
	[
		1,
		"woo-commerce-com",
		2,
		"",
		22,
		[1947],
		[{ "e": 1947 }],
		[{ "v": 1947 }],
		[{
			"if": { "e": 1948 },
			"then": [{ "c": 1949 }],
			"else": [
				{ "c": 1950 },
				{ "wv": 1951 },
				{
					"all": true,
					"optional": true,
					"k": 1952
				},
				{ "c": 1953 }
			]
		}],
		[{ "cc": 1954 }],
		{}
	],
	[
		1,
		"workday",
		2,
		"",
		22,
		[1955],
		[{ "e": 1956 }],
		[{ "v": 1955 }],
		[{ "c": 1956 }],
		[{ "cc": 1957 }],
		{}
	],
	[
		1,
		"worldbank",
		2,
		"",
		22,
		[1958],
		[{ "e": 1958 }],
		[{ "v": 1958 }],
		[{ "c": 1959 }],
		[{ "cc": 1960 }],
		{}
	],
	[
		1,
		"WP Cookie Notice for GDPR",
		2,
		"",
		22,
		[1961],
		[{ "v": 1961 }],
		[{ "v": 1961 }],
		[{ "c": 1962 }],
		[{ "cc": 1963 }],
		{}
	],
	[
		1,
		"WP DSGVO Tools",
		2,
		"",
		22,
		[1964],
		[{ "e": 1965 }],
		[{
			"check": "any",
			"v": 1965
		}],
		[{
			"if": { "e": 1966 },
			"then": [{ "c": 1966 }],
			"else": [{ "c": 1967 }]
		}],
		[{ "cc": 1968 }],
		{}
	],
	[
		1,
		"wpcc",
		1,
		"",
		22,
		[1969],
		[{ "e": 1969 }],
		[{ "e": 1970 }],
		[{ "h": 1969 }],
		[],
		{}
	],
	[
		1,
		"WPConsent",
		2,
		"",
		22,
		[1971],
		[{ "e": 1972 }],
		[{ "visible": ["#wpconsent-container", "#wpconsent-banner-holder.wpconsent-banner-visible"] }],
		[{ "waitForThenClick": ["#wpconsent-container", "#wpconsent-cancel-all"] }],
		[{ "cc": 1973 }],
		{}
	],
	[
		1,
		"xenforo-cookie-consent",
		2,
		"",
		22,
		[1974],
		[{ "e": 1975 }],
		[{ "v": 1976 }],
		[{
			"if": { "e": 1977 },
			"then": [{ "k": 1977 }],
			"else": [
				{
					"timeout": 2e3,
					"retry": 10,
					"retryInterval": 500,
					"c": 1978
				},
				{
					"timeout": 2e3,
					"wv": 1979
				},
				{
					"all": true,
					"optional": true,
					"k": 1980
				},
				{ "k": 1979 }
			]
		}],
		[{
			"timeout": 2e3,
			"check": "none",
			"wv": 1974
		}, { "cc": 1981 }],
		{}
	],
	[
		1,
		"xgroovy",
		1,
		"",
		22,
		[1982],
		[{ "e": 1983 }],
		[{ "v": 1983 }],
		[{ "h": 1982 }],
		[],
		{}
	],
	[
		1,
		"xing.com",
		2,
		"",
		22,
		[],
		[{ "e": 1984 }],
		[{ "e": 1984 }],
		[{ "k": 1985 }, { "k": 1986 }],
		[{ "cc": 1987 }],
		{}
	],
	[
		1,
		"xnxx-com",
		1,
		"",
		22,
		[1988],
		[{ "any": [{ "e": 1988 }, { "e": 1989 }] }],
		[{ "any": [{ "v": 1988 }, { "v": 1990 }] }],
		[{
			"if": { "v": 1990 },
			"then": [{ "c": 1991 }],
			"else": [{ "h": 1988 }]
		}],
		[],
		{}
	],
	[
		1,
		"yle-consent-sdk",
		2,
		"",
		22,
		[1992],
		[{ "e": 1993 }],
		[{ "v": 1992 }],
		[{ "c": 1993 }, {
			"timeout": 2e3,
			"check": "none",
			"wv": 1992
		}],
		[],
		{}
	],
	[
		1,
		"youtube-desktop",
		2,
		"",
		22,
		[1994, 1995],
		[{ "e": 1996 }, { "e": 1997 }],
		[{ "v": 1996 }],
		[{ "c": 1998 }, { "wait": 500 }],
		[{ "wait": 500 }, { "cc": 915 }],
		{}
	],
	[
		1,
		"youtube-mobile",
		2,
		"",
		22,
		[1999],
		[{ "e": 2e3 }],
		[{ "v": 2e3 }],
		[
			{ "wait": 500 },
			{ "c": 2001 },
			{ "wait": 500 }
		],
		[{ "wait": 500 }, { "cc": 915 }],
		{}
	],
	[
		1,
		"zdf",
		2,
		"",
		22,
		[2002],
		[{ "e": 2002 }],
		[{ "v": 2003 }],
		[{ "c": 2004 }],
		[],
		{}
	],
	[
		1,
		"zorginstituut-cookiewarning",
		0,
		"",
		22,
		[2005],
		[{ "e": 2006 }],
		[{ "v": 2006 }],
		[{ "c": 2006 }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 2007
		}],
		{}
	],
	[
		1,
		"zurich-cookies-notification-banner",
		0,
		"",
		10,
		[2008],
		[{ "e": 2009 }],
		[{ "v": 2010 }],
		[{ "c": 2009 }],
		[{ "cc": 2011 }],
		{}
	],
	[
		1,
		"cookiealert",
		2,
		"",
		11,
		[],
		[{ "e": 2012 }],
		[{ "v": 2013 }],
		[
			{ "k": 2014 },
			{
				"all": true,
				"optional": true,
				"k": 2015
			},
			{ "k": 2016 },
			{ "eval": "EVAL_COOKIEALERT_0" }
		],
		[{ "eval": "EVAL_COOKIEALERT_2" }],
		{ "intermediate": false }
	],
	[
		1,
		"piano.io",
		2,
		"",
		1,
		[],
		[{ "e": 2017 }],
		[{ "v": 2017 }],
		[{ "c": 2018 }],
		[],
		{}
	],
	[
		1,
		"auto_AU_help.dropbox.com_4ad_+1",
		0,
		"^https?://(www\\.)?dropbox\\.com/|^https?://(www\\.)?dropbox\\.com/",
		1,
		[],
		[{ "e": 2019 }],
		[{ "v": 2019 }],
		[{ "wait": 500 }, { "c": 2019 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2019
		}],
		{}
	],
	[
		1,
		"auto_CA_coasthotels.com_f8m",
		0,
		"^https?://(www\\.)?coasthotels\\.com/",
		1,
		[],
		[{ "e": 2020 }],
		[{ "v": 2020 }],
		[{ "c": 2020 }],
		[],
		{}
	],
	[
		1,
		"auto_CA_epihunter.eu_hd4",
		0,
		"^https?://(www\\.)?combell\\.com/",
		1,
		[],
		[{ "e": 2021 }],
		[{ "v": 2021 }],
		[{ "wait": 500 }, { "c": 2021 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2021
		}],
		{}
	],
	[
		1,
		"auto_CA_nationalarchives.gov.uk_rx0",
		0,
		"^https?://(www\\.)?webarchive\\.nationalarchives\\.gov\\.uk/",
		1,
		[],
		[{ "e": 2022 }],
		[{ "v": 2022 }],
		[{ "wait": 500 }, { "c": 2022 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2022
		}],
		{}
	],
	[
		1,
		"auto_CA_natureconservancy.ca_3pp",
		0,
		"^https?://(www\\.)?natureconservancy\\.ca/",
		1,
		[],
		[{ "e": 2023 }],
		[{ "v": 2023 }],
		[{ "wait": 500 }, { "c": 2023 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2023
		}],
		{}
	],
	[
		1,
		"auto_CA_ontariospca.ca_k32",
		0,
		"^https?://(www\\.)?widget-next\\.clym-sdk\\.net/",
		1,
		[],
		[{ "e": 2024 }],
		[{ "v": 2024 }],
		[{ "wait": 500 }, { "c": 2024 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2024
		}],
		{}
	],
	[
		1,
		"auto_CA_phoenixnap.com_hrb",
		0,
		"^https?://(www\\.)?widget-next\\.clym-sdk\\.net/",
		1,
		[],
		[{ "e": 2025 }],
		[{ "v": 2025 }],
		[{ "wait": 500 }, { "c": 2025 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2025
		}],
		{}
	],
	[
		1,
		"auto_CH_phoenixnap.com_lx5",
		0,
		"^https?://(www\\.)?widget-next\\.clym-sdk\\.net/",
		1,
		[],
		[{ "e": 2026 }],
		[{ "v": 2026 }],
		[{ "wait": 500 }, { "c": 2026 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2026
		}],
		{}
	],
	[
		1,
		"auto_CH_swisscare.com_arx",
		0,
		"^https?://(www\\.)?swisscare\\.com/",
		1,
		[],
		[{ "e": 2027 }],
		[{ "v": 2027 }],
		[{ "wait": 500 }, { "c": 2027 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2027
		}],
		{}
	],
	[
		1,
		"auto_DE_alfaromeo.de_gvg_+2",
		0,
		"^https?://(www\\.)?cookielaw\\.emea\\.fcagroup\\.com/|^https?://(www\\.)?cookielaw\\.emea\\.fcagroup\\.com/|^https?://(www\\.)?cookielaw\\.emea\\.fcagroup\\.com/",
		1,
		[],
		[{ "e": 2028 }],
		[{ "v": 2028 }],
		[{ "wait": 500 }, { "c": 2028 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2028
		}],
		{}
	],
	[
		1,
		"auto_DE_huss-licht-ton.de_jj0",
		0,
		"^https?://(www\\.)?huss-licht-ton\\.de/",
		1,
		[],
		[{ "e": 2029 }],
		[{ "v": 2029 }],
		[{ "wait": 500 }, { "c": 2029 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2029
		}],
		{}
	],
	[
		1,
		"auto_DE_modellbau-berlinski.de_8vm",
		0,
		"^https?://(www\\.)?modellbau-berlinski\\.de/",
		1,
		[],
		[{ "e": 2030 }],
		[{ "v": 2030 }],
		[{ "wait": 500 }, { "c": 2030 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2030
		}],
		{}
	],
	[
		1,
		"auto_DE_phoenixnap.com_xq7",
		0,
		"^https?://(www\\.)?widget-next\\.clym-sdk\\.net/",
		1,
		[],
		[{ "e": 2031 }],
		[{ "v": 2031 }],
		[{ "wait": 500 }, { "c": 2031 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2031
		}],
		{}
	],
	[
		1,
		"auto_FR_fiat.fr_3fh",
		0,
		"^https?://(www\\.)?cookielaw\\.emea\\.fcagroup\\.com/",
		1,
		[],
		[{ "e": 2032 }],
		[{ "v": 2032 }],
		[{ "wait": 500 }, { "c": 2032 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2032
		}],
		{}
	],
	[
		1,
		"auto_FR_stellantis.com_67q",
		0,
		"^https?://(www\\.)?cookielaw\\.emea\\.fcagroup\\.com/",
		1,
		[],
		[{ "e": 2032 }],
		[{ "v": 2032 }],
		[{ "wait": 500 }, { "c": 2032 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2032
		}],
		{}
	],
	[
		1,
		"auto_GB_dropbox.com_0_+1",
		0,
		"^https?://(www\\.)?dropbox\\.com/|^https?://(www\\.)?dropbox\\.com/",
		1,
		[],
		[{ "e": 2033 }],
		[{ "v": 2033 }],
		[{ "c": 2033 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_investing.thisismoney.co.uk_0",
		0,
		"^https?://(www\\.)?thisismoney\\.co\\.uk/",
		1,
		[],
		[{ "e": 2034 }],
		[{ "v": 2034 }],
		[{ "c": 2034 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_village-hotels.co.uk_hsa",
		0,
		"^https?://(www\\.)?village-hotels\\.co\\.uk/",
		1,
		[],
		[{ "e": 2035 }],
		[{ "v": 2035 }],
		[{ "wait": 500 }, { "c": 2035 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2035
		}],
		{}
	],
	[
		1,
		"auto_NL_fiat.nl_trv_+1",
		0,
		"^https?://(www\\.)?cookielaw\\.emea\\.fcagroup\\.com/|^https?://(www\\.)?cookielaw\\.emea\\.fcagroup\\.com/",
		1,
		[],
		[{ "e": 2032 }],
		[{ "v": 2032 }],
		[{ "wait": 500 }, { "c": 2032 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2032
		}],
		{}
	],
	[
		1,
		"auto_NL_flitsmeister.nl_ws8",
		0,
		"^https?://(www\\.)?cookies\\.flitsmeister\\.com/",
		1,
		[],
		[{ "e": 2036 }],
		[{ "v": 2036 }],
		[{ "wait": 500 }, { "c": 2036 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2036
		}],
		{}
	],
	[
		1,
		"auto_NL_interpolis.nl_jk9",
		0,
		"^https?://(www\\.)?interpolis\\.nl/",
		1,
		[],
		[{ "e": 2037 }],
		[{ "v": 2037 }],
		[{ "wait": 500 }, { "c": 2037 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2037
		}],
		{}
	],
	[
		1,
		"auto_US_dropbox.com_0_+1",
		0,
		"^https?://(www\\.)?dropbox\\.com/|^https?://(www\\.)?dropbox\\.com/",
		1,
		[],
		[{ "e": 2038 }],
		[{ "v": 2038 }],
		[{
			"text": "Decline",
			"c": 2038
		}],
		[],
		{}
	],
	[
		1,
		"coinbase",
		2,
		"^https://(www|help)\\.coinbase\\.com",
		11,
		[],
		[{ "e": 2039 }],
		[{ "v": 2039 }],
		[
			{ "k": 2040 },
			{
				"all": true,
				"optional": true,
				"k": 2041
			},
			{ "k": 2042 }
		],
		[{ "eval": "EVAL_COINBASE_0" }],
		{ "intermediate": false }
	],
	[
		1,
		"ecoprivacy",
		2,
		"^https://ecoprivacy\\.ecocerved\\.it/",
		1,
		[],
		[{ "e": 2043 }],
		[{ "v": 2043 }],
		[
			{ "wv": 2044 },
			{ "wait": 500 },
			{ "k": 2043 }
		],
		[],
		{}
	],
	[
		1,
		"figma",
		2,
		"^https://([a-z0-9-]+\\.)*figma\\.com/",
		11,
		[2045, 2046],
		[{ "e": 2047 }],
		[{ "v": 2048 }],
		[{ "c": 2049 }],
		[{ "cc": 2050 }, { "cc": 2051 }],
		{}
	],
	[
		1,
		"gmx-permission",
		2,
		"^https://plus\\.gmx\\.com/lt(?:[?#]|$)",
		1,
		[2052],
		[{ "e": 2052 }],
		[{ "v": 2053 }],
		[{
			"if": { "e": 2054 },
			"then": [{ "c": 2054 }],
			"else": [{
				"if": { "e": 2055 },
				"then": [
					{ "c": 2055 },
					{ "wv": 2056 },
					{ "c": 2056 }
				],
				"else": [{ "c": 2056 }]
			}]
		}],
		[{ "cc": 2057 }],
		{}
	],
	[
		1,
		"nojazz",
		2,
		"^https://nojazz\\.eu/",
		1,
		[],
		[{ "e": 2058 }],
		[{ "v": 2058 }],
		[{
			"if": { "v": 2059 },
			"then": [{ "k": 2059 }],
			"else": [
				{ "k": 2058 },
				{ "w": 2060 },
				{
					"all": true,
					"optional": true,
					"k": 2061
				},
				{ "c": 2062 }
			]
		}],
		[],
		{}
	],
	[
		1,
		"pdf24",
		2,
		"^https://consent\\.pdf24\\.org/",
		1,
		[],
		[{ "e": 2063 }],
		[{ "v": 2064 }],
		[{
			"if": { "v": 2065 },
			"then": [{ "k": 2065 }],
			"else": [
				{ "k": 2063 },
				{ "wv": 2066 },
				{ "c": 2067 }
			]
		}],
		[],
		{}
	],
	[
		1,
		"privacymanager.io",
		2,
		"^https://cmp-consent-tool\\.privacymanager\\.io/",
		1,
		[2068, 2069],
		[{ "e": 2070 }],
		[{ "v": 2070 }],
		[{
			"if": { "e": 2071 },
			"then": [{ "k": 2071 }, { "c": 2072 }],
			"else": [
				{ "c": 2073 },
				{ "w": 2074 },
				{ "w": 2075 },
				{
					"all": true,
					"optional": true,
					"k": 2076
				},
				{ "k": 2075 }
			]
		}],
		[],
		{}
	],
	[
		1,
		"tumblr-com",
		2,
		"^https://(www\\.)?tumblr\\.com/",
		21,
		[2077],
		[{ "e": 2077 }],
		[{
			"check": "any",
			"v": 2077
		}],
		[{
			"waitForThenClick": ["#cmp-app-container iframe", ".cmp-components-button.is-secondary"],
			"timeout": 5e3
		}],
		[],
		{}
	],
	[
		1,
		"web.de",
		2,
		"^https://([a-z]*\\.)?web\\.de/|^https://([a-z]*\\.)?gmx\\.net/",
		1,
		[],
		[{ "e": 2078 }, { "e": 2079 }],
		[{ "v": 2079 }],
		[{ "c": 2079 }],
		[],
		{}
	],
	[
		1,
		"widiba",
		0,
		"^https?://(www\\.)?widiba\\.it/",
		11,
		[2080],
		[{ "e": 2081 }],
		[{ "v": 2080 }],
		[{ "c": 2082 }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 2080
		}],
		{}
	],
	[
		1,
		"aa-cookie-banner",
		2,
		"^https://(www\\.)?(aa|envoyair|psaairlines)\\.com/",
		22,
		[2083],
		[{ "exists": ["adc-cookie-banner", "#cookie-banner"] }],
		[{ "visible": ["adc-cookie-banner", "#cookie-banner"] }],
		[{ "waitForThenClick": ["adc-cookie-banner", "#toast-dismiss-button"] }],
		[{ "cc": 2084 }],
		{}
	],
	[
		1,
		"abc",
		2,
		"^https://([a-z0-9-]+\\.)?abc\\.net\\.au/",
		22,
		[],
		[{ "e": 2085 }],
		[{ "v": 2086 }],
		[{ "c": 2087 }],
		[{ "cc": 2088 }],
		{}
	],
	[
		1,
		"abcacupuncture1",
		2,
		"^https?://(www\\.)?abcacupuncture1\\.com/",
		22,
		[595],
		[{ "any": [{ "e": 596 }, { "e": 870 }] }],
		[{ "any": [{ "v": 596 }, { "v": 2089 }] }],
		[
			{
				"if": { "v": 597 },
				"then": [{ "k": 597 }]
			},
			{
				"timeout": 4e3,
				"optional": true,
				"wv": 2089
			},
			{
				"if": { "v": 2089 },
				"then": [
					{ "k": 872 },
					{
						"all": true,
						"optional": true,
						"k": 874
					},
					{
						"optional": true,
						"k": 875
					}
				]
			},
			{
				"if": { "v": 597 },
				"then": [{ "c": 597 }]
			}
		],
		[{ "cc": 609 }],
		{}
	],
	[
		1,
		"abetterrouteplanner",
		2,
		"^https?://(www\\.)?abetterrouteplanner\\.com/",
		22,
		[],
		[{ "e": 2090 }],
		[{ "v": 2090 }],
		[{ "c": 2090 }],
		[{
			"negated": true,
			"e": 2090
		}],
		{}
	],
	[
		1,
		"accurx",
		2,
		"^https://(accurx\\.nhs\\.uk|patient\\.accurx\\.com)/",
		22,
		[2091],
		[{ "e": 2092 }],
		[{ "v": 2092 }],
		[{ "c": 2093 }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 2092
		}],
		{}
	],
	[
		1,
		"aceodds.com",
		2,
		"^https?://(www\\.)?aceodds\\.com/",
		22,
		[218],
		[{ "e": 2094 }],
		[{ "v": 218 }],
		[{
			"retry": 10,
			"retryInterval": 500,
			"c": 2095
		}, {
			"check": "none",
			"wv": 218
		}],
		[{ "cc": 2096 }],
		{}
	],
	[
		1,
		"activobank.pt",
		2,
		"^https://(www\\.)?activobank\\.pt",
		22,
		[2097],
		[{ "e": 2098 }],
		[{ "v": 2099 }],
		[{ "c": 2100 }],
		[],
		{}
	],
	[
		1,
		"adultfriendfinder",
		2,
		"^https://(www\\.)?adultfriendfinder\\.com/",
		22,
		[2101],
		[{ "e": 2102 }],
		[{ "v": 2102 }],
		[{ "c": 2103 }],
		[{ "eval": "EVAL_ADULTFRIENDFINDER_TEST" }],
		{}
	],
	[
		1,
		"aemet",
		1,
		"^https?://(www\\.)?aemet\\.es/",
		22,
		[2104],
		[{ "e": 2105 }],
		[{ "v": 2104 }],
		[{ "h": 2104 }],
		[{
			"check": "none",
			"v": 2104
		}],
		{}
	],
	[
		1,
		"aeolservice",
		2,
		"^https?://cloud\\.aeolservice\\.es/",
		22,
		[],
		[{ "e": 2106 }],
		[{ "v": 2107 }],
		[
			{ "c": 2107 },
			{ "wv": 2108 },
			{
				"all": true,
				"optional": true,
				"k": 2109
			},
			{ "c": 2110 }
		],
		[],
		{}
	],
	[
		1,
		"ah.nl",
		0,
		"^https?://(www\\.)?ah\\.nl/",
		10,
		[],
		[{ "e": 2111 }],
		[{ "v": 2111 }],
		[{ "c": 2112 }],
		[],
		{}
	],
	[
		1,
		"airbnb",
		2,
		"^https?://(www\\.)?airbnb\\.[a-z.]+/",
		22,
		[2113],
		[{ "e": 2114 }],
		[{ "v": 2114 }],
		[{
			"retry": 5,
			"retryInterval": 500,
			"c": 2114
		}],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2114
		}],
		{}
	],
	[
		1,
		"alaskaair",
		1,
		"^https://(www\\.)?alaskaair\\.com/",
		22,
		[2115],
		[{ "e": 2115 }],
		[{ "v": 2115 }],
		[{ "h": 2115 }],
		[],
		{}
	],
	[
		1,
		"aliexpress",
		2,
		"^https://([a-z]*\\.)?aliexpress\\.com/",
		22,
		[2116],
		[{ "e": 2117 }],
		[{
			"check": "any",
			"v": 2117
		}],
		[{
			"if": { "e": 2118 },
			"then": [{ "c": 2119 }],
			"else": [{
				"if": { "e": 2120 },
				"then": [{
					"if": { "e": 2121 },
					"then": [{ "c": 2122 }],
					"else": [{ "c": 2123 }, {
						"timeout": 5e3,
						"c": 2124
					}]
				}],
				"else": [{
					"if": { "e": 2125 },
					"then": [{ "c": 2126 }],
					"else": [
						{ "c": 2127 },
						{
							"timeout": 5e3,
							"wv": 2128
						},
						{ "c": 2129 }
					]
				}]
			}]
		}],
		[],
		{}
	],
	[
		1,
		"allabout-japan",
		2,
		"^https?://(\\w+\\.)?allabout-japan\\.com/",
		22,
		[2130],
		[{ "e": 2131 }],
		[{ "v": 2131 }],
		[
			{ "h": 2130 },
			{
				"timeout": 8e3,
				"optional": true,
				"wv": 2089
			},
			{
				"if": { "v": 2089 },
				"then": [
					{ "k": 872 },
					{
						"all": true,
						"optional": true,
						"k": 874
					},
					{
						"optional": true,
						"k": 875
					}
				]
			}
		],
		[],
		{}
	],
	[
		1,
		"ally",
		1,
		"^https://(www\\.)?ally\\.com/",
		22,
		[2132],
		[{ "e": 2133 }],
		[{ "v": 2133 }],
		[{ "h": 2132 }],
		[],
		{}
	],
	[
		1,
		"amazon-music",
		2,
		"^https?://music\\.amazon\\.[a-z.]+/",
		22,
		[2134],
		[{ "e": 2135 }],
		[{ "v": 2136 }],
		[{ "waitForThenClick": ["#bannerFooter music-button[variant=outline]", "button"] }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 2136
		}],
		{}
	],
	[
		1,
		"amazon-pay",
		2,
		"^https?://pay\\.amazon\\.",
		22,
		[2137],
		[{ "e": 2138 }],
		[{ "v": 2137 }],
		[{ "k": 2138 }],
		[{ "cc": 2139 }],
		{}
	],
	[
		1,
		"animatetimes",
		2,
		"^https?://(www\\.)?animatetimes\\.com/",
		22,
		[2140],
		[{ "e": 2140 }],
		[{ "v": 2140 }],
		[{ "c": 2141 }],
		[{
			"check": "none",
			"v": 2140
		}],
		{}
	],
	[
		1,
		"annunci69.it",
		2,
		"^https?://(www\\.)?annunci69\\.it/",
		22,
		[2142],
		[{ "e": 2143 }],
		[{ "v": 2142 }],
		[
			{ "c": 2144 },
			{ "wv": 2145 },
			{
				"optional": true,
				"k": 2146
			},
			{ "k": 2147 },
			{
				"check": "none",
				"wv": 2142
			}
		],
		[{ "cc": 2148 }],
		{}
	],
	[
		1,
		"app.discuss.io",
		2,
		"^https?://app\\.discuss\\.io/",
		10,
		[],
		[{ "e": 1414 }],
		[{ "v": 1414 }],
		[{ "c": 1414 }],
		[{ "cc": 184 }],
		{}
	],
	[
		1,
		"arbeidsplassen-nav-no",
		2,
		"^https?://arbeidsplassen\\.nav\\.no/",
		22,
		[2149],
		[{ "e": 2150 }],
		[{ "v": 2149 }],
		[{ "c": 2151 }],
		[{ "cc": 621 }],
		{}
	],
	[
		1,
		"arena.ai",
		2,
		"^https?://(\\w+\\.)?arena\\.ai/",
		22,
		[],
		[{ "e": 2152 }],
		[{ "v": 2152 }],
		[
			{ "c": 2153 },
			{ "wv": 2154 },
			{
				"all": true,
				"optional": true,
				"k": 2155
			},
			{ "c": 2156 }
		],
		[{ "cc": 2157 }],
		{}
	],
	[
		1,
		"aslroma1-it",
		2,
		"^https?://(\\w+\\.)?aslroma1\\.it/",
		22,
		[2158],
		[{ "e": 2159 }],
		[{ "v": 2158 }],
		[{ "c": 2159 }, {
			"check": "none",
			"wv": 2158
		}],
		[{ "cc": 2160 }],
		{}
	],
	[
		1,
		"athlinks-com",
		1,
		"^https://(www\\.)?athlinks\\.com/",
		22,
		[2161],
		[{ "e": 2161 }],
		[{ "v": 2162 }],
		[{ "h": 2161 }],
		[],
		{}
	],
	[
		1,
		"att",
		2,
		"^https://([a-z0-9-]+\\.)*att\\.com/",
		22,
		[2163],
		[{ "exists": ["#gpc-banner-container", "#declineSave"] }],
		[{ "visible": ["#gpc-banner-container", "#declineSave"] }],
		[{ "waitForThenClick": ["#gpc-banner-container", "#declineSave"] }],
		[{ "wait": 1e3 }, { "cc": 2164 }],
		{}
	],
	[
		1,
		"auctionet",
		2,
		"^https?://(www\\.)?auctionet\\.(com|se)/",
		22,
		[2165],
		[{ "e": 2166 }],
		[{ "v": 2166 }],
		[{ "c": 2167 }, { "c": 2168 }],
		[{ "wait": 500 }, { "cc": 2169 }],
		{}
	],
	[
		1,
		"auto_AU_acetool.com_n0w_+1",
		0,
		"^https?://(www\\.)?acetool\\.com/|^https?://(www\\.)?unclewiener\\.com/",
		10,
		[],
		[{ "e": 2170 }],
		[{ "v": 2170 }],
		[{ "wait": 500 }, { "c": 2170 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2170
		}],
		{}
	],
	[
		1,
		"auto_AU_aelfie.com_chb",
		0,
		"^https?://(www\\.)?aelfie\\.com/",
		10,
		[],
		[{ "e": 2171 }],
		[{ "v": 2171 }],
		[{ "wait": 500 }, { "c": 2171 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2171
		}],
		{}
	],
	[
		1,
		"auto_AU_cam.start.canon_3x5",
		0,
		"^https?://(www\\.)?cam\\.start\\.canon/",
		10,
		[],
		[{ "e": 2172 }],
		[{ "v": 2172 }],
		[{ "wait": 500 }, { "c": 2172 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2172
		}],
		{}
	],
	[
		1,
		"auto_AU_cam.start.canon_z06",
		0,
		"^https?://(www\\.)?cam\\.start\\.canon/",
		10,
		[],
		[{ "e": 2173 }],
		[{ "v": 2173 }],
		[{ "wait": 500 }, { "c": 2173 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2173
		}],
		{}
	],
	[
		1,
		"auto_AU_capitoltrades.com_ak9",
		0,
		"^https?://(www\\.)?capitoltrades\\.com/",
		10,
		[],
		[{ "e": 2174 }],
		[{ "v": 2174 }],
		[{ "wait": 500 }, { "c": 2174 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2174
		}],
		{}
	],
	[
		1,
		"auto_AU_community.dyson.com_lek",
		0,
		"^https?://(www\\.)?community\\.dyson\\.com/",
		10,
		[],
		[{ "e": 2175 }],
		[{ "v": 2175 }],
		[{ "wait": 500 }, { "c": 2175 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2175
		}],
		{}
	],
	[
		1,
		"auto_AU_conference-board.org_dce",
		0,
		"^https?://(www\\.)?conference-board\\.org/",
		10,
		[],
		[{ "e": 2176 }],
		[{ "v": 2176 }],
		[{ "wait": 500 }, { "c": 2176 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2176
		}],
		{}
	],
	[
		1,
		"auto_AU_cutterbuck.com_ko7",
		0,
		"^https?://(www\\.)?cutterbuck\\.com/",
		10,
		[],
		[{ "e": 2177 }],
		[{ "v": 2177 }],
		[{ "wait": 500 }, { "c": 2177 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2177
		}],
		{}
	],
	[
		1,
		"auto_AU_deezer.com_tmf",
		0,
		"^https?://(www\\.)?deezer\\.com/",
		10,
		[],
		[{ "e": 2178 }],
		[{ "v": 2178 }],
		[{ "wait": 500 }, { "c": 2178 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2178
		}],
		{}
	],
	[
		1,
		"auto_AU_docs.portainer.io_hn5",
		0,
		"^https?://(www\\.)?docs\\.portainer\\.io/",
		10,
		[],
		[{ "e": 2179 }],
		[{ "v": 2179 }],
		[{ "wait": 500 }, { "c": 2179 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2179
		}],
		{}
	],
	[
		1,
		"auto_AU_flinders.edu.au_7en_+1",
		0,
		"^https?://(www\\.)?flinders\\.edu\\.au/|^https?://(www\\.)?students\\.flinders\\.edu\\.au/",
		10,
		[],
		[{ "e": 2180 }],
		[{ "v": 2180 }],
		[{ "c": 2180 }],
		[],
		{}
	],
	[
		1,
		"auto_AU_flysaa.com_qsm",
		0,
		"^https?://(www\\.)?flysaa\\.com/",
		10,
		[2181],
		[{ "e": 2181 }],
		[{ "v": 2182 }],
		[{ "c": 2183 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2182
		}],
		{}
	],
	[
		1,
		"auto_AU_gayseniordating.com_bdr",
		0,
		"^https?://(www\\.)?gayseniordating\\.com/",
		10,
		[],
		[{ "e": 2184 }],
		[{ "v": 2184 }],
		[{ "wait": 500 }, { "c": 2184 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2184
		}],
		{}
	],
	[
		1,
		"auto_AU_goodmoodprints.com_9fy",
		1,
		"^https?://(www\\.)?goodmoodprints\\.com/",
		10,
		[2185],
		[{ "e": 2185 }],
		[{ "v": 2185 }],
		[{ "h": 2185 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2185
		}],
		{}
	],
	[
		1,
		"auto_AU_lush.com_bdf",
		0,
		"^https?://(www\\.)?lush\\.com/",
		10,
		[],
		[{ "e": 2186 }],
		[{ "v": 2186 }],
		[{ "wait": 500 }, { "c": 2186 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2186
		}],
		{}
	],
	[
		1,
		"auto_AU_newyork.doverstreetmarket.com_j5q",
		0,
		"^https?://(www\\.)?newyork\\.doverstreetmarket\\.com/",
		10,
		[],
		[{ "e": 2187 }],
		[{ "v": 2187 }],
		[{ "wait": 500 }, { "c": 2187 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2187
		}],
		{}
	],
	[
		1,
		"auto_AU_newyork.doverstreetmarket.com_k2q",
		0,
		"^https?://(www\\.)?newyork\\.doverstreetmarket\\.com/",
		10,
		[],
		[{ "e": 2188 }],
		[{ "v": 2188 }],
		[{ "wait": 500 }, { "c": 2188 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2188
		}],
		{}
	],
	[
		1,
		"auto_AU_niwaki.com_w41",
		0,
		"^https?://(www\\.)?niwaki\\.com/",
		10,
		[],
		[{ "e": 2189 }],
		[{ "v": 2189 }],
		[{ "wait": 500 }, { "c": 2189 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2189
		}],
		{}
	],
	[
		1,
		"auto_AU_pichunter.com_zhf",
		0,
		"^https?://(www\\.)?pichunter\\.com/",
		10,
		[],
		[{ "e": 2190 }],
		[{ "v": 2190 }],
		[{ "wait": 500 }, { "c": 2190 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2190
		}],
		{}
	],
	[
		1,
		"auto_AU_pnp.co.za_9lg",
		0,
		"^https?://(www\\.)?pnp\\.co\\.za/",
		10,
		[],
		[{ "e": 2191 }],
		[{ "v": 2191 }],
		[{ "wait": 500 }, { "c": 2191 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2191
		}],
		{}
	],
	[
		1,
		"auto_AU_publicdomainreview.org_7fg",
		0,
		"^https?://(www\\.)?publicdomainreview\\.org/",
		10,
		[],
		[{ "e": 2192 }],
		[{ "v": 2192 }],
		[{ "wait": 500 }, { "c": 2192 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2192
		}],
		{}
	],
	[
		1,
		"auto_AU_qldnaturistassoc.org_k53",
		0,
		"^https?://(www\\.)?qldnaturistassoc\\.org/",
		10,
		[],
		[{ "e": 2193 }],
		[{ "v": 2193 }],
		[{ "wait": 500 }, { "c": 2193 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2193
		}],
		{}
	],
	[
		1,
		"auto_AU_rki.de_tp5",
		0,
		"^https?://(www\\.)?rki\\.de/",
		10,
		[],
		[{ "e": 2194 }],
		[{ "v": 2194 }],
		[{ "wait": 500 }, { "c": 2194 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2194
		}],
		{}
	],
	[
		1,
		"auto_AU_solesavy.com_8q6",
		0,
		"^https?://(www\\.)?solesavy\\.com/",
		10,
		[],
		[{ "e": 2195 }],
		[{ "v": 2195 }],
		[{ "wait": 500 }, { "c": 2195 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2195
		}],
		{}
	],
	[
		1,
		"auto_AU_staff.flinders.edu.au_cpu",
		0,
		"^https?://(www\\.)?staff\\.flinders\\.edu\\.au/",
		10,
		[],
		[{ "e": 2180 }],
		[{ "v": 2180 }],
		[{ "wait": 500 }, { "c": 2180 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2180
		}],
		{}
	],
	[
		1,
		"auto_AU_telekom.hu_4lu",
		0,
		"^https?://(www\\.)?telekom\\.hu/",
		10,
		[],
		[{ "e": 2196 }],
		[{ "v": 2196 }],
		[{ "wait": 500 }, { "c": 2196 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2196
		}],
		{}
	],
	[
		1,
		"auto_AU_tourismnewbrunswick.ca_bjd",
		0,
		"^https?://(www\\.)?tourismnewbrunswick\\.ca/",
		10,
		[],
		[{ "e": 2197 }],
		[{ "v": 2197 }],
		[{ "wait": 500 }, { "c": 2197 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2197
		}],
		{}
	],
	[
		1,
		"auto_AU_tripcentral.ca_v7v",
		0,
		"^https?://(www\\.)?tripcentral\\.ca/",
		10,
		[],
		[{ "e": 2198 }],
		[{ "v": 2198 }],
		[{ "wait": 500 }, { "c": 2198 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2198
		}],
		{}
	],
	[
		1,
		"auto_AU_u-buy.com.au_rg0",
		0,
		"^https?://(www\\.)?u-buy\\.com\\.au/",
		10,
		[],
		[{ "e": 2199 }],
		[{ "v": 2199 }],
		[{ "wait": 500 }, { "c": 2199 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2199
		}],
		{}
	],
	[
		1,
		"auto_AU_whitepages.co.com_4cs",
		0,
		"^https?://(www\\.)?whitepages\\.co\\.com/",
		10,
		[],
		[{ "e": 2200 }],
		[{ "v": 2200 }],
		[{ "wait": 500 }, { "c": 2200 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2200
		}],
		{}
	],
	[
		1,
		"auto_CA_407etr.com_wrd",
		0,
		"^https?://(www\\.)?407etr\\.com/",
		10,
		[],
		[{ "e": 2201 }],
		[{ "v": 2201 }],
		[{ "wait": 500 }, { "c": 2201 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2201
		}],
		{}
	],
	[
		1,
		"auto_CA_arte.tv_7nv",
		0,
		"^https?://(www\\.)?arte\\.tv/",
		10,
		[],
		[{ "e": 2202 }],
		[{ "v": 2202 }],
		[{ "c": 2202 }],
		[],
		{}
	],
	[
		1,
		"auto_CA_babel.hathitrust.org_i6g",
		0,
		"^https?://(www\\.)?babel\\.hathitrust\\.org/",
		10,
		[],
		[{ "e": 2203 }],
		[{ "v": 2203 }],
		[{ "wait": 500 }, { "c": 2203 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2203
		}],
		{}
	],
	[
		1,
		"auto_CA_belairdirect.com_wic",
		0,
		"^https?://(www\\.)?belairdirect\\.com/",
		10,
		[],
		[{ "e": 2204 }],
		[{ "v": 2204 }],
		[{ "wait": 500 }, { "c": 2204 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2204
		}],
		{}
	],
	[
		1,
		"auto_CA_bet365.bet.br_kkx",
		0,
		"^https?://(www\\.)?bet365\\.bet\\.br/",
		10,
		[],
		[{ "e": 2205 }],
		[{ "v": 2205 }],
		[{ "wait": 500 }, { "c": 2205 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2205
		}],
		{}
	],
	[
		1,
		"auto_CA_blackdiamondequipment.com_dwp_+8",
		0,
		"^https?://(www\\.)?blackdiamondequipment\\.com/|^https?://(www\\.)?facetofacegames\\.com/|^https?://(www\\.)?suzyshier\\.com/|^https?://(www\\.)?urban-planet\\.com/|^https?://(www\\.)?eu\\.blackdiamondequipment\\.com/|^https?://(www\\.)?bushwear\\.co\\.uk/|^https?://(www\\.)?directdoors\\.com/|^https?://(www\\.)?keenfootwear\\.com/|^https?://(www\\.)?shop\\.panasonic\\.com/",
		10,
		[],
		[{ "e": 2206 }],
		[{ "v": 2206 }],
		[{ "wait": 500 }, { "c": 2206 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2206
		}],
		{}
	],
	[
		1,
		"auto_CA_brazzers.com_kik",
		0,
		"^https?://(www\\.)?brazzers\\.com/",
		10,
		[],
		[{ "e": 2207 }],
		[{ "v": 2207 }],
		[{ "wait": 500 }, { "c": 2207 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2207
		}],
		{}
	],
	[
		1,
		"auto_CA_busbud.com_0sh",
		0,
		"^https?://(www\\.)?busbud\\.com/",
		10,
		[],
		[{ "e": 2208 }],
		[{ "v": 2208 }],
		[{ "wait": 500 }, { "c": 2208 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2208
		}],
		{}
	],
	[
		1,
		"auto_CA_cegeplimoilou.ca_9tg",
		0,
		"^https?://(www\\.)?cegeplimoilou\\.ca/",
		10,
		[],
		[{ "e": 2209 }],
		[{ "v": 2209 }],
		[{ "wait": 500 }, { "c": 2209 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2209
		}],
		{}
	],
	[
		1,
		"auto_CA_cfo.coop_edx",
		0,
		"^https?://(www\\.)?cfo\\.coop/",
		10,
		[],
		[{ "e": 2210 }],
		[{ "v": 2210 }],
		[{ "wait": 500 }, { "c": 2210 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2210
		}],
		{}
	],
	[
		1,
		"auto_CA_chipolo.net_zo9",
		0,
		"^https?://(www\\.)?chipolo\\.net/",
		10,
		[],
		[{ "e": 2211 }],
		[{ "v": 2211 }],
		[{ "wait": 500 }, { "c": 2211 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2211
		}],
		{}
	],
	[
		1,
		"auto_CA_cmpa-acpm.ca_nja",
		0,
		"^https?://(www\\.)?cmpa-acpm\\.ca/",
		10,
		[],
		[{ "e": 2212 }],
		[{ "v": 2212 }],
		[{ "c": 2212 }],
		[],
		{}
	],
	[
		1,
		"auto_CA_denniskirk.com_ezr",
		0,
		"^https?://(www\\.)?denniskirk\\.com/",
		10,
		[],
		[{ "e": 2213 }],
		[{ "v": 2213 }],
		[{ "wait": 500 }, { "c": 2213 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2213
		}],
		{}
	],
	[
		1,
		"auto_CA_doyondespres.com_4jr",
		0,
		"^https?://(www\\.)?doyondespres\\.com/",
		10,
		[],
		[{ "e": 2214 }],
		[{ "v": 2214 }],
		[{ "wait": 500 }, { "c": 2214 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2214
		}],
		{}
	],
	[
		1,
		"auto_CA_f6s.com_yjw",
		0,
		"^https?://(www\\.)?f6s\\.com/",
		10,
		[],
		[{ "e": 2215 }],
		[{ "v": 2215 }],
		[{ "wait": 500 }, { "c": 2215 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2215
		}],
		{}
	],
	[
		1,
		"auto_CA_fischersports.com_1yr",
		0,
		"^https?://(www\\.)?fischersports\\.com/",
		10,
		[],
		[{ "e": 2216 }],
		[{ "v": 2216 }],
		[{ "wait": 500 }, { "c": 2216 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2216
		}],
		{}
	],
	[
		1,
		"auto_CA_golfavenue.ca_ero_+1",
		0,
		"^https?://(www\\.)?golfavenue\\.ca/|^https?://(www\\.)?golfbidder\\.co\\.uk/",
		10,
		[],
		[{ "e": 2217 }],
		[{ "v": 2217 }],
		[{ "wait": 500 }, { "c": 2217 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2217
		}],
		{}
	],
	[
		1,
		"auto_CA_golftown.com_zcn",
		0,
		"^https?://(www\\.)?golftown\\.com/",
		10,
		[],
		[{ "e": 2218 }],
		[{ "v": 2218 }],
		[{ "wait": 500 }, { "c": 2218 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2218
		}],
		{}
	],
	[
		1,
		"auto_CA_intact.ca_gax",
		0,
		"^https?://(www\\.)?intact\\.ca/",
		10,
		[],
		[{ "e": 2219 }],
		[{ "v": 2219 }],
		[{ "wait": 500 }, { "c": 2219 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2219
		}],
		{}
	],
	[
		1,
		"auto_CA_lethpolytech.ca_1r1",
		0,
		"^https?://(www\\.)?lethpolytech\\.ca/",
		10,
		[],
		[{ "e": 2220 }],
		[{ "v": 2220 }],
		[{ "wait": 500 }, { "c": 2220 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2220
		}],
		{}
	],
	[
		1,
		"auto_CA_libgen.help_7s8",
		0,
		"^https?://(www\\.)?libgen\\.help/",
		10,
		[],
		[{ "e": 2221 }],
		[{ "v": 2221 }],
		[{ "wait": 500 }, { "c": 2221 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2221
		}],
		{}
	],
	[
		1,
		"auto_CA_nationalarchives.gov.uk_vgx",
		0,
		"^https?://(www\\.)?webarchive\\.nationalarchives\\.gov\\.uk/",
		10,
		[],
		[{ "e": 2222 }],
		[{ "v": 2222 }],
		[{ "wait": 500 }, { "c": 2222 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2222
		}],
		{}
	],
	[
		1,
		"auto_CA_papajohns.ca_n5j",
		0,
		"^https?://(www\\.)?papajohns\\.ca/",
		10,
		[],
		[{ "e": 2223 }],
		[{ "v": 2223 }],
		[{ "wait": 500 }, { "c": 2223 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2223
		}],
		{}
	],
	[
		1,
		"auto_CA_pcsupport.lenovo.com_dxi",
		0,
		"^https?://(www\\.)?pcsupport\\.lenovo\\.com/",
		10,
		[],
		[{ "e": 2224 }],
		[{ "v": 2224 }],
		[{ "wait": 500 }, { "c": 2224 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2224
		}],
		{}
	],
	[
		1,
		"auto_CA_plex.tv_ee4_+1",
		0,
		"^https?://(www\\.)?plex\\.tv/|^https?://(www\\.)?support\\.plex\\.tv/",
		10,
		[],
		[{ "e": 2225 }],
		[{ "v": 2225 }],
		[{ "wait": 500 }, { "c": 2225 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2225
		}],
		{}
	],
	[
		1,
		"auto_CA_promessedefleurs.com_noy_+1",
		0,
		"^https?://(www\\.)?promessedefleurs\\.com/|^https?://(www\\.)?meillandrichardier\\.com/",
		10,
		[],
		[{ "e": 2226 }],
		[{ "v": 2226 }],
		[{ "wait": 500 }, { "c": 2226 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2226
		}],
		{}
	],
	[
		1,
		"auto_CA_queerty.com_fb8_+1",
		0,
		"^https?://(www\\.)?queerty\\.com/|^https?://(www\\.)?pestor\\.nl/",
		10,
		[],
		[{ "e": 2227 }],
		[{ "v": 2227 }],
		[{ "wait": 500 }, { "c": 2227 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2227
		}],
		{}
	],
	[
		1,
		"auto_CA_remitly.com_mm4",
		0,
		"^https?://(www\\.)?remitly\\.com/",
		10,
		[],
		[{ "e": 2228 }],
		[{ "v": 2228 }],
		[{ "wait": 500 }, { "c": 2228 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2228
		}],
		{}
	],
	[
		1,
		"auto_CA_reviewed.com_w2k",
		0,
		"^https?://(www\\.)?reviewed\\.com/",
		10,
		[],
		[{ "e": 2229 }],
		[{ "v": 2229 }],
		[{ "wait": 500 }, { "c": 2229 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2229
		}],
		{}
	],
	[
		1,
		"auto_CA_sheetmusicplus.com_b7d",
		0,
		"^https?://(www\\.)?sheetmusicplus\\.com/",
		10,
		[],
		[{ "e": 2230 }],
		[{ "v": 2230 }],
		[{ "wait": 500 }, { "c": 2230 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2230
		}],
		{}
	],
	[
		1,
		"auto_CA_skipthedishes.com_1sg",
		0,
		"^https?://(www\\.)?skipthedishes\\.com/",
		10,
		[],
		[{ "e": 2231 }],
		[{ "v": 2231 }],
		[{ "c": 2231 }],
		[],
		{}
	],
	[
		1,
		"auto_CA_streamingthe.net_v8e",
		0,
		"^https?://(www\\.)?streamingthe\\.net/",
		10,
		[],
		[{ "e": 2232 }],
		[{ "v": 2232 }],
		[{ "wait": 500 }, { "c": 2232 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2232
		}],
		{}
	],
	[
		1,
		"auto_CA_ticketsource.com_kiv",
		0,
		"^https?://(www\\.)?ticketsource\\.com/",
		10,
		[],
		[{ "e": 2233 }],
		[{ "v": 2233 }],
		[{ "wait": 500 }, { "c": 2233 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2233
		}],
		{}
	],
	[
		1,
		"auto_CA_ubereats.com_4nx",
		0,
		"^https?://(www\\.)?ubereats\\.com/",
		10,
		[],
		[{ "e": 2234 }],
		[{ "v": 2234 }],
		[{ "wait": 500 }, { "c": 2234 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2234
		}],
		{}
	],
	[
		1,
		"auto_CA_wealthsimple.com_kgz",
		0,
		"^https?://(www\\.)?wealthsimple\\.com/",
		10,
		[],
		[{ "e": 2235 }],
		[{ "v": 2235 }],
		[{ "wait": 500 }, { "c": 2235 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2235
		}],
		{}
	],
	[
		1,
		"auto_CA_xplore.ca_wwx",
		0,
		"^https?://(www\\.)?xplore\\.ca/",
		10,
		[],
		[{ "e": 2236 }],
		[{ "v": 2236 }],
		[{ "wait": 500 }, { "c": 2236 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2236
		}],
		{}
	],
	[
		1,
		"auto_CH_3djake.ch_6k2_+3",
		0,
		"^https?://(www\\.)?3djake\\.ch/|^https?://(www\\.)?ecco-verde\\.ch/|^https?://(www\\.)?vitalabo\\.ch/|^https?://(www\\.)?3djake\\.de/",
		10,
		[],
		[{ "e": 2237 }],
		[{ "v": 2237 }],
		[{ "wait": 500 }, { "c": 2237 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2237
		}],
		{}
	],
	[
		1,
		"auto_CH_alpenvereinaktiv.com_ms8_+1",
		0,
		"^https?://(www\\.)?alpenvereinaktiv\\.com/|^https?://(www\\.)?maps\\.viamala\\.ch/",
		10,
		[],
		[{ "e": 2238 }],
		[{ "v": 2238 }],
		[{ "wait": 500 }, { "c": 2238 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2238
		}],
		{}
	],
	[
		1,
		"auto_CH_android.bestsecret.com_m12_+2",
		0,
		"^https?://(www\\.)?android\\.bestsecret\\.com/|^https?://(www\\.)?bestsecret\\.com/|^https?://(www\\.)?orders\\.bestsecret\\.com/",
		10,
		[],
		[{ "e": 2239 }],
		[{ "v": 2239 }],
		[{ "wait": 500 }, { "c": 2239 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2239
		}],
		{}
	],
	[
		1,
		"auto_CH_aoc.com_dib",
		0,
		"^https?://(www\\.)?aoc\\.com/",
		10,
		[],
		[{ "e": 2240 }],
		[{ "v": 2240 }],
		[{ "wait": 500 }, { "c": 2240 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2240
		}],
		{}
	],
	[
		1,
		"auto_CH_arte.tv_ln7",
		0,
		"^https?://(www\\.)?arte\\.tv/",
		10,
		[],
		[{ "e": 2241 }],
		[{ "v": 2241 }],
		[{ "wait": 500 }, { "c": 2241 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2241
		}],
		{}
	],
	[
		1,
		"auto_CH_arttv.ch_2lm",
		0,
		"^https?://(www\\.)?arttv\\.ch/",
		10,
		[],
		[{ "e": 2242 }],
		[{ "v": 2242 }],
		[{ "wait": 500 }, { "c": 2242 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2242
		}],
		{}
	],
	[
		1,
		"auto_CH_ascona.il-centro.ch_59k",
		0,
		"^https?://(www\\.)?ascona\\.il-centro\\.ch/",
		10,
		[],
		[{ "e": 2243 }],
		[{ "v": 2243 }],
		[{ "wait": 500 }, { "c": 2243 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2243
		}],
		{}
	],
	[
		1,
		"auto_CH_astag.ch_1if",
		0,
		"^https?://(www\\.)?astag\\.ch/",
		10,
		[],
		[{ "e": 2244 }],
		[{ "v": 2244 }],
		[{ "wait": 500 }, { "c": 2244 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2244
		}],
		{}
	],
	[
		1,
		"auto_CH_auto.swiss_z35",
		0,
		"^https?://(www\\.)?auto\\.swiss/",
		10,
		[],
		[{ "e": 2245 }],
		[{ "v": 2245 }],
		[{ "wait": 500 }, { "c": 2245 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2245
		}],
		{}
	],
	[
		1,
		"auto_CH_bandlab.com_jul",
		0,
		"^https?://(www\\.)?bandlab\\.com/",
		10,
		[],
		[{ "e": 2246 }],
		[{ "v": 2246 }],
		[{ "wait": 500 }, { "c": 2246 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2246
		}],
		{}
	],
	[
		1,
		"auto_CH_bitbox.swiss_w0n",
		0,
		"^https?://(www\\.)?bitbox\\.swiss/",
		10,
		[],
		[{ "e": 2247 }],
		[{ "v": 2247 }],
		[{ "wait": 500 }, { "c": 2247 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2247
		}],
		{}
	],
	[
		1,
		"auto_CH_blogdumoderateur.com_8p6",
		0,
		"^https?://(www\\.)?blogdumoderateur\\.com/",
		10,
		[],
		[{ "e": 2248 }],
		[{ "v": 2248 }],
		[{ "wait": 500 }, { "c": 2248 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2248
		}],
		{}
	],
	[
		1,
		"auto_CH_blutspendezurich.ch_s0f",
		0,
		"^https?://(www\\.)?blutspendezurich\\.ch/",
		10,
		[],
		[{ "e": 2249 }],
		[{ "v": 2249 }],
		[{ "wait": 500 }, { "c": 2249 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2249
		}],
		{}
	],
	[
		1,
		"auto_CH_cardmarket.com_15t",
		0,
		"^https?://(www\\.)?cardmarket\\.com/",
		10,
		[],
		[{ "e": 2250 }],
		[{ "v": 2250 }],
		[{ "wait": 500 }, { "c": 2250 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2250
		}],
		{}
	],
	[
		1,
		"auto_CH_ch.rotho.com_h99_+2",
		0,
		"^https?://(www\\.)?ch\\.rotho\\.com/|^https?://(www\\.)?reclam\\.de/|^https?://(www\\.)?dacianer\\.de/",
		10,
		[],
		[{ "e": 2251 }],
		[{ "v": 2251 }],
		[{ "wait": 500 }, { "c": 2251 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2251
		}],
		{}
	],
	[
		1,
		"auto_CH_chambres-hotes.fr_hay",
		0,
		"^https?://(www\\.)?chambres-hotes\\.fr/",
		10,
		[],
		[{ "e": 2252 }],
		[{ "v": 2252 }],
		[{ "wait": 500 }, { "c": 2252 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2252
		}],
		{}
	],
	[
		1,
		"auto_CH_chrono24.ch_dve_+1",
		0,
		"^https?://(www\\.)?chrono24\\.ch/|^https?://(www\\.)?chrono24\\.de/",
		10,
		[],
		[{ "e": 2253 }],
		[{ "v": 2253 }],
		[{ "wait": 500 }, { "c": 2253 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2253
		}],
		{}
	],
	[
		1,
		"auto_CH_chrono24.com_lj5_+1",
		0,
		"^https?://(www\\.)?chrono24\\.com/|^https?://(www\\.)?chrono24\\.co\\.uk/",
		10,
		[],
		[{ "e": 2253 }],
		[{ "v": 2253 }],
		[{ "wait": 500 }, { "c": 2253 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2253
		}],
		{}
	],
	[
		1,
		"auto_CH_ersatzteil-shop24.de_mh5_+1",
		0,
		"^https?://(www\\.)?ersatzteil-shop24\\.de/|^https?://(www\\.)?der-rasenmaeher\\.de/",
		10,
		[],
		[{ "e": 2254 }],
		[{ "v": 2254 }],
		[{ "wait": 500 }, { "c": 2254 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2254
		}],
		{}
	],
	[
		1,
		"auto_CH_euroairport.com_3yl_+4",
		0,
		"^https?://(www\\.)?euroairport\\.com/|^https?://(www\\.)?carnavalet\\.paris\\.fr/|^https?://(www\\.)?ifrap\\.org/|^https?://(www\\.)?mam\\.paris\\.fr/|^https?://(www\\.)?petitpalais\\.paris\\.fr/",
		10,
		[],
		[{ "e": 2255 }],
		[{ "v": 2255 }],
		[{ "wait": 500 }, { "c": 2255 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2255
		}],
		{}
	],
	[
		1,
		"auto_CH_europarl.europa.eu_y2d",
		0,
		"^https?://(www\\.)?europarl\\.europa\\.eu/",
		10,
		[],
		[{ "e": 2256 }],
		[{ "v": 2256 }],
		[{ "wait": 500 }, { "c": 2256 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2256
		}],
		{}
	],
	[
		1,
		"auto_CH_feldschloesschen.ch_4mc",
		0,
		"^https?://(www\\.)?feldschloesschen\\.ch/",
		10,
		[],
		[{ "e": 2257 }],
		[{ "v": 2257 }],
		[{ "wait": 500 }, { "c": 2257 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2257
		}],
		{}
	],
	[
		1,
		"auto_CH_fhgr.ch_9nr",
		0,
		"^https?://(www\\.)?fhgr\\.ch/",
		10,
		[],
		[{ "e": 2258 }],
		[{ "v": 2258 }],
		[{ "wait": 500 }, { "c": 2258 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2258
		}],
		{}
	],
	[
		1,
		"auto_CH_fondationbeyeler.ch_o13",
		0,
		"^https?://(www\\.)?fondationbeyeler\\.ch/",
		10,
		[],
		[{ "e": 2251 }],
		[{ "v": 2251 }],
		[{ "wait": 500 }, { "c": 2251 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2251
		}],
		{}
	],
	[
		1,
		"auto_CH_fontis-shop.ch_ksd",
		0,
		"^https?://(www\\.)?fontis-shop\\.ch/",
		10,
		[],
		[{ "e": 2259 }],
		[{ "v": 2259 }],
		[{ "wait": 500 }, { "c": 2259 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2259
		}],
		{}
	],
	[
		1,
		"auto_CH_frankenspalter.ch_jo0",
		0,
		"^https?://(www\\.)?frankenspalter\\.ch/",
		10,
		[],
		[{ "e": 2260 }],
		[{ "v": 2260 }],
		[{ "wait": 500 }, { "c": 2260 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2260
		}],
		{}
	],
	[
		1,
		"auto_CH_frankenspalter.ch_l2w",
		0,
		"^https?://(www\\.)?frankenspalter\\.ch/",
		10,
		[],
		[{ "e": 2261 }],
		[{ "v": 2261 }],
		[{ "wait": 500 }, { "c": 2261 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2261
		}],
		{}
	],
	[
		1,
		"auto_CH_fruugoschweiz.com_6k8",
		0,
		"^https?://(www\\.)?fruugoschweiz\\.com/",
		10,
		[],
		[{ "e": 2262 }],
		[{ "v": 2262 }],
		[{ "wait": 500 }, { "c": 2262 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2262
		}],
		{}
	],
	[
		1,
		"auto_CH_gabrielweinberg.com_56i",
		0,
		"^https?://(www\\.)?gabrielweinberg\\.com/",
		10,
		[],
		[{ "e": 2263 }],
		[{ "v": 2263 }],
		[{ "wait": 500 }, { "c": 2263 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2263
		}],
		{}
	],
	[
		1,
		"auto_CH_galaxus.de_sqv_+1",
		0,
		"^https?://(www\\.)?galaxus\\.de/|^https?://(www\\.)?galaxus\\.fr/",
		10,
		[],
		[{ "e": 2264 }],
		[{ "v": 2264 }],
		[{ "wait": 500 }, { "c": 2264 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2264
		}],
		{}
	],
	[
		1,
		"auto_CH_gstaadmenuhinfestival.ch_vp3",
		0,
		"^https?://(www\\.)?gstaadmenuhinfestival\\.ch/",
		10,
		[],
		[{ "e": 2265 }],
		[{ "v": 2265 }],
		[{ "wait": 500 }, { "c": 2265 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2265
		}],
		{}
	],
	[
		1,
		"auto_CH_haushaltstipps.com_9kx_+1",
		0,
		"^https?://(www\\.)?haushaltstipps\\.com/|^https?://(www\\.)?alltours\\.de/",
		10,
		[],
		[{ "e": 2251 }],
		[{ "v": 2251 }],
		[{ "wait": 500 }, { "c": 2251 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2251
		}],
		{}
	],
	[
		1,
		"auto_CH_independentxpress.de_0qj",
		0,
		"^https?://(www\\.)?independentxpress\\.de/",
		10,
		[],
		[{ "e": 2266 }],
		[{ "v": 2266 }],
		[{ "wait": 500 }, { "c": 2266 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2266
		}],
		{}
	],
	[
		1,
		"auto_CH_instant-gaming.com_8j3",
		0,
		"^https?://(www\\.)?instant-gaming\\.com/",
		10,
		[],
		[{ "e": 2267 }],
		[{ "v": 2267 }],
		[{ "wait": 500 }, { "c": 2267 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2267
		}],
		{}
	],
	[
		1,
		"auto_CH_kinopoisk.ru_w3g_+14",
		0,
		"^https?://(www\\.)?kinopoisk\\.ru/|^https?://(www\\.)?market\\.yandex\\.ru/|^https?://(www\\.)?translate\\.yandex\\.com/|^https?://(www\\.)?yandex\\.com\\.tr/|^https?://(www\\.)?ya\\.ru/|^https?://(www\\.)?yandex\\.com/|^https?://(www\\.)?translate\\.yandex\\.ru/|^https?://(www\\.)?yandex\\.by/|^https?://(www\\.)?local\\.yandex\\.com/|^https?://(www\\.)?sso\\.passport\\.yandex\\.ru/|^https?://(www\\.)?360\\.yandex\\.ru/|^https?://(www\\.)?360\\.yandex\\.com/|^https?://(www\\.)?music\\.yandex\\.ru/|^https?://(www\\.)?hd\\.kinopoisk\\.ru/|^https?://(www\\.)?wap\\.yandex\\.com/",
		10,
		[],
		[{ "e": 2268 }],
		[{ "v": 2268 }],
		[{ "wait": 500 }, { "c": 2268 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2268
		}],
		{}
	],
	[
		1,
		"auto_CH_kobo.com_p4l",
		0,
		"^https?://(www\\.)?kobo\\.com/",
		10,
		[],
		[{ "e": 2269 }],
		[{ "v": 2269 }],
		[{ "wait": 500 }, { "c": 2269 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2269
		}],
		{}
	],
	[
		1,
		"auto_CH_labanquepostale.fr_o6f_+1",
		0,
		"^https?://(www\\.)?labanquepostale\\.fr/|^https?://(www\\.)?labanquepostale\\.com/",
		10,
		[],
		[{ "e": 2270 }],
		[{ "v": 2270 }],
		[{ "wait": 500 }, { "c": 2270 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2270
		}],
		{}
	],
	[
		1,
		"auto_CH_laposte.fr_ctu_+2",
		0,
		"^https?://(www\\.)?laposte\\.fr/|^https?://(www\\.)?localiser\\.laposte\\.fr/|^https?://(www\\.)?aide\\.laposte\\.fr/",
		10,
		[],
		[{ "e": 2271 }],
		[{ "v": 2271 }],
		[{ "wait": 500 }, { "c": 2271 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2271
		}],
		{}
	],
	[
		1,
		"auto_CH_larian.com_kp5",
		0,
		"^https?://(www\\.)?larian\\.com/",
		10,
		[],
		[{ "e": 2272 }],
		[{ "v": 2272 }],
		[{ "wait": 500 }, { "c": 2272 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2272
		}],
		{}
	],
	[
		1,
		"auto_CH_louis-moto.ch_5yk",
		0,
		"^https?://(www\\.)?louis-moto\\.ch/",
		10,
		[],
		[{ "e": 2273 }],
		[{ "v": 2273 }],
		[{ "wait": 500 }, { "c": 2273 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2273
		}],
		{}
	],
	[
		1,
		"auto_CH_manufactum.ch_ag0_+1",
		0,
		"^https?://(www\\.)?manufactum\\.ch/|^https?://(www\\.)?manufactum\\.de/",
		10,
		[],
		[{ "e": 2274 }],
		[{ "v": 2274 }],
		[{ "wait": 500 }, { "c": 2274 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2274
		}],
		{}
	],
	[
		1,
		"auto_CH_maps.engadin.ch_m40_+3",
		0,
		"^https?://(www\\.)?maps\\.engadin\\.ch/|^https?://(www\\.)?outdoor\\.glarnerland\\.ch/|^https?://(www\\.)?altenberg\\.de/|^https?://(www\\.)?tourenplaner-rheinland-pfalz\\.de/",
		10,
		[],
		[{ "e": 2238 }],
		[{ "v": 2238 }],
		[{ "wait": 500 }, { "c": 2238 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2238
		}],
		{}
	],
	[
		1,
		"auto_CH_mein-kraeuterkeller.de_zjh",
		0,
		"^https?://(www\\.)?mein-kraeuterkeller\\.de/",
		10,
		[],
		[{ "e": 2275 }],
		[{ "v": 2275 }],
		[{ "wait": 500 }, { "c": 2275 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2275
		}],
		{}
	],
	[
		1,
		"auto_CH_meintiptopf.ch_84l",
		0,
		"^https?://(www\\.)?meintiptopf\\.ch/",
		10,
		[],
		[{ "e": 2276 }],
		[{ "v": 2276 }],
		[{ "wait": 500 }, { "c": 2276 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2276
		}],
		{}
	],
	[
		1,
		"auto_CH_mio.se_hd0",
		0,
		"^https?://(www\\.)?mio\\.se/",
		10,
		[],
		[{ "e": 2277 }],
		[{ "v": 2277 }],
		[{ "wait": 500 }, { "c": 2277 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2277
		}],
		{}
	],
	[
		1,
		"auto_CH_moebel24.ch_fck_+1",
		0,
		"^https?://(www\\.)?moebel24\\.ch/|^https?://(www\\.)?moebel\\.de/",
		10,
		[],
		[{ "e": 2278 }],
		[{ "v": 2278 }],
		[{ "wait": 500 }, { "c": 2278 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2278
		}],
		{}
	],
	[
		1,
		"auto_CH_mrporter.com_0nl_+1",
		0,
		"^https?://(www\\.)?mrporter\\.com/|^https?://(www\\.)?net-a-porter\\.com/",
		10,
		[],
		[{ "e": 2279 }],
		[{ "v": 2279 }],
		[{ "wait": 500 }, { "c": 2279 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2279
		}],
		{}
	],
	[
		1,
		"auto_CH_platform.openai.com_g5y",
		0,
		"^https?://(www\\.)?platform\\.openai\\.com/",
		10,
		[],
		[{ "e": 2280 }],
		[{ "v": 2280 }],
		[{ "wait": 500 }, { "c": 2280 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2280
		}],
		{}
	],
	[
		1,
		"auto_CH_pmphotomedia.ch_ume",
		0,
		"^https?://(www\\.)?pmphotomedia\\.ch/",
		10,
		[],
		[{ "e": 2281 }],
		[{ "v": 2281 }],
		[{ "wait": 500 }, { "c": 2281 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2281
		}],
		{}
	],
	[
		1,
		"auto_CH_radio1.ch_1v2",
		0,
		"^https?://(www\\.)?radio1\\.ch/",
		10,
		[],
		[{ "e": 2282 }],
		[{ "v": 2282 }],
		[{ "wait": 500 }, { "c": 2282 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2282
		}],
		{}
	],
	[
		1,
		"auto_CH_renens.ch_2uc",
		0,
		"^https?://(www\\.)?renens\\.ch/",
		10,
		[],
		[{ "e": 2283 }],
		[{ "v": 2283 }],
		[{ "wait": 500 }, { "c": 2283 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2283
		}],
		{}
	],
	[
		1,
		"auto_CH_sac-uto.ch_3gu",
		0,
		"^https?://(www\\.)?sac-uto\\.ch/",
		10,
		[],
		[{ "e": 2284 }],
		[{ "v": 2284 }],
		[{ "wait": 500 }, { "c": 2284 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2284
		}],
		{}
	],
	[
		1,
		"auto_CH_seetickets.com_4b2",
		0,
		"^https?://(www\\.)?seetickets\\.com/",
		10,
		[],
		[{ "e": 2285 }],
		[{ "v": 2285 }],
		[{ "wait": 500 }, { "c": 2285 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2285
		}],
		{}
	],
	[
		1,
		"auto_CH_sparkasse.de_lwr",
		0,
		"^https?://(www\\.)?sparkasse\\.de/",
		10,
		[],
		[{ "e": 2286 }],
		[{ "v": 2286 }],
		[{ "wait": 500 }, { "c": 2286 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2286
		}],
		{}
	],
	[
		1,
		"auto_CH_sva-bl.ch_h2k_+1",
		0,
		"^https?://(www\\.)?sva-bl\\.ch/|^https?://(www\\.)?uni-bremen\\.de/",
		10,
		[],
		[{ "e": 2287 }],
		[{ "v": 2287 }],
		[{ "wait": 500 }, { "c": 2287 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2287
		}],
		{}
	],
	[
		1,
		"auto_CH_transn.ch_ygb",
		0,
		"^https?://(www\\.)?transn\\.ch/",
		10,
		[],
		[{ "e": 2288 }],
		[{ "v": 2288 }],
		[{ "wait": 500 }, { "c": 2288 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2288
		}],
		{}
	],
	[
		1,
		"auto_CH_ubs-kidscup.ch_5oc",
		0,
		"^https?://(www\\.)?ubs-kidscup\\.ch/",
		10,
		[],
		[{ "e": 2289 }],
		[{ "v": 2289 }],
		[{ "wait": 500 }, { "c": 2289 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2289
		}],
		{}
	],
	[
		1,
		"auto_CH_velofactory.ch_tpq",
		0,
		"^https?://(www\\.)?velofactory\\.ch/",
		10,
		[],
		[{ "e": 2290 }],
		[{ "v": 2290 }],
		[{ "wait": 500 }, { "c": 2290 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2290
		}],
		{}
	],
	[
		1,
		"auto_DE_116117-termine.de_nwg",
		0,
		"^https?://(www\\.)?116117-termine\\.de/",
		10,
		[],
		[{ "e": 2291 }],
		[{ "v": 2291 }],
		[{ "wait": 500 }, { "c": 2291 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2291
		}],
		{}
	],
	[
		1,
		"auto_DE_6relax.de_na9",
		0,
		"^https?://(www\\.)?6relax\\.de/",
		10,
		[],
		[{ "e": 2292 }],
		[{ "v": 2292 }],
		[{ "wait": 500 }, { "c": 2292 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2292
		}],
		{}
	],
	[
		1,
		"auto_DE_accio.com_kdu",
		0,
		"^https?://(www\\.)?accio\\.com/",
		10,
		[],
		[{ "e": 2293 }],
		[{ "v": 2293 }],
		[{ "wait": 500 }, { "c": 2293 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2293
		}],
		{}
	],
	[
		1,
		"auto_DE_aerztekammer-bw.de_rse",
		0,
		"^https?://(www\\.)?aerztekammer-bw\\.de/",
		10,
		[],
		[{ "e": 2294 }],
		[{ "v": 2294 }],
		[{ "wait": 500 }, { "c": 2294 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2294
		}],
		{}
	],
	[
		1,
		"auto_DE_afd.de_tad",
		0,
		"^https?://(www\\.)?afd\\.de/",
		10,
		[],
		[{ "e": 2295 }],
		[{ "v": 2295 }],
		[{ "wait": 500 }, { "c": 2295 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2295
		}],
		{}
	],
	[
		1,
		"auto_DE_aknw.de_wcz_+1",
		0,
		"^https?://(www\\.)?aknw\\.de/|^https?://(www\\.)?regioentsorgung\\.de/",
		10,
		[],
		[{ "e": 2296 }],
		[{ "v": 2296 }],
		[{ "wait": 500 }, { "c": 2296 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2296
		}],
		{}
	],
	[
		1,
		"auto_DE_all-inkl.com_toh",
		0,
		"^https?://(www\\.)?all-inkl\\.com/",
		10,
		[],
		[{ "e": 2297 }],
		[{ "v": 2297 }],
		[{ "wait": 500 }, { "c": 2297 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2297
		}],
		{}
	],
	[
		1,
		"auto_DE_almenrausch.at_c6z",
		0,
		"^https?://(www\\.)?almenrausch\\.at/",
		10,
		[],
		[{ "e": 2298 }],
		[{ "v": 2298 }],
		[{ "wait": 500 }, { "c": 2298 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2298
		}],
		{}
	],
	[
		1,
		"auto_DE_alza.de_iq3",
		0,
		"^https?://(www\\.)?alza\\.de/",
		10,
		[],
		[{ "e": 2299 }],
		[{ "v": 2299 }],
		[{ "wait": 500 }, { "c": 2299 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2299
		}],
		{}
	],
	[
		1,
		"auto_DE_ancestry.com_k1k",
		0,
		"^https?://(www\\.)?ancestry\\.com/",
		10,
		[],
		[{ "e": 2300 }],
		[{ "v": 2300 }],
		[{ "wait": 500 }, { "c": 2300 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2300
		}],
		{}
	],
	[
		1,
		"auto_DE_apozilla.de_d1h",
		0,
		"^https?://(www\\.)?apozilla\\.de/",
		10,
		[],
		[{ "e": 2301 }],
		[{ "v": 2301 }],
		[{ "wait": 500 }, { "c": 2301 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2301
		}],
		{}
	],
	[
		1,
		"auto_DE_ardplus.de_ue3",
		0,
		"^https?://(www\\.)?ardplus\\.de/",
		10,
		[],
		[{ "e": 2302 }],
		[{ "v": 2302 }],
		[{ "wait": 500 }, { "c": 2302 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2302
		}],
		{}
	],
	[
		1,
		"auto_DE_axa.de_vyk",
		0,
		"^https?://(www\\.)?axa\\.de/",
		10,
		[],
		[{ "e": 2303 }],
		[{ "v": 2303 }],
		[{ "wait": 500 }, { "c": 2303 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2303
		}],
		{}
	],
	[
		1,
		"auto_DE_backmarket.de_dzf",
		0,
		"^https?://(www\\.)?backmarket\\.de/",
		10,
		[],
		[{ "e": 2304 }],
		[{ "v": 2304 }],
		[{ "wait": 500 }, { "c": 2304 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2304
		}],
		{}
	],
	[
		1,
		"auto_DE_bbbank.de_dcf_+15",
		0,
		"^https?://(www\\.)?bbbank\\.de/|^https?://(www\\.)?diebank\\.de/|^https?://(www\\.)?genobroker\\.de/|^https?://(www\\.)?ligabank\\.de/|^https?://(www\\.)?pax-bkc\\.de/|^https?://(www\\.)?psd-berlin-brandenburg\\.de/|^https?://(www\\.)?psd-nuernberg\\.de/|^https?://(www\\.)?sparda-bank-hamburg\\.de/|^https?://(www\\.)?sparda-h\\.de/|^https?://(www\\.)?sparda-n\\.de/|^https?://(www\\.)?v-mn\\.de/|^https?://(www\\.)?vr-bayernmitte\\.de/|^https?://(www\\.)?vrbank-brs\\.de/|^https?://(www\\.)?vrbank-eg\\.de/|^https?://(www\\.)?vrbank-lb\\.de/|^https?://(www\\.)?wvb\\.de/",
		10,
		[],
		[{ "e": 2305 }],
		[{ "v": 2305 }],
		[{ "wait": 500 }, { "c": 2305 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2305
		}],
		{}
	],
	[
		1,
		"auto_DE_biunsinnorden.de_kwa_+1",
		0,
		"^https?://(www\\.)?biunsinnorden\\.de/|^https?://(www\\.)?livegigs\\.de/",
		10,
		[],
		[{ "e": 2306 }],
		[{ "v": 2306 }],
		[{ "wait": 500 }, { "c": 2306 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2306
		}],
		{}
	],
	[
		1,
		"auto_DE_bmz.de_nss",
		0,
		"^https?://(www\\.)?bmz\\.de/",
		10,
		[],
		[{ "e": 2307 }],
		[{ "v": 2307 }],
		[{ "wait": 500 }, { "c": 2307 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2307
		}],
		{}
	],
	[
		1,
		"auto_DE_buerklin.com_bya",
		0,
		"^https?://(www\\.)?buerklin\\.com/",
		10,
		[],
		[{ "e": 2251 }],
		[{ "v": 2251 }],
		[{ "wait": 500 }, { "c": 2251 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2251
		}],
		{}
	],
	[
		1,
		"auto_DE_bundeswehrkarriere.de_g9g",
		0,
		"^https?://(www\\.)?bundeswehrkarriere\\.de/",
		10,
		[],
		[{ "e": 2308 }],
		[{ "v": 2308 }],
		[{ "wait": 500 }, { "c": 2308 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2308
		}],
		{}
	],
	[
		1,
		"auto_DE_byak.de_dcj",
		0,
		"^https?://(www\\.)?byak\\.de/",
		10,
		[],
		[{ "e": 2309 }],
		[{ "v": 2309 }],
		[{ "wait": 500 }, { "c": 2309 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2309
		}],
		{}
	],
	[
		1,
		"auto_DE_byte.fm_83l",
		0,
		"^https?://(www\\.)?byte\\.fm/",
		10,
		[],
		[{ "e": 2310 }],
		[{ "v": 2310 }],
		[{ "wait": 500 }, { "c": 2310 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2310
		}],
		{}
	],
	[
		1,
		"auto_DE_camping-outdoorshop.de_oo4_+1",
		0,
		"^https?://(www\\.)?camping-outdoorshop\\.de/|^https?://(www\\.)?elektro-wandelt\\.de/",
		10,
		[],
		[{ "e": 2298 }],
		[{ "v": 2298 }],
		[{ "wait": 500 }, { "c": 2298 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2298
		}],
		{}
	],
	[
		1,
		"auto_DE_club.auto-doc.at_6xj",
		0,
		"^https?://(www\\.)?club\\.auto-doc\\.at/",
		10,
		[],
		[{ "e": 2311 }],
		[{ "v": 2311 }],
		[{ "wait": 500 }, { "c": 2311 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2311
		}],
		{}
	],
	[
		1,
		"auto_DE_daad.de_w45",
		0,
		"^https?://(www\\.)?daad\\.de/",
		10,
		[],
		[{ "e": 2312 }],
		[{ "v": 2312 }],
		[{ "wait": 500 }, { "c": 2312 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2312
		}],
		{}
	],
	[
		1,
		"auto_DE_das-ist-drin.de_e12",
		0,
		"^https?://(www\\.)?das-ist-drin\\.de/",
		10,
		[],
		[{ "e": 2313 }],
		[{ "v": 2313 }],
		[{ "wait": 500 }, { "c": 2313 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2313
		}],
		{}
	],
	[
		1,
		"auto_DE_de.accio.com_97o",
		0,
		"^https?://(www\\.)?de\\.accio\\.com/",
		10,
		[],
		[{ "e": 2293 }],
		[{ "v": 2293 }],
		[{ "wait": 500 }, { "c": 2293 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2293
		}],
		{}
	],
	[
		1,
		"auto_DE_de.artprice.com_kfk",
		0,
		"^https?://(www\\.)?de\\.artprice\\.com/",
		10,
		[],
		[{ "e": 2314 }],
		[{ "v": 2314 }],
		[{ "wait": 500 }, { "c": 2314 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2314
		}],
		{}
	],
	[
		1,
		"auto_DE_de.nothing.tech_0fr_+1",
		0,
		"^https?://(www\\.)?de\\.nothing\\.tech/|^https?://(www\\.)?nothing\\.tech/",
		10,
		[],
		[{ "e": 2315 }],
		[{ "v": 2315 }],
		[{ "wait": 500 }, { "c": 2315 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2315
		}],
		{}
	],
	[
		1,
		"auto_DE_dekra.de_qrb",
		0,
		"^https?://(www\\.)?dekra\\.de/",
		10,
		[],
		[{ "e": 2316 }],
		[{ "v": 2316 }],
		[{ "wait": 500 }, { "c": 2316 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2316
		}],
		{}
	],
	[
		1,
		"auto_DE_edelstahl-tuerklingel.de_375",
		0,
		"^https?://(www\\.)?edelstahl-tuerklingel\\.de/",
		10,
		[],
		[{ "e": 2317 }],
		[{ "v": 2317 }],
		[{ "wait": 500 }, { "c": 2317 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2317
		}],
		{}
	],
	[
		1,
		"auto_DE_eezy.nrw_9aj",
		0,
		"^https?://(www\\.)?eezy\\.nrw/",
		10,
		[],
		[{ "e": 2318 }],
		[{ "v": 2318 }],
		[{ "wait": 500 }, { "c": 2318 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2318
		}],
		{}
	],
	[
		1,
		"auto_DE_ernstings-family.de_xqf",
		0,
		"^https?://(www\\.)?ernstings-family\\.de/",
		10,
		[],
		[{ "e": 2319 }],
		[{ "v": 2319 }],
		[{ "wait": 500 }, { "c": 2319 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2319
		}],
		{}
	],
	[
		1,
		"auto_DE_fcbinside.de_0d6",
		0,
		"^https?://(www\\.)?fcbinside\\.de/",
		10,
		[],
		[{ "e": 2320 }],
		[{ "v": 2320 }],
		[{ "wait": 500 }, { "c": 2320 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2320
		}],
		{}
	],
	[
		1,
		"auto_DE_feierabend.de_kr4",
		0,
		"^https?://(www\\.)?feierabend\\.de/",
		10,
		[],
		[{ "e": 2321 }],
		[{ "v": 2321 }],
		[{ "wait": 500 }, { "c": 2321 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2321
		}],
		{}
	],
	[
		1,
		"auto_DE_feser-graf.de_qz8",
		0,
		"^https?://(www\\.)?feser-graf\\.de/",
		10,
		[],
		[{ "e": 2322 }],
		[{ "v": 2322 }],
		[{ "wait": 500 }, { "c": 2322 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2322
		}],
		{}
	],
	[
		1,
		"auto_DE_finanzpartner.de_13s",
		0,
		"^https?://(www\\.)?finanzpartner\\.de/",
		10,
		[],
		[{ "e": 2323 }],
		[{ "v": 2323 }],
		[{ "wait": 500 }, { "c": 2323 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2323
		}],
		{}
	],
	[
		1,
		"auto_DE_gasometer.de_0xw",
		0,
		"^https?://(www\\.)?gasometer\\.de/",
		10,
		[],
		[{ "e": 2324 }],
		[{ "v": 2324 }],
		[{ "wait": 500 }, { "c": 2324 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2324
		}],
		{}
	],
	[
		1,
		"auto_DE_hermoney.de_jsi",
		0,
		"^https?://(www\\.)?hermoney\\.de/",
		10,
		[],
		[{ "e": 2325 }],
		[{ "v": 2325 }],
		[{ "wait": 500 }, { "c": 2325 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2325
		}],
		{}
	],
	[
		1,
		"auto_DE_hilfe.kleinanzeigen.de_44a_+1",
		0,
		"^https?://(www\\.)?hilfe\\.kleinanzeigen\\.de/|^https?://(www\\.)?themen\\.kleinanzeigen\\.de/",
		10,
		[],
		[{ "e": 2326 }],
		[{ "v": 2326 }],
		[{ "wait": 500 }, { "c": 2326 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2326
		}],
		{}
	],
	[
		1,
		"auto_DE_howik.com_99g",
		0,
		"^https?://(www\\.)?howik\\.com/",
		10,
		[],
		[{ "e": 2327 }],
		[{ "v": 2327 }],
		[{ "wait": 500 }, { "c": 2327 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2327
		}],
		{}
	],
	[
		1,
		"auto_DE_hu-berlin.de_sk6",
		0,
		"^https?://(www\\.)?hu-berlin\\.de/",
		10,
		[],
		[{ "e": 2328 }],
		[{ "v": 2328 }],
		[{ "wait": 500 }, { "c": 2328 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2328
		}],
		{}
	],
	[
		1,
		"auto_DE_imd-berlin.de_6m1",
		0,
		"^https?://(www\\.)?imd-berlin\\.de/",
		10,
		[],
		[{ "e": 2329 }],
		[{ "v": 2329 }],
		[{ "wait": 500 }, { "c": 2329 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2329
		}],
		{}
	],
	[
		1,
		"auto_DE_immobilien.sparkasse.de_zj7",
		0,
		"^https?://(www\\.)?immobilien\\.sparkasse\\.de/",
		10,
		[2330],
		[{ "e": 2331 }],
		[{ "v": 2331 }],
		[{ "c": 2332 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2331
		}],
		{}
	],
	[
		1,
		"auto_DE_impfen-info.de_am5_+1",
		0,
		"^https?://(www\\.)?impfen-info\\.de/|^https?://(www\\.)?infektionsschutz\\.de/",
		10,
		[],
		[{ "e": 2333 }],
		[{ "v": 2333 }],
		[{ "wait": 500 }, { "c": 2333 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2333
		}],
		{}
	],
	[
		1,
		"auto_DE_jobvector.de_641",
		0,
		"^https?://(www\\.)?jobvector\\.de/",
		10,
		[],
		[{ "e": 2334 }],
		[{ "v": 2334 }],
		[{ "wait": 500 }, { "c": 2334 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2334
		}],
		{}
	],
	[
		1,
		"auto_DE_kinsta.com_hc5",
		0,
		"^https?://(www\\.)?kinsta\\.com/",
		10,
		[],
		[{ "e": 2335 }],
		[{ "v": 2335 }],
		[{ "wait": 500 }, { "c": 2335 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2335
		}],
		{}
	],
	[
		1,
		"auto_DE_kleineskraftwerk.de_fx7",
		0,
		"^https?://(www\\.)?kleineskraftwerk\\.de/",
		10,
		[],
		[{ "e": 2336 }],
		[{ "v": 2336 }],
		[{ "wait": 500 }, { "c": 2336 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2336
		}],
		{}
	],
	[
		1,
		"auto_DE_kundenportal.m-net.de_y8l",
		0,
		"^https?://(www\\.)?kundenportal\\.m-net\\.de/",
		10,
		[],
		[{ "e": 2286 }],
		[{ "v": 2286 }],
		[{ "wait": 500 }, { "c": 2286 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2286
		}],
		{}
	],
	[
		1,
		"auto_DE_kvhb.de_hhf",
		0,
		"^https?://(www\\.)?kvhb\\.de/",
		10,
		[],
		[{ "e": 2337 }],
		[{ "v": 2337 }],
		[{ "wait": 500 }, { "c": 2337 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2337
		}],
		{}
	],
	[
		1,
		"auto_DE_la.spankbang.com_sva",
		0,
		"^https?://(www\\.)?la\\.spankbang\\.com/",
		10,
		[],
		[{ "e": 2338 }],
		[{ "v": 2338 }],
		[{ "wait": 500 }, { "c": 2338 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2338
		}],
		{}
	],
	[
		1,
		"auto_DE_lbs.de_6zt",
		0,
		"^https?://(www\\.)?lbs\\.de/",
		10,
		[],
		[{ "e": 2339 }],
		[{ "v": 2339 }],
		[{ "wait": 500 }, { "c": 2339 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2339
		}],
		{}
	],
	[
		1,
		"auto_DE_lenovo.com_xcv",
		0,
		"^https?://(www\\.)?lenovo\\.com/",
		10,
		[],
		[{ "e": 2340 }],
		[{ "v": 2340 }],
		[{ "wait": 500 }, { "c": 2340 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2340
		}],
		{}
	],
	[
		1,
		"auto_DE_listando.de_c5i",
		0,
		"^https?://(www\\.)?listando\\.de/",
		10,
		[],
		[{ "e": 2341 }],
		[{ "v": 2341 }],
		[{ "wait": 500 }, { "c": 2341 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2341
		}],
		{}
	],
	[
		1,
		"auto_DE_lite-magazin.de_e1s",
		0,
		"^https?://(www\\.)?lite-magazin\\.de/",
		10,
		[],
		[{ "e": 2342 }],
		[{ "v": 2342 }],
		[{ "wait": 500 }, { "c": 2342 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2342
		}],
		{}
	],
	[
		1,
		"auto_DE_m.livejasmin.com_cvg",
		0,
		"^https?://(www\\.)?livejasmin\\.com/",
		10,
		[],
		[{ "e": 2343 }],
		[{ "v": 2343 }],
		[{ "wait": 500 }, { "c": 2343 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2343
		}],
		{}
	],
	[
		1,
		"auto_DE_mhplus-krankenkasse.de_4xb",
		0,
		"^https?://(www\\.)?mhplus-krankenkasse\\.de/",
		10,
		[],
		[{ "e": 2298 }],
		[{ "v": 2298 }],
		[{ "wait": 500 }, { "c": 2298 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2298
		}],
		{}
	],
	[
		1,
		"auto_DE_mitarbeiterservice.bayern.de_quh",
		0,
		"^https?://(www\\.)?mitarbeiterservice\\.bayern\\.de/",
		10,
		[],
		[{ "e": 2344 }],
		[{ "v": 2344 }],
		[{ "wait": 500 }, { "c": 2344 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2344
		}],
		{}
	],
	[
		1,
		"auto_DE_mrmarvis.com_bo5",
		0,
		"^https?://(www\\.)?mrmarvis\\.com/",
		10,
		[],
		[{ "e": 2345 }],
		[{ "v": 2345 }],
		[{ "wait": 500 }, { "c": 2345 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2345
		}],
		{}
	],
	[
		1,
		"auto_DE_nanu-nana.de_7my",
		0,
		"^https?://(www\\.)?nanu-nana\\.de/",
		10,
		[],
		[{ "e": 2346 }],
		[{ "v": 2346 }],
		[{ "wait": 500 }, { "c": 2346 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2346
		}],
		{}
	],
	[
		1,
		"auto_DE_originalteile.mercedes-benz.de_tce",
		0,
		"^https?://(www\\.)?originalteile\\.mercedes-benz\\.de/",
		10,
		[],
		[{ "e": 2347 }],
		[{ "v": 2347 }],
		[{ "wait": 500 }, { "c": 2347 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2347
		}],
		{}
	],
	[
		1,
		"auto_DE_parqet.com_6wm",
		0,
		"^https?://(www\\.)?parqet\\.com/",
		10,
		[],
		[{ "e": 2348 }],
		[{ "v": 2348 }],
		[{ "wait": 500 }, { "c": 2348 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2348
		}],
		{}
	],
	[
		1,
		"auto_DE_pflanzenhof-online.de_au2",
		0,
		"^https?://(www\\.)?pflanzenhof-online\\.de/",
		10,
		[],
		[{ "e": 2349 }],
		[{ "v": 2349 }],
		[{ "wait": 500 }, { "c": 2349 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2349
		}],
		{}
	],
	[
		1,
		"auto_DE_polizei.hessen.de_rsx",
		0,
		"^https?://(www\\.)?polizei\\.hessen\\.de/",
		10,
		[],
		[{ "e": 2350 }],
		[{ "v": 2350 }],
		[{ "wait": 500 }, { "c": 2350 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2350
		}],
		{}
	],
	[
		1,
		"auto_DE_regierung.oberbayern.bayern.de_zx2_+2",
		0,
		"^https?://(www\\.)?regierung\\.oberbayern\\.bayern\\.de/|^https?://(www\\.)?statistik\\.bayern\\.de/|^https?://(www\\.)?stmb\\.bayern\\.de/",
		10,
		[],
		[{ "e": 2351 }],
		[{ "v": 2351 }],
		[{ "wait": 500 }, { "c": 2351 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2351
		}],
		{}
	],
	[
		1,
		"auto_DE_roller.de_pjo",
		0,
		"^https?://(www\\.)?roller\\.de/",
		10,
		[],
		[{ "e": 2352 }],
		[{ "v": 2352 }],
		[{ "wait": 500 }, { "c": 2352 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2352
		}],
		{}
	],
	[
		1,
		"auto_DE_rundfunkbeitrag.de_g4y",
		0,
		"^https?://(www\\.)?rundfunkbeitrag\\.de/",
		10,
		[],
		[{ "e": 2353 }],
		[{ "v": 2353 }],
		[{ "wait": 500 }, { "c": 2353 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2353
		}],
		{}
	],
	[
		1,
		"auto_DE_schwabach.de_fjr",
		0,
		"^https?://(www\\.)?schwabach\\.de/",
		10,
		[],
		[{ "e": 2354 }],
		[{ "v": 2354 }],
		[{ "wait": 500 }, { "c": 2354 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2354
		}],
		{}
	],
	[
		1,
		"auto_DE_schwaebisch-hall.de_0g1",
		0,
		"^https?://(www\\.)?schwaebisch-hall\\.de/",
		10,
		[],
		[{ "e": 2355 }],
		[{ "v": 2355 }],
		[{ "wait": 500 }, { "c": 2355 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2355
		}],
		{}
	],
	[
		1,
		"auto_DE_sellercentral.amazon.de_xi0",
		0,
		"^https?://(www\\.)?sellercentral\\.amazon\\.de/",
		10,
		[],
		[{ "e": 2356 }],
		[{ "v": 2356 }],
		[{ "wait": 500 }, { "c": 2356 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2356
		}],
		{}
	],
	[
		1,
		"auto_DE_sephora.de_exg",
		0,
		"^https?://(www\\.)?sephora\\.de/",
		10,
		[],
		[{ "e": 2279 }],
		[{ "v": 2279 }],
		[{ "wait": 500 }, { "c": 2279 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2279
		}],
		{}
	],
	[
		1,
		"auto_DE_solarspeicher24.de_w5k",
		0,
		"^https?://(www\\.)?solarspeicher24\\.de/",
		10,
		[],
		[{ "e": 2357 }],
		[{ "v": 2357 }],
		[{ "wait": 500 }, { "c": 2357 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2357
		}],
		{}
	],
	[
		1,
		"auto_DE_speedtest.vodafone.de_dha",
		0,
		"^https?://(www\\.)?speedtest\\.vodafone\\.de/",
		10,
		[],
		[{ "e": 2358 }],
		[{ "v": 2358 }],
		[{ "wait": 500 }, { "c": 2358 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2358
		}],
		{}
	],
	[
		1,
		"auto_DE_steeltoyz.de_i51",
		0,
		"^https?://(www\\.)?steeltoyz\\.de/",
		10,
		[],
		[{ "e": 2359 }],
		[{ "v": 2359 }],
		[{ "wait": 500 }, { "c": 2359 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2359
		}],
		{}
	],
	[
		1,
		"auto_DE_survival-kompass.de_kv6",
		0,
		"^https?://(www\\.)?survival-kompass\\.de/",
		10,
		[],
		[{ "e": 2360 }],
		[{ "v": 2360 }],
		[{ "wait": 500 }, { "c": 2360 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2360
		}],
		{}
	],
	[
		1,
		"auto_DE_typografie.info_mnj",
		0,
		"^https?://(www\\.)?typografie\\.info/",
		10,
		[],
		[{ "e": 2361 }],
		[{ "v": 2361 }],
		[{ "wait": 500 }, { "c": 2361 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2361
		}],
		{}
	],
	[
		1,
		"auto_DE_uni-hildesheim.de_7kj",
		0,
		"^https?://(www\\.)?uni-hildesheim\\.de/",
		10,
		[],
		[{ "e": 2362 }],
		[{ "v": 2362 }],
		[{ "wait": 500 }, { "c": 2362 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2362
		}],
		{}
	],
	[
		1,
		"auto_DE_uni-mannheim.de_omi",
		0,
		"^https?://(www\\.)?uni-mannheim\\.de/",
		10,
		[],
		[{ "e": 2363 }],
		[{ "v": 2363 }],
		[{ "wait": 500 }, { "c": 2363 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2363
		}],
		{}
	],
	[
		1,
		"auto_DE_variete.de_6cc",
		0,
		"^https?://(www\\.)?variete\\.de/",
		10,
		[],
		[{ "e": 2364 }],
		[{ "v": 2364 }],
		[{ "wait": 500 }, { "c": 2364 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2364
		}],
		{}
	],
	[
		1,
		"auto_DE_wien.gv.at_mm2",
		0,
		"^https?://(www\\.)?wien\\.gv\\.at/",
		10,
		[],
		[{ "e": 2365 }],
		[{ "v": 2365 }],
		[{ "wait": 500 }, { "c": 2365 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2365
		}],
		{}
	],
	[
		1,
		"auto_DE_wolt.com_jyq",
		0,
		"^https?://(www\\.)?wolt\\.com/",
		10,
		[],
		[{ "e": 2366 }],
		[{ "v": 2366 }],
		[{ "wait": 500 }, { "c": 2366 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2366
		}],
		{}
	],
	[
		1,
		"auto_FR_3ds.com_pa7",
		0,
		"^https?://(www\\.)?3ds\\.com/",
		10,
		[],
		[{ "e": 2367 }],
		[{ "v": 2367 }],
		[{ "wait": 500 }, { "c": 2367 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2367
		}],
		{}
	],
	[
		1,
		"auto_FR_aefinfo.fr_6r7",
		0,
		"^https?://(www\\.)?aefinfo\\.fr/",
		10,
		[],
		[{ "e": 2368 }],
		[{ "v": 2368 }],
		[{ "wait": 500 }, { "c": 2368 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2368
		}],
		{}
	],
	[
		1,
		"auto_FR_alinea.com_d9k",
		0,
		"^https?://(www\\.)?alinea\\.com/",
		10,
		[],
		[{ "e": 2369 }],
		[{ "v": 2369 }],
		[{ "wait": 500 }, { "c": 2369 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2369
		}],
		{}
	],
	[
		1,
		"auto_FR_alinea.com_gst",
		0,
		"^https?://(www\\.)?alinea\\.com/",
		10,
		[],
		[{ "e": 2370 }],
		[{ "v": 2370 }],
		[{ "wait": 500 }, { "c": 2370 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2370
		}],
		{}
	],
	[
		1,
		"auto_FR_annuaire-inverse-france.com_4oi",
		0,
		"^https?://(www\\.)?annuaire-inverse-france\\.com/",
		10,
		[],
		[{ "e": 2371 }],
		[{ "v": 2371 }],
		[{ "wait": 500 }, { "c": 2371 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2371
		}],
		{}
	],
	[
		1,
		"auto_FR_asp.gouv.fr_ytt",
		0,
		"^https?://(www\\.)?asp\\.gouv\\.fr/",
		10,
		[],
		[{ "e": 2372 }],
		[{ "v": 2372 }],
		[{ "wait": 500 }, { "c": 2372 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2372
		}],
		{}
	],
	[
		1,
		"auto_FR_bd-adultes.com_nn2",
		0,
		"^https?://(www\\.)?bd-adultes\\.com/",
		10,
		[],
		[{ "e": 2373 }],
		[{ "v": 2373 }],
		[{ "wait": 500 }, { "c": 2373 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2373
		}],
		{}
	],
	[
		1,
		"auto_FR_bobvoyeur.com_qm5",
		0,
		"^https?://(www\\.)?bobvoyeur\\.com/",
		10,
		[],
		[{ "e": 2374 }],
		[{ "v": 2374 }],
		[{ "wait": 500 }, { "c": 2374 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2374
		}],
		{}
	],
	[
		1,
		"auto_FR_bpi.fr_l52",
		0,
		"^https?://(www\\.)?bpi\\.fr/",
		10,
		[],
		[{ "e": 2227 }],
		[{ "v": 2227 }],
		[{ "wait": 500 }, { "c": 2227 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2227
		}],
		{}
	],
	[
		1,
		"auto_FR_chamrousse.com_i7u",
		0,
		"^https?://(www\\.)?chamrousse\\.com/",
		10,
		[],
		[{ "e": 2375 }],
		[{ "v": 2375 }],
		[{ "wait": 500 }, { "c": 2375 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2375
		}],
		{}
	],
	[
		1,
		"auto_FR_charliehebdo.fr_smr",
		0,
		"^https?://(www\\.)?charliehebdo\\.fr/",
		10,
		[],
		[{ "e": 2376 }],
		[{ "v": 2376 }],
		[{ "wait": 500 }, { "c": 2376 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2376
		}],
		{}
	],
	[
		1,
		"auto_FR_cite-sciences.fr_kcx",
		0,
		"^https?://(www\\.)?cite-sciences\\.fr/",
		10,
		[],
		[{ "e": 2377 }],
		[{ "v": 2377 }],
		[{ "wait": 500 }, { "c": 2377 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2377
		}],
		{}
	],
	[
		1,
		"auto_FR_coe.int_cfo",
		0,
		"^https?://(www\\.)?coe\\.int/",
		10,
		[],
		[{ "e": 2378 }],
		[{ "v": 2378 }],
		[{ "wait": 500 }, { "c": 2378 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2378
		}],
		{}
	],
	[
		1,
		"auto_FR_coutellerie-tourangelle.com_rcf",
		0,
		"^https?://(www\\.)?coutellerie-tourangelle\\.com/",
		10,
		[],
		[{ "e": 2379 }],
		[{ "v": 2379 }],
		[{ "wait": 500 }, { "c": 2379 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2379
		}],
		{}
	],
	[
		1,
		"auto_FR_cre.fr_sd4",
		0,
		"^https?://(www\\.)?cre\\.fr/",
		10,
		[],
		[{ "e": 2380 }],
		[{ "v": 2380 }],
		[{ "wait": 500 }, { "c": 2380 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2380
		}],
		{}
	],
	[
		1,
		"auto_FR_cybevasion.fr_jjp",
		0,
		"^https?://(www\\.)?cybevasion\\.fr/",
		10,
		[],
		[{ "e": 2252 }],
		[{ "v": 2252 }],
		[{ "wait": 500 }, { "c": 2252 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2252
		}],
		{}
	],
	[
		1,
		"auto_FR_edumoov.com_sij",
		0,
		"^https?://(www\\.)?edumoov\\.com/",
		10,
		[],
		[{ "e": 2381 }],
		[{ "v": 2381 }],
		[{ "wait": 500 }, { "c": 2381 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2381
		}],
		{}
	],
	[
		1,
		"auto_FR_engie-homeservices.fr_lyo",
		0,
		"^https?://(www\\.)?engie-homeservices\\.fr/",
		10,
		[],
		[{ "e": 2382 }],
		[{ "v": 2382 }],
		[{ "wait": 500 }, { "c": 2382 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2382
		}],
		{}
	],
	[
		1,
		"auto_FR_es.xhamster.com_f69",
		0,
		"^https?://(www\\.)?es\\.xhamster\\.com/",
		10,
		[],
		[{ "e": 2383 }],
		[{ "v": 2383 }],
		[{ "wait": 500 }, { "c": 2383 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2383
		}],
		{}
	],
	[
		1,
		"auto_FR_euro-expos.com_tok",
		0,
		"^https?://(www\\.)?euro-expos\\.com/",
		10,
		[],
		[{ "e": 2384 }],
		[{ "v": 2384 }],
		[{ "wait": 500 }, { "c": 2384 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2384
		}],
		{}
	],
	[
		1,
		"auto_FR_fr.accio.com_zdn",
		0,
		"^https?://(www\\.)?fr\\.accio\\.com/",
		10,
		[],
		[{ "e": 2293 }],
		[{ "v": 2293 }],
		[{ "wait": 500 }, { "c": 2293 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2293
		}],
		{}
	],
	[
		1,
		"auto_FR_fr.xgimi.com_fzb_+1",
		0,
		"^https?://(www\\.)?fr\\.xgimi\\.com/|^https?://(www\\.)?leminor\\.fr/",
		10,
		[],
		[{ "e": 2206 }],
		[{ "v": 2206 }],
		[{ "wait": 500 }, { "c": 2206 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2206
		}],
		{}
	],
	[
		1,
		"auto_FR_glamuse.com_n32",
		0,
		"^https?://(www\\.)?glamuse\\.com/",
		10,
		[],
		[{ "e": 2385 }],
		[{ "v": 2385 }],
		[{ "wait": 500 }, { "c": 2385 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2385
		}],
		{}
	],
	[
		1,
		"auto_FR_gmf.fr_pxt",
		0,
		"^https?://(www\\.)?gmf\\.fr/",
		10,
		[],
		[{ "e": 2386 }],
		[{ "v": 2386 }],
		[{ "wait": 500 }, { "c": 2386 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2386
		}],
		{}
	],
	[
		1,
		"auto_FR_gov.br_n2f",
		0,
		"^https?://(www\\.)?gov\\.br/",
		10,
		[],
		[{ "e": 2387 }],
		[{ "v": 2387 }],
		[{ "wait": 500 }, { "c": 2387 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2387
		}],
		{}
	],
	[
		1,
		"auto_FR_greengo.voyage_fg3",
		0,
		"^https?://(www\\.)?greengo\\.voyage/",
		10,
		[],
		[{ "e": 2388 }],
		[{ "v": 2388 }],
		[{ "wait": 500 }, { "c": 2388 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2388
		}],
		{}
	],
	[
		1,
		"auto_FR_haproxy.com_arh",
		0,
		"^https?://(www\\.)?haproxy\\.com/",
		10,
		[],
		[{ "e": 2389 }],
		[{ "v": 2389 }],
		[{ "wait": 500 }, { "c": 2389 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2389
		}],
		{}
	],
	[
		1,
		"auto_FR_interencheres.com_c67",
		0,
		"^https?://(www\\.)?interencheres\\.com/",
		10,
		[],
		[{ "e": 2384 }],
		[{ "v": 2384 }],
		[{ "wait": 500 }, { "c": 2384 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2384
		}],
		{}
	],
	[
		1,
		"auto_FR_ita.xhamster.com_jhk",
		0,
		"^https?://(www\\.)?ita\\.xhamster\\.com/",
		10,
		[],
		[{ "e": 2383 }],
		[{ "v": 2383 }],
		[{ "wait": 500 }, { "c": 2383 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2383
		}],
		{}
	],
	[
		1,
		"auto_FR_kobo.com_ajz",
		0,
		"^https?://(www\\.)?kobo\\.com/",
		10,
		[],
		[{ "e": 2390 }],
		[{ "v": 2390 }],
		[{ "wait": 500 }, { "c": 2390 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2390
		}],
		{}
	],
	[
		1,
		"auto_FR_lalibrairie.com_0lt",
		0,
		"^https?://(www\\.)?lalibrairie\\.com/",
		10,
		[],
		[{ "e": 2391 }],
		[{ "v": 2391 }],
		[{ "wait": 500 }, { "c": 2391 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2391
		}],
		{}
	],
	[
		1,
		"auto_FR_leclercvoyages.com_2o4",
		0,
		"^https?://(www\\.)?leclercvoyages\\.com/",
		10,
		[],
		[{ "e": 2386 }],
		[{ "v": 2386 }],
		[{ "wait": 500 }, { "c": 2386 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2386
		}],
		{}
	],
	[
		1,
		"auto_FR_lesprosdelapetiteenfance.fr_bng",
		0,
		"^https?://(www\\.)?lesprosdelapetiteenfance\\.fr/",
		10,
		[],
		[{ "e": 2255 }],
		[{ "v": 2255 }],
		[{ "wait": 500 }, { "c": 2255 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2255
		}],
		{}
	],
	[
		1,
		"auto_FR_ludum.fr_gl5",
		0,
		"^https?://(www\\.)?ludum\\.fr/",
		10,
		[],
		[{ "e": 2392 }],
		[{ "v": 2392 }],
		[{ "wait": 500 }, { "c": 2392 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2392
		}],
		{}
	],
	[
		1,
		"auto_FR_maboussoleaidants.fr_f8f",
		0,
		"^https?://(www\\.)?maboussoleaidants\\.fr/",
		10,
		[],
		[{ "e": 2393 }],
		[{ "v": 2393 }],
		[{ "wait": 500 }, { "c": 2393 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2393
		}],
		{}
	],
	[
		1,
		"auto_FR_magellan-bio.fr_5xr",
		0,
		"^https?://(www\\.)?magellan-bio\\.fr/",
		10,
		[],
		[{ "e": 2394 }],
		[{ "v": 2394 }],
		[{ "wait": 500 }, { "c": 2394 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2394
		}],
		{}
	],
	[
		1,
		"auto_FR_manuels.solutions_3gb",
		0,
		"^https?://(www\\.)?manuels\\.solutions/",
		10,
		[],
		[{ "e": 2395 }],
		[{ "v": 2395 }],
		[{ "wait": 500 }, { "c": 2395 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2395
		}],
		{}
	],
	[
		1,
		"auto_FR_maty.com_2v7",
		0,
		"^https?://(www\\.)?maty\\.com/",
		10,
		[],
		[{ "e": 2286 }],
		[{ "v": 2286 }],
		[{ "wait": 500 }, { "c": 2286 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2286
		}],
		{}
	],
	[
		1,
		"auto_FR_mawaqit.net_0cw",
		0,
		"^https?://(www\\.)?mawaqit\\.net/",
		10,
		[],
		[{ "e": 2396 }],
		[{ "v": 2396 }],
		[{ "wait": 500 }, { "c": 2396 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2396
		}],
		{}
	],
	[
		1,
		"auto_FR_meformerenregion.fr_64b",
		0,
		"^https?://(www\\.)?meformerenregion\\.fr/",
		10,
		[],
		[{ "e": 2397 }],
		[{ "v": 2397 }],
		[{ "wait": 500 }, { "c": 2397 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2397
		}],
		{}
	],
	[
		1,
		"auto_FR_mesinfos.fr_gt2",
		0,
		"^https?://(www\\.)?mesinfos\\.fr/",
		10,
		[],
		[{ "e": 2398 }],
		[{ "v": 2398 }],
		[{ "wait": 500 }, { "c": 2398 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2398
		}],
		{}
	],
	[
		1,
		"auto_FR_naval-group.com_yzx",
		0,
		"^https?://(www\\.)?naval-group\\.com/",
		10,
		[],
		[{ "e": 2255 }],
		[{ "v": 2255 }],
		[{ "wait": 500 }, { "c": 2255 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2255
		}],
		{}
	],
	[
		1,
		"auto_FR_norauto.fr_mbi",
		0,
		"^https?://(www\\.)?norauto\\.fr/",
		10,
		[],
		[{ "e": 2286 }],
		[{ "v": 2286 }],
		[{ "wait": 500 }, { "c": 2286 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2286
		}],
		{}
	],
	[
		1,
		"auto_FR_nouslib.com_1tl",
		0,
		"^https?://(www\\.)?nouslib\\.com/",
		10,
		[],
		[{ "e": 2399 }],
		[{ "v": 2399 }],
		[{ "wait": 500 }, { "c": 2399 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2399
		}],
		{}
	],
	[
		1,
		"auto_FR_oceane.breizhgo.bzh_g7u",
		0,
		"^https?://(www\\.)?oceane\\.breizhgo\\.bzh/",
		10,
		[],
		[{ "e": 2400 }],
		[{ "v": 2400 }],
		[{ "wait": 500 }, { "c": 2400 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2400
		}],
		{}
	],
	[
		1,
		"auto_FR_pfg.fr_j2d_+1",
		0,
		"^https?://(www\\.)?pfg\\.fr/|^https?://(www\\.)?pointp\\.fr/",
		10,
		[],
		[{ "e": 2386 }],
		[{ "v": 2386 }],
		[{ "wait": 500 }, { "c": 2386 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2386
		}],
		{}
	],
	[
		1,
		"auto_FR_picwish.com_l0k",
		0,
		"^https?://(www\\.)?picwish\\.com/",
		10,
		[],
		[{ "e": 2401 }],
		[{ "v": 2401 }],
		[{ "wait": 500 }, { "c": 2401 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2401
		}],
		{}
	],
	[
		1,
		"auto_FR_platform.openai.com_nyz",
		0,
		"^https?://(www\\.)?platform\\.openai\\.com/",
		10,
		[],
		[{ "e": 2402 }],
		[{ "v": 2402 }],
		[{ "wait": 500 }, { "c": 2402 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2402
		}],
		{}
	],
	[
		1,
		"auto_FR_pointdevente.parionssport.fdj.fr_9uh",
		0,
		"^https?://(www\\.)?pointdevente\\.parionssport\\.fdj\\.fr/",
		10,
		[],
		[{ "e": 2339 }],
		[{ "v": 2339 }],
		[{ "wait": 500 }, { "c": 2339 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2339
		}],
		{}
	],
	[
		1,
		"auto_FR_politis.fr_g33",
		0,
		"^https?://(www\\.)?politis\\.fr/",
		10,
		[],
		[{ "e": 2403 }],
		[{ "v": 2403 }],
		[{ "wait": 500 }, { "c": 2403 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2403
		}],
		{}
	],
	[
		1,
		"auto_FR_pretto.fr_kb5",
		0,
		"^https?://(www\\.)?pretto\\.fr/",
		10,
		[],
		[{ "e": 2404 }],
		[{ "v": 2404 }],
		[{ "wait": 500 }, { "c": 2404 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2404
		}],
		{}
	],
	[
		1,
		"auto_FR_privateaser.com_uco",
		0,
		"^https?://(www\\.)?privateaser\\.com/",
		10,
		[],
		[{ "e": 2405 }],
		[{ "v": 2405 }],
		[{ "wait": 500 }, { "c": 2405 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2405
		}],
		{}
	],
	[
		1,
		"auto_FR_pro.inserm.fr_omt",
		0,
		"^https?://(www\\.)?pro\\.inserm\\.fr/",
		10,
		[],
		[{ "e": 2227 }],
		[{ "v": 2227 }],
		[{ "wait": 500 }, { "c": 2227 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2227
		}],
		{}
	],
	[
		1,
		"auto_FR_proantic.com_oyg",
		0,
		"^https?://(www\\.)?proantic\\.com/",
		10,
		[],
		[{ "e": 2406 }],
		[{ "v": 2406 }],
		[{ "wait": 500 }, { "c": 2406 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2406
		}],
		{}
	],
	[
		1,
		"auto_FR_revue-histoire.fr_jex",
		0,
		"^https?://(www\\.)?revue-histoire\\.fr/",
		10,
		[],
		[{ "e": 2407 }],
		[{ "v": 2407 }],
		[{ "wait": 500 }, { "c": 2407 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2407
		}],
		{}
	],
	[
		1,
		"auto_FR_rhinoshield.fr_k5l",
		0,
		"^https?://(www\\.)?rhinoshield\\.fr/",
		10,
		[],
		[{ "e": 2206 }],
		[{ "v": 2206 }],
		[{ "wait": 500 }, { "c": 2206 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2206
		}],
		{}
	],
	[
		1,
		"auto_FR_sephora.fr_k3l",
		0,
		"^https?://(www\\.)?sephora\\.fr/",
		10,
		[],
		[{ "e": 2279 }],
		[{ "v": 2279 }],
		[{ "wait": 500 }, { "c": 2279 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2279
		}],
		{}
	],
	[
		1,
		"auto_FR_xhamster.desi_pv1_+1",
		0,
		"^https?://(www\\.)?xhamster\\.desi/|^https?://(www\\.)?xhamster3\\.com/",
		10,
		[],
		[{ "e": 2383 }],
		[{ "v": 2383 }],
		[{ "wait": 500 }, { "c": 2383 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2383
		}],
		{}
	],
	[
		1,
		"auto_GB_3djake.uk_0",
		0,
		"^https?://(www\\.)?3djake\\.uk/",
		10,
		[],
		[{ "e": 2408 }],
		[{ "v": 2408 }],
		[{ "c": 2408 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_actionfraud.org.uk_92k",
		0,
		"^https?://(www\\.)?actionfraud\\.org\\.uk/",
		10,
		[],
		[{ "e": 2409 }],
		[{ "v": 2409 }],
		[{ "wait": 500 }, { "c": 2409 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2409
		}],
		{}
	],
	[
		1,
		"auto_GB_ancestry.com_0",
		0,
		"^https?://(www\\.)?ancestry\\.com/",
		10,
		[],
		[{ "e": 2410 }],
		[{ "v": 2410 }],
		[{ "wait": 500 }, { "c": 2410 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2410
		}],
		{}
	],
	[
		1,
		"auto_GB_arte.tv_0",
		0,
		"^https?://(www\\.)?arte\\.tv/",
		10,
		[],
		[{ "e": 2411 }],
		[{ "v": 2411 }],
		[{ "c": 2411 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_bensnaturalhealth.co.uk_0",
		0,
		"^https?://(www\\.)?bensnaturalhealth\\.co\\.uk/",
		10,
		[],
		[{ "e": 2412 }],
		[{ "v": 2412 }],
		[{ "c": 2412 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_bike24.com_0",
		0,
		"^https?://(www\\.)?bike24\\.com/",
		10,
		[],
		[{ "e": 2413 }],
		[{ "v": 2413 }],
		[{ "c": 2413 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_brazzers.com_0",
		0,
		"^https?://(www\\.)?brazzers\\.com/",
		10,
		[],
		[{ "e": 2414 }],
		[{ "v": 2414 }],
		[{ "c": 2414 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_bricksandlogic.co.uk_o5o",
		0,
		"^https?://(www\\.)?bricksandlogic\\.co\\.uk/",
		10,
		[],
		[{ "e": 2415 }],
		[{ "v": 2415 }],
		[{ "wait": 500 }, { "c": 2415 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2415
		}],
		{}
	],
	[
		1,
		"auto_GB_brightondome.org_iz9",
		0,
		"^https?://(www\\.)?brightondome\\.org/",
		10,
		[],
		[{ "e": 2416 }],
		[{ "v": 2416 }],
		[{ "wait": 500 }, { "c": 2416 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2416
		}],
		{}
	],
	[
		1,
		"auto_GB_businessclass.com_0",
		0,
		"^https?://(www\\.)?businessclass\\.com/",
		10,
		[],
		[{ "e": 2417 }],
		[{ "v": 2417 }],
		[{ "c": 2417 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_capcut.com_0",
		0,
		"^https?://(www\\.)?capcut\\.com/",
		10,
		[],
		[{ "e": 2418 }],
		[{ "v": 2418 }],
		[{ "c": 2418 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_cardmarket.com_oxh",
		0,
		"^https?://(www\\.)?cardmarket\\.com/",
		10,
		[],
		[{ "e": 2419 }],
		[{ "v": 2419 }],
		[{ "wait": 500 }, { "c": 2419 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2419
		}],
		{}
	],
	[
		1,
		"auto_GB_catawiki.com_0",
		0,
		"^https?://(www\\.)?catawiki\\.com/",
		10,
		[],
		[{ "e": 2420 }],
		[{ "v": 2420 }],
		[{ "c": 2420 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_charlesclinkard.co.uk_0",
		0,
		"^https?://(www\\.)?charlesclinkard\\.co\\.uk/",
		10,
		[],
		[{ "e": 2421 }],
		[{ "v": 2421 }],
		[{ "wait": 500 }, { "c": 2421 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2421
		}],
		{}
	],
	[
		1,
		"auto_GB_chilternseeds.co.uk_0",
		0,
		"^https?://(www\\.)?chilternseeds\\.co\\.uk/",
		10,
		[],
		[{ "e": 2422 }],
		[{ "v": 2422 }],
		[{ "wait": 500 }, { "c": 2422 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2422
		}],
		{}
	],
	[
		1,
		"auto_GB_chrono24.com_0",
		0,
		"^https?://(www\\.)?chrono24\\.com/",
		10,
		[],
		[{ "e": 2423 }],
		[{ "v": 2423 }],
		[{ "c": 2423 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_cpfc.co.uk_0",
		0,
		"^https?://(www\\.)?cpfc\\.co\\.uk/",
		10,
		[],
		[{ "e": 2424 }],
		[{ "v": 2424 }],
		[{ "c": 2424 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_deezer.com_0",
		0,
		"^https?://(www\\.)?deezer\\.com/",
		10,
		[],
		[{ "e": 2425 }],
		[{ "v": 2425 }],
		[{ "c": 2425 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_edinburghcastle.scot_h2e",
		0,
		"^https?://(www\\.)?edinburghcastle\\.scot/",
		10,
		[],
		[{ "e": 2426 }],
		[{ "v": 2426 }],
		[{ "wait": 500 }, { "c": 2426 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2426
		}],
		{}
	],
	[
		1,
		"auto_GB_europarl.europa.eu_0",
		0,
		"^https?://(www\\.)?europarl\\.europa\\.eu/",
		10,
		[],
		[{ "e": 2427 }],
		[{ "v": 2427 }],
		[{ "c": 2427 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_everysaving.co.uk_38t",
		0,
		"^https?://(www\\.)?everysaving\\.co\\.uk/",
		10,
		[],
		[{ "e": 2428 }],
		[{ "v": 2428 }],
		[{ "c": 2428 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_ewrc-results.com_y5f",
		0,
		"^https?://(www\\.)?ewrc-results\\.com/",
		10,
		[],
		[{ "e": 2429 }],
		[{ "v": 2429 }],
		[{ "wait": 500 }, { "c": 2429 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2429
		}],
		{}
	],
	[
		1,
		"auto_GB_f6s.com_221",
		0,
		"^https?://(www\\.)?f6s\\.com/",
		10,
		[],
		[{ "e": 2430 }],
		[{ "v": 2430 }],
		[{ "wait": 500 }, { "c": 2430 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2430
		}],
		{}
	],
	[
		1,
		"auto_GB_faphouse.com_0",
		0,
		"^https?://(www\\.)?faphouse\\.com/",
		10,
		[],
		[{ "e": 2431 }],
		[{ "v": 2431 }],
		[{ "c": 2431 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_farmergracy.co.uk_dl3",
		0,
		"^https?://(www\\.)?farmergracy\\.co\\.uk/",
		10,
		[],
		[{ "e": 2432 }],
		[{ "v": 2432 }],
		[{ "wait": 500 }, { "c": 2432 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2432
		}],
		{}
	],
	[
		1,
		"auto_GB_fca.org.uk_9p9",
		0,
		"^https?://(www\\.)?fca\\.org\\.uk/",
		10,
		[],
		[{ "e": 2433 }],
		[{ "v": 2433 }],
		[{ "wait": 500 }, { "c": 2433 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2433
		}],
		{}
	],
	[
		1,
		"auto_GB_forum.affinity.serif.com_0",
		0,
		"^https?://(www\\.)?forum\\.affinity\\.serif\\.com/",
		10,
		[],
		[{ "e": 2434 }],
		[{ "v": 2434 }],
		[{ "c": 2434 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_garden4less.co.uk_0",
		0,
		"^https?://(www\\.)?garden4less\\.co\\.uk/",
		10,
		[],
		[{ "e": 2435 }],
		[{ "v": 2435 }],
		[{ "c": 2435 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_glassesdirect.co.uk_bt9",
		0,
		"^https?://(www\\.)?glassesdirect\\.co\\.uk/",
		10,
		[],
		[{ "e": 2436 }],
		[{ "v": 2436 }],
		[{ "wait": 500 }, { "c": 2436 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2436
		}],
		{}
	],
	[
		1,
		"auto_GB_handbook.fca.org.uk_0",
		0,
		"^https?://(www\\.)?handbook\\.fca\\.org\\.uk/",
		10,
		[],
		[{ "e": 2437 }],
		[{ "v": 2437 }],
		[{ "wait": 500 }, { "c": 2437 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2437
		}],
		{}
	],
	[
		1,
		"auto_GB_historicenvironment.scot_0",
		0,
		"^https?://(www\\.)?historicenvironment\\.scot/",
		10,
		[],
		[{ "e": 2438 }],
		[{ "v": 2438 }],
		[{ "c": 2438 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_ionos.co.uk_c0a",
		0,
		"^https?://(www\\.)?ionos\\.co\\.uk/",
		10,
		[],
		[{ "e": 2439 }],
		[{ "v": 2439 }],
		[{ "wait": 500 }, { "c": 2439 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2439
		}],
		{}
	],
	[
		1,
		"auto_GB_kick.com_0",
		0,
		"^https?://(www\\.)?kick\\.com/",
		10,
		[],
		[{ "e": 2440 }],
		[{ "v": 2440 }],
		[{ "c": 2440 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_kinopoisk.ru_0",
		0,
		"^https?://(www\\.)?kinopoisk\\.ru/",
		10,
		[],
		[{ "e": 2441 }],
		[{ "v": 2441 }],
		[{ "wait": 500 }, { "c": 2441 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2441
		}],
		{}
	],
	[
		1,
		"auto_GB_kirklees.gov.uk_0",
		0,
		"^https?://(www\\.)?kirklees\\.gov\\.uk/",
		10,
		[],
		[{ "e": 2442 }],
		[{ "v": 2442 }],
		[{ "c": 2442 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_lancaster.ac.uk_0",
		0,
		"^https?://(www\\.)?lancaster\\.ac\\.uk/",
		10,
		[],
		[{ "e": 2443 }],
		[{ "v": 2443 }],
		[{ "c": 2443 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_lustery.com_0",
		0,
		"^https?://(www\\.)?lustery\\.com/",
		10,
		[],
		[{ "e": 2444 }],
		[{ "v": 2444 }],
		[{ "c": 2444 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_m.yandex.com_0_+2",
		0,
		"^https?://(www\\.)?m\\.yandex\\.com/|^https?://(www\\.)?online\\.yandex\\.com/|^https?://(www\\.)?xmlsearch\\.yandex\\.ru/",
		10,
		[],
		[{ "e": 2445 }],
		[{ "v": 2445 }],
		[{
			"text": "Allow essential cookies",
			"c": 2445
		}],
		[],
		{}
	],
	[
		1,
		"auto_GB_mypharmacy.co.uk_0",
		0,
		"^https?://(www\\.)?mypharmacy\\.co\\.uk/",
		10,
		[],
		[{ "e": 2446 }],
		[{ "v": 2446 }],
		[{
			"text": "DENY ALL",
			"c": 2446
		}],
		[],
		{}
	],
	[
		1,
		"auto_GB_onestream.co.uk_dpx",
		0,
		"^https?://(www\\.)?onestream\\.co\\.uk/",
		10,
		[],
		[{ "e": 2447 }],
		[{ "v": 2447 }],
		[{ "wait": 500 }, { "c": 2447 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2447
		}],
		{}
	],
	[
		1,
		"auto_GB_outfox.energy_6ux",
		0,
		"^https?://(www\\.)?outfox\\.energy/",
		10,
		[],
		[{ "e": 2448 }],
		[{ "v": 2448 }],
		[{ "wait": 500 }, { "c": 2448 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2448
		}],
		{}
	],
	[
		1,
		"auto_GB_partscentre.co.uk_s70",
		0,
		"^https?://(www\\.)?partscentre\\.co\\.uk/",
		10,
		[],
		[{ "e": 2449 }],
		[{ "v": 2449 }],
		[{ "wait": 500 }, { "c": 2449 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2449
		}],
		{}
	],
	[
		1,
		"auto_GB_plumbingworld.co.uk_vmi",
		0,
		"^https?://(www\\.)?plumbingworld\\.co\\.uk/",
		10,
		[],
		[{ "e": 2450 }],
		[{ "v": 2450 }],
		[{ "wait": 500 }, { "c": 2450 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2450
		}],
		{}
	],
	[
		1,
		"auto_GB_reading.gov.uk_0",
		0,
		"^https?://(www\\.)?reading\\.gov\\.uk/",
		10,
		[],
		[{ "e": 2451 }],
		[{ "v": 2451 }],
		[{ "wait": 500 }, { "c": 2451 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2451
		}],
		{}
	],
	[
		1,
		"auto_GB_shopify.com_0",
		0,
		"^https?://(www\\.)?shopify\\.com/",
		10,
		[],
		[{ "e": 2452 }],
		[{ "v": 2452 }],
		[{ "c": 2452 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_sso.passport.yandex.ru_0_+4",
		0,
		"^https?://(www\\.)?sso\\.passport\\.yandex\\.ru/|^https?://(www\\.)?translate\\.yandex\\.com/|^https?://(www\\.)?ya\\.ru/|^https?://(www\\.)?yandex\\.com\\.tr/|^https?://(www\\.)?yandex\\.com/",
		10,
		[],
		[{ "e": 2441 }],
		[{ "v": 2441 }],
		[{ "c": 2441 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_stoneacre.co.uk_73c",
		0,
		"^https?://(www\\.)?stoneacre\\.co\\.uk/",
		10,
		[],
		[{ "e": 2453 }],
		[{ "v": 2453 }],
		[{ "wait": 500 }, { "c": 2453 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2453
		}],
		{}
	],
	[
		1,
		"auto_GB_supremecourt.uk_0",
		0,
		"^https?://(www\\.)?supremecourt\\.uk/",
		10,
		[],
		[{ "e": 2454 }],
		[{ "v": 2454 }],
		[{ "c": 2454 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2454
		}],
		{}
	],
	[
		1,
		"auto_GB_thebatteryshop.co.uk_0",
		0,
		"^https?://(www\\.)?thebatteryshop\\.co\\.uk/",
		10,
		[],
		[{ "e": 2455 }],
		[{ "v": 2455 }],
		[{
			"text": "Reject All",
			"c": 2455
		}],
		[],
		{}
	],
	[
		1,
		"auto_GB_thebushcraftstore.co.uk_0_+1",
		0,
		"^https?://(www\\.)?thebushcraftstore\\.co\\.uk/|^https?://(www\\.)?thewoolfactory\\.co\\.uk/",
		10,
		[],
		[{ "e": 2456 }],
		[{ "v": 2456 }],
		[{ "wait": 500 }, { "c": 2456 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2456
		}],
		{}
	],
	[
		1,
		"auto_GB_trove.scot_xtg",
		0,
		"^https?://(www\\.)?trove\\.scot/",
		10,
		[],
		[{ "e": 2457 }],
		[{ "v": 2457 }],
		[{ "wait": 500 }, { "c": 2457 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2457
		}],
		{}
	],
	[
		1,
		"auto_GB_truecaller.com_0",
		0,
		"^https?://(www\\.)?truecaller\\.com/",
		10,
		[],
		[{ "e": 2458 }],
		[{ "v": 2458 }],
		[{ "c": 2458 }],
		[],
		{}
	],
	[
		1,
		"auto_GB_vetuk.co.uk_0",
		0,
		"^https?://(www\\.)?vetuk\\.co\\.uk/",
		10,
		[],
		[{ "e": 2459 }],
		[{ "v": 2459 }],
		[{ "wait": 500 }, { "c": 2459 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2459
		}],
		{}
	],
	[
		1,
		"auto_GB_virgin.com_0",
		0,
		"^https?://(www\\.)?virgin\\.com/",
		10,
		[],
		[{ "e": 2460 }],
		[{ "v": 2460 }],
		[{ "wait": 500 }, { "c": 2460 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2460
		}],
		{}
	],
	[
		1,
		"auto_GB_vrhump.com_pb5",
		0,
		"^https?://(www\\.)?vrhump\\.com/",
		10,
		[],
		[{ "e": 2461 }],
		[{ "v": 2461 }],
		[{ "wait": 500 }, { "c": 2461 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2461
		}],
		{}
	],
	[
		1,
		"auto_GB_weldricks.co.uk_0",
		0,
		"^https?://(www\\.)?weldricks\\.co\\.uk/",
		10,
		[],
		[{ "e": 2462 }],
		[{ "v": 2462 }],
		[{ "wait": 500 }, { "c": 2462 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2462
		}],
		{}
	],
	[
		1,
		"auto_NL_3cx.com_0mf",
		0,
		"^https?://(www\\.)?3cx\\.com/",
		10,
		[],
		[{ "e": 2463 }],
		[{ "v": 2463 }],
		[{ "wait": 500 }, { "c": 2463 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2463
		}],
		{}
	],
	[
		1,
		"auto_NL_aegon.nl_y2y",
		0,
		"^https?://(www\\.)?aegon\\.nl/",
		10,
		[],
		[{ "e": 2464 }],
		[{ "v": 2464 }],
		[{ "wait": 500 }, { "c": 2464 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2464
		}],
		{}
	],
	[
		1,
		"auto_NL_app.chatgirl.nl_uqi",
		0,
		"^https?://(www\\.)?app\\.chatgirl\\.nl/",
		10,
		[],
		[{ "e": 2465 }],
		[{ "v": 2465 }],
		[{ "wait": 500 }, { "c": 2465 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2465
		}],
		{}
	],
	[
		1,
		"auto_NL_beekman.nl_f9e",
		0,
		"^https?://(www\\.)?beekman\\.nl/",
		10,
		[],
		[{ "e": 2466 }],
		[{ "v": 2466 }],
		[{ "wait": 500 }, { "c": 2466 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2466
		}],
		{}
	],
	[
		1,
		"auto_NL_berivita.com_q3z",
		0,
		"^https?://(www\\.)?berivita\\.com/",
		10,
		[],
		[{ "e": 2467 }],
		[{ "v": 2467 }],
		[{ "wait": 500 }, { "c": 2467 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2467
		}],
		{}
	],
	[
		1,
		"auto_NL_bibliotheekaanzet.nl_mh6",
		0,
		"^https?://(www\\.)?bibliotheekaanzet\\.nl/",
		10,
		[],
		[{ "e": 2468 }],
		[{ "v": 2468 }],
		[{ "wait": 500 }, { "c": 2468 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2468
		}],
		{}
	],
	[
		1,
		"auto_NL_bk.nl_tx4",
		0,
		"^https?://(www\\.)?bk\\.nl/",
		10,
		[],
		[{ "e": 2206 }],
		[{ "v": 2206 }],
		[{ "wait": 500 }, { "c": 2206 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2206
		}],
		{}
	],
	[
		1,
		"auto_NL_blgwonen.nl_g5c",
		0,
		"^https?://(www\\.)?blgwonen\\.nl/",
		10,
		[],
		[{ "e": 2469 }],
		[{ "v": 2469 }],
		[{ "wait": 500 }, { "c": 2469 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2469
		}],
		{}
	],
	[
		1,
		"auto_NL_bonprix.nl_ovi",
		0,
		"^https?://(www\\.)?bonprix\\.nl/",
		10,
		[],
		[{ "e": 2470 }],
		[{ "v": 2470 }],
		[{ "wait": 500 }, { "c": 2470 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2470
		}],
		{}
	],
	[
		1,
		"auto_NL_braumarkt.com_wfi",
		0,
		"^https?://(www\\.)?braumarkt\\.com/",
		10,
		[],
		[{ "e": 2347 }],
		[{ "v": 2347 }],
		[{ "wait": 500 }, { "c": 2347 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2347
		}],
		{}
	],
	[
		1,
		"auto_NL_brillen24.nl_08c",
		0,
		"^https?://(www\\.)?brillen24\\.nl/",
		10,
		[],
		[{ "e": 2471 }],
		[{ "v": 2471 }],
		[{ "wait": 500 }, { "c": 2471 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2471
		}],
		{}
	],
	[
		1,
		"auto_NL_chasse.nl_gs1",
		0,
		"^https?://(www\\.)?chasse\\.nl/",
		10,
		[],
		[{ "e": 2472 }],
		[{ "v": 2472 }],
		[{ "wait": 500 }, { "c": 2472 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2472
		}],
		{}
	],
	[
		1,
		"auto_NL_cheaptickets.nl_cwt",
		0,
		"^https?://(www\\.)?cheaptickets\\.nl/",
		10,
		[],
		[{ "e": 2473 }],
		[{ "v": 2473 }],
		[{ "wait": 500 }, { "c": 2473 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2473
		}],
		{}
	],
	[
		1,
		"auto_NL_chillplanet.nl_xcp",
		0,
		"^https?://(www\\.)?chillplanet\\.nl/",
		10,
		[],
		[{ "e": 2474 }],
		[{ "v": 2474 }],
		[{ "wait": 500 }, { "c": 2474 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2474
		}],
		{}
	],
	[
		1,
		"auto_NL_chrono24.nl_dco",
		0,
		"^https?://(www\\.)?chrono24\\.nl/",
		10,
		[],
		[{ "e": 2253 }],
		[{ "v": 2253 }],
		[{ "wait": 500 }, { "c": 2253 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2253
		}],
		{}
	],
	[
		1,
		"auto_NL_clinicaldiagnostics.nl_pmu",
		0,
		"^https?://(www\\.)?clinicaldiagnostics\\.nl/",
		10,
		[],
		[{ "e": 2475 }],
		[{ "v": 2475 }],
		[{ "wait": 500 }, { "c": 2475 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2475
		}],
		{}
	],
	[
		1,
		"auto_NL_consumentenbond.nl_53g",
		0,
		"^https?://(www\\.)?consumentenbond\\.nl/",
		10,
		[],
		[{ "e": 2476 }],
		[{ "v": 2476 }],
		[{ "wait": 500 }, { "c": 2476 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2476
		}],
		{}
	],
	[
		1,
		"auto_NL_denboschregion.nl_4x6",
		0,
		"^https?://(www\\.)?denboschregion\\.nl/",
		10,
		[],
		[{ "e": 2477 }],
		[{ "v": 2477 }],
		[{ "wait": 500 }, { "c": 2477 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2477
		}],
		{}
	],
	[
		1,
		"auto_NL_denieuwebibliotheek.nl_c1z",
		0,
		"^https?://(www\\.)?denieuwebibliotheek\\.nl/",
		10,
		[],
		[{ "e": 2478 }],
		[{ "v": 2478 }],
		[{ "wait": 500 }, { "c": 2478 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2478
		}],
		{}
	],
	[
		1,
		"auto_NL_discountoffice.nl_2fb",
		0,
		"^https?://(www\\.)?discountoffice\\.nl/",
		10,
		[],
		[{ "e": 2479 }],
		[{ "v": 2479 }],
		[{ "wait": 500 }, { "c": 2479 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2479
		}],
		{}
	],
	[
		1,
		"auto_NL_ditjesendatjes.nl_0sa",
		0,
		"^https?://(www\\.)?ditjesendatjes\\.nl/",
		10,
		[],
		[{ "e": 2480 }],
		[{ "v": 2480 }],
		[{ "wait": 500 }, { "c": 2480 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2480
		}],
		{}
	],
	[
		1,
		"auto_NL_duitslandinstituut.nl_d4q",
		0,
		"^https?://(www\\.)?duitslandinstituut\\.nl/",
		10,
		[],
		[{ "e": 2481 }],
		[{ "v": 2481 }],
		[{ "wait": 500 }, { "c": 2481 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2481
		}],
		{}
	],
	[
		1,
		"auto_NL_effenaar.nl_nia",
		0,
		"^https?://(www\\.)?effenaar\\.nl/",
		10,
		[],
		[{ "e": 2482 }],
		[{ "v": 2482 }],
		[{ "wait": 500 }, { "c": 2482 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2482
		}],
		{}
	],
	[
		1,
		"auto_NL_fietsonderdelenoutlet.nl_x8u",
		0,
		"^https?://(www\\.)?fietsonderdelenoutlet\\.nl/",
		10,
		[],
		[{ "e": 2483 }],
		[{ "v": 2483 }],
		[{ "wait": 500 }, { "c": 2483 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2483
		}],
		{}
	],
	[
		1,
		"auto_NL_followthebeat.nl_mx5",
		0,
		"^https?://(www\\.)?followthebeat\\.nl/",
		10,
		[],
		[{ "e": 2484 }],
		[{ "v": 2484 }],
		[{ "wait": 500 }, { "c": 2484 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2484
		}],
		{}
	],
	[
		1,
		"auto_NL_frankenergie.nl_9xh",
		0,
		"^https?://(www\\.)?frankenergie\\.nl/",
		10,
		[],
		[{ "e": 2485 }],
		[{ "v": 2485 }],
		[{ "wait": 500 }, { "c": 2485 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2485
		}],
		{}
	],
	[
		1,
		"auto_NL_gezondheidenwetenschap.be_zgi",
		0,
		"^https?://(www\\.)?gezondheidenwetenschap\\.be/",
		10,
		[],
		[{ "e": 2486 }],
		[{ "v": 2486 }],
		[{ "wait": 500 }, { "c": 2486 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2486
		}],
		{}
	],
	[
		1,
		"auto_NL_independer.nl_ind",
		0,
		"^https?://(www\\.)?independer\\.nl/",
		10,
		[2487],
		[{ "e": 2488 }],
		[{ "v": 2488 }],
		[{ "c": 2488 }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 2487
		}],
		{}
	],
	[
		1,
		"auto_NL_info.mumc.nl_8s5",
		0,
		"^https?://(www\\.)?info\\.mumc\\.nl/",
		10,
		[],
		[{ "e": 2489 }],
		[{ "v": 2489 }],
		[{ "wait": 500 }, { "c": 2489 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2489
		}],
		{}
	],
	[
		1,
		"auto_NL_inshared.nl_p70",
		0,
		"^https?://(www\\.)?inshared\\.nl/",
		10,
		[],
		[{ "e": 2490 }],
		[{ "v": 2490 }],
		[{ "wait": 500 }, { "c": 2490 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2490
		}],
		{}
	],
	[
		1,
		"auto_NL_isvw.nl_7x0",
		0,
		"^https?://(www\\.)?isvw\\.nl/",
		10,
		[],
		[{ "e": 2491 }],
		[{ "v": 2491 }],
		[{ "wait": 500 }, { "c": 2491 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2491
		}],
		{}
	],
	[
		1,
		"auto_NL_kaartje2go.nl_ecw",
		0,
		"^https?://(www\\.)?kaartje2go\\.nl/",
		10,
		[],
		[{ "e": 2492 }],
		[{ "v": 2492 }],
		[{ "wait": 500 }, { "c": 2492 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2492
		}],
		{}
	],
	[
		1,
		"auto_NL_kathmandu.nl_7j4",
		0,
		"^https?://(www\\.)?kathmandu\\.nl/",
		10,
		[],
		[{ "e": 2493 }],
		[{ "v": 2493 }],
		[{ "wait": 500 }, { "c": 2493 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2493
		}],
		{}
	],
	[
		1,
		"auto_NL_kvk.nl_0wn",
		0,
		"^https?://(www\\.)?kvk\\.nl/",
		10,
		[],
		[{ "e": 2494 }],
		[{ "v": 2494 }],
		[{ "wait": 500 }, { "c": 2494 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2494
		}],
		{}
	],
	[
		1,
		"auto_NL_labplusarts.nl_feg",
		0,
		"^https?://(www\\.)?labplusarts\\.nl/",
		10,
		[],
		[{ "e": 2495 }],
		[{ "v": 2495 }],
		[{ "wait": 500 }, { "c": 2495 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2495
		}],
		{}
	],
	[
		1,
		"auto_NL_lakenhal.nl_3go",
		0,
		"^https?://(www\\.)?lakenhal\\.nl/",
		10,
		[],
		[{ "e": 2496 }],
		[{ "v": 2496 }],
		[{ "wait": 500 }, { "c": 2496 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2496
		}],
		{}
	],
	[
		1,
		"auto_NL_magazines-motivatie.nl_6o1",
		0,
		"^https?://(www\\.)?magazines-motivatie\\.nl/",
		10,
		[],
		[{ "e": 2497 }],
		[{ "v": 2497 }],
		[{ "wait": 500 }, { "c": 2497 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2497
		}],
		{}
	],
	[
		1,
		"auto_NL_makro.nl_ror",
		0,
		"^https?://(www\\.)?makro\\.nl/",
		10,
		[],
		[{ "e": 2498 }],
		[{ "v": 2498 }],
		[{ "wait": 500 }, { "c": 2498 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2498
		}],
		{}
	],
	[
		1,
		"auto_NL_manufactum.nl_w9l",
		0,
		"^https?://(www\\.)?manufactum\\.nl/",
		10,
		[],
		[{ "e": 2274 }],
		[{ "v": 2274 }],
		[{ "wait": 500 }, { "c": 2274 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2274
		}],
		{}
	],
	[
		1,
		"auto_NL_matrassencheck.nl_cap",
		0,
		"^https?://(www\\.)?matrassencheck\\.nl/",
		10,
		[],
		[{ "e": 2499 }],
		[{ "v": 2499 }],
		[{ "wait": 500 }, { "c": 2499 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2499
		}],
		{}
	],
	[
		1,
		"auto_NL_mijn.simyo.nl_xm9",
		0,
		"^https?://(www\\.)?mijn\\.simyo\\.nl/",
		10,
		[],
		[{ "e": 2500 }],
		[{ "v": 2500 }],
		[{ "wait": 500 }, { "c": 2500 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2500
		}],
		{}
	],
	[
		1,
		"auto_NL_mijngelderland.nl_rkj",
		0,
		"^https?://(www\\.)?mijngelderland\\.nl/",
		10,
		[],
		[{ "e": 2501 }],
		[{ "v": 2501 }],
		[{ "wait": 500 }, { "c": 2501 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2501
		}],
		{}
	],
	[
		1,
		"auto_NL_milieucentraal.nl_p66",
		0,
		"^https?://(www\\.)?milieucentraal\\.nl/",
		10,
		[],
		[{ "e": 2502 }],
		[{ "v": 2502 }],
		[{ "wait": 500 }, { "c": 2502 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2502
		}],
		{}
	],
	[
		1,
		"auto_NL_muziekgebouw.nl_cob",
		0,
		"^https?://(www\\.)?muziekgebouw\\.nl/",
		10,
		[],
		[{ "e": 2472 }],
		[{ "v": 2472 }],
		[{ "wait": 500 }, { "c": 2472 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2472
		}],
		{}
	],
	[
		1,
		"auto_NL_nec-nijmegen.nl_04y",
		0,
		"^https?://(www\\.)?nec-nijmegen\\.nl/",
		10,
		[],
		[{ "e": 2503 }],
		[{ "v": 2503 }],
		[{ "wait": 500 }, { "c": 2503 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2503
		}],
		{}
	],
	[
		1,
		"auto_NL_nl.spankbang.com_bnh_+1",
		0,
		"^https?://(www\\.)?nl\\.spankbang\\.com/|^https?://(www\\.)?spankbang\\.com/",
		10,
		[],
		[{ "e": 2504 }],
		[{ "v": 2504 }],
		[{ "wait": 500 }, { "c": 2504 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2504
		}],
		{}
	],
	[
		1,
		"auto_NL_orpheus.nl_cxu",
		0,
		"^https?://(www\\.)?orpheus\\.nl/",
		10,
		[],
		[{ "e": 2472 }],
		[{ "v": 2472 }],
		[{ "wait": 500 }, { "c": 2472 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2472
		}],
		{}
	],
	[
		1,
		"auto_NL_partnerplatform.bol.com_k9h",
		0,
		"^https?://(www\\.)?partnerplatform\\.bol\\.com/",
		10,
		[],
		[{ "e": 2505 }],
		[{ "v": 2505 }],
		[{ "wait": 500 }, { "c": 2505 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2505
		}],
		{}
	],
	[
		1,
		"auto_NL_persportaal.anp.nl_o32",
		0,
		"^https?://(www\\.)?persportaal\\.anp\\.nl/",
		10,
		[],
		[{ "e": 2506 }],
		[{ "v": 2506 }],
		[{ "wait": 500 }, { "c": 2506 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2506
		}],
		{}
	],
	[
		1,
		"auto_NL_planteenolijfboom.nl_pdo",
		0,
		"^https?://(www\\.)?planteenolijfboom\\.nl/",
		10,
		[],
		[{ "e": 2507 }],
		[{ "v": 2507 }],
		[{ "wait": 500 }, { "c": 2507 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2507
		}],
		{}
	],
	[
		1,
		"auto_NL_psv.nl_2pt",
		0,
		"^https?://(www\\.)?psv\\.nl/",
		10,
		[],
		[{ "e": 2508 }],
		[{ "v": 2508 }],
		[{ "wait": 500 }, { "c": 2508 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2508
		}],
		{}
	],
	[
		1,
		"auto_NL_sanitairkamer.nl_vig",
		0,
		"^https?://(www\\.)?sanitairkamer\\.nl/",
		10,
		[],
		[{ "e": 2509 }],
		[{ "v": 2509 }],
		[{ "wait": 500 }, { "c": 2509 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2509
		}],
		{}
	],
	[
		1,
		"auto_NL_schaapcitroen.nl_6v0",
		0,
		"^https?://(www\\.)?schaapcitroen\\.nl/",
		10,
		[],
		[{ "e": 2510 }],
		[{ "v": 2510 }],
		[{ "wait": 500 }, { "c": 2510 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2510
		}],
		{}
	],
	[
		1,
		"auto_NL_scouting.nl_ue4",
		0,
		"^https?://(www\\.)?scouting\\.nl/",
		10,
		[],
		[{ "e": 2511 }],
		[{ "v": 2511 }],
		[{ "wait": 500 }, { "c": 2511 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2511
		}],
		{}
	],
	[
		1,
		"auto_NL_slachtofferhulp.nl_4m4",
		0,
		"^https?://(www\\.)?slachtofferhulp\\.nl/",
		10,
		[],
		[{ "e": 2512 }],
		[{ "v": 2512 }],
		[{ "wait": 500 }, { "c": 2512 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2512
		}],
		{}
	],
	[
		1,
		"auto_NL_sprinklr.co_3ww",
		0,
		"^https?://(www\\.)?sprinklr\\.co/",
		10,
		[],
		[{ "e": 2206 }],
		[{ "v": 2206 }],
		[{ "wait": 500 }, { "c": 2206 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2206
		}],
		{}
	],
	[
		1,
		"auto_NL_stadsschouwburg-utrecht.nl_tcz",
		0,
		"^https?://(www\\.)?stadsschouwburg-utrecht\\.nl/",
		10,
		[],
		[{ "e": 2513 }],
		[{ "v": 2513 }],
		[{ "wait": 500 }, { "c": 2513 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2513
		}],
		{}
	],
	[
		1,
		"auto_NL_stedelijkmuseumschiedam.nl_y6j",
		0,
		"^https?://(www\\.)?stedelijkmuseumschiedam\\.nl/",
		10,
		[],
		[{ "e": 2409 }],
		[{ "v": 2409 }],
		[{ "wait": 500 }, { "c": 2409 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2409
		}],
		{}
	],
	[
		1,
		"auto_NL_texelsecourant.nl_v4b",
		0,
		"^https?://(www\\.)?texelsecourant\\.nl/",
		10,
		[],
		[{ "e": 2514 }],
		[{ "v": 2514 }],
		[{ "wait": 500 }, { "c": 2514 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2514
		}],
		{}
	],
	[
		1,
		"auto_NL_ticketswap.com_d3j",
		0,
		"^https?://(www\\.)?ticketswap\\.com/",
		10,
		[],
		[{ "e": 2515 }],
		[{ "v": 2515 }],
		[{ "wait": 500 }, { "c": 2515 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2515
		}],
		{}
	],
	[
		1,
		"auto_NL_uit.inapeldoorn.nl_gt5",
		0,
		"^https?://(www\\.)?uit\\.inapeldoorn\\.nl/",
		10,
		[],
		[{ "e": 2516 }],
		[{ "v": 2516 }],
		[{ "wait": 500 }, { "c": 2516 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2516
		}],
		{}
	],
	[
		1,
		"auto_NL_vlaanderen.be_c8w",
		0,
		"^https?://(www\\.)?vlaanderen\\.be/",
		10,
		[],
		[{ "e": 2517 }],
		[{ "v": 2517 }],
		[{ "wait": 500 }, { "c": 2517 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2517
		}],
		{}
	],
	[
		1,
		"auto_NL_vvaa.nl_avs",
		0,
		"^https?://(www\\.)?vvaa\\.nl/",
		10,
		[],
		[{ "e": 2518 }],
		[{ "v": 2518 }],
		[{ "wait": 500 }, { "c": 2518 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2518
		}],
		{}
	],
	[
		1,
		"auto_NL_werkenbijdefensie.nl_0cv",
		0,
		"^https?://(www\\.)?werkenbijdefensie\\.nl/",
		10,
		[],
		[{ "e": 2519 }],
		[{ "v": 2519 }],
		[{ "wait": 500 }, { "c": 2519 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2519
		}],
		{}
	],
	[
		1,
		"auto_NL_winkelstraat.nl_hxj",
		0,
		"^https?://(www\\.)?winkelstraat\\.nl/",
		10,
		[],
		[{ "e": 2520 }],
		[{ "v": 2520 }],
		[{ "wait": 500 }, { "c": 2520 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2520
		}],
		{}
	],
	[
		1,
		"auto_NL_woonnetrijnmond.nl_itj",
		0,
		"^https?://(www\\.)?woonnetrijnmond\\.nl/",
		10,
		[],
		[{ "e": 2521 }],
		[{ "v": 2521 }],
		[{ "wait": 500 }, { "c": 2521 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2521
		}],
		{}
	],
	[
		1,
		"auto_NL_zuidas.nl_abm",
		0,
		"^https?://(www\\.)?zuidas\\.nl/",
		10,
		[],
		[{ "e": 2522 }],
		[{ "v": 2522 }],
		[{ "wait": 500 }, { "c": 2522 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2522
		}],
		{}
	],
	[
		1,
		"auto_NO_apxml.com_l6n",
		0,
		"^https?://(www\\.)?apxml\\.com/",
		10,
		[],
		[{ "e": 2523 }],
		[{ "v": 2523 }],
		[{ "wait": 500 }, { "c": 2523 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2523
		}],
		{}
	],
	[
		1,
		"auto_NO_arbetsformedlingen.se_wxz",
		0,
		"^https?://(www\\.)?arbetsformedlingen\\.se/",
		10,
		[],
		[{ "e": 2524 }],
		[{ "v": 2524 }],
		[{ "wait": 500 }, { "c": 2524 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2524
		}],
		{}
	],
	[
		1,
		"auto_NO_avanza.se_b5b",
		0,
		"^https?://(www\\.)?avanza\\.se/",
		10,
		[],
		[{ "e": 2525 }],
		[{ "v": 2525 }],
		[{ "wait": 500 }, { "c": 2525 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2525
		}],
		{}
	],
	[
		1,
		"auto_NO_avidafinance.com_jwc",
		0,
		"^https?://(www\\.)?avidafinance\\.com/",
		10,
		[],
		[{ "e": 2526 }],
		[{ "v": 2526 }],
		[{ "wait": 500 }, { "c": 2526 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2526
		}],
		{}
	],
	[
		1,
		"auto_NO_beducated.com_jjt",
		0,
		"^https?://(www\\.)?beducated\\.com/",
		10,
		[],
		[{ "e": 2527 }],
		[{ "v": 2527 }],
		[{ "wait": 500 }, { "c": 2527 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2527
		}],
		{}
	],
	[
		1,
		"auto_NO_dsa.no_w2b",
		0,
		"^https?://(www\\.)?dsa\\.no/",
		10,
		[],
		[{ "e": 2528 }],
		[{ "v": 2528 }],
		[{ "wait": 500 }, { "c": 2528 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2528
		}],
		{}
	],
	[
		1,
		"auto_NO_goteborg.com_q7v",
		0,
		"^https?://(www\\.)?goteborg\\.com/",
		10,
		[],
		[{ "e": 2529 }],
		[{ "v": 2529 }],
		[{ "wait": 500 }, { "c": 2529 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2529
		}],
		{}
	],
	[
		1,
		"auto_NO_hacksmith.store_49t",
		0,
		"^https?://(www\\.)?hacksmith\\.store/",
		10,
		[],
		[{ "e": 2530 }],
		[{ "v": 2530 }],
		[{ "wait": 500 }, { "c": 2530 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2530
		}],
		{}
	],
	[
		1,
		"auto_NO_hotelfinse1222.no_zpm",
		0,
		"^https?://(www\\.)?hotelfinse1222\\.no/",
		10,
		[],
		[{ "e": 2507 }],
		[{ "v": 2507 }],
		[{ "wait": 500 }, { "c": 2507 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2507
		}],
		{}
	],
	[
		1,
		"auto_NO_jaksta.com_own",
		0,
		"^https?://(www\\.)?jaksta\\.com/",
		10,
		[],
		[{ "e": 2531 }],
		[{ "v": 2531 }],
		[{ "wait": 500 }, { "c": 2531 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2531
		}],
		{}
	],
	[
		1,
		"auto_NO_ledigajobb.se_tx3",
		0,
		"^https?://(www\\.)?ledigajobb\\.se/",
		10,
		[],
		[{ "e": 2532 }],
		[{ "v": 2532 }],
		[{ "wait": 500 }, { "c": 2532 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2532
		}],
		{}
	],
	[
		1,
		"auto_NO_pcsx2.net_grl",
		0,
		"^https?://(www\\.)?pcsx2\\.net/",
		10,
		[],
		[{ "e": 2533 }],
		[{ "v": 2533 }],
		[{ "wait": 500 }, { "c": 2533 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2533
		}],
		{}
	],
	[
		1,
		"auto_NO_saseurobonusmastercard.se_oqd",
		0,
		"^https?://(www\\.)?saseurobonusmastercard\\.se/",
		10,
		[],
		[{ "e": 2534 }],
		[{ "v": 2534 }],
		[{ "wait": 500 }, { "c": 2534 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2534
		}],
		{}
	],
	[
		1,
		"auto_NO_sverigesradio.se_a00",
		0,
		"^https?://(www\\.)?sverigesradio\\.se/",
		10,
		[],
		[{ "e": 2535 }],
		[{ "v": 2535 }],
		[{ "wait": 500 }, { "c": 2535 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2535
		}],
		{}
	],
	[
		1,
		"auto_NO_swedbank.se_63w",
		0,
		"^https?://(www\\.)?swedbank\\.se/",
		10,
		[],
		[{ "e": 2536 }],
		[{ "v": 2536 }],
		[{ "wait": 500 }, { "c": 2536 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2536
		}],
		{}
	],
	[
		1,
		"auto_NO_tingstad.com_z23",
		0,
		"^https?://(www\\.)?tingstad\\.com/",
		10,
		[],
		[{ "e": 2537 }],
		[{ "v": 2537 }],
		[{ "wait": 500 }, { "c": 2537 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2537
		}],
		{}
	],
	[
		1,
		"auto_NO_truecaller.com_sdg",
		0,
		"^https?://(www\\.)?truecaller\\.com/",
		10,
		[],
		[{ "e": 2538 }],
		[{ "v": 2538 }],
		[{ "wait": 500 }, { "c": 2538 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2538
		}],
		{}
	],
	[
		1,
		"auto_NO_webank.it_6rx",
		0,
		"^https?://(www\\.)?webank\\.it/",
		10,
		[],
		[{ "e": 2539 }],
		[{ "v": 2539 }],
		[{ "wait": 500 }, { "c": 2539 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2539
		}],
		{}
	],
	[
		1,
		"auto_NO_xrealgirl.com_r42",
		0,
		"^https?://(www\\.)?xrealgirl\\.com/",
		10,
		[],
		[{ "e": 2540 }],
		[{ "v": 2540 }],
		[{ "wait": 500 }, { "c": 2540 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2540
		}],
		{}
	],
	[
		1,
		"auto_US_amazon.jobs_0",
		0,
		"^https?://(www\\.)?amazon\\.jobs/",
		10,
		[],
		[{ "e": 2541 }],
		[{ "v": 2541 }],
		[{ "wait": 500 }, { "c": 2541 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2541
		}],
		{}
	],
	[
		1,
		"auto_US_amsoil.com_fgr",
		0,
		"^https?://(www\\.)?amsoil\\.com/",
		10,
		[],
		[{ "e": 2542 }],
		[{ "v": 2542 }],
		[{ "c": 2542 }],
		[],
		{}
	],
	[
		1,
		"auto_US_balsamhill.com_oxq",
		0,
		"^https?://(www\\.)?balsamhill\\.com/",
		10,
		[],
		[{ "e": 2543 }],
		[{ "v": 2543 }],
		[{ "wait": 500 }, { "c": 2543 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2543
		}],
		{}
	],
	[
		1,
		"auto_US_computerworld.com_0_+1",
		0,
		"^https?://(www\\.)?computerworld\\.com/|^https?://(www\\.)?csoonline\\.com/",
		10,
		[],
		[{ "e": 2544 }],
		[{ "v": 2544 }],
		[{
			"text": "Do not accept",
			"c": 2544
		}],
		[],
		{}
	],
	[
		1,
		"auto_US_coupons.slickdeals.net_wya",
		0,
		"^https?://(www\\.)?coupons\\.slickdeals\\.net/",
		10,
		[],
		[{ "e": 2545 }],
		[{ "v": 2545 }],
		[{ "wait": 500 }, { "c": 2545 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2545
		}],
		{}
	],
	[
		1,
		"auto_US_deezer.com_0",
		0,
		"^https?://(www\\.)?deezer\\.com/",
		10,
		[],
		[{ "e": 2546 }],
		[{ "v": 2546 }],
		[{
			"text": "Refuse",
			"c": 2546
		}],
		[],
		{}
	],
	[
		1,
		"auto_US_emagine-entertainment.com_0",
		0,
		"^https?://(www\\.)?emagine-entertainment\\.com/",
		10,
		[],
		[{ "e": 2547 }],
		[{ "v": 2547 }],
		[{ "wait": 500 }, { "c": 2547 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2547
		}],
		{}
	],
	[
		1,
		"auto_US_fawesome.tv_gjx",
		0,
		"^https?://(www\\.)?fawesome\\.tv/",
		10,
		[],
		[{ "e": 2548 }],
		[{ "v": 2548 }],
		[{ "wait": 500 }, { "c": 2548 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2548
		}],
		{}
	],
	[
		1,
		"auto_US_forum.affinity.serif.com_0",
		0,
		"^https?://(www\\.)?forum\\.affinity\\.serif\\.com/",
		10,
		[],
		[{ "e": 2549 }],
		[{ "v": 2549 }],
		[{
			"text": "\xA0Reject Cookies",
			"c": 2549
		}],
		[],
		{}
	],
	[
		1,
		"auto_US_forum.prusa3d.com_0",
		0,
		"^https?://(www\\.)?forum\\.prusa3d\\.com/",
		10,
		[],
		[{ "e": 2550 }],
		[{ "v": 2550 }],
		[{
			"text": "Reject All",
			"c": 2550
		}],
		[],
		{}
	],
	[
		1,
		"auto_US_greenpan.us_cko",
		0,
		"^https?://(www\\.)?greenpan\\.us/",
		10,
		[],
		[{ "e": 2206 }],
		[{ "v": 2206 }],
		[{ "wait": 500 }, { "c": 2206 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2206
		}],
		{}
	],
	[
		1,
		"auto_US_interactivebrokers.com_0",
		0,
		"^https?://(www\\.)?interactivebrokers\\.com/",
		10,
		[],
		[{ "e": 2551 }],
		[{ "v": 2551 }],
		[{
			"text": "Reject All Cookies",
			"c": 2551
		}],
		[],
		{}
	],
	[
		1,
		"auto_US_ligonier.org_0",
		0,
		"^https?://(www\\.)?ligonier\\.org/",
		10,
		[],
		[{ "e": 2552 }],
		[{ "v": 2552 }],
		[{
			"text": "Strictly Necessary",
			"c": 2552
		}],
		[],
		{}
	],
	[
		1,
		"auto_US_lilly.com_lh6_+1",
		0,
		"^https?://(www\\.)?lilly\\.com/|^https?://(www\\.)?zepbound\\.lilly\\.com/",
		10,
		[],
		[{ "e": 2553 }],
		[{ "v": 2553 }],
		[{ "wait": 500 }, { "c": 2553 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2553
		}],
		{}
	],
	[
		1,
		"auto_US_mixedbread.ai_tge",
		0,
		"^https?://(www\\.)?mixedbread\\.com/",
		10,
		[],
		[{ "e": 2523 }],
		[{ "v": 2523 }],
		[{ "wait": 500 }, { "c": 2523 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2523
		}],
		{}
	],
	[
		1,
		"auto_US_musicnotes.com_0",
		0,
		"^https?://(www\\.)?musicnotes\\.com/",
		10,
		[],
		[{ "exists": ["#polaris-css-lockdown-container", ".polaris-consent-widget"] }],
		[{ "visible": ["#polaris-css-lockdown-container", ".polaris-consent-widget"] }],
		[{
			"if": { "exists": ["#polaris-css-lockdown-container", "[data-testid='oneClickOptOutLink']"] },
			"then": [{ "waitForThenClick": ["#polaris-css-lockdown-container", "[data-testid='oneClickOptOutLink']"] }],
			"else": [{ "hide": ["#polaris-css-lockdown-container", ".polaris-consent-widget"] }]
		}],
		[],
		{}
	],
	[
		1,
		"auto_US_newmedicare.com_6jp",
		0,
		"^https?://(www\\.)?newmedicare\\.com/",
		10,
		[],
		[{ "e": 2554 }],
		[{ "v": 2554 }],
		[{ "wait": 500 }, { "c": 2554 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2554
		}],
		{}
	],
	[
		1,
		"auto_US_peptidesciences.com_0",
		0,
		"^https?://(www\\.)?peptidesciences\\.com/",
		10,
		[],
		[{ "e": 2555 }],
		[{ "v": 2555 }],
		[{ "wait": 500 }, { "c": 2555 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2555
		}],
		{}
	],
	[
		1,
		"auto_US_semrush.com_0",
		0,
		"^https?://(www\\.)?semrush\\.com/",
		10,
		[],
		[{ "e": 2556 }],
		[{ "v": 2556 }],
		[{ "wait": 500 }, { "c": 2556 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2556
		}],
		{}
	],
	[
		1,
		"auto_US_sso.passport.yandex.ru_0_+5",
		0,
		"^https?://(www\\.)?sso\\.passport\\.yandex\\.ru/|^https?://(www\\.)?translate\\.yandex\\.com/|^https?://(www\\.)?tv\\.yandex\\.com/|^https?://(www\\.)?ya\\.ru/|^https?://(www\\.)?yandex\\.com\\.tr/|^https?://(www\\.)?yandex\\.com/",
		10,
		[],
		[{ "e": 2557 }],
		[{ "v": 2557 }],
		[{
			"text": "Allow essential cookies",
			"c": 2557
		}],
		[],
		{}
	],
	[
		1,
		"auto_US_truecaller.com_0",
		0,
		"^https?://(www\\.)?truecaller\\.com/",
		10,
		[],
		[{ "e": 2558 }],
		[{ "v": 2558 }],
		[{
			"text": "Accept Necessary Cookies",
			"c": 2558
		}],
		[],
		{}
	],
	[
		1,
		"auto_US_weingartz.com_aso",
		0,
		"^https?://(www\\.)?weingartz\\.com/",
		10,
		[],
		[{ "e": 2559 }],
		[{ "v": 2559 }],
		[{ "c": 2559 }],
		[],
		{}
	],
	[
		1,
		"axesor",
		2,
		"^https?://([\\w-]+\\.)?axesor\\.es/",
		22,
		[2560],
		[{ "e": 2561 }],
		[{ "v": 2561 }],
		[{ "c": 2561 }],
		[{ "cc": 2562 }],
		{}
	],
	[
		1,
		"aytm",
		2,
		"^https?://(www\\.|)?aytm\\.com/",
		22,
		[407],
		[{ "e": 2563 }],
		[{ "v": 2563 }],
		[{ "c": 2563 }],
		[],
		{}
	],
	[
		1,
		"bahn-de",
		0,
		"^https://(www\\.)?bahn\\.de/",
		10,
		[],
		[{ "exists": ["body > div:first-child", "#consent-layer"] }],
		[{ "visible": ["body > div:first-child", "#consent-layer"] }],
		[{ "waitForThenClick": ["body > div:first-child", "#consent-layer .js-accept-essential-cookies"] }],
		[{ "eval": "EVAL_BAHN_TEST" }],
		{ "intermediate": false }
	],
	[
		1,
		"bakeca",
		2,
		"^https?://([\\w-]+\\.)?bakecaincontrii\\.com/",
		22,
		[],
		[{ "e": 2564 }],
		[{ "v": 2565 }],
		[{ "c": 2566 }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 2565
		}],
		{}
	],
	[
		1,
		"bandcamp.com",
		2,
		"^https://([a-z0-9-]+\\.)?bandcamp\\.com",
		22,
		[],
		[{ "e": 2567 }],
		[{ "any": [
			{ "v": 2568 },
			{ "visible": ["menu-bar", ".cookie-dialog-initial"] },
			{ "visible": ["page-footer", ".cookie-dialog-initial"] }
		] }],
		[{ "any": [
			{
				"timeout": 500,
				"c": 2569
			},
			{
				"waitForThenClick": ["menu-bar", ".cookie-dialog-initial button.g-button.outline"],
				"timeout": 500
			},
			{
				"waitForThenClick": ["page-footer", ".cookie-dialog-initial button.g-button.outline"],
				"timeout": 500
			}
		] }],
		[{ "wait": 500 }, { "cc": 2570 }],
		{}
	],
	[
		1,
		"bankmillennium.pl",
		2,
		"^https?://(www\\.)?bankmillennium\\.pl/",
		22,
		[2571],
		[{ "e": 2571 }],
		[{ "v": 2571 }],
		[{ "waitForThenClick": ["#cookie_modal_placeholder dialog.bm-modal--cookie", "xpath///button[contains(normalize-space(.), 'Odrzu')]"] }],
		[{ "cc": 2572 }, { "cc": 2573 }],
		{}
	],
	[
		1,
		"banknorwegian",
		2,
		"^https?://(www\\.)?banknorwegian\\.(no|se|dk|fi|de|es)/",
		22,
		[2574],
		[{ "e": 2575 }],
		[{ "v": 2576 }],
		[
			{ "c": 2576 },
			{ "wv": 2577 },
			{
				"all": true,
				"optional": true,
				"k": 2578
			},
			{ "k": 2577 },
			{
				"check": "none",
				"timeout": 3e3,
				"optional": true,
				"wv": 2577
			}
		],
		[{
			"check": "none",
			"v": 2579
		}],
		{}
	],
	[
		1,
		"batteriexperten.com",
		2,
		"^https?://(\\w+\\.)?(batteriexperten\\.com|teknikdelar\\.se|teknikkdeler\\.no|teknikdele\\.dk|tekniikkaosat\\.fi)/",
		22,
		[2580],
		[{ "e": 2581 }],
		[{ "v": 2581 }],
		[{
			"if": { "e": 2582 },
			"then": [{ "c": 2583 }],
			"else": [
				{ "c": 2584 },
				{ "wv": 2585 },
				{
					"all": true,
					"optional": true,
					"k": 2586
				},
				{ "c": 2587 }
			]
		}, {
			"check": "none",
			"wv": 2581
		}],
		[{ "cc": 2588 }],
		{}
	],
	[
		1,
		"bbc.com",
		2,
		"^https://(www\\.)?bbc\\.(com|co\\.uk)/",
		22,
		[2589, 2590],
		[{ "any": [{ "e": 2591 }, { "e": 2592 }] }],
		[{ "any": [{ "v": 2591 }, { "v": 2592 }] }],
		[{
			"if": { "e": 2592 },
			"then": [{ "c": 2592 }],
			"else": [{ "c": 2593 }]
		}],
		[{ "wait": 500 }, { "cc": 2594 }],
		{}
	],
	[
		1,
		"bbc.com-orb-cosmetic",
		1,
		"^https://(www\\.)?bbc\\.(com|co\\.uk)/",
		22,
		[2595],
		[{ "e": 2596 }],
		[{ "v": 2596 }],
		[{ "h": 2595 }],
		[{
			"check": "none",
			"v": 2597
		}],
		{}
	],
	[
		1,
		"bcferries.com",
		2,
		"^https?://(\\w+\\.)?bcferries\\.com/",
		22,
		[2598],
		[{ "e": 2599 }],
		[{ "v": 2598 }],
		[
			{ "c": 2600 },
			{ "c": 2601 },
			{ "c": 2602 }
		],
		[],
		{}
	],
	[
		1,
		"berelax.com",
		2,
		"^https://(www\\.)?berelax\\.com/",
		22,
		[2603],
		[{ "e": 2604 }],
		[{ "v": 2605 }],
		[{ "c": 2606 }, {
			"check": "none",
			"timeout": 2e3,
			"wv": 2605
		}],
		[],
		{}
	],
	[
		1,
		"bibliotheek-nl",
		0,
		"^https?://(?:www\\.)?(?:onlinebibliotheek|bibliotheek)\\.nl/",
		10,
		[2607],
		[{ "e": 2608 }],
		[{ "v": 2607 }],
		[{ "c": 2609 }],
		[],
		{}
	],
	[
		1,
		"blitzrechner",
		2,
		"^https?://(www\\.)?blitzrechner\\.de/",
		22,
		[2610],
		[{ "e": 2610 }],
		[{ "v": 2611 }],
		[{
			"all": true,
			"optional": true,
			"k": 2612
		}, { "c": 2613 }],
		[{ "cc": 2614 }],
		{}
	],
	[
		1,
		"bokadirekt.se",
		2,
		"^https?://(\\w+\\.)?bokadirekt\\.se/",
		22,
		[],
		[{ "e": 2615 }],
		[{ "v": 2615 }],
		[
			{ "c": 2616 },
			{ "wv": 2617 },
			{
				"if": { "e": 2618 },
				"then": [{
					"all": true,
					"k": 2618
				}]
			},
			{ "k": 2617 }
		],
		[{ "cc": 2619 }],
		{}
	],
	[
		1,
		"breuninger",
		2,
		"^https://(www\\.)?breuninger\\.com/",
		22,
		[2620],
		[{ "e": 2621 }],
		[{ "v": 2622 }],
		[{ "c": 2621 }],
		[{ "cc": 2623 }],
		{}
	],
	[
		1,
		"bricklink",
		2,
		"^https?://([a-z0-9-]+\\.)?bricklink\\.com/",
		22,
		[2624],
		[{ "e": 2624 }],
		[{ "v": 2624 }],
		[{ "c": 2625 }],
		[{ "cc": 2626 }],
		{}
	],
	[
		1,
		"bringatrailer",
		2,
		"^https?://(www\\.)?bringatrailer\\.com/",
		22,
		[],
		[{ "e": 2627 }, { "cc": 2628 }],
		[{ "v": 2629 }],
		[{ "c": 2627 }],
		[{ "cc": 2630 }],
		{}
	],
	[
		1,
		"buonmedico",
		2,
		"^https?://(www\\.)?buonmedico\\.it/",
		22,
		[2631],
		[{ "e": 2632 }],
		[{ "v": 2632 }],
		[{ "c": 2632 }],
		[{ "cc": 2633 }],
		{}
	],
	[
		1,
		"canva",
		2,
		"^https?://(www\\.)?canva\\.com/",
		22,
		[2634],
		[{ "e": 2634 }],
		[{ "v": 2634 }],
		[
			{ "c": 2635 },
			{ "c": 2636 },
			{ "c": 2637 }
		],
		[{ "wait": 1e3 }, { "cc": 2638 }],
		{}
	],
	[
		1,
		"canyon.com",
		2,
		"^https://www\\.canyon\\.com/",
		22,
		[2639],
		[{ "e": 2639 }],
		[{ "v": 2639 }],
		[{ "k": 2640 }, { "c": 2641 }],
		[],
		{}
	],
	[
		1,
		"capitalone-ca",
		2,
		"^https://(www\\.)?capitalone\\.ca/",
		22,
		[],
		[{ "e": 2642 }],
		[{ "v": 2642 }],
		[{ "c": 2642 }],
		[{ "cc": 2643 }],
		{}
	],
	[
		1,
		"carpetaciudadana",
		2,
		"^https?://(\\w+\\.)?carpetaciudadana\\.gob\\.es/",
		22,
		[2644],
		[{ "e": 2645 }],
		[{ "v": 2646 }],
		[
			{ "c": 2645 },
			{ "wv": 2647 },
			{
				"if": { "e": 2648 },
				"then": [{ "k": 2647 }]
			},
			{
				"retry": 2,
				"retryInterval": 600,
				"c": 2649
			}
		],
		[{ "cc": 2650 }],
		{}
	],
	[
		1,
		"carre.nl",
		2,
		"^https?://(www\\.)?carre\\.nl/",
		10,
		[2651],
		[{ "e": 2652 }],
		[{ "v": 2651 }],
		[{ "c": 2652 }],
		[],
		{}
	],
	[
		1,
		"casier-judiciaire-justice-gouv-fr",
		2,
		"^https?://casier-judiciaire\\.justice\\.gouv\\.fr/",
		22,
		[2653],
		[{ "e": 2654 }],
		[{ "v": 2653 }],
		[{ "c": 2655 }, {
			"check": "none",
			"timeout": 2e3,
			"optional": true,
			"wv": 2653
		}],
		[{
			"check": "none",
			"v": 2653
		}],
		{}
	],
	[
		1,
		"ccm-net",
		1,
		"^https?://([\\w-]+\\.)?ccm\\.net/",
		22,
		[68, 2656],
		[{ "any": [{ "e": 69 }, { "e": 2656 }] }],
		[{ "any": [{ "v": 68 }, { "v": 2656 }] }],
		[{ "h": 2656 }, {
			"if": { "v": 68 },
			"then": [{ "waitForThenClick": ["iframe[srcdoc*='frame-root']", ".button__skip"] }]
		}],
		[],
		{}
	],
	[
		1,
		"channel4.com",
		2,
		"^https?://(www\\.)?channel4\\.com/",
		10,
		[218, 2657],
		[{ "e": 2658 }],
		[{ "v": 2658 }],
		[{ "c": 2659 }],
		[{ "cc": 2660 }],
		{}
	],
	[
		1,
		"chatgpt",
		0,
		"^https?://(\\w+\\.)?chatgpt\\.com/",
		10,
		[2661],
		[{ "e": 2662 }],
		[{ "v": 2663 }],
		[{ "c": 2662 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2664
		}],
		{}
	],
	[
		1,
		"chomikuj",
		2,
		"^https?://(\\w+\\.)?chomikuj\\.pl/",
		22,
		[],
		[{ "e": 2665 }],
		[{ "v": 2665 }],
		[{ "c": 2665 }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 2666
		}],
		{}
	],
	[
		1,
		"citizensadvice",
		2,
		"^https?://(\\w+\\.)?citizensadvice\\.org\\.uk/",
		22,
		[2667],
		[{ "e": 2668 }],
		[{ "v": 2668 }],
		[{ "c": 2668 }, {
			"timeout": 2e3,
			"optional": true,
			"c": 2669
		}],
		[{ "cc": 621 }],
		{}
	],
	[
		1,
		"civilservicejobs-service-gov-uk",
		2,
		"^https?://(\\w+\\.)?civilservicejobs\\.service\\.gov\\.uk/",
		22,
		[2670],
		[{ "e": 2671 }],
		[{ "v": 2671 }],
		[{ "c": 2671 }, {
			"check": "none",
			"timeout": 2e3,
			"optional": true,
			"wv": 2670
		}],
		[{ "cc": 2672 }],
		{}
	],
	[
		1,
		"clasohlson.com",
		2,
		"^https?://(www\\.)?clasohlson\\.com/",
		22,
		[2673],
		[{ "e": 2674 }],
		[{ "v": 2675 }],
		[{
			"retry": 10,
			"retryInterval": 500,
			"c": 2676
		}, {
			"check": "none",
			"wv": 2675
		}],
		[{ "cc": 2677 }],
		{}
	],
	[
		1,
		"clustrmaps.com",
		1,
		"^https://(www\\.)?clustrmaps\\.com/",
		22,
		[1e3],
		[{ "e": 1e3 }],
		[{ "v": 1e3 }],
		[{ "h": 1e3 }],
		[],
		{}
	],
	[
		3,
		"community.screwfix.com",
		2,
		"^https?://community\\.screwfix\\.com/",
		10,
		[2678],
		[{ "e": 2679 }],
		[{ "v": 2679 }],
		[{ "c": 2680 }, {
			"stylesheet": "#consent-banner::before { display: none !important; }",
			"stylesheetId": "screwfix-backdrop"
		}],
		[{ "cc": 2681 }],
		{}
	],
	[
		1,
		"concordia-ch",
		2,
		"^https://(\\w+\\.)?concordia\\.(ch|li)/",
		22,
		[2682],
		[{ "e": 2682 }],
		[{ "v": 2683 }],
		[{ "c": 2684 }],
		[{ "cc": 2685 }],
		{}
	],
	[
		1,
		"conjointly",
		2,
		"^https://(www\\.)?conjointly\\.com/",
		22,
		[2686],
		[{ "e": 2687 }],
		[{ "v": 2687 }],
		[{
			"if": { "e": 2688 },
			"then": [{ "k": 2689 }]
		}, { "c": 2690 }],
		[{ "cc": 2691 }],
		{}
	],
	[
		1,
		"controlgame",
		2,
		"^https?://(www\\.)?controlgame\\.com/",
		22,
		[],
		[{ "e": 2692 }],
		[{ "v": 2692 }],
		[{
			"retry": 10,
			"retryInterval": 500,
			"c": 2692
		}],
		[{ "cc": 609 }],
		{}
	],
	[
		1,
		"copaamerica",
		1,
		"^https://(www\\.)?copaamerica\\.com/",
		22,
		[2693],
		[{ "e": 2693 }],
		[{ "v": 2693 }],
		[{ "h": 2693 }],
		[],
		{}
	],
	[
		1,
		"copilot-microsoft",
		0,
		"^https://copilot\\.microsoft\\.com/",
		10,
		[34],
		[{ "e": 34 }],
		[{ "v": 34 }],
		[{ "c": 2694 }],
		[{ "cc": 2695 }],
		{}
	],
	[
		1,
		"costco",
		1,
		"^https?://([\\w-]+\\.)*costco(businesscentre|businessdelivery)?\\.(ca|com)/",
		22,
		[2696],
		[{ "e": 2697 }],
		[{ "v": 2696 }],
		[{ "h": 2698 }],
		[],
		{}
	],
	[
		1,
		"csu-landtag-de",
		2,
		"^https://(www\\.|)?csu-landtag\\.de",
		22,
		[2699],
		[{ "e": 2699 }],
		[{ "v": 2699 }],
		[{ "k": 2700 }],
		[],
		{}
	],
	[
		1,
		"ctv-disneyonice",
		2,
		"^https://www\\.ctv\\.co\\.jp/disneyonice(?:/|[?#]|$)",
		22,
		[2701],
		[{ "e": 2702 }],
		[{ "v": 2702 }],
		[{ "c": 2703 }],
		[{ "cc": 2704 }],
		{}
	],
	[
		1,
		"cuvva.com",
		0,
		"^https://(www\\.)?cuvva\\.com/",
		22,
		[],
		[{ "e": 2705 }],
		[{ "v": 2705 }, {
			"negated": true,
			"cc": 2706
		}],
		[
			{
				"retry": 10,
				"retryInterval": 500,
				"c": 2707
			},
			{ "wait": 500 },
			{
				"if": { "v": 2707 },
				"then": [{
					"retry": 10,
					"retryInterval": 500,
					"c": 2707
				}]
			}
		],
		[{ "cc": 2708 }],
		{}
	],
	[
		1,
		"dailymotion.com",
		2,
		"^https://(www\\.)?dailymotion\\.com/",
		22,
		[2709],
		[{ "e": 2710 }],
		[{ "v": 2711 }],
		[{ "c": 2712 }],
		[{ "cc": 2713 }],
		{}
	],
	[
		1,
		"dalecarnegie",
		2,
		"^https?://(\\w+\\.)?dalecarnegie\\.com/",
		22,
		[],
		[{ "e": 2714 }],
		[{ "v": 2715 }],
		[
			{ "c": 2714 },
			{ "wv": 2716 },
			{
				"all": true,
				"optional": true,
				"k": 2717
			},
			{ "k": 2716 }
		],
		[{ "cc": 2718 }],
		{}
	],
	[
		1,
		"darkounity.com",
		2,
		"^https://(www\\.)?darkounity\\.com/",
		22,
		[2719],
		[{ "exists": ["gdpr-consent-popup", "[data-action='necessary-only']"] }],
		[{ "visible": ["gdpr-consent-popup", ".banner"] }],
		[{ "waitForThenClick": ["gdpr-consent-popup", "[data-action='necessary-only']"] }],
		[{
			"waitForVisible": ["gdpr-consent-popup", ".banner"],
			"timeout": 2e3,
			"check": "none"
		}],
		{}
	],
	[
		1,
		"deliveroo",
		2,
		"^https?://(\\w+\\.)?deliveroo\\.(co\\.uk|\\w+)/",
		22,
		[2720],
		[{ "e": 2720 }],
		[{ "v": 2720 }],
		[{ "c": 2721 }, {
			"check": "none",
			"wv": 2720
		}],
		[{ "cc": 1821 }],
		{}
	],
	[
		1,
		"delta.com",
		1,
		"^https://www\\.delta\\.com/",
		22,
		[2722],
		[{ "e": 2723 }],
		[{ "v": 2723 }],
		[{ "h": 2723 }],
		[],
		{}
	],
	[
		2,
		"depop",
		1,
		"^https://(www\\.)?depop\\.com/",
		22,
		[1781, 2724],
		[{ "e": 1781 }],
		[{ "visible": ["#transcend-consent-manager", "#consentManagerMainDialog"] }],
		[
			{ "h": 1781 },
			{ "h": 2724 },
			{
				"timeout": 3e3,
				"optional": true,
				"w": 2724
			},
			{
				"addStyle": "overflow: auto !important",
				"selector": "body",
				"optional": true
			}
		],
		[],
		{}
	],
	[
		1,
		"dhbbank",
		2,
		"^https?://(www\\.)?dhbbank\\.(com|nl|be|de)/",
		22,
		[2725],
		[{ "e": 2726 }],
		[{ "v": 2726 }],
		[{ "c": 2726 }],
		[{
			"check": "none",
			"timeout": 3e3,
			"wv": 2725
		}, { "cc": 2727 }],
		{}
	],
	[
		1,
		"diag.pl",
		2,
		"^https?://(\\w+\\.)?diag\\.pl/",
		22,
		[],
		[{ "e": 2728 }],
		[{ "v": 2728 }],
		[{ "c": 2728 }],
		[{
			"check": "none",
			"timeout": 3e3,
			"wv": 2728
		}],
		{}
	],
	[
		1,
		"dji",
		0,
		"^https://(\\w+\\.)+dji\\.com/",
		22,
		[2729],
		[{ "e": 2730 }],
		[{ "e": 2729 }],
		[{ "c": 2731 }],
		[{ "cc": 2732 }],
		{}
	],
	[
		1,
		"dndbeyond",
		2,
		"^https://(www\\.)?dndbeyond\\.com/",
		22,
		[2733],
		[{ "e": 2733 }],
		[{ "v": 2733 }],
		[{ "c": 2734 }],
		[{ "cc": 2735 }],
		{}
	],
	[
		1,
		"dwaalzin.nu",
		2,
		"^https?://(www\\.)?dwaalzin\\.nu/",
		22,
		[391],
		[{ "e": 2736 }],
		[{ "v": 2736 }],
		[{ "c": 2736 }],
		[{ "cc": 1155 }],
		{}
	],
	[
		1,
		"eastlink",
		2,
		"^https?://(www\\.)?eastlink\\.ca/",
		22,
		[],
		[{ "e": 2737 }],
		[{ "e": 2738 }, {
			"negated": true,
			"cc": 2739
		}],
		[
			{
				"timeout": 1e4,
				"wv": 2740
			},
			{ "k": 2737 },
			{ "wv": 2741 },
			{
				"if": { "e": 2742 },
				"then": [{ "k": 2743 }]
			},
			{
				"if": { "e": 2744 },
				"then": [{ "k": 2745 }]
			},
			{ "k": 2738 }
		],
		[],
		{}
	],
	[
		1,
		"ebay",
		0,
		"^https://(www\\.)?ebay\\.([.a-z]+)/",
		10,
		[2746],
		[{ "e": 2746 }],
		[{ "v": 2746 }],
		[
			{ "c": 2747 },
			{
				"check": "none",
				"timeout": 2e3,
				"optional": true,
				"wv": 2746
			},
			{
				"if": { "v": 2746 },
				"then": [{
					"timeout": 2e3,
					"c": 2747
				}]
			}
		],
		[],
		{}
	],
	[
		1,
		"ecosia",
		2,
		"^https://www\\.ecosia\\.org/",
		22,
		[2748],
		[{ "e": 2749 }],
		[{ "v": 2749 }],
		[{ "c": 2750 }],
		[],
		{}
	],
	[
		1,
		"edpb-edps",
		2,
		"^https://(www\\.)?(edpb|edps)\\.europa\\.eu/",
		22,
		[2751],
		[{ "e": 2752 }],
		[{ "v": 2751 }],
		[{ "c": 2752 }],
		[{ "cc": 2753 }],
		{}
	],
	[
		1,
		"ef-ccpa",
		0,
		"^https://(www\\.)?eforms\\.com",
		22,
		[2754],
		[{ "e": 2754 }],
		[{ "v": 2754 }],
		[{ "c": 2755 }],
		[],
		{}
	],
	[
		1,
		"elektro-material-ch",
		1,
		"^https?://(www\\.)?elektro-material\\.ch/",
		22,
		[2756],
		[{ "e": 2757 }],
		[{ "v": 2758 }],
		[{ "h": 2756 }],
		[],
		{}
	],
	[
		1,
		"elsevier",
		2,
		"^https?://(\\w+\\.)?elsevier\\.(com|support)/",
		22,
		[2759],
		[{ "e": 2760 }],
		[{ "v": 2760 }],
		[{
			"if": { "e": 2761 },
			"then": [{
				"retry": 3,
				"retryInterval": 1e3,
				"c": 2761
			}],
			"else": [
				{
					"retry": 3,
					"retryInterval": 1e3,
					"c": 2762
				},
				{
					"timeout": 1e4,
					"wv": 1817
				},
				{
					"all": true,
					"optional": true,
					"c": 1819
				},
				{
					"timeout": 5e3,
					"c": 1820
				}
			]
		}, {
			"check": "none",
			"timeout": 1e4,
			"wv": 2763
		}],
		[{ "cc": 1821 }],
		{}
	],
	[
		1,
		"eltax-lta-go-jp",
		2,
		"^https://(?:[^/]+\\.)?eltax\\.lta\\.go\\.jp/",
		22,
		[2764],
		[{ "e": 2765 }],
		[{ "v": 2765 }],
		[{ "c": 2765 }],
		[],
		{}
	],
	[
		1,
		"emr-ch",
		2,
		"^https?://(www\\.)?(emr|emfeedback)\\.ch/",
		22,
		[2766],
		[{ "e": 2767 }],
		[{ "v": 2766 }],
		[{
			"all": true,
			"optional": true,
			"k": 2768
		}, {
			"retry": 3,
			"retryInterval": 500,
			"c": 2767
		}],
		[{ "cc": 2769 }],
		{}
	],
	[
		1,
		"endocrine.org",
		2,
		"^https?://(www\\.)?endocrine\\.org/",
		22,
		[],
		[{ "e": 2770 }],
		[{ "v": 2771 }],
		[{ "c": 2771 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2770
		}],
		{}
	],
	[
		1,
		"eneba",
		0,
		"^https?://(www\\.)?eneba\\.com/",
		10,
		[2772],
		[{ "e": 2773 }],
		[{ "v": 2773 }],
		[
			{ "c": 2774 },
			{
				"timeout": 2e3,
				"optional": true,
				"wv": 2775
			},
			{
				"if": {
					"check": "none",
					"v": 2775
				},
				"then": [{ "k": 2774 }]
			},
			{ "wv": 2775 },
			{
				"all": true,
				"optional": true,
				"k": 2776
			},
			{ "c": 2777 }
		],
		[{ "wait": 500 }, { "cc": 2778 }],
		{}
	],
	[
		1,
		"england.nhs.uk",
		2,
		"^https?://(www\\.)?england\\.nhs\\.uk/",
		22,
		[2779],
		[{ "e": 2780 }],
		[{ "v": 2779 }],
		[
			{ "c": 2780 },
			{ "wv": 345 },
			{
				"if": { "e": 2781 },
				"then": [{
					"all": true,
					"k": 2781
				}]
			},
			{ "c": 347 }
		],
		[{ "cc": 2782 }],
		{}
	],
	[
		1,
		"ensembleartsphilly",
		2,
		"^https?://(\\w+\\.)?ensembleartsphilly\\.org/",
		22,
		[2783],
		[{ "e": 2784 }],
		[{ "v": 2785 }],
		[{ "c": 2784 }],
		[{ "cc": 2786 }],
		{}
	],
	[
		1,
		"eon.pl",
		2,
		"^https?://(\\w+\\.)?eon\\.pl/",
		22,
		[2787],
		[{ "e": 2788 }],
		[{ "v": 2787 }],
		[
			{ "c": 2789 },
			{ "wv": 2790 },
			{
				"optional": true,
				"k": 2791
			},
			{ "k": 2792 }
		],
		[{ "cc": 2793 }],
		{}
	],
	[
		1,
		"epidemicsound.com",
		2,
		"^https?://(\\w+\\.)?epidemicsound\\.com/",
		22,
		[2794],
		[{ "e": 2795 }],
		[{ "v": 2796 }],
		[
			{ "w": 1820 },
			{ "c": 2796 },
			{ "wv": 1817 },
			{
				"all": true,
				"optional": true,
				"k": 2797
			},
			{ "c": 1820 },
			{
				"check": "none",
				"wv": 2796
			}
		],
		[{ "cc": 1821 }],
		{}
	],
	[
		1,
		"eroticiracconti-it",
		1,
		"^https?://(www\\.)?eroticiracconti\\.it/",
		22,
		[2798],
		[{ "e": 2799 }],
		[{ "v": 2800 }],
		[{ "h": 2798 }],
		[],
		{}
	],
	[
		1,
		"ersatzteile-24",
		2,
		"^https?://(www\\.)?ersatzteile-24\\.com/",
		22,
		[2801],
		[{ "e": 2802 }],
		[{ "v": 2803 }],
		[
			{
				"retry": 5,
				"retryInterval": 1e3,
				"c": 2804
			},
			{ "wv": 2805 },
			{ "k": 2805 },
			{ "k": 2802 }
		],
		[{ "cc": 2806 }, { "cc": 2807 }],
		{}
	],
	[
		1,
		"escaparium.ca",
		2,
		"^https://(www\\.)?escaparium\\.ca/",
		22,
		[],
		[{ "e": 2808 }],
		[{ "v": 2809 }],
		[{ "c": 2810 }, { "c": 2811 }],
		[{ "cc": 2812 }],
		{}
	],
	[
		1,
		"escorteintime",
		2,
		"^https?://(www\\.)?escorteintime\\.com/",
		22,
		[2813],
		[{ "e": 2813 }],
		[{ "v": 2813 }],
		[{ "c": 2814 }, { "c": 2815 }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 2813
		}],
		{}
	],
	[
		1,
		"espace-personnel.agirc-arrco.fr",
		2,
		"^https://espace-personnel\\.agirc-arrco\\.fr/",
		22,
		[2816],
		[{ "e": 2817 }],
		[{ "v": 2817 }],
		[{ "c": 2818 }],
		[],
		{}
	],
	[
		1,
		"europa-eu",
		2,
		"^https://([a-z0-9.-]*\\.)?europa\\.eu/",
		22,
		[2819],
		[{ "e": 2819 }],
		[{ "v": 2819 }],
		[{ "c": 2820 }],
		[{ "cc": 2821 }],
		{}
	],
	[
		1,
		"eventfrog",
		2,
		"^https?://(www\\.)?eventfrog\\.(ch|de|at)/",
		22,
		[2822],
		[{ "e": 2823 }],
		[{ "v": 2824 }],
		[
			{ "wv": 2823 },
			{ "wait": 500 },
			{ "k": 2823 }
		],
		[{ "cc": 2825 }],
		{}
	],
	[
		1,
		"evium.de",
		2,
		"^https://(www\\.)?evium\\.de/",
		22,
		[2826],
		[{ "e": 2826 }],
		[{ "v": 2826 }],
		[{ "c": 2827 }, {
			"check": "none",
			"timeout": 2e3,
			"wv": 2826
		}],
		[],
		{}
	],
	[
		1,
		"evozen.fr",
		2,
		"^https?://(\\w+\\.)?evozen\\.fr/",
		22,
		[2828],
		[{ "e": 2829 }],
		[{ "v": 2828 }],
		[{ "c": 2830 }],
		[],
		{}
	],
	[
		1,
		"facebook",
		2,
		"^https://(www\\.)?facebook\\.com/",
		22,
		[],
		[{ "e": 2831 }],
		[{ "v": 2831 }],
		[{ "c": 2831 }, {
			"check": "none",
			"wv": 2831
		}],
		[],
		{}
	],
	[
		1,
		"facebook-mobile",
		2,
		"^https://(m|mbasic)\\.facebook\\.com/",
		22,
		[1215],
		[{ "e": 1215 }],
		[{ "v": 1215 }],
		[{ "c": 2832 }, {
			"check": "none",
			"wv": 1215
		}],
		[],
		{}
	],
	[
		1,
		"fascicolosanitario-lombardia",
		0,
		"^https?://(\\w+\\.)?fascicolosanitario\\.regione\\.lombardia\\.it/",
		22,
		[456],
		[{ "e": 2833 }],
		[{ "v": 2834 }],
		[{ "c": 2835 }],
		[{ "cc": 2836 }],
		{}
	],
	[
		1,
		"fideuram",
		2,
		"^https?://(www\\.)?fideuram\\.it/",
		22,
		[2837],
		[{ "e": 2838 }],
		[{ "v": 2838 }],
		[{ "c": 2838 }],
		[{ "cc": 2839 }],
		{}
	],
	[
		1,
		"financestrategists.com",
		1,
		"^https://(www\\.)?financestrategists\\.com/",
		22,
		[2840],
		[{ "e": 2840 }],
		[{ "v": 2840 }],
		[{ "h": 2840 }],
		[],
		{}
	],
	[
		1,
		"fis-data-exchange",
		2,
		"^https://services\\.dataexchange\\.fiscloudservices\\.com/",
		22,
		[2841],
		[{ "e": 2842 }],
		[{ "v": 2842 }],
		[{ "c": 2842 }],
		[{ "cc": 2843 }],
		{}
	],
	[
		1,
		"fondoest.it",
		2,
		"^https?://(www\\.)?fondoest\\.it/",
		22,
		[2844],
		[{ "e": 2845 }],
		[{ "v": 2846 }],
		[{ "c": 2846 }, { "c": 2847 }],
		[{ "cc": 2848 }],
		{}
	],
	[
		1,
		"fonts.google.com",
		2,
		"^https?://fonts\\.google\\.com/",
		22,
		[2849],
		[{ "e": 2850 }],
		[{ "v": 2849 }],
		[{ "c": 2851 }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 2849
		}],
		{}
	],
	[
		1,
		"forsakringskassan.se",
		2,
		"^https?://(\\w+\\.)?forsakringskassan\\.se/",
		22,
		[2852],
		[{ "e": 2853 }],
		[{ "v": 2853 }],
		[{ "c": 2854 }],
		[{ "cc": 2855 }],
		{}
	],
	[
		1,
		"futurabolzano.it",
		1,
		"^https?://(www\\.)?futurabolzano\\.it/",
		22,
		[2856],
		[{ "e": 2856 }],
		[{ "v": 2856 }],
		[{ "h": 2856 }],
		[{
			"check": "none",
			"v": 2856
		}],
		{}
	],
	[
		1,
		"gays-cruising",
		2,
		"^https?://([\\w-]+\\.)?gays-cruising\\.com/",
		22,
		[2857],
		[{ "e": 2858 }],
		[{ "v": 2857 }],
		[
			{ "c": 2859 },
			{ "wv": 2860 },
			{
				"all": true,
				"optional": true,
				"k": 2861
			},
			{ "k": 2862 }
		],
		[{ "cc": 2863 }],
		{}
	],
	[
		1,
		"geeks-for-geeks",
		1,
		"^https://www\\.geeksforgeeks\\.org/",
		22,
		[2864],
		[{ "e": 2864 }],
		[{ "v": 2864 }],
		[{ "h": 2864 }],
		[],
		{}
	],
	[
		1,
		"geni.com",
		1,
		"^https://(www\\.)?geni\\.com/",
		22,
		[2865],
		[{ "e": 2865 }],
		[{ "v": 2865 }],
		[{ "h": 2865 }],
		[],
		{}
	],
	[
		1,
		"givedirectly",
		2,
		"^https?://(www\\.)?givedirectly\\.org/",
		22,
		[2866],
		[{ "e": 2866 }],
		[{ "v": 2866 }],
		[{
			"retry": 3,
			"c": 2867
		}],
		[{
			"check": "none",
			"wv": 2866
		}],
		{}
	],
	[
		1,
		"gla.ac.uk",
		2,
		"^https?://(\\w+\\.)?gla\\.ac\\.uk/",
		22,
		[2868],
		[{ "e": 2869 }],
		[{ "v": 2869 }],
		[
			{ "c": 2870 },
			{ "k": 2871 },
			{ "k": 2872 }
		],
		[
			{ "cc": 2873 },
			{ "cc": 2874 },
			{ "cc": 2875 }
		],
		{}
	],
	[
		1,
		"glastonburyfestivals",
		0,
		"^https://(\\w+\\.)?glastonburyfestivals\\.co\\.uk/",
		22,
		[2876],
		[{ "e": 2877 }],
		[{ "v": 2877 }],
		[{ "c": 2878 }],
		[],
		{}
	],
	[
		1,
		"gnoccaforum",
		2,
		"^https?://(www\\.)?gnoccaforum\\.com/",
		22,
		[2879],
		[{ "e": 2880 }],
		[{ "v": 2879 }],
		[{ "c": 2881 }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 2879
		}],
		{}
	],
	[
		1,
		"gobiernodecanarias",
		2,
		"^https?://(\\w+\\.)?(gobiernodecanarias\\.org|gobcan\\.net)/",
		22,
		[2882],
		[{ "e": 2883 }],
		[{ "v": 2882 }],
		[
			{ "c": 2884 },
			{ "wv": 2883 },
			{
				"optional": true,
				"k": 2885
			},
			{ "c": 2886 }
		],
		[{ "cc": 2887 }],
		{}
	],
	[
		1,
		"gov-pl-cookies-info",
		1,
		"^https?://([\\w-]+\\.)*gov\\.pl/",
		22,
		[2888],
		[{ "e": 2889 }],
		[{ "v": 2890 }],
		[{ "h": 2888 }],
		[],
		{}
	],
	[
		1,
		"groundnews",
		0,
		"^https://(www\\.)?ground\\.news/",
		22,
		[],
		[{ "e": 2891 }],
		[{ "v": 2891 }],
		[
			{ "waitForThenClick": [".fixed:has([data-testid=closeCookieBanner])", "xpath///button[contains(., 'Manage cookies')]"] },
			{ "waitFor": ["[data-testid=modal]", "xpath///span[contains(., 'Essential cookies')]"] },
			{
				"click": ["[data-testid=modal]", "xpath///button[contains(., 'On')]"],
				"all": true,
				"optional": true
			},
			{ "waitForThenClick": ["[data-testid=modal]", "xpath///button[contains(., 'Save & reload')]"] }
		],
		[],
		{}
	],
	[
		1,
		"groupama.fr",
		2,
		"^https?://(www\\.)?groupama\\.fr/",
		22,
		[2892],
		[{ "e": 2893 }],
		[{ "v": 2892 }],
		[{
			"timeout": 1e4,
			"c": 2894
		}],
		[{ "cc": 2895 }],
		{}
	],
	[
		1,
		"gundam-base-entry",
		2,
		"^https://(www\\.)?gundam-base-entry\\.net/",
		22,
		[2896],
		[{ "e": 2897 }],
		[{ "v": 2897 }],
		[
			{ "c": 2897 },
			{ "c": 2898 },
			{
				"check": "none",
				"wv": 2896
			}
		],
		[{ "cc": 2899 }],
		{}
	],
	[
		1,
		"hashicorp",
		2,
		"^https://[a-z]*\\.hashicorp\\.com/",
		22,
		[2900],
		[{ "e": 2900 }],
		[{ "v": 2900 }],
		[{ "c": 2901 }, { "c": 2902 }],
		[],
		{}
	],
	[
		1,
		"head-fi",
		2,
		"^https?://(www\\.)?head-fi\\.org/",
		22,
		[2903],
		[{ "e": 2904 }],
		[{ "v": 2903 }],
		[{ "c": 2904 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 2903
		}],
		{}
	],
	[
		1,
		"hearst-us",
		1,
		"^https://(www\\.)?(menshealth|womenshealthmag|cosmopolitan|esquire|elle|elledecor|harpersbazaar|goodhousekeeping|popularmechanics|caranddriver|delish|veranda|roadandtrack|bestproducts|countryliving|housebeautiful|bicycling|biography|pitchfork|prevention|runnersworld|thepioneerwoman|townandcountrymag|seventeen|oprahdaily|womansday|redbookmag|autoweek)\\.com/",
		10,
		[2905],
		[{ "e": 2905 }],
		[{
			"check": "any",
			"v": 2905
		}],
		[{ "h": 2905 }],
		[{
			"check": "none",
			"v": 2905
		}],
		{}
	],
	[
		1,
		"hetzner.com",
		2,
		"^https://www\\.hetzner\\.com/",
		22,
		[2906],
		[{ "e": 2906 }],
		[{ "v": 2906 }],
		[{ "k": 2907 }],
		[],
		{}
	],
	[
		1,
		"hsbc-au",
		2,
		"^https://(www\\.)?hsbc\\.com\\.au/",
		22,
		[2908],
		[{ "e": 2909 }],
		[{ "v": 2909 }],
		[{ "c": 2910 }],
		[{
			"check": "none",
			"timeout": 3e3,
			"wv": 2909
		}],
		{}
	],
	[
		1,
		"hyrabostad.se",
		2,
		"^https?://(www\\.)?hyrabostad\\.se/",
		22,
		[2911],
		[{ "e": 2912 }],
		[{ "v": 2912 }],
		[
			{ "c": 2913 },
			{ "wv": 2914 },
			{
				"if": { "e": 2915 },
				"then": [{ "k": 2915 }]
			},
			{
				"retry": 3,
				"retryInterval": 400,
				"c": 2916
			}
		],
		[{
			"check": "none",
			"v": 2917
		}],
		{}
	],
	[
		1,
		"ibanez",
		2,
		"^https?://www\\.ibanez\\.com/",
		22,
		[2918],
		[{ "e": 2919 }],
		[{ "v": 2920 }],
		[{ "c": 2919 }],
		[{ "cc": 2921 }],
		{}
	],
	[
		1,
		"idoctors.it",
		2,
		"^https?://(www\\.)?idoctors\\.it/",
		22,
		[2922, 2923],
		[{ "e": 2922 }],
		[{ "v": 2922 }],
		[
			{ "c": 2924 },
			{ "wv": 2923 },
			{
				"if": { "e": 2925 },
				"then": [{ "k": 2926 }]
			},
			{
				"retry": 3,
				"retryInterval": 500,
				"c": 2927
			}
		],
		[{ "cc": 2928 }],
		{}
	],
	[
		1,
		"ign.es",
		1,
		"^https?://(www\\.)?ign\\.es/",
		22,
		[2929],
		[{ "e": 2930 }],
		[{ "v": 2929 }],
		[{ "h": 2929 }],
		[{
			"check": "none",
			"v": 2929
		}],
		{}
	],
	[
		1,
		"iisvaldagno",
		1,
		"^https?://(www\\.)?iisvaldagno\\.it/",
		22,
		[2931],
		[{ "e": 2932 }],
		[{ "v": 2931 }],
		[{ "h": 2931 }],
		[{
			"check": "none",
			"v": 2931
		}],
		{}
	],
	[
		1,
		"imdb",
		0,
		"^https://(www\\.)?(m\\.)?imdb.com/",
		22,
		[2900],
		[{ "e": 2900 }],
		[{ "v": 2900 }],
		[{ "c": 2933 }],
		[],
		{}
	],
	[
		1,
		"ing-de",
		0,
		"^https://(\\w+\\.)?ing\\.de/",
		10,
		[],
		[{ "exists": ["ing-cc-manager", "ing-cc-dialog-level0"] }],
		[{ "exists": [
			"ing-cc-manager[is-open]",
			"ing-cc-dialog-level0",
			".cc-l0__button__more"
		] }],
		[{ "waitForThenClick": [
			"ing-cc-manager",
			"ing-cc-dialog-level0",
			".cc-l0__button__more"
		] }],
		[],
		{}
	],
	[
		1,
		"ing-nl",
		2,
		"^https://([a-z0-9-]+\\.)?ing\\.nl/",
		22,
		[],
		[{ "exists": [
			"ing-app-open-page",
			"#cookieDialog",
			"ing-feat-cookie-dialog-nl"
		] }],
		[{ "visible": [
			"ing-app-open-page",
			"#cookieDialog",
			"ing-feat-cookie-dialog-nl",
			"ing-feat-global-cookie-preference",
			"cookie-preference-main",
			"[data-testid=reject]"
		] }],
		[{ "waitForThenClick": [
			"ing-app-open-page",
			"#cookieDialog",
			"ing-feat-cookie-dialog-nl",
			"ing-feat-global-cookie-preference",
			"cookie-preference-main",
			"[data-testid=reject]"
		] }],
		[{ "cc": 2934 }],
		{}
	],
	[
		1,
		"instagram",
		2,
		"^https://www\\.instagram\\.com/",
		22,
		[],
		[{ "e": 2935 }],
		[{ "v": 2935 }],
		[{ "c": 2936 }, { "wait": 2e3 }],
		[],
		{}
	],
	[
		1,
		"intesasanpaolo",
		2,
		"^https?://(\\w+\\.)?intesasanpaolo\\.com/",
		22,
		[2937],
		[{ "e": 2938 }],
		[{ "v": 2938 }],
		[{ "c": 2938 }],
		[{ "cc": 2939 }, {
			"negated": true,
			"cc": 2940
		}],
		{}
	],
	[
		1,
		"io.no",
		0,
		"^https?://([a-z0-9-]+\\.)?io\\.no/",
		22,
		[2941],
		[{ "e": 2942 }],
		[{ "v": 2941 }],
		[{ "c": 2942 }],
		[{
			"check": "none",
			"timeout": 1e3,
			"wv": 2941
		}],
		{}
	],
	[
		2,
		"istore.co.za",
		1,
		"^https?://(www\\.)?istore(preowned)?\\.co\\.za/",
		22,
		[274],
		[{ "e": 274 }],
		[{ "v": 274 }],
		[
			{ "h": 274 },
			{
				"optional": true,
				"h": 2943
			},
			{
				"removeClass": "no-scroll",
				"selector": "body",
				"optional": true
			}
		],
		[],
		{}
	],
	[
		1,
		"itopvpn.com",
		1,
		"^https://(www\\.)?itopvpn.com/",
		22,
		[],
		[{ "e": 2944 }],
		[{ "e": 2944 }],
		[{ "h": 2944 }],
		[],
		{}
	],
	[
		1,
		"iubenda-rti",
		2,
		"^https?://([\\w-]+\\.)*(mediaset\\.it|meteo\\.it|wittytv\\.it|today\\.it|milanotoday\\.it|romatoday\\.it|padovaoggi\\.it|bolognatoday\\.it|torinotoday\\.it|genovatoday\\.it|trevisotoday\\.it)/",
		10,
		[1032],
		[{ "e": 2945 }],
		[{ "v": 2945 }],
		[{ "c": 2945 }, { "c": 2946 }],
		[],
		{}
	],
	[
		1,
		"iworks-footer-notice",
		2,
		"^https?://(www\\.)?prorankingi\\.pl/",
		22,
		[2947],
		[{ "e": 2947 }],
		[{ "v": 2947 }, {
			"negated": true,
			"cc": 2948
		}],
		[{
			"timeout": 15e3,
			"optional": true,
			"w": 2949
		}, {
			"retry": 3,
			"retryInterval": 1e3,
			"c": 2950
		}],
		[{ "cc": 2948 }],
		{}
	],
	[
		1,
		"justgiving.com",
		2,
		"^https://(?:[a-z0-9-]+\\.)?justgiving\\.com/",
		22,
		[2951],
		[{ "any": [{ "e": 2951 }, { "e": 2952 }] }],
		[{ "v": 2951 }, { "e": 2953 }],
		[{ "c": 2953 }],
		[{ "wait": 500 }, { "cc": 2954 }],
		{}
	],
	[
		1,
		"juzaphoto",
		2,
		"^https?://(\\w+\\.)?juzaphoto\\.com/",
		22,
		[2955],
		[{ "e": 2955 }],
		[{ "v": 2955 }],
		[{ "c": 2956 }],
		[{ "cc": 2957 }],
		{}
	],
	[
		1,
		"kartverket",
		0,
		"^https?://([a-z0-9-]+\\.)?kartverket\\.no/",
		22,
		[2958],
		[{ "e": 2959 }],
		[{ "v": 2959 }],
		[
			{ "c": 2959 },
			{ "wv": 2960 },
			{
				"optional": true,
				"k": 2961
			},
			{ "k": 2960 }
		],
		[{
			"check": "none",
			"timeout": 1e3,
			"wv": 2960
		}],
		{}
	],
	[
		1,
		"kickstarter.com",
		2,
		"^https?://(www\\.)?kickstarter\\.com/",
		22,
		[2962],
		[{ "e": 2963 }],
		[{ "v": 2963 }],
		[{ "c": 2964 }],
		[{
			"check": "none",
			"v": 2963
		}],
		{}
	],
	[
		1,
		"kingrecords-co-jp",
		2,
		"^https?://(?:[^/]+\\.)?kingrecords\\.co\\.jp/",
		22,
		[2965],
		[{ "e": 2966 }],
		[{ "v": 2966 }],
		[
			{
				"timeout": 1e4,
				"optional": true,
				"w": 2967
			},
			{ "c": 2966 },
			{
				"if": { "v": 2968 },
				"then": [{ "wait": 1e3 }, { "k": 2966 }]
			},
			{
				"check": "none",
				"timeout": 5e3,
				"wv": 2968
			}
		],
		[{ "cc": 2969 }],
		{}
	],
	[
		1,
		"kiwico",
		2,
		"^https?://(www\\.)?kiwico\\.com/",
		10,
		[2970],
		[{ "e": 2971 }],
		[{ "v": 2972 }],
		[
			{ "c": 2971 },
			{ "c": 2973 },
			{
				"check": "none",
				"timeout": 3e3,
				"wv": 2974
			},
			{ "c": 2975 }
		],
		[{
			"check": "none",
			"timeout": 3e3,
			"wv": 2970
		}],
		{}
	],
	[
		1,
		"kleinanzeigen-de",
		2,
		"^https?://(www\\.)?kleinanzeigen\\.de",
		22,
		[2976],
		[{ "e": 2977 }],
		[{ "v": 2977 }],
		[{ "k": 2977 }],
		[],
		{}
	],
	[
		1,
		"la-becanerie",
		2,
		"^https://(www\\.)?la-becanerie\\.com/",
		22,
		[2978],
		[{ "e": 2979 }],
		[{ "v": 2980 }],
		[{ "c": 2981 }],
		[{ "cc": 2982 }],
		{}
	],
	[
		1,
		"lacoccinelle",
		2,
		"^https?://(\\w+\\.)?lacoccinelle\\.net/",
		22,
		[1430],
		[{ "e": 1430 }],
		[{
			"check": "any",
			"v": 2983
		}],
		[{
			"if": { "e": 1432 },
			"then": [
				{
					"all": true,
					"retry": 3,
					"c": 1436
				},
				{ "c": 2984 },
				{
					"timeout": 5e3,
					"optional": true,
					"c": 2985
				}
			],
			"else": [
				{ "c": 2986 },
				{ "c": 2987 },
				{
					"check": "none",
					"timeout": 1500,
					"optional": true,
					"wv": 1446
				},
				{
					"if": {
						"check": "any",
						"v": 2988
					},
					"then": [{
						"all": true,
						"k": 2988
					}, {
						"check": "none",
						"timeout": 5e3,
						"wv": 1446
					}]
				}
			]
		}],
		[{
			"check": "none",
			"v": 2983
		}],
		{}
	],
	[
		1,
		"lantmateriet",
		2,
		"^https?://(www\\.)?lantmateriet\\.se/",
		22,
		[2989],
		[{ "e": 2990 }],
		[{ "v": 2991 }],
		[{ "c": 2990 }],
		[{ "cc": 2992 }],
		{}
	],
	[
		3,
		"latrobe.edu.au",
		1,
		"^https?://(\\w+\\.)?latrobe\\.edu\\.au/",
		10,
		[2993],
		[{ "e": 2994 }],
		[{ "v": 2993 }],
		[{ "h": 2993 }, {
			"stylesheet": "body.gdpr-on #header { top: 0 !important; } body.vi #header #gdpr ~ #global-search-button, body.vi #header #gdpr ~ #global-search-button + label { top: 1.25rem; bottom: auto; }",
			"stylesheetId": "latrobe-gdpr-layout"
		}],
		[],
		{}
	],
	[
		1,
		"leafly",
		1,
		"^https://(www\\.)?leafly\\.com/",
		22,
		[],
		[{ "e": 2995 }],
		[{ "v": 2995 }],
		[{ "h": 2995 }],
		[],
		{}
	],
	[
		1,
		"legislation-gov-uk",
		2,
		"^https?://(\\w+\\.)?legislation\\.gov\\.uk/",
		22,
		[2996],
		[{ "e": 2997 }],
		[{ "v": 2997 }],
		[{ "c": 2997 }, {
			"timeout": 3e3,
			"optional": true,
			"c": 2998
		}],
		[{ "cc": 2999 }],
		{}
	],
	[
		1,
		"lego",
		2,
		"^https?://(www\\.)?lego\\.com/",
		22,
		[3e3],
		[{ "e": 3001 }],
		[{ "v": 3001 }],
		[
			{ "c": 3001 },
			{
				"any": [{ "cc": 3002 }, {
					"timeout": 1e3,
					"wv": 3003
				}],
				"optional": true
			},
			{
				"if": { "v": 3003 },
				"then": [{
					"check": "none",
					"timeout": 3e4,
					"wv": 3003
				}, {
					"timeout": 5e3,
					"c": 3001
				}],
				"optional": true
			}
		],
		[{ "cc": 3004 }],
		{}
	],
	[
		1,
		"lendable",
		2,
		"^https?://([\\w-]+\\.)?lendable\\.co\\.uk/",
		22,
		[3005],
		[{ "e": 3006 }],
		[{ "v": 3005 }],
		[
			{ "c": 3007 },
			{ "c": 3008 },
			{
				"check": "none",
				"wv": 3005
			}
		],
		[{ "cc": 441 }],
		{}
	],
	[
		1,
		"leukhuis-nl",
		1,
		"^https?://(www\\.)?leukhuis\\.nl/",
		22,
		[3009],
		[{ "e": 3010 }],
		[{ "v": 3009 }],
		[{ "h": 3009 }],
		[{
			"check": "none",
			"v": 3009
		}],
		{}
	],
	[
		1,
		"lexbase.se",
		1,
		"^https?://(www\\.)?lexbase\\.se/",
		22,
		[3011],
		[{ "e": 3012 }],
		[{ "v": 3011 }],
		[{ "h": 3011 }],
		[{
			"check": "none",
			"v": 3011
		}],
		{}
	],
	[
		1,
		"libris.nl",
		2,
		"^https?://(www\\.)?libris\\.nl/",
		22,
		[3013],
		[{ "e": 3014 }],
		[{ "v": 3014 }],
		[{
			"if": { "e": 3015 },
			"then": [{
				"all": true,
				"k": 3015
			}]
		}, { "c": 3014 }],
		[{ "cc": 3016 }],
		{}
	],
	[
		1,
		"librus",
		2,
		"^https?://([a-z0-9-]+\\.)?librus\\.pl/",
		22,
		[3017],
		[{ "e": 3018 }],
		[{ "v": 3018 }],
		[
			{ "c": 3018 },
			{ "w": 3019 },
			{
				"if": { "e": 3020 },
				"then": [{
					"all": true,
					"k": 3020
				}]
			},
			{ "c": 3021 }
		],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 3022
		}],
		{}
	],
	[
		1,
		"livsmedelsverket",
		2,
		"^https?://(\\w+\\.)?livsmedelsverket\\.se/",
		22,
		[34],
		[{ "e": 3023 }],
		[{ "v": 3024 }],
		[
			{ "c": 3023 },
			{ "wv": 3025 },
			{
				"all": true,
				"optional": true,
				"k": 3026
			},
			{ "k": 3027 }
		],
		[{ "cc": 3028 }],
		{}
	],
	[
		1,
		"lucozade.com",
		2,
		"^https://(www\\.)?lucozade\\.com/",
		22,
		[2740, 3029],
		[{ "e": 2740 }],
		[{ "v": 2740 }],
		[{ "c": 3030 }],
		[{ "cc": 3031 }],
		{}
	],
	[
		1,
		"lucrin",
		2,
		"^https?://(www\\.)?lucrin\\.(com|com\\.au|co\\.uk|ca|ch|de|es|fr|it)/",
		22,
		[3032, 3033],
		[{ "e": 3034 }],
		[{ "v": 274 }],
		[
			{ "c": 3034 },
			{ "wv": 3035 },
			{
				"all": true,
				"optional": true,
				"k": 3036
			},
			{ "c": 3035 }
		],
		[{ "cc": 3037 }],
		{}
	],
	[
		1,
		"luxmed",
		2,
		"^https?://([a-z0-9-]+\\.)?luxmed\\.pl/",
		22,
		[],
		[{ "e": 3038 }],
		[{ "v": 3038 }],
		[{ "c": 3039 }],
		[{ "cc": 3040 }],
		{}
	],
	[
		1,
		"mackeeper",
		0,
		"^https?://(\\w+\\.)?mackeeper\\.com/",
		22,
		[3041],
		[{ "e": 3042 }],
		[{ "v": 3042 }],
		[{ "c": 3043 }],
		[{ "cc": 3044 }],
		{}
	],
	[
		1,
		"mainichi",
		2,
		"^https?://(\\w+\\.)?mainichi\\.jp/",
		22,
		[],
		[{ "e": 3045 }, {
			"negated": true,
			"e": 870
		}],
		[{ "v": 3045 }],
		[{ "c": 3046 }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 3047
		}],
		{}
	],
	[
		1,
		"makitatools",
		2,
		"^https://(www\\.)?makitatools\\.com/",
		22,
		[3048],
		[{ "e": 3048 }],
		[{ "v": 3048 }],
		[
			{ "c": 3049 },
			{ "c": 3050 },
			{
				"check": "none",
				"wv": 3048
			}
		],
		[{
			"check": "none",
			"v": 3048
		}],
		{}
	],
	[
		1,
		"malaysiaairlines.com",
		0,
		"^https?://(\\w+\\.)?malaysiaairlines\\.com/",
		22,
		[],
		[{ "e": 3051 }],
		[{ "v": 3051 }],
		[
			{ "c": 3052 },
			{ "wv": 3053 },
			{
				"all": true,
				"optional": true,
				"k": 3054
			},
			{ "c": 3055 }
		],
		[],
		{}
	],
	[
		1,
		"mango",
		2,
		"^https://(shop\\.mango|www\\.mangooutlet)\\.com/",
		22,
		[3056],
		[{ "e": 3057 }],
		[{ "v": 3057 }],
		[{
			"if": { "e": 3058 },
			"then": [{
				"retry": 5,
				"retryInterval": 500,
				"c": 3058
			}],
			"else": [{
				"retry": 5,
				"retryInterval": 500,
				"c": 3059
			}, {
				"retry": 5,
				"retryInterval": 500,
				"c": 3060
			}]
		}],
		[{ "cc": 3061 }],
		{}
	],
	[
		1,
		"massaggiamilano",
		2,
		"^https?://(www\\.)?massagg(iamilano|iemozionali)\\.it/",
		22,
		[3062],
		[{ "e": 3063 }],
		[{ "v": 3063 }],
		[{ "c": 3063 }, { "c": 3064 }],
		[{
			"check": "none",
			"timeout": 5e3,
			"wv": 3065
		}],
		{}
	],
	[
		1,
		"massgeneralbrigham",
		0,
		"^https?://(\\w+\\.)?massgeneralbrigham\\.org/",
		22,
		[3066],
		[{ "e": 3067 }],
		[{ "v": 3067 }],
		[{ "c": 3067 }],
		[{
			"negated": true,
			"e": 3066
		}],
		{}
	],
	[
		1,
		"matemaks",
		1,
		"^https?://(www\\.)?matemaks\\.pl/",
		22,
		[3068],
		[{ "e": 3069 }],
		[{ "v": 3068 }],
		[{ "h": 3068 }],
		[],
		{}
	],
	[
		1,
		"maticrobots-com",
		2,
		"^https?://(\\w+\\.)?maticrobots\\.com/",
		22,
		[3070],
		[{ "e": 3070 }],
		[{ "v": 3070 }],
		[
			{ "c": 3071 },
			{ "wv": 3072 },
			{ "c": 3073 },
			{ "c": 3074 }
		],
		[],
		{}
	],
	[
		1,
		"medium",
		1,
		"^https://([a-z0-9-]+\\.)?medium\\.com/",
		10,
		[],
		[{ "e": 3075 }],
		[{ "v": 3075 }],
		[{ "h": 3075 }],
		[],
		{}
	],
	[
		1,
		"mega.io",
		2,
		"^https?://(\\w+\\.)?mega\\.(io|nz)/",
		22,
		[3076],
		[{ "e": 3077 }],
		[{ "v": 3076 }],
		[{
			"if": { "v": 3078 },
			"then": [{ "k": 3078 }],
			"else": [
				{ "k": 3077 },
				{ "wv": 3079 },
				{
					"all": true,
					"optional": true,
					"k": 3080
				},
				{ "k": 3079 }
			]
		}],
		[{ "cc": 2928 }],
		{}
	],
	[
		1,
		"merito.pl",
		2,
		"^https?://(\\w+\\.)?merito\\.pl/",
		22,
		[],
		[{ "e": 3081 }],
		[{ "v": 3082 }],
		[
			{ "c": 3083 },
			{ "wv": 3084 },
			{
				"all": true,
				"optional": true,
				"k": 3085
			},
			{ "k": 3086 }
		],
		[{ "cc": 3087 }],
		{}
	],
	[
		1,
		"midway-usa",
		1,
		"^https://www\\.midwayusa\\.com/",
		22,
		[3088],
		[{ "e": 3088 }],
		[{ "v": 3088 }],
		[{ "h": 3088 }],
		[],
		{}
	],
	[
		1,
		"miles-and-more",
		2,
		"^https://(www\\.)?miles-and-more\\.com/",
		22,
		[3089],
		[{ "e": 3090 }],
		[{ "v": 3091 }],
		[{ "wait": 500 }, { "c": 3091 }],
		[{ "cc": 3092 }],
		{}
	],
	[
		1,
		"mipro.com.tw",
		2,
		"^https?://(\\w+\\.)?mipro\\.com\\.tw/",
		22,
		[3093],
		[{ "e": 3094 }],
		[{ "v": 3095 }],
		[{ "c": 3095 }],
		[{
			"negated": true,
			"e": 3093
		}],
		{}
	],
	[
		1,
		"mizuno.com",
		2,
		"^https?://(\\w+\\.)?mizuno\\.com/",
		22,
		[70],
		[{ "e": 3096 }],
		[{ "v": 70 }],
		[{ "c": 3096 }],
		[{ "cc": 3097 }],
		{}
	],
	[
		1,
		"mobile.de",
		2,
		"^https?://([a-z0-9-]+\\.)?mobile\\.de/",
		22,
		[3098],
		[{ "e": 3098 }],
		[{ "v": 3099 }],
		[{
			"retry": 3,
			"retryInterval": 500,
			"c": 3100
		}],
		[{ "wait": 500 }, { "cc": 3101 }],
		{}
	],
	[
		1,
		"modelsociety",
		2,
		"^https?://(www\\.)?modelsociety\\.com/",
		22,
		[3102],
		[{ "e": 3102 }],
		[{ "v": 3102 }],
		[{ "c": 3103 }, {
			"timeout": 3e3,
			"optional": true,
			"c": 3104
		}],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 3102
		}],
		{}
	],
	[
		1,
		"mq.edu.au",
		2,
		"^https?://(\\w+\\.)?mq\\.edu\\.au/",
		10,
		[3105],
		[{ "exists": ["mq-alert-cookies", ".alert"] }],
		[{
			"visible": ["mq-alert-cookies", ".alert"],
			"check": "any"
		}],
		[{
			"if": { "exists": ["mq-alert-cookies[variant=tiktok]", ".alert .button.secondary"] },
			"then": [{ "waitForThenClick": ["mq-alert-cookies[variant=tiktok]", ".alert .button.secondary"] }],
			"else": [{ "waitForThenClick": ["mq-alert-cookies[variant=cookies]", ".alert .button-container button"] }]
		}],
		[{
			"waitForVisible": ["mq-alert-cookies", ".alert"],
			"check": "none",
			"timeout": 2e3
		}],
		{}
	],
	[
		1,
		"msn",
		0,
		"^https?://(www\\.)?msn\\.com/",
		10,
		[3106, 3107],
		[{ "e": 3106 }],
		[{ "v": 3106 }],
		[{ "c": 3108 }],
		[{ "cc": 1821 }],
		{}
	],
	[
		1,
		"nba.com",
		1,
		"^https://(www\\.)?nba\\.com/",
		22,
		[3109],
		[{ "e": 3109 }],
		[{ "v": 3109 }],
		[{ "h": 3109 }],
		[],
		{}
	],
	[
		1,
		"ndl-go-jp",
		2,
		"^https://([a-z0-9-]+\\.)?ndl\\.go\\.jp/",
		22,
		[3110],
		[{ "e": 3111 }],
		[{ "v": 3111 }],
		[{ "c": 3112 }],
		[{
			"timeout": 2e3,
			"check": "none",
			"wv": 3111
		}],
		{}
	],
	[
		1,
		"nederlandseloterij",
		2,
		"^https?://([a-z0-9-]+\\.)?nederlandseloterij\\.nl/",
		22,
		[3113, 3114],
		[{ "e": 3115 }],
		[{ "v": 3115 }],
		[{ "c": 3116 }],
		[{
			"timeout": 2e3,
			"check": "none",
			"wv": 3117
		}],
		{}
	],
	[
		1,
		"nestpensions",
		0,
		"^https?://(www\\.)?nestpensions\\.org\\.uk/",
		22,
		[3118],
		[{ "e": 3119 }],
		[{ "v": 3118 }],
		[{ "c": 3119 }],
		[{ "cc": 3120 }],
		{}
	],
	[
		1,
		"netbeat.de",
		2,
		"^https://(www\\.)?netbeat\\.de/",
		22,
		[3121],
		[{ "e": 3121 }],
		[{ "v": 3121 }],
		[{ "c": 3122 }],
		[],
		{}
	],
	[
		1,
		"newsbreak",
		0,
		"^https?://(www\\.)?newsbreak\\.com/",
		10,
		[],
		[{ "e": 3123 }],
		[{ "v": 3123 }],
		[{ "c": 3123 }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 3123
		}],
		{}
	],
	[
		1,
		"nhm.ac.uk",
		1,
		"^https?://(\\w+\\.)?nhm\\.ac\\.uk/",
		22,
		[3124, 3125],
		[{ "e": 3124 }],
		[{ "v": 3124 }],
		[{ "h": 3126 }],
		[],
		{}
	],
	[
		1,
		"nhnieuws",
		2,
		"^https://(www\\.)?nhnieuws\\.nl/",
		22,
		[3127],
		[{ "e": 3128 }],
		[{
			"check": "any",
			"v": 3128
		}],
		[{ "c": 3129 }],
		[{ "eval": "EVAL_NHNIEUWS_TEST" }],
		{}
	],
	[
		1,
		"nhs-jobs",
		2,
		"^https?://(\\w+\\.)?jobs\\.nhs\\.uk/",
		22,
		[34],
		[{ "e": 3130 }],
		[{ "v": 3130 }],
		[{ "c": 3130 }],
		[],
		{}
	],
	[
		1,
		"nhsapp",
		2,
		"^https?://(\\w+\\.)?nhsapp\\.service\\.nhs\\.uk/",
		22,
		[3131],
		[{ "e": 3132 }],
		[{ "v": 3133 }],
		[{ "c": 3132 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 3133
		}],
		{}
	],
	[
		1,
		"nike",
		2,
		"^https://(www\\.)?nike\\.com/",
		22,
		[],
		[{ "e": 3134 }],
		[{ "v": 3134 }],
		[{
			"all": true,
			"c": 3135
		}, { "c": 3136 }],
		[],
		{}
	],
	[
		1,
		"nordea",
		2,
		"^https?://([a-z0-9-]+\\.)?nordea\\.(se|fi|no|dk)/",
		22,
		[],
		[{ "e": 3137 }],
		[{ "v": 578 }],
		[{
			"all": true,
			"optional": true,
			"k": 3138
		}, { "c": 3139 }],
		[{ "cc": 3140 }],
		{}
	],
	[
		1,
		"nordnet",
		2,
		"^https?://(www\\.)?nordnet\\.(dk|se|no|fi)/",
		22,
		[],
		[{ "e": 3141 }],
		[{ "v": 3141 }],
		[{ "c": 3142 }],
		[{ "cc": 3143 }],
		{}
	],
	[
		1,
		"nos.nl",
		1,
		"^https://nos\\.nl/",
		22,
		[1289],
		[{ "e": 1289 }],
		[{ "visible": ["ccm-notification"] }],
		[{ "h": 1289 }],
		[],
		{}
	],
	[
		1,
		"nutritionix.com",
		0,
		"^https://(www\\.)?nutritionix\\.com/",
		22,
		[3144],
		[{ "e": 3144 }],
		[{ "v": 3144 }],
		[{ "waitForThenClick": ["gdpr-banner", "xpath///button[contains(., 'Refuse')]"] }],
		[],
		{}
	],
	[
		1,
		"octopusenergy-it",
		2,
		"^https?://(www\\.)?octopusenergy\\.it/",
		22,
		[],
		[{ "e": 3145 }],
		[{ "v": 3145 }],
		[
			{ "c": 3145 },
			{ "w": 3146 },
			{
				"if": { "e": 3147 },
				"then": [{ "k": 3146 }]
			},
			{
				"if": { "e": 3148 },
				"then": [{ "k": 3149 }]
			},
			{ "c": 3150 }
		],
		[{ "cc": 3151 }],
		{}
	],
	[
		1,
		"ok",
		0,
		"^https://(\\w+\\.)?ok\\.ru/",
		22,
		[3152],
		[{ "e": 3153 }],
		[{ "v": 3153 }],
		[
			{
				"retry": 6,
				"retryInterval": 1e3,
				"c": 3154
			},
			{ "wv": 3155 },
			{ "wait": 500 },
			{
				"all": true,
				"optional": true,
				"k": 3156
			},
			{ "c": 3157 }
		],
		[],
		{}
	],
	[
		1,
		"olvg",
		2,
		"^https?://(www\\.)?olvg\\.nl/",
		22,
		[3158],
		[{ "e": 3159 }],
		[{ "v": 3160 }],
		[
			{ "c": 3159 },
			{ "c": 3161 },
			{
				"check": "none",
				"timeout": 2e3,
				"optional": true,
				"wv": 3158
			}
		],
		[{ "cc": 3162 }],
		{}
	],
	[
		1,
		"onlineradiobox",
		1,
		"^https?://(\\w+\\.)?onlineradiobox\\.com/",
		22,
		[3163],
		[{ "e": 3164 }],
		[{ "v": 3163 }],
		[{ "h": 3163 }],
		[{
			"check": "none",
			"v": 3163
		}],
		{}
	],
	[
		1,
		"onlyFans.com",
		2,
		"^https://onlyfans\\.com/",
		22,
		[3165],
		[{ "e": 3165 }],
		[{ "e": 3165 }],
		[{ "k": 3166 }, {
			"if": { "e": 3167 },
			"then": [{
				"all": true,
				"k": 3168
			}, { "k": 3169 }]
		}],
		[],
		{}
	],
	[
		1,
		"opalcollection-com",
		1,
		"^https://(www\\.)?opalcollection\\.com/",
		22,
		[3170],
		[{ "v": 3171 }],
		[{ "v": 3170 }],
		[{ "h": 3170 }],
		[],
		{}
	],
	[
		1,
		"openai",
		0,
		"^https://([a-z0-9-]+\\.)?openai\\.com/",
		22,
		[3172],
		[{ "e": 3172 }],
		[{ "v": 3172 }],
		[{ "c": 3173 }],
		[{ "wait": 500 }, { "cc": 3174 }],
		{}
	],
	[
		1,
		"opera.com",
		0,
		"^https?://(www\\.|)?opera\\.com/",
		22,
		[407],
		[{ "e": 3175 }],
		[{ "v": 3175 }],
		[{
			"all": true,
			"timeout": 500,
			"optional": true,
			"c": 3176
		}, { "c": 3177 }],
		[{ "cc": 3178 }, {
			"negated": true,
			"cc": 3179
		}],
		{}
	],
	[
		1,
		"optyczne-pl",
		1,
		"^https?://(\\w+\\.)?optyczne\\.pl/",
		22,
		[3180],
		[{ "e": 3181 }],
		[{ "v": 3180 }],
		[{ "h": 3180 }],
		[],
		{}
	],
	[
		1,
		"orbys",
		1,
		"^https?://(\\w+\\.)?orbys\\.eu/",
		22,
		[3182],
		[{ "e": 3183 }],
		[{ "v": 3182 }],
		[{ "h": 3182 }],
		[{
			"check": "none",
			"v": 3182
		}],
		{}
	],
	[
		1,
		"osf.io",
		1,
		"^https?://(\\w+\\.)?osf\\.io/",
		22,
		[3184],
		[{ "e": 3185 }],
		[{ "v": 3185 }],
		[{ "h": 3184 }],
		[],
		{}
	],
	[
		1,
		"ourworldindata",
		2,
		"^https://ourworldindata\\.org/",
		22,
		[3186],
		[{ "e": 3186 }],
		[{ "v": 3187 }],
		[{ "c": 3188 }],
		[],
		{}
	],
	[
		1,
		"palace-company",
		1,
		"^https://(www\\.)?(moonpalace|palaceresorts|leblancsparesorts|baglionihotels)\\.com/",
		22,
		[407, 3189],
		[{ "e": 3190 }],
		[{ "v": 3190 }],
		[{ "h": 3191 }],
		[],
		{}
	],
	[
		1,
		"paychex",
		1,
		"^https://(www\\.)?paychex\\.com/",
		22,
		[3192],
		[{ "e": 3192 }],
		[{ "v": 3192 }],
		[{ "h": 3192 }],
		[],
		{}
	],
	[
		1,
		"payfip",
		1,
		"^https?://(www\\.)?payfip\\.gouv\\.fr/",
		22,
		[3193],
		[{ "e": 3194 }],
		[{
			"check": "any",
			"v": 3193
		}],
		[{ "h": 3193 }],
		[{
			"check": "none",
			"v": 3193
		}],
		{}
	],
	[
		1,
		"pekao24",
		2,
		"^https?://(www\\.)?pekao24\\.pl/",
		22,
		[3195],
		[{ "e": 3196 }],
		[{ "v": 3196 }],
		[{ "c": 3197 }],
		[{ "cc": 3198 }],
		{}
	],
	[
		1,
		"pensionsmyndigheten",
		2,
		"^https?://(\\w+\\.)?pensionsmyndigheten\\.se/",
		22,
		[3199],
		[{ "e": 3199 }],
		[{ "v": 3199 }],
		[{ "c": 3200 }],
		[{ "cc": 3201 }],
		{}
	],
	[
		1,
		"pharmasave",
		2,
		"^https?://(www\\.)?pharmasave\\.com/",
		22,
		[3202],
		[{ "e": 3203 }],
		[{ "v": 3203 }],
		[{
			"retry": 10,
			"retryInterval": 500,
			"c": 3204
		}, {
			"check": "none",
			"wv": 3202
		}],
		[{ "cc": 3205 }],
		{}
	],
	[
		1,
		"pinterest-business",
		2,
		"^https://[a-z]*\\.pinterest\\.com/",
		22,
		[3206],
		[{ "e": 3206 }],
		[{ "v": 3207 }],
		[{ "c": 3208 }],
		[],
		{}
	],
	[
		1,
		"pitt-edu",
		1,
		"^https?://(\\w+\\.)?pitt\\.edu/",
		22,
		[3209],
		[{ "e": 3209 }],
		[{ "v": 3209 }],
		[{ "h": 3209 }],
		[],
		{}
	],
	[
		1,
		"pizzapilgrims.co.uk",
		2,
		"^https?://(www\\.)?pizzapilgrims\\.co\\.uk/",
		10,
		[3210],
		[{ "e": 3211 }],
		[{ "v": 3212 }],
		[
			{ "c": 3213 },
			{ "wv": 3214 },
			{
				"all": true,
				"optional": true,
				"k": 3215
			},
			{ "k": 3216 }
		],
		[{ "cc": 3217 }, { "cc": 3218 }],
		{}
	],
	[
		1,
		"plos",
		0,
		"^https://([.a-zA-Z0-9-]+\\.)?plos\\.org/",
		22,
		[407],
		[{ "e": 3219 }],
		[{ "v": 3219 }],
		[{
			"all": true,
			"optional": true,
			"k": 3220
		}, { "waitForThenClick": ["#cookie-consent", "xpath///button[contains(., 'Save Selected')]"] }],
		[{ "cc": 3221 }],
		{}
	],
	[
		1,
		"podimo",
		2,
		"^https?://(www\\.)?podimo\\.com/",
		22,
		[],
		[{ "e": 3222 }],
		[{
			"check": "any",
			"v": 3222
		}],
		[
			{
				"if": { "v": 3223 },
				"then": [{ "c": 3223 }],
				"else": [{ "c": 3224 }]
			},
			{ "wv": 3225 },
			{
				"all": true,
				"optional": true,
				"k": 3226
			},
			{ "c": 3227 }
		],
		[{ "cc": 3228 }, {
			"negated": true,
			"cc": 3229
		}],
		{}
	],
	[
		1,
		"poki",
		2,
		"^https?://(\\w+\\.)?poki\\.com/",
		22,
		[3230],
		[{ "e": 3231 }],
		[{ "v": 3231 }],
		[{ "c": 3231 }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 3232
		}],
		{}
	],
	[
		1,
		"pornhub-compact-cookie-banner",
		0,
		"^https://(www\\.)?pornhub\\.com/",
		22,
		[3233],
		[{ "e": 3234 }],
		[{ "v": 3234 }],
		[{ "k": 3234 }],
		[],
		{}
	],
	[
		1,
		"pornhub.com",
		0,
		"^https://(\\w+\\.)?pornhub\\.com/",
		22,
		[3235],
		[{ "e": 3236 }],
		[{ "v": 3236 }],
		[{
			"if": { "e": 3237 },
			"then": [{ "c": 3237 }]
		}, {
			"if": { "e": 3238 },
			"then": [{ "k": 3238 }],
			"else": [{ "c": 3239 }]
		}],
		[],
		{}
	],
	[
		1,
		"pornpics.de",
		2,
		"^https?://(www\\.)?pornpics\\.(com|de)/",
		22,
		[],
		[{ "e": 3240 }],
		[{ "v": 3240 }],
		[{ "c": 3241 }],
		[{ "cc": 3242 }],
		{}
	],
	[
		1,
		"posthog",
		2,
		"^https?://(www\\.)?posthog\\.com/",
		22,
		[],
		[{ "e": 3243 }],
		[{ "v": 3243 }],
		[{ "c": 3244 }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 3243
		}],
		{}
	],
	[
		2,
		"postnl",
		0,
		"^https://([a-z]*\\.)?postnl\\.nl/",
		22,
		[3245],
		[{ "e": 3245 }],
		[{ "visible": ["pnl-cookie-wall-widget", ".pnl-cookie-wall"] }],
		[
			{ "waitForThenClick": ["pnl-cookie-wall-widget", ".cookie-overview__footer button.stamp-button--variant-secondary:last-child"] },
			{
				"waitForVisible": ["pnl-cookie-wall-widget", ".pnl-cookie-wall"],
				"check": "none",
				"timeout": 3e3,
				"optional": true
			},
			{
				"setStyle": "",
				"selector": "body",
				"optional": true
			}
		],
		[{ "cc": 3246 }],
		{}
	],
	[
		1,
		"povr",
		0,
		"^https://povr\\.com/",
		22,
		[],
		[{ "e": 3247 }],
		[{ "v": 3247 }],
		[{ "h": 3248 }, {
			"if": { "e": 3249 },
			"then": [
				{ "w": 3250 },
				{
					"all": true,
					"optional": true,
					"k": 3251
				},
				{ "c": 3252 },
				{ "eval": "EVAL_POVR_GOBACK" }
			],
			"else": [{ "c": 3253 }]
		}],
		[],
		{}
	],
	[
		1,
		"praca-pl",
		2,
		"^https?://(www\\.)?praca\\.pl/",
		22,
		[3254],
		[{ "e": 3255 }],
		[{ "v": 3255 }],
		[
			{ "c": 3255 },
			{ "wv": 3256 },
			{ "k": 3255 }
		],
		[{
			"check": "none",
			"wv": 3257
		}],
		{}
	],
	[
		1,
		"praktikertjanst",
		2,
		"^https?://(www\\.)?praktikertjanst\\.se/",
		22,
		[3258],
		[{ "e": 3259 }],
		[{ "v": 3260 }],
		[{
			"all": true,
			"optional": true,
			"k": 3261
		}, { "c": 3260 }],
		[{ "cc": 3262 }],
		{}
	],
	[
		1,
		"productz.com",
		2,
		"^https://productz\\.com/",
		22,
		[],
		[{ "e": 3263 }],
		[{ "v": 3263 }],
		[{ "c": 3264 }],
		[],
		{}
	],
	[
		1,
		"profiler-dk",
		1,
		"^https?://(www\\.)?(profiler|debtor)\\.dk/",
		22,
		[3265],
		[{ "e": 3266 }],
		[{ "v": 3265 }],
		[{ "h": 3265 }],
		[],
		{}
	],
	[
		1,
		"publicmobile",
		2,
		"^https?://(www\\.)?publicmobile\\.ca/",
		22,
		[3267],
		[{ "e": 3267 }],
		[{ "v": 3268 }],
		[
			{ "c": 3269 },
			{ "wv": 3270 },
			{
				"all": true,
				"optional": true,
				"k": 3271
			},
			{ "c": 3272 },
			{
				"check": "none",
				"timeout": 3e3,
				"wv": 3268
			}
		],
		[{ "cc": 3273 }],
		{}
	],
	[
		1,
		"puesc-gov-pl",
		2,
		"^https?://(www\\.)?puesc\\.gov\\.pl/",
		22,
		[3274],
		[{ "e": 3275 }],
		[{ "v": 3275 }],
		[{
			"retry": 3,
			"retryInterval": 500,
			"c": 3275
		}],
		[{ "cc": 3276 }],
		{}
	],
	[
		3,
		"racv",
		1,
		"^https?://(www\\.)?racv\\.com\\.au/",
		10,
		[3277],
		[{ "e": 3278 }],
		[{ "v": 3278 }],
		[{ "h": 3277 }, {
			"stylesheet": "body.gdpr-active { overflow: auto !important; } body.gdpr-active::before { display: none !important; }",
			"stylesheetId": "racv-gdpr-backdrop"
		}],
		[],
		{}
	],
	[
		1,
		"raspberrypi.com",
		0,
		"^https://([a-z0-9-]+\\.)?raspberrypi\\.com/",
		10,
		[],
		[{ "e": 3279 }],
		[{ "v": 3279 }],
		[{ "c": 3279 }],
		[{
			"check": "none",
			"v": 3279
		}],
		{}
	],
	[
		1,
		"readly",
		2,
		"^https://([a-z0-9-]+\\.)?readly\\.(com|co)/",
		22,
		[3280, 3281],
		[{ "e": 3282 }],
		[{
			"check": "any",
			"v": 3282
		}],
		[{
			"if": { "e": 3283 },
			"then": [{ "c": 3283 }],
			"else": [
				{ "c": 3284 },
				{
					"if": { "e": 3285 },
					"then": [{
						"all": true,
						"c": 3285
					}],
					"else": []
				},
				{ "c": 3286 }
			]
		}],
		[],
		{}
	],
	[
		1,
		"reddit.com",
		2,
		"^https://(www|old)\\.reddit\\.com/",
		22,
		[3287],
		[{ "e": 3288 }],
		[{ "v": 3288 }],
		[{ "c": 3289 }],
		[{ "cc": 3290 }],
		{}
	],
	[
		1,
		"refurbed",
		2,
		"^https?://(www\\.)?refurbed\\.(com|co\\.uk|[a-z]{2})/",
		22,
		[3291],
		[{ "e": 3292 }],
		[{ "v": 3291 }],
		[{ "c": 3292 }, {
			"check": "none",
			"timeout": 2e3,
			"wv": 3291
		}],
		[{ "cc": 3293 }, { "cc": 3294 }],
		{}
	],
	[
		1,
		"rejestr.io",
		0,
		"^https?://(www\\.)?rejestr\\.io/",
		22,
		[],
		[{ "e": 3295 }],
		[{ "v": 3295 }],
		[{ "c": 3295 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 3295
		}],
		{}
	],
	[
		1,
		"remarkable.com",
		1,
		"^https://(www\\.)?remarkable\\.com/",
		22,
		[3296],
		[{ "e": 3297 }],
		[{ "v": 3297 }],
		[{ "h": 3296 }],
		[],
		{}
	],
	[
		1,
		"rinkabyror-se",
		1,
		"^https?://(www\\.)?rinkabyror\\.se/",
		22,
		[3298],
		[{ "e": 3299 }],
		[{ "v": 3298 }],
		[{ "h": 3298 }],
		[],
		{}
	],
	[
		1,
		"roblox",
		0,
		"^https://(www\\.)?roblox\\.com/",
		10,
		[],
		[{ "e": 3300 }],
		[{ "v": 3301 }],
		[{ "c": 3302 }],
		[{ "cc": 3303 }],
		{}
	],
	[
		1,
		"rog-forum.asus.com",
		2,
		"^https://rog-forum\\.asus\\.com/",
		22,
		[3304],
		[{ "e": 3304 }],
		[{ "v": 3304 }],
		[{ "k": 3305 }, { "c": 3306 }],
		[],
		{}
	],
	[
		1,
		"romeo",
		2,
		"^https?://(www\\.)?romeo\\.com/",
		22,
		[],
		[{ "e": 3307 }],
		[{ "v": 3307 }],
		[
			{ "c": 3308 },
			{ "wv": 3309 },
			{
				"if": { "e": 3310 },
				"then": [{ "k": 3309 }]
			},
			{ "k": 3311 },
			{
				"check": "none",
				"wv": 3307
			}
		],
		[],
		{}
	],
	[
		1,
		"roofingmegastore.co.uk",
		2,
		"^https://(www\\.)?roofingmegastore\\.co\\.uk",
		22,
		[3312],
		[{ "e": 3312 }],
		[{ "v": 3312 }],
		[{ "k": 3313 }, { "c": 3314 }],
		[],
		{}
	],
	[
		1,
		"route-inn",
		2,
		"^https?://(\\w+\\.)?(route-inn|ark-hotel)\\.co\\.jp/",
		22,
		[2864],
		[{ "e": 3315 }],
		[{ "v": 3316 }],
		[{ "c": 3315 }],
		[{ "cc": 3317 }],
		{}
	],
	[
		1,
		"rspb.org.uk",
		0,
		"^https://(\\w+\\.)?rspb\\.org\\.uk/",
		10,
		[3318],
		[{ "e": 3318 }],
		[{ "v": 3318 }],
		[
			{ "c": 3319 },
			{ "wv": 3320 },
			{ "c": 3321 }
		],
		[{ "cc": 3322 }],
		{}
	],
	[
		1,
		"rt",
		1,
		"^https://(www\\.)?rt\\.com/",
		22,
		[3323],
		[{ "e": 3323 }],
		[{ "v": 3323 }],
		[{ "h": 3323 }],
		[],
		{}
	],
	[
		1,
		"rug-nl",
		0,
		"^https?://(\\w+\\.)?rug\\.nl/",
		10,
		[3324],
		[{ "e": 3325 }],
		[{ "v": 3324 }],
		[{ "c": 3325 }],
		[],
		{}
	],
	[
		1,
		"rule34-xxx",
		2,
		"^https?://(www\\.)?rule34\\.xxx/",
		22,
		[3326],
		[{ "e": 3326 }],
		[{ "v": 3326 }],
		[{ "c": 3327 }],
		[{ "cc": 3328 }],
		{}
	],
	[
		1,
		"rutjes",
		2,
		"^https?://(www\\.)?rutjes(paardenboxen\\.nl|pferdeboxen\\.de)/",
		22,
		[3291],
		[{ "e": 3329 }],
		[{ "v": 3330 }],
		[{ "c": 3330 }],
		[{ "wait": 500 }, { "cc": 3331 }],
		{}
	],
	[
		1,
		"ryanair",
		0,
		"^https://(www\\.)?ryanair\\.com/",
		10,
		[3332],
		[{ "e": 3332 }],
		[{ "v": 3332 }],
		[{ "c": 3333 }],
		[{ "cc": 3334 }],
		{}
	],
	[
		1,
		"samsung.com",
		1,
		"^https://www\\.samsung\\.com/",
		22,
		[3335],
		[{ "e": 3335 }],
		[{ "v": 3335 }],
		[{ "h": 3335 }],
		[],
		{}
	],
	[
		1,
		"saturdaysnyc",
		2,
		"^https?://(www\\.)?saturdaysnyc\\.com/",
		22,
		[3336],
		[{ "e": 3337 }],
		[{ "v": 3336 }],
		[{ "c": 3337 }],
		[{ "cc": 3338 }],
		{}
	],
	[
		1,
		"scb.se",
		2,
		"^https?://(www\\.)?scb\\.se/",
		22,
		[3339],
		[{ "e": 3340 }],
		[{ "v": 3339 }],
		[{ "waitForThenClick": ["#kakrutan scb-button[value='inget']", "button"] }],
		[{
			"check": "none",
			"v": 3339
		}],
		{}
	],
	[
		1,
		"schadefonds",
		2,
		"^https?://(www\\.)?schadefonds\\.nl/",
		22,
		[3341],
		[{ "e": 3342 }],
		[{ "v": 3342 }],
		[{
			"timeout": 2e3,
			"optional": true,
			"w": 3343
		}, { "c": 3344 }],
		[],
		{}
	],
	[
		1,
		"schoolhouse-com",
		1,
		"^https://(www\\.)?schoolhouse\\.com/",
		22,
		[3345],
		[{ "e": 3345 }],
		[{ "v": 3345 }],
		[{ "h": 3345 }],
		[],
		{}
	],
	[
		1,
		"schumacher.com",
		2,
		"^https?://(www\\.)?schumacher\\.com/",
		22,
		[],
		[{ "e": 3346 }],
		[{ "v": 3346 }],
		[{
			"if": { "e": 3347 },
			"then": [{ "k": 3347 }],
			"else": [{ "c": 3348 }, { "c": 3349 }]
		}],
		[
			{ "cc": 3350 },
			{ "cc": 3351 },
			{ "cc": 3352 }
		],
		{}
	],
	[
		1,
		"scmp",
		2,
		"^https://(www\\.)?scmp\\.com/",
		22,
		[3353],
		[{ "any": [{ "e": 3354 }, { "e": 870 }] }],
		[{ "any": [{ "v": 3354 }, { "v": 2089 }] }],
		[
			{
				"timeout": 4e3,
				"optional": true,
				"wv": 2089
			},
			{
				"if": { "v": 2089 },
				"then": [
					{ "k": 872 },
					{
						"all": true,
						"optional": true,
						"k": 874
					},
					{
						"optional": true,
						"k": 875
					}
				]
			},
			{
				"timeout": 3e3,
				"optional": true,
				"wv": 3354
			},
			{ "h": 3353 }
		],
		[],
		{}
	],
	[
		1,
		"seg-social",
		2,
		"^https?://([a-z0-9-]+\\.)*seg-social\\.(gob\\.)?es/",
		22,
		[3355],
		[{ "e": 3356 }],
		[{ "v": 3356 }],
		[{ "c": 3356 }],
		[{ "cc": 3357 }],
		{}
	],
	[
		1,
		"seniorweb",
		2,
		"^https?://(www\\.)?seniorweb\\.nl/",
		22,
		[3358],
		[{ "e": 3358 }],
		[{ "v": 3358 }],
		[
			{ "c": 3359 },
			{ "wv": 3360 },
			{ "k": 3360 },
			{ "c": 3361 }
		],
		[{ "cc": 3362 }],
		{}
	],
	[
		1,
		"serpstat-com",
		1,
		"^https://(\\w+\\.)?serpstat\\.com/",
		22,
		[3363],
		[{ "e": 3364 }],
		[{ "v": 3364 }],
		[{ "h": 3363 }],
		[],
		{}
	],
	[
		1,
		"service2school",
		2,
		"^https?://(www\\.)?service2school\\.org/",
		22,
		[1612, 996],
		[{ "e": 1620 }, {
			"negated": true,
			"cc": 3365
		}],
		[{ "v": 1614 }],
		[{ "h": 1612 }, {
			"timeout": 5e3,
			"c": 997
		}],
		[{ "cc": 3366 }],
		{}
	],
	[
		1,
		"sex.com",
		2,
		"^https?://(\\w+\\.)?sex\\.com/",
		22,
		[3367],
		[{ "e": 3368 }],
		[{ "v": 3369 }],
		[
			{ "w": 3370 },
			{ "c": 3371 },
			{ "c": 3372 }
		],
		[{ "cc": 621 }],
		{}
	],
	[
		1,
		"sfanytime",
		2,
		"^https?://(www\\.)?sfanytime\\.com/",
		22,
		[2759],
		[{ "e": 2759 }],
		[{ "v": 2759 }],
		[
			{ "c": 3373 },
			{ "wv": 3374 },
			{
				"all": true,
				"optional": true,
				"k": 3375
			},
			{ "c": 3376 }
		],
		[{
			"check": "none",
			"v": 2759
		}],
		{}
	],
	[
		1,
		"shein.com",
		2,
		"^https?://([a-z]+\\.)?shein\\.com/",
		22,
		[3377],
		[{ "e": 3378 }],
		[{ "v": 3378 }],
		[{ "c": 3378 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 3378
		}],
		{}
	],
	[
		1,
		"shinden.pl",
		2,
		"^https?://(www\\.)?shinden\\.pl/",
		22,
		[456],
		[{ "e": 3379 }],
		[{
			"check": "any",
			"v": 3379
		}],
		[
			{ "h": 456 },
			{
				"timeout": 1e4,
				"optional": true,
				"wv": 1782
			},
			{
				"if": { "v": 1782 },
				"then": [
					{
						"retry": 2,
						"retryInterval": 500,
						"c": 1783
					},
					{ "c": 1784 },
					{
						"check": "none",
						"wv": 1782
					}
				]
			}
		],
		[],
		{}
	],
	[
		1,
		"shopquarters",
		1,
		"^https?://(www\\.)?shopquarters\\.com/",
		22,
		[1536],
		[{ "e": 3380 }],
		[{
			"check": "any",
			"v": 3381
		}],
		[{ "h": 3380 }, {
			"timeout": 2e3,
			"optional": true,
			"c": 1537
		}],
		[],
		{}
	],
	[
		1,
		"simplehuman-com",
		2,
		"^https?://(www\\.)?simplehuman\\.com/",
		10,
		[3382],
		[{ "e": 3383 }],
		[{ "v": 3384 }],
		[{ "c": 3383 }, { "c": 3385 }],
		[],
		{}
	],
	[
		1,
		"simyo-nl",
		2,
		"^https?://(www\\.)?simyo\\.nl/",
		10,
		[3386],
		[{ "v": 3386 }],
		[{ "v": 3386 }],
		[{ "c": 3387 }],
		[{ "cc": 3388 }],
		{}
	],
	[
		1,
		"skatteverket-se",
		2,
		"^https?://(www\\.)?skatteverket\\.se/",
		22,
		[3389],
		[{ "exists": ["skv-cookie-banner", ".skv-cookie-banner-root"] }],
		[{ "visible": ["skv-cookie-banner", ".skv-cookie-banner-root"] }],
		[{ "waitForThenClick": ["skv-cookie-banner", "#deny-all"] }],
		[{ "cc": 3390 }],
		{}
	],
	[
		1,
		"skyscanner",
		0,
		"^https://(www\\.)?skyscanner[\\.a-z]+/",
		10,
		[3300],
		[{ "e": 3391 }],
		[{ "v": 3391 }],
		[{ "c": 3392 }, {
			"check": "none",
			"wv": 3391
		}],
		[{ "eval": "EVAL_SKYSCANNER_TEST" }],
		{}
	],
	[
		1,
		"sl-se",
		2,
		"^https?://(www\\.)?sl\\.se/",
		22,
		[3393],
		[{ "e": 3394 }],
		[{ "v": 3394 }],
		[{ "c": 3394 }],
		[{ "cc": 3395 }],
		{}
	],
	[
		1,
		"smallpdf",
		2,
		"^https?://(www\\.)?smallpdf\\.com/",
		22,
		[],
		[{ "e": 3396 }],
		[{ "v": 3396 }],
		[
			{ "c": 3397 },
			{ "wv": 3398 },
			{
				"all": true,
				"optional": true,
				"k": 3399
			},
			{ "k": 3398 }
		],
		[{ "cc": 3400 }],
		{}
	],
	[
		1,
		"smile-insurances",
		2,
		"^https?://(www\\.)?smile-insurances\\.com/",
		22,
		[3401],
		[{ "e": 3401 }],
		[{ "v": 3402 }],
		[{ "c": 3402 }],
		[{ "cc": 3403 }],
		{}
	],
	[
		1,
		"snb.ch",
		2,
		"^https?://(www\\.)?snb\\.ch/",
		22,
		[3404, 3405],
		[{ "e": 3406 }],
		[{ "v": 3407 }],
		[
			{ "c": 3406 },
			{ "wv": 3408 },
			{
				"all": true,
				"optional": true,
				"k": 3409
			},
			{ "k": 3408 }
		],
		[{
			"check": "none",
			"v": 3404
		}],
		{}
	],
	[
		1,
		"solvhealth.com",
		2,
		"^https://(www\\.)?solvhealth\\.com/",
		22,
		[2741],
		[{ "e": 3410 }],
		[{ "v": 2741 }],
		[{ "c": 3411 }, {
			"check": "none",
			"wv": 2741
		}],
		[{
			"check": "none",
			"v": 2741
		}],
		{}
	],
	[
		1,
		"sostereo.com",
		2,
		"^https://(www\\.)?sostereo\\.com/",
		22,
		[3412],
		[{ "e": 3412 }],
		[{ "v": 3412 }],
		[
			{ "c": 3413 },
			{ "w": 3414 },
			{
				"all": true,
				"optional": true,
				"k": 3415
			},
			{ "c": 3416 }
		],
		[],
		{}
	],
	[
		1,
		"speciesplus.net",
		2,
		"^https?://(www\\.)?speciesplus\\.net/",
		22,
		[3417],
		[{ "e": 3418 }],
		[{ "v": 3417 }],
		[{ "c": 3419 }, {
			"check": "none",
			"wv": 3417
		}],
		[{ "cc": 3420 }],
		{}
	],
	[
		1,
		"spermidinelife-us",
		1,
		"^https://(www\\.)?spermidinelife\\.us/",
		22,
		[3421],
		[{ "e": 3422 }],
		[{ "v": 3423 }],
		[{ "h": 3421 }],
		[],
		{}
	],
	[
		3,
		"sportmedizin-rheuma",
		1,
		"^https?://(www\\.)?sportmedizin-rheuma\\.de/",
		22,
		[391],
		[{ "e": 392 }],
		[{ "v": 392 }],
		[{ "h": 3424 }, { "stylesheet": "body#home { overflow: visible !important; }" }],
		[],
		{}
	],
	[
		1,
		"sportsmans.com",
		2,
		"^https?://(www\\.)?sportsmans\\.com/",
		22,
		[3425],
		[{ "e": 3425 }, { "exists": [".dg-consent-banner", "button.dg-button.reject_all"] }],
		[{
			"check": "any",
			"v": 3425
		}],
		[{ "waitForThenClick": [".dg-consent-banner", "button.dg-button.reject_all"] }, { "h": 3425 }],
		[],
		{}
	],
	[
		1,
		"store2000.fr",
		2,
		"^https?://(www\\.)?store2000\\.fr/",
		22,
		[3426],
		[{ "e": 3426 }],
		[{ "v": 3426 }],
		[{ "c": 3427 }, { "h": 3426 }],
		[],
		{}
	],
	[
		1,
		"strato.de",
		2,
		"^https://www\\.strato\\.de/",
		22,
		[3428],
		[{ "e": 3429 }],
		[{ "v": 3429 }],
		[{ "k": 3430 }, { "c": 3431 }],
		[],
		{}
	],
	[
		1,
		"studentapan",
		2,
		"^https?://(www\\.)?studentapan\\.se/",
		22,
		[3432],
		[{ "e": 3432 }],
		[{ "v": 3432 }],
		[
			{ "c": 3433 },
			{ "wv": 3434 },
			{
				"all": true,
				"optional": true,
				"k": 3435
			},
			{ "c": 3436 }
		],
		[{ "cc": 3437 }],
		{}
	],
	[
		1,
		"sujetdebac.fr",
		2,
		"^https?://(www\\.)?sujetdebac\\.fr/",
		22,
		[3438],
		[{ "e": 3438 }],
		[{ "v": 3438 }],
		[{ "c": 3439 }],
		[{
			"check": "none",
			"v": 3438
		}],
		{}
	],
	[
		1,
		"svt.se",
		2,
		"^https://(\\w+\\.)?svt\\.se/",
		22,
		[3440],
		[{ "e": 3440 }],
		[{ "v": 3441 }],
		[{ "c": 3442 }],
		[{ "cc": 3443 }],
		{}
	],
	[
		1,
		"teacherspensions.co.uk",
		2,
		"^https?://(www\\.)?teacherspensions\\.co\\.uk/",
		10,
		[3444],
		[{ "e": 3445 }],
		[{ "v": 3444 }],
		[
			{ "c": 3445 },
			{ "wv": 3446 },
			{
				"all": true,
				"optional": true,
				"k": 3447
			},
			{ "k": 3446 }
		],
		[{ "cc": 3448 }],
		{}
	],
	[
		1,
		"telegram-im",
		2,
		"^https?://(www\\.)?(telegram\\.im|telegramcn\\.org\\.cn|telegramim\\.ru)/",
		22,
		[3449],
		[{ "e": 3450 }],
		[{ "v": 3449 }],
		[{ "c": 3449 }],
		[{
			"check": "none",
			"v": 3449
		}],
		{}
	],
	[
		1,
		"temu",
		2,
		"^https://([a-z0-9-]+\\.)?temu\\.com/",
		22,
		[],
		[{ "e": 3451 }],
		[{ "v": 3451 }],
		[{ "c": 3452 }],
		[{ "wait": 500 }, { "cc": 3453 }],
		{}
	],
	[
		1,
		"tesco",
		0,
		"^https://(www\\.)?tesco\\.com/",
		22,
		[3454],
		[{ "e": 3454 }],
		[{ "v": 3454 }],
		[{ "w": 1817 }, { "c": 3455 }],
		[{ "cc": 3456 }],
		{}
	],
	[
		1,
		"tesla",
		2,
		"^https://(www\\.)?tesla\\.com/",
		10,
		[],
		[{ "e": 206 }],
		[{ "v": 206 }],
		[{ "c": 3457 }],
		[{ "cc": 3458 }],
		{}
	],
	[
		1,
		"thecode",
		2,
		"^https?://(www\\.)?(thecode\\.co\\.uk|lovethesales\\.com)/",
		22,
		[3459],
		[{ "e": 3459 }],
		[{ "v": 3460 }],
		[
			{ "c": 3461 },
			{ "wv": 3462 },
			{
				"if": { "e": 3463 },
				"then": [{ "k": 3464 }]
			},
			{ "k": 3465 }
		],
		[{ "wait": 1e3 }, { "cc": 3466 }],
		{}
	],
	[
		1,
		"thegrandyork",
		2,
		"^https?://(www\\.)?thegrandyork\\.co\\.uk/",
		22,
		[3467],
		[{ "e": 3468 }],
		[{ "v": 3469 }],
		[
			{ "c": 3468 },
			{ "wv": 3470 },
			{
				"all": true,
				"optional": true,
				"k": 3471
			},
			{ "k": 3472 }
		],
		[{ "wait": 500 }, { "cc": 3473 }],
		{}
	],
	[
		1,
		"theinfatuation",
		2,
		"^https://(www\\.)?theinfatuation\\.com",
		10,
		[2678],
		[{ "e": 3474 }],
		[{ "v": 3474 }],
		[{ "c": 3474 }],
		[{
			"check": "none",
			"v": 2678
		}],
		{}
	],
	[
		1,
		"thenounproject",
		2,
		"^https?://(\\w+\\.)?thenounproject\\.com/",
		22,
		[3475],
		[{ "e": 3476 }],
		[{
			"check": "any",
			"v": 3476
		}],
		[
			{ "c": 3476 },
			{ "any": [{
				"timeout": 2e3,
				"check": "any",
				"wv": 3477
			}, { "k": 3476 }] },
			{
				"check": "any",
				"wv": 3477
			},
			{
				"all": true,
				"optional": true,
				"k": 3478
			},
			{ "c": 3479 }
		],
		[{ "cc": 621 }, { "cc": 3480 }],
		{}
	],
	[
		1,
		"thenude",
		0,
		"^https?://(www\\.)?thenude\\.com/",
		10,
		[3481],
		[{ "e": 3481 }],
		[{ "v": 3481 }],
		[
			{ "c": 3482 },
			{ "wv": 3483 },
			{
				"if": { "e": 3484 },
				"then": [{ "k": 3484 }, {
					"timeout": 1e3,
					"c": 3485
				}]
			},
			{
				"if": { "e": 3484 },
				"then": [{ "k": 3484 }, {
					"timeout": 1e3,
					"c": 3485
				}]
			},
			{
				"if": { "e": 3484 },
				"then": [{ "k": 3484 }, {
					"timeout": 1e3,
					"c": 3485
				}]
			},
			{
				"if": { "e": 3484 },
				"then": [{ "k": 3484 }, {
					"timeout": 1e3,
					"c": 3485
				}]
			},
			{ "k": 3486 },
			{
				"check": "none",
				"timeout": 3e3,
				"wv": 3481
			}
		],
		[{ "cc": 1821 }, { "cc": 3487 }],
		{}
	],
	[
		1,
		"therealest",
		2,
		"^https?://([a-z0-9-]+\\.)?therealest\\.com/",
		22,
		[3488],
		[{ "e": 3488 }],
		[{ "v": 3488 }],
		[
			{ "c": 3489 },
			{ "c": 3490 },
			{ "w": 3491 },
			{ "c": 3492 }
		],
		[{ "cc": 621 }],
		{}
	],
	[
		1,
		"thomsonlocal.com",
		2,
		"^https?://(www\\.)?thomsonlocal\\.com/",
		22,
		[2651],
		[{ "e": 3493 }],
		[{ "v": 3494 }],
		[{ "c": 3493 }],
		[{ "cc": 3495 }],
		{}
	],
	[
		1,
		"tinder",
		2,
		"^https?://(www\\.)?tinder\\.com/",
		22,
		[3496],
		[{ "e": 3496 }],
		[{ "v": 3496 }],
		[{ "c": 3497 }, { "c": 3498 }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 3496
		}],
		{}
	],
	[
		1,
		"tineye",
		1,
		"^https://(www\\.)?tineye\\.com/",
		22,
		[3499],
		[{ "e": 3499 }],
		[{ "v": 3499 }],
		[{ "h": 3499 }],
		[{
			"check": "none",
			"v": 3499
		}],
		{}
	],
	[
		1,
		"tinyurl",
		1,
		"^https://tinyurl\\.com/",
		22,
		[3500],
		[{ "e": 3500 }],
		[{ "v": 3500 }],
		[{ "h": 3500 }],
		[],
		{}
	],
	[
		1,
		"tk-aerztefuehrer.de",
		0,
		"^https?://(www\\.)?tk-aerztefuehrer\\.de/",
		10,
		[3501],
		[{ "e": 3501 }],
		[{ "v": 3501 }],
		[{ "c": 3502 }],
		[{ "cc": 3503 }],
		{}
	],
	[
		1,
		"tlc-direct",
		2,
		"^https?://(\\w+\\.)?tlc-direct\\.co\\.uk/",
		22,
		[407],
		[{ "e": 3504 }, { "e": 3505 }],
		[{ "v": 407 }],
		[
			{ "c": 3506 },
			{
				"if": { "e": 3507 },
				"then": [{ "k": 3508 }]
			},
			{
				"if": { "e": 3509 },
				"then": [{ "k": 3510 }]
			},
			{ "c": 3511 }
		],
		[{ "cc": 3512 }],
		{}
	],
	[
		1,
		"todostuslibros",
		2,
		"^https?://(www\\.)?todostuslibros\\.com/",
		22,
		[3513],
		[{ "e": 3514 }],
		[{ "v": 3513 }],
		[
			{ "c": 3515 },
			{ "wv": 3514 },
			{
				"if": { "e": 3516 },
				"then": [{ "k": 3517 }]
			},
			{
				"if": { "e": 3518 },
				"then": [{ "k": 3519 }]
			},
			{ "k": 3514 }
		],
		[{ "cc": 3520 }, {
			"negated": true,
			"cc": 3521
		}],
		{}
	],
	[
		1,
		"toho-one.com",
		2,
		"^https?://www\\.toho-one\\.com/",
		22,
		[],
		[{ "e": 3522 }],
		[{ "v": 3522 }],
		[
			{ "c": 3523 },
			{ "waitFor": ["xpath///div[contains(@class, 'fixed') and .//button[normalize-space()='設定を保存する']]", "input[type=checkbox]:checked:not(:disabled)"] },
			{
				"click": ["xpath///div[contains(@class, 'fixed') and .//button[normalize-space()='設定を保存する']]", "input[type=checkbox]:checked:not(:disabled)"],
				"all": true
			},
			{ "c": 3524 }
		],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 3522
		}],
		{}
	],
	[
		1,
		"tohotheater-jp",
		2,
		"^https?://(?:[^/]+\\.)?tohotheater\\.jp/",
		22,
		[3525],
		[{ "e": 3526 }],
		[{ "v": 3525 }],
		[
			{ "c": 3526 },
			{ "c": 3527 },
			{ "c": 3528 },
			{ "c": 3529 },
			{ "c": 3530 },
			{ "c": 3531 }
		],
		[{ "cc": 3532 }, { "cc": 3533 }],
		{}
	],
	[
		1,
		"track.amazon.com",
		2,
		"^https://[a-z]*\\.amazon\\.",
		22,
		[3534],
		[{ "e": 3535 }],
		[{ "v": 3535 }],
		[{ "k": 3536 }],
		[],
		{}
	],
	[
		1,
		"transip-nl",
		2,
		"^https://www\\.transip\\.nl/",
		22,
		[3537],
		[{ "any": [{ "e": 3537 }, { "e": 3538 }] }],
		[{ "any": [{ "v": 3537 }, { "v": 3538 }] }],
		[{
			"if": { "e": 3538 },
			"then": [{ "k": 3539 }],
			"else": [{ "k": 3540 }]
		}],
		[],
		{}
	],
	[
		1,
		"truecar",
		1,
		"^https://(www\\.)?truecar\\.com/",
		22,
		[3541],
		[{ "e": 3542 }],
		[{ "v": 3542 }],
		[{ "h": 3541 }],
		[],
		{}
	],
	[
		1,
		"turkishairlines.com",
		2,
		"^https?://(\\w+\\.)?turkishairlines\\.com/",
		22,
		[3543],
		[{ "e": 3544 }],
		[{ "v": 3545 }],
		[{ "c": 3545 }],
		[{ "cc": 3546 }],
		{}
	],
	[
		1,
		"tvp",
		0,
		"^https?://(\\w+\\.)?tvp\\.pl/",
		10,
		[3547],
		[{ "e": 3548 }],
		[{ "v": 3548 }],
		[
			{ "c": 3549 },
			{ "w": 3550 },
			{
				"if": { "e": 3551 },
				"then": [{ "k": 3552 }]
			},
			{ "k": 3550 },
			{
				"check": "none",
				"timeout": 2e3,
				"optional": true,
				"wv": 3548
			}
		],
		[{ "cc": 3553 }],
		{}
	],
	[
		1,
		"twitch.tv",
		2,
		"^https?://([\\w-]+\\.)?twitch\\.tv/",
		22,
		[3554],
		[{ "e": 3555 }],
		[{ "v": 3555 }],
		[{
			"if": { "e": 3556 },
			"then": [{
				"retry": 3,
				"retryInterval": 1e3,
				"c": 3557
			}, {
				"check": "none",
				"wv": 3555
			}],
			"else": [
				{ "c": 3558 },
				{ "w": 3559 },
				{
					"all": true,
					"optional": true,
					"k": 3560
				},
				{ "c": 3561 },
				{
					"check": "none",
					"wv": 3562
				}
			]
		}],
		[],
		{}
	],
	[
		1,
		"ubisoft.com",
		2,
		"^https?://(\\w+\\.)?ubisoft\\.com/",
		22,
		[2856, 3563],
		[{ "e": 3564 }],
		[{
			"check": "any",
			"v": 3565
		}],
		[{
			"if": { "e": 3566 },
			"then": [{ "c": 3566 }],
			"else": [{ "c": 3567 }, { "c": 3568 }]
		}],
		[{ "cc": 3569 }, { "cc": 3570 }],
		{}
	],
	[
		1,
		"unicourt",
		1,
		"^https://(www\\.)?unicourt\\.com/",
		22,
		[2657],
		[{ "e": 2657 }],
		[{ "v": 2657 }],
		[{ "h": 2657 }],
		[],
		{}
	],
	[
		1,
		"unive-nl",
		0,
		"^https?://(?:[^/]+\\.)?unive\\.nl/",
		10,
		[3571],
		[{ "e": 3572 }],
		[{ "v": 3571 }],
		[{ "c": 3573 }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 3571
		}],
		{}
	],
	[
		1,
		"unive.it",
		0,
		"^https?://(\\w+\\.)?unive\\.it/",
		22,
		[3574],
		[{ "e": 3575 }],
		[{ "any": [{ "v": 3575 }, {
			"negated": true,
			"cc": 3576
		}] }],
		[{
			"timeout": 15e3,
			"wv": 3575
		}, {
			"retry": 3,
			"retryInterval": 500,
			"c": 3575
		}],
		[
			{ "cc": 3576 },
			{
				"negated": true,
				"cc": 3577
			},
			{
				"negated": true,
				"cc": 3578
			}
		],
		{}
	],
	[
		1,
		"urvaerket",
		2,
		"^https?://(www\\.)?(urvaerket\\.dk|uret\\.se|urverket\\.no|laatukellot\\.fi|thewatchagency\\.com)/",
		22,
		[3579],
		[{ "e": 3580 }],
		[{ "v": 3580 }],
		[{ "c": 3581 }],
		[{ "cc": 3512 }],
		{}
	],
	[
		1,
		"usherbrooke",
		2,
		"^https?://(\\w+\\.)?usherbrooke\\.ca/",
		22,
		[3582],
		[{ "e": 3583 }],
		[{ "v": 218 }],
		[
			{ "c": 3584 },
			{ "wv": 3585 },
			{
				"if": { "e": 3509 },
				"then": [{ "k": 3510 }]
			},
			{
				"if": { "e": 3586 },
				"then": [{ "k": 3587 }]
			},
			{
				"retry": 3,
				"retryInterval": 600,
				"c": 3585
			},
			{
				"check": "none",
				"wv": 3588
			}
		],
		[],
		{}
	],
	[
		1,
		"uswitch.com",
		2,
		"^https://(www\\.)?uswitch\\.com/",
		10,
		[3589],
		[{ "e": 3590 }],
		[{ "v": 3590 }],
		[{ "c": 3591 }],
		[],
		{}
	],
	[
		1,
		"uwv-nl",
		0,
		"^https?://(?:www\\.)?uwv\\.nl/",
		10,
		[3592],
		[{ "e": 3592 }],
		[{ "v": 3593 }],
		[{ "c": 3593 }],
		[{
			"check": "none",
			"timeout": 2e3,
			"wv": 3593
		}],
		{}
	],
	[
		1,
		"vd-ch",
		0,
		"^https?://(\\w+\\.)?vd\\.ch/",
		22,
		[],
		[{ "e": 3594 }],
		[{ "v": 3594 }],
		[{ "c": 3594 }],
		[{ "cc": 3595 }],
		{}
	],
	[
		1,
		"venngage.com",
		2,
		"^https?://(\\w+\\.)?venngage\\.com/",
		22,
		[3596, 3597],
		[{ "e": 3598 }, { "v": 3599 }],
		[{ "v": 3599 }],
		[{ "c": 3598 }, { "c": 3600 }],
		[{ "cc": 3601 }],
		{}
	],
	[
		1,
		"vmock",
		2,
		"^https?://(\\w+\\.)?vmock\\.com/",
		22,
		[3602, 3603],
		[{ "e": 3604 }],
		[{ "v": 3604 }],
		[
			{ "c": 3604 },
			{ "c": 3605 },
			{
				"timeout": 2e3,
				"check": "none",
				"wv": 3603
			}
		],
		[{ "cc": 1883 }],
		{}
	],
	[
		1,
		"vodafone.de",
		2,
		"^https://www\\.vodafone\\.de/",
		22,
		[3606],
		[{ "e": 3607 }],
		[{ "v": 3608 }],
		[{ "k": 3609 }],
		[],
		{}
	],
	[
		1,
		"volvocars-com",
		2,
		"^https://([a-z0-9-]+\\.)?volvocars\\.com/",
		10,
		[3610],
		[{ "exists": ["cookie-banner#cookie-banner-host", "#dialog_cookie_consent"] }],
		[{ "visible": ["cookie-banner#cookie-banner-host", "#dialog_cookie_consent"] }],
		[
			{ "wait": 500 },
			{
				"if": { "exists": ["cookie-banner#cookie-banner-host", "#onetrust-reject-all-handler"] },
				"then": [{ "waitForThenClick": ["cookie-banner#cookie-banner-host", "#onetrust-reject-all-handler"] }],
				"else": [{ "waitForThenClick": ["cookie-banner#cookie-banner-host", "#onetrust-pc-btn-handler"] }, { "c": 1818 }]
			},
			{
				"waitForVisible": ["cookie-banner#cookie-banner-host", "#dialog_cookie_consent"],
				"check": "none",
				"timeout": 5e3
			}
		],
		[
			{ "cc": 1821 },
			{ "cc": 3611 },
			{ "cc": 3612 }
		],
		{}
	],
	[
		1,
		"vowels",
		1,
		"^https://(www\\.)?vowels\\.(net|jp)/",
		22,
		[3613],
		[{ "e": 3614 }],
		[{ "v": 3615 }],
		[{ "h": 3613 }],
		[],
		{}
	],
	[
		1,
		"walmart-ca",
		0,
		"^https?://(www\\.)?walmart\\.ca/",
		22,
		[],
		[{ "e": 3616 }],
		[{ "v": 3616 }],
		[{
			"retry": 5,
			"retryInterval": 500,
			"c": 3617
		}, { "c": 3618 }],
		[{
			"check": "none",
			"timeout": 5e3,
			"wv": 3616
		}],
		{}
	],
	[
		1,
		"warszawa19115.pl",
		2,
		"^https?://(\\w+\\.)?warszawa19115\\.pl/",
		22,
		[],
		[{ "e": 3619 }],
		[{ "v": 3619 }],
		[
			{ "c": 3620 },
			{ "wv": 3621 },
			{
				"if": { "e": 3622 },
				"then": [{
					"all": true,
					"k": 3622
				}]
			},
			{ "k": 3621 }
		],
		[{
			"check": "none",
			"timeout": 3e3,
			"wv": 3623
		}],
		{}
	],
	[
		1,
		"web-rewind.com",
		0,
		"^https?://(www\\.)?web-rewind\\.com/",
		22,
		[],
		[{ "e": 3624 }],
		[{ "v": 3624 }],
		[{
			"all": true,
			"timeout": 500,
			"optional": true,
			"c": 3625
		}, { "c": 3624 }],
		[],
		{}
	],
	[
		1,
		"what3words",
		2,
		"^https?://(\\w+\\.)?what3words\\.com/",
		22,
		[],
		[{ "e": 3626 }],
		[{
			"check": "any",
			"v": 3626
		}],
		[
			{
				"if": { "e": 3627 },
				"then": [{ "k": 3627 }, { "c": 3628 }],
				"else": [{ "k": 3629 }, { "c": 3630 }]
			},
			{
				"timeout": 4e3,
				"optional": true,
				"wv": 2089
			},
			{
				"if": { "v": 2089 },
				"then": [
					{ "k": 872 },
					{
						"all": true,
						"optional": true,
						"k": 874
					},
					{
						"optional": true,
						"k": 875
					}
				]
			}
		],
		[{ "any": [{ "cc": 3512 }, { "cc": 3631 }] }],
		{}
	],
	[
		1,
		"wikiwand",
		1,
		"^https://(www\\.)?wikiwand\\.com/",
		22,
		[3632],
		[{ "e": 3632 }],
		[{ "v": 3632 }],
		[{ "h": 3632 }],
		[],
		{}
	],
	[
		1,
		"wildling-com",
		1,
		"^https://(www\\.)?wildling\\.com/",
		22,
		[3633],
		[{ "e": 3634 }],
		[{ "v": 3634 }],
		[{ "h": 3633 }],
		[],
		{}
	],
	[
		1,
		"wojsko-polskie-pl",
		1,
		"^https?://(www\\.)?wojsko-polskie\\.pl/",
		22,
		[3635],
		[{ "e": 3636 }],
		[{ "v": 3635 }],
		[{ "h": 3635 }],
		[],
		{}
	],
	[
		1,
		"xe.com",
		2,
		"^https?://(www\\.)?xe\\.com/",
		22,
		[3637, 3638],
		[{ "e": 3639 }],
		[{ "v": 3639 }],
		[
			{
				"retry": 3,
				"retryInterval": 500,
				"c": 3640
			},
			{ "wv": 3641 },
			{ "c": 3642 }
		],
		[{ "cc": 3643 }],
		{}
	],
	[
		1,
		"xhamster-eu",
		2,
		"^https://(\\w+\\.)?xhamster\\d?\\.com",
		22,
		[3644],
		[{ "e": 3645 }],
		[{ "v": 3645 }],
		[
			{ "wv": 3646 },
			{ "wait": 500 },
			{ "k": 3646 },
			{
				"optional": true,
				"h": 3647
			}
		],
		[],
		{}
	],
	[
		1,
		"xhamster-us",
		1,
		"^https://(\\w+\\.)?xhamster\\d?\\.com",
		22,
		[3648],
		[{ "e": 3648 }],
		[{ "v": 3649 }],
		[{ "h": 3648 }],
		[],
		{}
	],
	[
		1,
		"xlbygg.se",
		2,
		"^https?://(\\w+\\.)?xlbygg\\.se/",
		22,
		[],
		[{ "e": 3650 }],
		[{ "v": 3651 }],
		[
			{ "c": 3652 },
			{ "wv": 3653 },
			{
				"all": true,
				"optional": true,
				"k": 3654
			},
			{ "k": 3650 }
		],
		[{ "cc": 3655 }],
		{}
	],
	[
		1,
		"xtb",
		2,
		"^https?://(www\\.)?xtb\\.com/",
		22,
		[3656, 3254],
		[{ "e": 3657 }],
		[{ "v": 3656 }],
		[
			{ "c": 3658 },
			{ "wv": 3659 },
			{
				"all": true,
				"optional": true,
				"k": 3660
			},
			{ "k": 3659 }
		],
		[{
			"check": "none",
			"wv": 3656
		}, { "cc": 3661 }],
		{}
	],
	[
		1,
		"xvideos",
		2,
		"^https://[a-z]*\\.xvideos\\.com/",
		22,
		[],
		[{ "e": 1989 }],
		[{ "v": 1990 }],
		[{ "c": 1991 }],
		[],
		{}
	],
	[
		1,
		"yachtclubgames.com",
		2,
		"^https?://(www\\.)?yachtclubgames\\.com/",
		22,
		[3662],
		[{ "e": 3662 }],
		[{ "v": 3662 }],
		[{ "c": 3663 }],
		[{
			"timeout": 1e3,
			"check": "none",
			"wv": 3662
		}],
		{}
	],
	[
		1,
		"Yahoo",
		2,
		"^https://consent\\.yahoo\\.com/v2/",
		22,
		[1733],
		[{ "e": 3664 }],
		[{ "v": 3664 }],
		[{ "c": 3665 }],
		[],
		{}
	],
	[
		1,
		"yuntrack",
		2,
		"^https://(www\\.|m\\.)?yuntrack\\.com/",
		22,
		[3666],
		[{ "e": 3667 }],
		[{ "v": 3666 }],
		[
			{ "c": 3667 },
			{ "wv": 3668 },
			{
				"if": { "e": 3669 },
				"then": [{
					"all": true,
					"k": 3669
				}]
			},
			{ "c": 3670 }
		],
		[{ "cc": 3671 }],
		{}
	],
	[
		1,
		"zentralruf-de",
		2,
		"^https://(www\\.)?zentralruf\\.de",
		22,
		[3672],
		[{ "e": 3672 }],
		[{ "v": 3672 }],
		[{ "c": 3673 }],
		[],
		{}
	],
	[
		1,
		"zinio",
		0,
		"^https://(www\\.)?zinio\\.com/",
		22,
		[],
		[{ "e": 3674 }],
		[{ "v": 3674 }],
		[{ "c": 3675 }, { "c": 3676 }],
		[{ "cc": 3677 }],
		{}
	],
	[
		1,
		"ziptozipmoving",
		2,
		"^https://(www\\.)?ziptozipmoving\\.com/",
		22,
		[],
		[{ "e": 3678 }],
		[{ "v": 3678 }],
		[
			{ "c": 3679 },
			{ "wv": 3680 },
			{
				"all": true,
				"optional": true,
				"k": 3681
			},
			{ "c": 3682 }
		],
		[{ "cc": 3683 }],
		{}
	]
];
var index = {
	"genericRuleRange": [0, 459],
	"frameRuleRange": [457, 491],
	"specificRuleRange": [459, 1271],
	"genericStringEnd": 2019,
	"frameStringEnd": 2083
};
var compact_rules_default = {
	v: 1,
	s,
	r,
	index
};
export { compact_rules_default as default, index, r, s };
