import scriptlets$1, { run } from "./ubo.js";
// node_modules/@ghostery/scriptlets/index.js
var scriptlets = {};
for (const [name, scriptlet] of Object.entries(scriptlets$1)) {
	scriptlets[name] = scriptlet;
	for (const alias of scriptlet.aliases) scriptlets[alias] = scriptlet;
}
export { scriptlets as default, run };
