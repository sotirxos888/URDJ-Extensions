import store_default from "../npm/hybrids/src/store.js";
import { isWebkit } from "../utils/browser-info.js";
import Options from "../store/options.js";
import ExtendedRequest from "../utils/request.js";
import { getMetadata, getUnidentifiedTracker } from "../utils/trackerdb.js";
import DailyStats from "../store/daily-stats.js";
import TabStats from "../store/tab-stats.js";
import { getMatchedRequestUrls } from "../utils/dnr.js";
import debounce from "../utils/debounce.js";
import { recordSerpVisit } from "./telemetry/index.js";
import { logRequests } from "./logger.js";
import { SERP_URL_REGEXP } from "./serp.js";
// src/background/stats.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
var REQUESTS_LIMIT = 100;
var OBSERVED_REQUESTS_LIMIT = 25;
async function updateRequests(tabId, requests) {
	const stats = await store_default.resolve(TabStats, tabId);
	if (!stats.hostname) return;
	const updatedAt = Date.now();
	requests = requests.filter((request) => request.timestamp >= stats.createdAt && (!request.sourceHostname || request.sourceHostname.endsWith(stats.hostname)));
	const matchedUrls = isWebkit() ? await getMatchedRequestUrls(tabId, Math.max(stats.createdAt, stats.updatedAt)) : [];
	for (const url of matchedUrls) {
		const request = ExtendedRequest.fromRequestDetails({
			url,
			originUrl: stats.url
		});
		request.blocked = true;
		requests.push(request);
	}
	logRequests(requests);
	const options = await store_default.resolve(Options);
	const trackers = Object.fromEntries(Object.entries(stats.trackers).map(([key, t]) => [key, {
		...t,
		requests: t.requests.map((r) => ({ ...r }))
	}]));
	const savedRequests = new Map(Object.values(trackers).flatMap((tracker) => tracker.requests.map((r) => [r.url, [r, tracker]])));
	let changed = matchedUrls.length > 0;
	for (const request of requests) {
		if (request.blocked && request.requestId) {
			for (const [chainRequest, chainTracker] of savedRequests.values()) if (chainRequest.requestId === request.requestId && !chainRequest.blocked) {
				chainRequest.blocked = true;
				chainTracker.blocked = true;
				changed = true;
			}
		}
		const [savedRequest, savedTracker] = savedRequests.get(request.url) || [];
		if (savedRequest) {
			if (request.blocked && !savedRequest.blocked || request.modified && !savedRequest.modified) {
				savedRequest.blocked ||= request.blocked;
				savedRequest.modified ||= request.modified;
				savedTracker.blocked ||= request.blocked;
				savedTracker.modified ||= request.modified;
				changed = true;
			}
			continue;
		}
		const metadata = getMetadata(request) || (request.blocked || request.modified || options.exceptions[request.hostname]) && getUnidentifiedTracker(request.hostname);
		if (!metadata) continue;
		const tracker = trackers[metadata.id] ??= {
			...metadata,
			key: metadata.id,
			requests: [],
			requestsCount: 0
		};
		tracker.requestsCount += 1;
		tracker.blocked ||= request.blocked;
		tracker.modified ||= request.modified;
		changed = true;
		if (request.blocked || request.modified || tracker.requests.filter((r) => !r.blocked && !r.modified).length < OBSERVED_REQUESTS_LIMIT) {
			const { requestId, url, blocked, modified } = request;
			tracker.requests.unshift({
				requestId,
				url,
				blocked,
				modified
			});
			savedRequests.set(url, [tracker.requests[0], tracker]);
			for (const r of tracker.requests.splice(REQUESTS_LIMIT)) savedRequests.delete(r.url);
		}
	}
	if (!changed) return;
	const currentStats = await store_default.resolve(TabStats, tabId);
	if (currentStats.createdAt === stats.createdAt) await store_default.set(currentStats, {
		trackers,
		updatedAt
	});
}
var pendingRequests = /* @__PURE__ */ new Map();
function flushRequests() {
	const batch = [...pendingRequests];
	pendingRequests.clear();
	for (const [tabId, requests] of batch) updateRequests(tabId, requests).catch((e) => console.error("[stats] Failed to update tab stats", e));
}
var scheduleFlush = debounce(flushRequests, {
	waitFor: 200,
	maxWait: 1e3
});
function updateTabStats(tabId, request) {
	request.timestamp ??= Date.now();
	const pending = pendingRequests.get(tabId);
	if (pending) pending.push(request);
	else pendingRequests.set(tabId, [request]);
	scheduleFlush();
}
async function flushTabStatsToDailyStats(stats) {
	if (!stats.hostname || stats.incognito) return;
	if (SERP_URL_REGEXP.test(stats.url)) recordSerpVisit();
	let dailyStats = await store_default.resolve(DailyStats, (/* @__PURE__ */ new Date()).toISOString().split("T")[0]);
	while (store_default.pending(dailyStats)) dailyStats = await store_default.resolve(dailyStats);
	await store_default.set(dailyStats, {
		trackersBlocked: dailyStats.trackersBlocked + stats.trackersBlocked,
		trackersModified: dailyStats.trackersModified + stats.trackersModified,
		pages: dailyStats.pages + 1,
		patterns: [.../* @__PURE__ */ new Set([...dailyStats.patterns, ...Object.keys(stats.trackers)])]
	});
}
var PANEL_URL = chrome.runtime.getURL("pages/panel/index.html");
chrome.webNavigation.onCommitted.addListener(async (details) => {
	if (details.url === PANEL_URL) return;
	if (details.documentLifecycle === "prerender") return;
	if (details.tabId > -1 && details.parentFrameId === -1) {
		const { tabId } = details;
		const request = ExtendedRequest.fromRequestDetails(details);
		const stats = store_default.get(TabStats, tabId);
		store_default.resolve(stats).then(flushTabStatsToDailyStats);
		if (request.isHttp || request.isHttps) {
			const currentStats = await store_default.set(stats, {
				hostname: request.hostname,
				domain: request.domain,
				url: request.url,
				trackers: null,
				createdAt: details.timeStamp
			});
			if ((await chrome.tabs.get(details.tabId).catch(() => null))?.incognito) await store_default.set(currentStats, { incognito: true });
		} else await store_default.set(stats, null);
	}
});
if (chrome.webRequest) {
	chrome.webRequest.onBeforeRequest.addListener((details) => {
		if (details.tabId < 0 || details.type === "main_frame") return;
		const request = ExtendedRequest.fromRequestDetails(details);
		updateTabStats(details.tabId, request);
	}, { urls: ["<all_urls>"] });
	chrome.webRequest.onBeforeRedirect.addListener((details) => {
		if (details.redirectUrl.startsWith("chrome-extension://")) {
			const request = ExtendedRequest.fromRequestDetails(details);
			request.blocked = true;
			updateTabStats(details.tabId, request);
		}
	}, { urls: ["<all_urls>"] });
	chrome.webRequest.onErrorOccurred.addListener((details) => {
		if (details.error === "net::ERR_BLOCKED_BY_CLIENT") {
			const request = ExtendedRequest.fromRequestDetails(details);
			request.blocked = true;
			updateTabStats(details.tabId, request);
		}
	}, { urls: ["<all_urls>"] });
}
chrome.tabs.onRemoved.addListener(async (tabId) => {
	const stats = await store_default.resolve(TabStats, tabId);
	await store_default.set(stats, null);
	await flushTabStatsToDailyStats(stats);
});
export { updateTabStats };
