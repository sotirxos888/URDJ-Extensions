import store_default from "../npm/hybrids/src/store.js";
import Options from "../store/options.js";
import { waitForIdle } from "../utils/options-observer.js";
import Config from "../store/config.js";
import { hasWTMStats } from "../utils/wtm-stats.js";
import { isUserScriptsSupported } from "../utils/user-scripts.js";
import { setup, updateEngines } from "./adblocker/engines.js";
import { captureAttribution } from "./telemetry/index.js";
import { openElementPicker } from "./element-picker.js";
// src/background/helpers.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
	switch (msg.action) {
		case "hasWTMStats":
			sendResponse(hasWTMStats(msg.domain));
			break;
		case "openTabWithUrl":
			chrome.tabs.create({ url: msg.url }).then(({ id }) => {
				sendResponse({ id });
			}, () => sendResponse({ id: null }));
			return true;
		case "openPrivateWindowWithUrl":
			chrome.windows.getAll().then((windows) => {
				const inIncognito = windows.find((w) => w.incognito);
				if (inIncognito) chrome.tabs.create({
					url: msg.url,
					windowId: inIncognito.id,
					active: true
				});
				else chrome.windows.create({
					url: msg.url,
					incognito: true
				});
			});
			break;
		case "openElementPicker":
			openElementPicker(msg.tabId).catch(console.error);
			break;
		case "updateEngines":
			updateEngines({ cache: false }).then(() => {
				sendResponse();
				console.debug("[helpers] \"updateEngines\" finished");
			});
			return true;
		case "idle":
			waitForIdle().then(() => {
				sendResponse();
				console.debug("[helpers] \"idleOptionsObservers\" finished");
			});
			return true;
		case "keepAlive":
			console.debug("[helpers] Received \"keepAlive\" message");
			break;
		case "devtools:navigator":
			sendResponse({
				userAgent: navigator.userAgent,
				platform: navigator.platform,
				maxTouchPoints: navigator.maxTouchPoints
			});
			break;
		case "e2e:idle":
			Promise.all([waitForIdle(), setup.pending]).then(() => {
				sendResponse("done");
				console.debug("[helpers] \"idleOptionsObservers\" finished");
			}, sendResponse);
			return true;
		case "e2e:setConfigDomains":
			store_default.resolve(Config).then(async (config) => {
				const domains = {};
				for (const domain of Object.keys(config.domains)) domains[domain] = null;
				Object.assign(domains, msg.domains);
				await store_default.set(Config, { domains });
				sendResponse("done");
				console.debug("[helpers] \"setConfigDomains\" finished");
			}, sendResponse);
			return true;
		case "e2e:clearExceptions":
			store_default.resolve(Options).then(async (options) => {
				const exceptions = {};
				for (const id of Object.keys(options.exceptions)) exceptions[id] = null;
				await store_default.set(Options, { exceptions });
				sendResponse("done");
				console.debug("[helpers] \"clearExceptions\" finished");
			}, sendResponse);
			return true;
		case "e2e:managedConfig":
			chrome.storage.local.set({ managedConfig: msg.config }).then(() => {
				sendResponse("done");
				console.debug("[helpers] \"managedConfig\" finished");
			}, sendResponse);
			return true;
		case "e2e:userScriptsActive":
			sendResponse(isUserScriptsSupported());
			break;
		case "e2e:userScriptsRegistrations":
			if (isUserScriptsSupported()) {
				chrome.userScripts.getScripts().then((scripts) => {
					sendResponse(scripts.map((script) => script.id));
				}, sendResponse);
				return true;
			}
			sendResponse([]);
			break;
		case "e2e:captureAttribution":
			captureAttribution().then(() => {
				sendResponse("done");
				console.debug("[helpers] \"captureAttribution\" finished");
			}, sendResponse);
			return true;
	}
	return false;
});
