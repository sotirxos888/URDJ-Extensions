import CosmeticFilter from "../../npm/@ghostery/adblocker/dist/esm/filters/cosmetic.js";
import "../../npm/@ghostery/adblocker/dist/esm/index.js";
// src/background/custom-filters/scriptlets.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
function encodeSelector(filter) {
	const parsed = filter.parseScript();
	if (!parsed || !parsed.name) return void 0;
	return [parsed.name, ...parsed.args.map((arg) => encodeURIComponent(arg))].join(", ");
}
function withSelector(filter, selector) {
	return new CosmeticFilter({
		mask: filter.mask,
		selector,
		domains: filter.domains,
		parentDomains: filter.parentDomains,
		style: filter.style,
		rawLine: filter.rawLine
	});
}
function encodeScriptletFilters(cosmeticFilters, preprocessors) {
	const result = [];
	for (const filter of cosmeticFilters) {
		const selector = filter.isScriptInject() && filter.selector ? encodeSelector(filter) : void 0;
		if (selector === void 0 || selector === filter.selector) {
			result.push(filter);
			continue;
		}
		const encoded = withSelector(filter, selector);
		for (const preprocessor of preprocessors) if (preprocessor.filterIDs.has(filter.getId())) preprocessor.filterIDs.add(encoded.getId());
		if (filter.isUnhide()) result.push(filter);
		result.push(encoded);
	}
	return result;
}
export { encodeScriptletFilters };
