//#region src/background/adblocker/content-scripts.js
var USER_SCRIPTS_NAMESPACE = "ghostery-scriptlet";
function userScriptId(hostname, world) {
	return `${USER_SCRIPTS_NAMESPACE}:${world}:${hostname}`;
}
var contentScripts = (() => {
	const registered = /* @__PURE__ */ new Set();
	return {
		async register(hostname, scriptletsByWorld) {
			registered.add(hostname);
			const jobs = [];
			for (const [world, code] of Object.entries(scriptletsByWorld)) {
				const id = userScriptId(hostname, world);
				if (!code) {
					jobs.push(chrome.userScripts.unregister({ ids: [id] }).catch(() => {}));
					continue;
				}
				const script = {
					id,
					js: [{ code }],
					allFrames: true,
					matches: [`https://${hostname}/*`, `http://${hostname}/*`],
					runAt: "document_start",
					world: world === "ISOLATED" ? "USER_SCRIPT" : world
				};
				jobs.push(chrome.userScripts.register([script]).catch(() => chrome.userScripts.update([script])).catch((e) => {
					console.warn(e);
					this.unregister(hostname);
				}));
			}
			await Promise.all(jobs);
		},
		isRegistered(hostname) {
			return registered.has(hostname);
		},
		unregister(hostname) {
			registered.delete(hostname);
			for (const world of ["MAIN", "ISOLATED"]) chrome.userScripts.unregister({ ids: [userScriptId(hostname, world)] }).catch(() => {});
		},
		unregisterAll() {
			registered.clear();
			chrome.userScripts.getScripts().then((scripts) => {
				const keep = new Set([...registered].flatMap((hostname) => [userScriptId(hostname, "MAIN"), userScriptId(hostname, "ISOLATED")]));
				const ids = scripts.filter((s) => s.id.startsWith(USER_SCRIPTS_NAMESPACE) && !keep.has(s.id)).map((s) => s.id);
				for (const id of ids) chrome.userScripts.unregister({ ids: [id] }).catch(() => {});
			}, console.warn);
		}
	};
})();
//#endregion
export { contentScripts };
