import store_default from "../../npm/hybrids/src/store.js";
import Options, { getPausedDetails } from "../../store/options.js";
import { addListener } from "../../utils/options-observer.js";
import DisabledFilters from "../../store/disabled-filters.js";
import { FLAG_SUBFRAME_SCRIPTING } from "../../npm/@ghostery/config/dist/esm/flags.js";
import { resolveFlag } from "../../store/config.js";
import { MAIN_ENGINE, get } from "../../utils/engines.js";
import { parseWithCache } from "../../utils/request.js";
import FilteringDebug from "../../store/filtering-debug.js";
import { isUserScriptsRegisterSupported } from "../../utils/user-scripts.js";
import scriptlets from "../../npm/@ghostery/scriptlets/index.js";
import { contentScripts } from "./content-scripts.js";
import { setup } from "./engines.js";
import { tabStats } from "../stats.js";
import { FramesHierarchy } from "./ancestors.js";
//#region src/background/adblocker/cosmetics.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
function resolveInjectionTarget(details) {
	const target = { tabId: details.tabId };
	if (details.documentId) target.documentIds = [details.documentId];
	else target.frameIds = [details.frameId];
	return target;
}
var scriptletGlobals = { warOrigin: chrome.runtime.getURL("/rule_resources/redirects/empty").slice(0, -6) };
var USER_SCRIPTS = isUserScriptsRegisterSupported();
var INJECTED_DOCUMENTS_KEY = "injectedScriptletDocuments";
var injectedDocuments = /* @__PURE__ */ new Set();
chrome.storage.session.get(INJECTED_DOCUMENTS_KEY).then((stored) => {
	for (const id of stored[INJECTED_DOCUMENTS_KEY] || []) injectedDocuments.add(id);
}).catch(() => {});
function rememberInjectedDocument(documentId) {
	injectedDocuments.add(documentId);
	if (injectedDocuments.size > 1e3) injectedDocuments.delete(injectedDocuments.values().next().value);
	chrome.storage.session.set({ [INJECTED_DOCUMENTS_KEY]: [...injectedDocuments] }).catch(() => {});
}
async function injectScriptlets(filters, hostname, details) {
	const useRegistry = USER_SCRIPTS && !details.localFrame;
	if (filters.length === 0 && !useRegistry) return;
	if (details.documentId) {
		if (injectedDocuments.has(details.documentId)) return;
		injectedDocuments.add(details.documentId);
	}
	const scriptletsByWorld = {
		MAIN: "",
		ISOLATED: ""
	};
	const injections = [];
	for (const filter of filters) {
		const parsed = filter.parseScript();
		if (!parsed) {
			console.warn("[adblocker] could not inject script filter:", filter.toString());
			continue;
		}
		const scriptletName = `${parsed.name}${parsed.name.endsWith(".js") ? "" : ".js"}`;
		const scriptlet = scriptlets[scriptletName];
		if (!scriptlet) {
			console.warn("[adblocker] unknown scriptlet with name:", scriptletName);
			continue;
		}
		const func = scriptlet.func;
		const args = [scriptletGlobals, ...parsed.args.map((arg) => decodeURIComponent(arg))];
		const declaredWorld = scriptlet.world === "ISOLATED" ? "ISOLATED" : "MAIN";
		if (useRegistry && !filter.hasSubframeConstraint()) {
			scriptletsByWorld[declaredWorld] += `(${func.toString()})(...${JSON.stringify(args)});\n`;
			continue;
		}
		injections.push(chrome.scripting.executeScript({
			injectImmediately: true,
			world: declaredWorld,
			target: resolveInjectionTarget(details),
			func,
			args
		}).catch((e) => {
			console.warn(e);
			return null;
		}));
	}
	if (useRegistry) if (scriptletsByWorld.MAIN || scriptletsByWorld.ISOLATED) {
		if (!contentScripts.isRegistered(hostname)) contentScripts.register(hostname, scriptletsByWorld);
	} else contentScripts.unregister(hostname);
	const injectedDocumentId = (await Promise.all(injections)).flat().find((result) => result?.documentId)?.documentId;
	if (injectedDocumentId) rememberInjectedDocument(injectedDocumentId);
	else if (details.documentId) injectedDocuments.delete(details.documentId);
}
function injectStyles(styles, details) {
	chrome.scripting.insertCSS({
		css: styles,
		origin: "USER",
		target: resolveInjectionTarget(details)
	}).catch(async (e) => {
		const frame = await chrome.webNavigation.getFrame({
			tabId: details.tabId,
			frameId: details.frameId
		}).catch(() => null);
		if (!frame) return;
		if (details.documentId && frame.documentId !== details.documentId) return;
		console.warn("[adblocker] failed to inject CSS", e);
	});
}
var SUBFRAME_SCRIPTING = resolveFlag(FLAG_SUBFRAME_SCRIPTING);
var framesHierarchy = new FramesHierarchy();
framesHierarchy.handleWebWorkerStart();
framesHierarchy.handleWebextensionEvents();
async function injectCosmetics(details, config) {
	const { bootstrap: isBootstrap = false, scriptletsOnly } = config;
	try {
		setup.pending && await setup.pending;
	} catch (e) {
		console.error("[adblocker] not ready for cosmetic injection", e);
		return;
	}
	const { tabId, frameId, parentFrameId, documentId, url } = details;
	const parsed = parseWithCache(url);
	const domain = parsed.domain || "";
	const hostname = parsed.hostname || "";
	if (USER_SCRIPTS && scriptletsOnly && contentScripts.isRegistered(hostname)) return;
	const options = store_default.get(Options);
	if (getPausedDetails(options, hostname)) return false;
	const tabHostname = tabStats.get(tabId)?.hostname;
	if (tabHostname && getPausedDetails(options, tabHostname)) return false;
	const engine = get(MAIN_ENGINE);
	const debug = store_default.get(FilteringDebug);
	const debugReady = store_default.ready(debug);
	const cssEnabled = !debugReady || debug.cosmeticsCSS;
	const scriptletsEnabled = !debugReady || debug.cosmeticsScriptlets;
	const extendedCSSEnabled = !debugReady || debug.cosmeticsExtendedCSS;
	let ancestors;
	if (SUBFRAME_SCRIPTING.enabled && !scriptletsOnly) {
		if (typeof parentFrameId === "number") {
			framesHierarchy.updateAncestry({
				tabId,
				frameId,
				parentFrameId,
				documentId
			}, {
				domain,
				hostname
			});
			ancestors = framesHierarchy.ancestorsOf(tabId, frameId);
		}
	}
	{
		const { matches } = engine.matchCosmeticFilters({
			domain,
			hostname,
			url,
			ancestors,
			classes: config.classes,
			hrefs: config.hrefs,
			ids: config.ids,
			getInjectionRules: isBootstrap,
			getExtendedRules: isBootstrap,
			getRulesFromHostname: isBootstrap,
			getPureHasRules: true,
			getRulesFromDOM: !isBootstrap,
			callerContext: { tabId }
		});
		const styleFilters = [];
		const scriptFilters = [];
		const disabledFilters = store_default.get(DisabledFilters);
		for (const { filter, exception } of matches) {
			if (exception !== void 0) continue;
			if (store_default.ready(disabledFilters) && disabledFilters.ids[filter.getId()]) continue;
			if (filter.isScriptInject()) scriptFilters.push(filter);
			else styleFilters.push(filter);
		}
		if (isBootstrap) injectScriptlets(scriptletsEnabled ? scriptFilters : [], hostname, details);
		if (scriptletsOnly) return;
		const { styles, extended } = engine.injectCosmeticFilters(styleFilters, {
			url,
			injectScriptlets: isBootstrap,
			injectExtended: isBootstrap,
			injectPureHasSafely: true,
			allowGenericHides: false,
			getBaseRules: false
		});
		if (styles && cssEnabled) injectStyles(styles, details);
		if (extended && extended.length > 0 && extendedCSSEnabled) chrome.tabs.sendMessage(tabId, {
			action: "evaluateExtendedSelectors",
			extended
		}, { frameId }).catch(() => {});
	}
	if (isBootstrap && cssEnabled) {
		const { styles } = engine.getCosmeticsFilters({
			domain,
			hostname,
			url,
			getBaseRules: true,
			getInjectionRules: false,
			getExtendedRules: false,
			getRulesFromDOM: false,
			getRulesFromHostname: false
		});
		injectStyles(styles, details);
	}
}
chrome.webNavigation.onCommitted.addListener((details) => injectCosmetics(details, { bootstrap: true }), { url: [{ urlPrefix: "http://" }, { urlPrefix: "https://" }] });
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
	if (msg.action === "injectCosmetics" && sender.tab) {
		const localFrame = !sender.url.startsWith("http");
		injectCosmetics({
			url: localFrame ? sender.origin : sender.url,
			tabId: sender.tab.id,
			frameId: sender.frameId,
			documentId: sender.documentId,
			localFrame
		}, msg).then(sendResponse);
		return true;
	}
});
if (USER_SCRIPTS) {
	addListener("paused", function contentScriptScriptlets(paused, lastPaused) {
		if (!lastPaused) return;
		if (paused["<all_urls>"]) contentScripts.unregisterAll();
		else for (const hostname of Object.keys(paused)) contentScripts.unregister(hostname);
	});
	chrome.webNavigation.onBeforeNavigate.addListener((details) => {
		injectCosmetics(details, {
			bootstrap: true,
			scriptletsOnly: true
		});
	}, { url: [{ urlPrefix: "http://" }, { urlPrefix: "https://" }] });
}
chrome.webRequest?.onResponseStarted.addListener((details) => {
	if (details.tabId === -1) return;
	if (details.type !== "main_frame" && details.type !== "sub_frame") return;
	if (!details.documentId) return;
	injectCosmetics(details, { bootstrap: true });
}, { urls: ["http://*/*", "https://*/*"] });
if (USER_SCRIPTS) {
	const refresh = () => contentScripts.unregisterAll();
	chrome.runtime.onStartup.addListener(refresh);
	chrome.runtime.onInstalled.addListener(refresh);
}
//#endregion
