import store_default from "../../npm/hybrids/src/store.js";
import Options, { isGloballyPaused } from "../../store/options.js";
import { addListener, isOptionEqual } from "../../utils/options-observer.js";
import { ACTION_DISABLE_GPC } from "../../npm/@ghostery/config/dist/esm/actions.js";
import Config from "../../store/config.js";
import "../../utils/request.js";
import { ALL_RESOURCE_TYPES, GPC_RULE_ID, GPC_RULE_PRIORITY, getDynamicRulesByIds } from "../../utils/dnr.js";
//#region src/background/never-consent/gpc.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
var GPC_CONTENT_SCRIPT_ID = "gpc";
function getDisabledDomains(config) {
	return Object.keys(config.domains).filter((domain) => config.hasAction(domain, ACTION_DISABLE_GPC));
}
function shouldEnableGPC(options) {
	return options.terms && options.blockAnnoyances && options.autoconsent.gpc && !isGloballyPaused(options);
}
async function updateGPCContentScript(options, lastOptions) {
	const enabledNow = shouldEnableGPC(options);
	if (lastOptions) {
		if (enabledNow === shouldEnableGPC(lastOptions)) return;
	}
	const registered = (await chrome.scripting.getRegisteredContentScripts({ ids: [GPC_CONTENT_SCRIPT_ID] })).length > 0;
	if (registered) await chrome.scripting.unregisterContentScripts({ ids: [GPC_CONTENT_SCRIPT_ID] });
	if (enabledNow) {
		const config = await store_default.resolve(Config);
		await chrome.scripting.registerContentScripts([{
			id: GPC_CONTENT_SCRIPT_ID,
			js: ["/content_scripts/main-world/gpc.js"],
			matches: ["http://*/*", "https://*/*"],
			excludeMatches: getDisabledDomains(config).flatMap((domain) => [`*://${domain}/*`, `*://*.${domain}/*`]),
			runAt: "document_start",
			matchOriginAsFallback: true,
			allFrames: true,
			world: "MAIN",
			persistAcrossSessions: true
		}]);
		console.log("[autoconsent] GPC content script has been registered");
	} else if (registered) console.log("[autoconsent] GPC content script has been unregistered");
}
addListener(updateGPCContentScript);
{
	async function updateGPCRule(options, lastOptions) {
		const enabledNow = shouldEnableGPC(options);
		if (lastOptions && enabledNow === shouldEnableGPC(lastOptions) && isOptionEqual(options.paused, lastOptions.paused)) return;
		if (!enabledNow) {
			if ((await getDynamicRulesByIds([6e6])).length) {
				await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: [GPC_RULE_ID] });
				console.log("[autoconsent] GPC rule has been removed");
			}
			return;
		}
		const config = await store_default.resolve(Config);
		const excludedDomains = [.../* @__PURE__ */ new Set([...Object.keys(options.paused), ...getDisabledDomains(config)])];
		const existingRules = await getDynamicRulesByIds([GPC_RULE_ID]);
		if (existingRules.length) {
			const existingDomains = existingRules[0].condition.excludedInitiatorDomains || [];
			if (existingDomains.length === excludedDomains.length && existingDomains.every((d) => excludedDomains.includes(d))) return;
		}
		await chrome.declarativeNetRequest.updateDynamicRules({
			removeRuleIds: [GPC_RULE_ID],
			addRules: [{
				id: GPC_RULE_ID,
				priority: GPC_RULE_PRIORITY,
				action: {
					type: "modifyHeaders",
					requestHeaders: [{
						header: "Sec-GPC",
						operation: "set",
						value: "1"
					}]
				},
				condition: {
					...excludedDomains.length ? {
						excludedInitiatorDomains: excludedDomains,
						excludedRequestDomains: excludedDomains
					} : {},
					resourceTypes: ALL_RESOURCE_TYPES
				}
			}]
		});
		console.log("[autoconsent] GPC rule has been updated");
	}
	addListener(updateGPCRule);
	store_default.observe(Config, async (_, config, lastConfig) => {
		if (lastConfig) updateGPCRule(await store_default.resolve(Options));
	});
}
//#endregion
