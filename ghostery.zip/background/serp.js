import store_default from "../npm/hybrids/src/store.js";
import Options, { isGloballyPaused } from "../store/options.js";
import { addListener } from "../utils/options-observer.js";
import { parseWithCache } from "../utils/request.js";
import { getWTMStats } from "../utils/wtm-stats.js";
import trackers_preview_default from "../content_scripts/trackers-preview.css_raw.js";
// src/background/serp.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
	if (msg.action === "getWTMReport") sendResponse({ wtmStats: msg.links.map((url) => {
		const { domain } = parseWithCache(url);
		return {
			stats: getWTMStats(domain),
			domain
		};
	}) });
	if (msg.action === "disableWTMReport") store_default.set(Options, { wtmSerpReport: false });
	return false;
});
var SERP_URL_REGEXP = /^https?:[/][/][^/]*[.](google|bing)[.][a-z]+([.][a-z]+)?([/][a-z]+)*[/]search/;
chrome.webNavigation.onCommitted.addListener(async (details) => {
	if (details.url.match(SERP_URL_REGEXP)) {
		if ((await store_default.resolve(Options)).wtmSerpReport) {
			const target = details.documentId ? {
				tabId: details.tabId,
				documentIds: [details.documentId]
			} : {
				tabId: details.tabId,
				frameIds: [details.frameId]
			};
			chrome.scripting.insertCSS({
				target,
				css: trackers_preview_default
			});
			chrome.scripting.executeScript({
				injectImmediately: true,
				world: chrome.scripting.ExecutionWorld?.ISOLATED ?? "ISOLATED",
				target,
				files: ["/content_scripts/trackers-preview.js"]
			}, () => {
				if (chrome.runtime.lastError) console.error(chrome.runtime.lastError);
			});
		}
	}
});
var SERP_TRACKING_CONTENT_SCRIPT_ID = "serp-tracking-prevention";
addListener(async function serpTrackingPrevention(options, lastOptions) {
	const enabled = options.serpTrackingPrevention && !isGloballyPaused(options);
	if (lastOptions) {
		if (enabled === (lastOptions.serpTrackingPrevention && !isGloballyPaused(lastOptions))) return;
	}
	if (enabled === !!(await chrome.scripting.getRegisteredContentScripts({ ids: [SERP_TRACKING_CONTENT_SCRIPT_ID] })).length) return;
	if (enabled) await chrome.scripting.registerContentScripts([{
		id: SERP_TRACKING_CONTENT_SCRIPT_ID,
		js: ["/content_scripts/prevent-serp-tracking.js"],
		matches: ["*://*/search*", "*://*/*/search*"],
		allFrames: true,
		runAt: "document_start",
		persistAcrossSessions: true
	}]);
	else await chrome.scripting.unregisterContentScripts({ ids: [SERP_TRACKING_CONTENT_SCRIPT_ID] });
});
var SERP_TARGETS_STORAGE_KEY = "serpTargetsMap";
var SERP_TARGETS_LIMIT = 5e3;
var serpTargetsPending = Promise.resolve();
function isHttpUrl(value) {
	return typeof value === "string" && /^https?:\/\//.test(value);
}
async function loadSerpTargets() {
	const { [SERP_TARGETS_STORAGE_KEY]: entries = [] } = await chrome.storage.session.get(SERP_TARGETS_STORAGE_KEY);
	return new Map(entries);
}
function recordSerpTargets(entries) {
	serpTargetsPending = serpTargetsPending.then(async () => {
		const map = await loadSerpTargets();
		for (const [id, url] of Object.entries(entries)) {
			if (map.get(id) === null) continue;
			if (url !== null && !isHttpUrl(url)) continue;
			map.delete(id);
			map.set(id, url);
		}
		while (map.size > SERP_TARGETS_LIMIT) map.delete(map.keys().next().value);
		await chrome.storage.session.set({ [SERP_TARGETS_STORAGE_KEY]: [...map] });
	}).catch((e) => console.error("[serp] Failed to record targets", e));
}
async function resolveSerpTargets(ids) {
	const map = await loadSerpTargets();
	const resolved = {};
	for (const id of ids) {
		const url = map.get(id);
		if (url) resolved[id] = url;
	}
	return resolved;
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
	if (msg.action === "serp:record-targets") {
		if (msg.entries && typeof msg.entries === "object") recordSerpTargets(msg.entries);
		return false;
	}
	if (msg.action === "serp:resolve-targets") {
		resolveSerpTargets(Array.isArray(msg.ids) ? msg.ids : []).then(sendResponse, () => sendResponse({}));
		return true;
	}
	return false;
});
export { SERP_URL_REGEXP };
