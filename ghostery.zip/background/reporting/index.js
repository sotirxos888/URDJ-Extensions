import { isWebkit } from "../../utils/browser-info.js";
import "../../store/managed-config.js";
import { addListener } from "../../utils/options-observer.js";
import { compareVersions } from "../../utils/config.js";
import { describeLoggers, setLogLevel } from "../../npm/@whotracksme/reporting/reporting/src/logger.js";
import "../../npm/@whotracksme/reporting/reporting/src/index.js";
import config_default from "./config.js";
import communication_default from "./communication.js";
import url_reporter_default from "./url-reporter.js";
import webrequest_reporter_default from "./webrequest-reporter.js";
// src/background/reporting/index.js
(async () => {
	try {
		const key = "ghosteryReportingLoggerConfig";
		const { [key]: config } = await chrome.storage.local.get(key) || {};
		if (config) for (const { level, prefix = "*" } of config) setLogLevel(level, { prefix });
		else setLogLevel("off");
	} catch (e) {
		console.warn("Failed to apply logger overwrites", e);
	}
})();
if (isWebkit()) chrome.runtime.onInstalled.addListener(({ reason, previousVersion }) => {
	if (reason === "update" && compareVersions(previousVersion, "10.6.7") < 0) chrome.storage.local.remove("wtm::v1::reporting::scheduled_jobs").catch((e) => {
		console.warn("Failed to remove reporting scheduled jobs", e);
	});
});
addListener("terms", async function reporting(terms) {
	if (terms && true) {
		if (webrequest_reporter_default) webrequest_reporter_default.init().catch((e) => {
			console.warn("Failed to initialize request reporting. Leaving the module disabled and continue.", e);
		});
		url_reporter_default.init().catch((e) => {
			console.warn("Failed to initialize urlReporting. Leaving the module disabled and continue.", e);
		});
	} else {
		try {
			url_reporter_default.unload();
		} catch (e) {
			console.error(e);
		}
		try {
			webrequest_reporter_default?.unload();
		} catch (e) {
			console.error(e);
		}
	}
});
(globalThis.ghostery ??= {}).WTM = {
	communication: communication_default,
	urlReporter: url_reporter_default,
	config: config_default,
	webRequestReporter: webrequest_reporter_default,
	extensionStartedAt: /* @__PURE__ */ new Date(),
	logging: {
		setLogLevel,
		describeLoggers
	}
};
