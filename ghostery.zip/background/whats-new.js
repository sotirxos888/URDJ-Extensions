import store_default from "../npm/hybrids/src/store.js";
import ManagedConfig from "../store/managed-config.js";
import Options from "../store/options.js";
import "../npm/@ghostery/config/dist/esm/flags.js";
import Config from "../store/config.js";
//#region src/background/whats-new.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
var chromeAction = chrome.action || chrome.browserAction;
var PANEL_URL = chrome.runtime.getURL("/pages/panel/index.html");
function getMinorVersion() {
	return chrome.runtime.getManifest().version.split(".", 2).join(".");
}
async function openPanel() {
	if (!(await store_default.resolve(Config)).hasFlag("whats-new")) return;
	const options = await store_default.resolve(Options);
	const version = getMinorVersion();
	if (!options.terms || options.whatsNew.version === version) return;
	const { notifications } = options.panel;
	await store_default.set(options, { whatsNew: {
		version,
		shown: !notifications
	} });
	if ((await store_default.resolve(ManagedConfig)).disableUserControl || !notifications) return;
	if (!chromeAction.openPopup) {
		console.warn("[whats-new] The panel cannot be opened automatically in this browser");
		return;
	}
	try {
		await chromeAction.setPopup({ popup: `${PANEL_URL}?whatsNew` });
		await chromeAction.openPopup();
		console.log("[whats-new] Opening the panel with the recap view...");
	} catch (e) {
		console.error("[whats-new] Failed to open the panel:", e);
	} finally {
		await chromeAction.setPopup({ popup: PANEL_URL });
	}
}
chrome.runtime.onStartup.addListener(async () => {
	const options = await store_default.resolve(Options);
	const version = getMinorVersion();
	if (!options.whatsNew.version) {
		await store_default.set(options, { whatsNew: { version } });
		return;
	}
	await openPanel();
});
//#endregion
