import { checkSessionStorage } from "../utils/storage.js";
import { captureError } from "../utils/errors.js";
//#region src/background/storage.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
checkSessionStorage().catch((e) => {
	captureError(e, {
		critical: true,
		once: true
	});
});
//#endregion
