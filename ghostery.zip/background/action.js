import store_default from "../npm/hybrids/src/store.js";
import { isOpera, isWebkit } from "../utils/browser-info.js";
import Options, { getPausedDetails } from "../store/options.js";
import { addListener } from "../utils/options-observer.js";
import TabStats from "../store/tab-stats.js";
import { isSerpSupported } from "../utils/opera.js";
import { getOffscreenImageData } from "../ui/wheel.js";
// src/background/action.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
var chromeAction = chrome.action || chrome.browserAction;
var { icons } = chrome.runtime.getManifest();
Object.keys(icons).forEach((key) => {
	icons[key] = `/${icons[key]}`;
});
var inactiveIcons = Object.keys(icons).reduce((acc, key) => {
	acc[key] = icons[key].replace(".", "-inactive.");
	return acc;
}, {});
function setBadgeColor(color = "#3f4146") {
	chromeAction.setBadgeBackgroundColor({ color });
}
addListener("terms", async function icon(terms) {
	if (!terms) {
		await chromeAction.setBadgeText({ text: "!" });
		setBadgeColor("#f13436");
	} else {
		await chromeAction.setBadgeText({ text: "" });
		setBadgeColor();
	}
});
async function hasAccessToPage(tabId) {
	try {
		await chrome.scripting.insertCSS({
			target: { tabId },
			css: ""
		});
		return true;
	} catch {
		return false;
	}
}
async function refreshIcon(tabId) {
	const options = await store_default.resolve(Options);
	if (isOpera() && options.terms) isSerpSupported().then(async (supported) => {
		if (!supported) setBadgeColor(await hasAccessToPage(tabId) ? void 0 : "#f13436");
	});
	const stats = await store_default.resolve(TabStats, tabId);
	if (!stats.hostname) return;
	const paused = !!getPausedDetails(options, stats.hostname);
	const inactive = options.mode !== "zap" && (!options.terms || paused);
	const data = {};
	if (options.trackerWheel && stats.categories.length > 0) data.imageData = getOffscreenImageData(128, stats.categories, { grayscale: inactive });
	else data.path = inactive ? inactiveIcons : icons;
	chromeAction.setIcon({
		tabId,
		...data
	}, () => {
		if (chrome.runtime.lastError) console.error("setIcon failed for tabId", tabId, "(most likely the tab was closed)", chrome.runtime.lastError);
	});
	if (!isWebkit()) try {
		await chromeAction.setBadgeText({
			tabId,
			text: options.trackerCount && (options.mode !== "zap" || !paused) ? String(Object.keys(stats.trackers).length) : ""
		});
	} catch (e) {
		console.error("Error while trying update the badge", e);
	}
}
var delayMap = /* @__PURE__ */ new Map();
function updateIcon(tabId, force) {
	if (delayMap.has(tabId)) {
		if (!force) return;
		clearTimeout(delayMap.get(tabId));
	}
	delayMap.set(tabId, setTimeout(() => {
		delayMap.delete(tabId);
		refreshIcon(tabId);
	}, 250));
	refreshIcon(tabId);
}
store_default.observe(TabStats, (id, stats, lastStats) => {
	if (!stats?.hostname) return;
	const tabId = Number(id);
	if (stats.createdAt !== lastStats?.createdAt) updateIcon(tabId, true);
	else if (stats.categories.length !== lastStats.categories.length) updateIcon(tabId);
});
